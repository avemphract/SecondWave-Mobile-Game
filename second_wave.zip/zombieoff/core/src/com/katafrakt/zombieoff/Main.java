package com.katafrakt.zombieoff;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.katafrakt.zombieoff.managers.ScreenManager;
import com.katafrakt.zombieoff.screens.LoadingScreen;
import com.katafrakt.zombieoff.utilities.RangeGenerator;

import sun.security.jgss.GSSCaller;

public class Main extends Game {
	private static final String TAG=Main.class.getSimpleName();
	//public static final int WIDTH=16*90;
	//public static final int HEIGHT=9*90;

	public static int WIDTH;//= Gdx.graphics.getWidth();
	public static int HEIGHT;//=Gdx.graphics.getHeight();

	public BitmapFont bitmapFont;
	SpriteBatch batch;
	ScreenManager screenManager;

	@Override
	public void create () {

		WIDTH=Gdx.graphics.getWidth();
		HEIGHT=Gdx.graphics.getHeight();

		Gdx.app.log("MAIN","Opened");
		batch = new SpriteBatch();


		bitmapFont=new BitmapFont();
		Gdx.app.log(TAG,"SpriteBach and bitmapfont");
		RangeGenerator.getInstance();
		bitmapFont.setColor(Color.BLACK);
		bitmapFont.setUseIntegerPositions(true);
		Gdx.app.log("MAIN","Range generated");
		screenManager=ScreenManager.getInstance();
		screenManager.init(this);
		Gdx.app.log("MAIN","Po:1");
		screenManager.addScreen(new LoadingScreen(this,batch));
		Gdx.app.log("Main","loading scrren post");
		screenManager.setScreens();
	}

	@Override
	public void render () {
		Gdx.gl20.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);
		//batch.begin();
		super.render();
		//batch.end();
	}
	
	@Override
	public void dispose () {
		batch.dispose();
		screenManager.peekScreen().dispose();
		Gdx.app.log(TAG,"MAIN class disposed");
	}

}
