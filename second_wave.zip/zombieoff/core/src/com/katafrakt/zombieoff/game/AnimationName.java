package com.katafrakt.zombieoff.game;

import com.badlogic.gdx.Gdx;

public enum AnimationName {
    WALK_RIGHT(Direction.RIGHT,true),WALK_LEFT(Direction.LEFT,true),WALK_UP(Direction.UP,false),WALK_DOWN(Direction.DOWN,true),
    WAIT_RIGHT(Direction.RIGHT,true),WAIT_LEFT(Direction.LEFT,true),WAIT_UP(Direction.UP,false),WAIT_DOWN(Direction.DOWN,true),
    ATTACK_RIGHT(Direction.RIGHT,true),ATTACK_LEFT(Direction.LEFT,true),ATTACK_UP(Direction.UP,false),ATTACK_DOWN(Direction.DOWN,true),
    WALK_RIGHT_LOOK_UP(Direction.RIGHT,false),WALK_RIGHT_LOOK_DOWN(Direction.LEFT,true),
    WALK_LEFT_LOOK_UP(Direction.LEFT,false),WALK_LEFT_LOOK_DOWN(Direction.LEFT,true),
    WALK_UP_LOOK_RIGHT(Direction.UP,false),WALK_UP_LOOK_LEFT(Direction.UP,false),
    WALK_DOWN_LOOK_RIGHT(Direction.DOWN,true),WALK_DOWN_LOOK_LEFT(Direction.UP,true);

    public enum Direction{
        RIGHT,LEFT,UP,DOWN
    }

    public final Direction direction;
    public final boolean isGunFront;
    AnimationName(Direction direction,boolean isGunFront){
        this.direction=direction;
        this.isGunFront=isGunFront;
    }

    public static AnimationName getWaitName(Direction direction){
        switch (direction){
            case UP:
                return WAIT_UP;
            case RIGHT:
                return WAIT_RIGHT;
            case LEFT:
                return WAIT_LEFT;
            case DOWN:
                return WAIT_DOWN;
        }
        Gdx.app.log("AnimationNameError","");
        return WALK_DOWN;
    }
    public static AnimationName getWalkName(Direction direction){
        switch (direction){
            case UP:
                return WALK_UP;
            case RIGHT:
                return WALK_RIGHT;
            case LEFT:
                return WALK_LEFT;
            case DOWN:
                return WALK_DOWN;
        }
        Gdx.app.log("AnimationNameError","");
        return WALK_DOWN;
    }
    public static AnimationName getAttackName(Direction direction){
        switch (direction){
            case UP:
                return ATTACK_UP;
            case RIGHT:
                return ATTACK_RIGHT;
            case LEFT:
                return ATTACK_LEFT;
            case DOWN:
                return ATTACK_DOWN;
        }
        Gdx.app.log("AnimationNameError","");
        return ATTACK_DOWN;
    }



    public static Direction getDirection(float x, float y){
        if (Math.abs(x)>Math.abs(y)){
            if (x>0)
                return Direction.RIGHT;
            else
                return Direction.LEFT;
        }
        else {
            if (y>0)
                return Direction.UP;
            else
                return Direction.DOWN;
        }
    }
}
