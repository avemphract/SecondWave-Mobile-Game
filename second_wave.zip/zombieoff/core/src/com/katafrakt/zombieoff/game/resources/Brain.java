package com.katafrakt.zombieoff.game.resources;

import com.badlogic.gdx.graphics.Color;
import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.managers.PreferenceManager;

public class Brain extends ResourceAbstract {
    final String NAME = "Brain";

    public float addProductionRate=10;
    public float multiplierProductionRatePrestige;

    public Brain() {
        super(Color.LIME,50, true);
        isAvailable=true;
        loadValues();
        setCapacity();
    }

    @Override
    public String name() {
        return NAME;
    }

    @Override
    public float getProduction() {
        return addProductionRate*(multiplierProductionRatePrestige+1)+1;
    }

    @Override
    public void saveValues() {
        PreferenceManager.getInstance().prefs.putFloat(ADD_CAPACITY,addCapacity);
        PreferenceManager.getInstance().prefs.putFloat(MULTIPLIER_CAPACITY_UPGRADE,multiplierCapacityUpgrade);
        PreferenceManager.getInstance().prefs.putFloat(MULTIPLIER_CAPACITY_PRESTIGE,multiplierCapacityPrestige);
        PreferenceManager.getInstance().prefs.putFloat(MULTIPLIER_CAPACITY_TROPHY,multiplierCapacityTrophy);

        PreferenceManager.getInstance().prefs.putFloat(EFFICIENT_TROPHY,efficientTrophy);
        PreferenceManager.getInstance().prefs.putFloat(EFFICIENT_PRESTIGE,efficientPrestige);

        PreferenceManager.getInstance().prefs.putFloat(CURRENT,current);

        PreferenceManager.getInstance().prefs.putFloat(ADD_PRODUCTION_RATE,addProductionRate);
        PreferenceManager.getInstance().prefs.putFloat(MULTIPLIER_PRODUCTION_RATE_PRESTIGE,multiplierProductionRatePrestige);
    }

    @Override
    public void loadValues() {
        addCapacity=PreferenceManager.getInstance().prefs.getFloat(ADD_CAPACITY);
        multiplierCapacityUpgrade = PreferenceManager.getInstance().prefs.getFloat(MULTIPLIER_CAPACITY_UPGRADE);
        multiplierCapacityPrestige = PreferenceManager.getInstance().prefs.getFloat(MULTIPLIER_CAPACITY_PRESTIGE);
        multiplierCapacityTrophy = PreferenceManager.getInstance().prefs.getFloat(MULTIPLIER_CAPACITY_TROPHY);

        efficientTrophy = PreferenceManager.getInstance().prefs.getFloat(EFFICIENT_TROPHY);
        efficientPrestige = PreferenceManager.getInstance().prefs.getFloat(EFFICIENT_PRESTIGE);

        current=PreferenceManager.getInstance().prefs.getFloat(CURRENT);

        multiplierProductionRatePrestige=PreferenceManager.getInstance().prefs.getFloat(MULTIPLIER_PRODUCTION_RATE_PRESTIGE);
    }

    private static final String ADD_CAPACITY="BRAIN_ADD_CAPACITY";
    private static final String MULTIPLIER_CAPACITY_UPGRADE="BRAIN_MULTIPLIER_CAPACITY_UPGRADE";
    private static final String MULTIPLIER_CAPACITY_PRESTIGE="BRAIN_MULTIPLIER_CAPACITY_PRESTIGE";
    private static final String MULTIPLIER_CAPACITY_TROPHY="BRAIN_MULTIPLIER_CAPACITY_TROPHY";

    private static final String EFFICIENT_TROPHY="BRAIN_EFFICIENT_TROPHY";
    private static final String EFFICIENT_PRESTIGE="BRAIN_EFFICIENT_PRESTIGE";

    private static final String CURRENT="BRAIN_CURRENT";

    private static final String ADD_PRODUCTION_RATE="BRAIN_ADD_PRODUCTION_RATE";
    private static final String MULTIPLIER_PRODUCTION_RATE_PRESTIGE="BRAIN_MULTIPLIER_PRODUCTION_RATE_PRESTIGE";
}
