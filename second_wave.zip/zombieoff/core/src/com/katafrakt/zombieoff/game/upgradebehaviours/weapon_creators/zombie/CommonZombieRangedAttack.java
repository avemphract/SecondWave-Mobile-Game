package com.katafrakt.zombieoff.game.upgradebehaviours.weapon_creators.zombie;

import com.katafrakt.zombieoff.entities.BulletType;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponInformation;
import com.katafrakt.zombieoff.game.weapons.StandardRangedWeapon;
import com.katafrakt.zombieoff.game.weapons.Weapon;
import com.katafrakt.zombieoff.game.weapons.hitbehaviour.SingleTargetHitBehaviour;

public class CommonZombieRangedAttack extends WeaponInformation {
    public CommonZombieRangedAttack(){
        index=-1;
        energy=0;

        name="Common Ranged Attack";
        type=Type.Ranged;

        damage="0.5";
        attRate="0.4";
        range="9";

    }
    @Override
    public Weapon getWeapon() {
        return new StandardRangedWeapon(Weapon.Recommended.LOW, SingleTargetHitBehaviour.pool.obtain(), BulletType.LINE,0.4f,0.5f,6,30,50);
    }
}
