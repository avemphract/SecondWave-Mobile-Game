package com.katafrakt.zombieoff.game.weapons.hitbehaviour;

import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.creatures.BulletComponent;

public interface HitBehaviour {
    public void hit(BulletComponent bulletComponent);
    HitBehaviour clone();
    Pool getPool();
}
