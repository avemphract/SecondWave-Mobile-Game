package com.katafrakt.zombieoff.game;

public enum StateType {
    IDLE,FOLLOW,ATTACK,
    GIVER,FLEE
}
