package com.katafrakt.zombieoff.game.abilitiybehaviours.effects;

import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.game.abilitiybehaviours.StatusTypes;

public class PoisonEffect extends AbilityEffect<PoisonEffect> {
    public static Pool<PoisonEffect> pool=new Pool<PoisonEffect>() {
        @Override
        protected PoisonEffect newObject() {
            return new PoisonEffect();
        }
    };

    private PoisonEffect(){
        name="Poison effect";
    }
    public PoisonEffect init(float value){
        this.value=value;
        return this;
    }
    @Override
    public void entryEffect(AgentComponentV2 agent) {

    }

    @Override
    public void tickEffect(AgentComponentV2 agent) {
        Mappers.particleComponents.get(agent.entity).addStatus(StatusTypes.POISONED).getEmitters().first().addParticles(1);
    }

    @Override
    public void leaveEffect(AgentComponentV2 agent) {

    }

    @Override
    public PoisonEffect clone() {
        return pool.obtain().init(value);
    }

    @Override
    public Pool<PoisonEffect> getPool() {
        return pool;
    }

    @Override
    public void free() {
        pool.free(this);
    }
}
