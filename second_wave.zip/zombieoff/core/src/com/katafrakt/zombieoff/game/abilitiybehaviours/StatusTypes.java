package com.katafrakt.zombieoff.game.abilitiybehaviours;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.ParticleEffect;
import com.badlogic.gdx.graphics.g2d.ParticleEffectPool;

public enum  StatusTypes {
    BURNING(){
        @Override
        public ParticleEffectPool.PooledEffect getParticleEffect() {
            return burning.obtain();
        }
    },
    FREEZE(){
        @Override
        public ParticleEffectPool.PooledEffect getParticleEffect() {
            return freeze.obtain();
        }
    },
    POISONED(){
        @Override
        public ParticleEffectPool.PooledEffect getParticleEffect() {
            return poisoned.obtain();
        }
    };

    StatusTypes() {
        ParticleEffect particleEffect=new ParticleEffect();
        particleEffect.load(Gdx.files.internal("particles/burning.party"),Gdx.files.internal("particles"));
        burning=new ParticleEffectPool(particleEffect,0,30);

        particleEffect=new ParticleEffect();
        particleEffect.load(Gdx.files.internal("particles/freeze.party"),Gdx.files.internal("particles"));
        freeze=new ParticleEffectPool(particleEffect,0,20);

        particleEffect=new ParticleEffect();
        particleEffect.load(Gdx.files.internal("particles/poisoned.party"),Gdx.files.internal("particles"));
        poisoned=new ParticleEffectPool(particleEffect,0,20);
    }
    protected ParticleEffectPool burning;
    protected ParticleEffectPool freeze;
    protected ParticleEffectPool poisoned;
    public abstract ParticleEffectPool.PooledEffect getParticleEffect();
}
