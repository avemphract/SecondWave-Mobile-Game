package com.katafrakt.zombieoff.game.upgradebehaviours.weaponunlocker.melee;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponInformation;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponUnlock;
import com.katafrakt.zombieoff.game.weapons.Weapon;
import com.katafrakt.zombieoff.game.weapons.zombie.melee.CriticAttack;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.player.ZombieBuilder;

public class CriticAttackUnlock implements WeaponUnlock {
    private static final String NAME= CriticAttackUnlock.class.getSimpleName();
    CriticAttack.Level level0=new CriticAttack.Level(0.5f,0.75f,1,0.2f,2);
    CriticAttack.Level level1=new CriticAttack.Level(0.5f,0.75f,1,0.2f,2.5f);
    CriticAttack.Level level2=new CriticAttack.Level(0.5f,0.80f,1,0.25f,2.75f);

    CriticAttack.Level[] levels=new CriticAttack.Level[]{level0,level1,level2};

    WeaponInformation weaponInformation =new WeaponInformation() {
        @Override
        public Weapon getWeapon() {
            return new CriticAttack(levels[count]);
        }
    };

    int index= UpgradeManager.setIndex();
    int count;
    float cost=10;


    @Override
    public String getType() {
        return "Melee";
    }

    @Override
    public String getTitle() {
        if (count==0)
            return "Critic Attack "+(count+1);
        else if (count<maximumCount())
            return "Critic Attack "+(count)+" -> "+(count+1);
        else
            return "Critic Attack "+(count);
    }

    @Override
    public String getDamage() {
        if (count==0)
            return "D: "+levels[count].damageRatio;
        else if (count<maximumCount())
            return "D: "+levels[count-1].damageRatio+" -> "+levels[count].damageRatio;
        else
            return "D: "+levels[count-1].damageRatio;
    }

    @Override
    public String getAttRate() {
        if (count==0)
            return "S: "+levels[count].attackSpeed;
        else if (count<maximumCount())
            return "S: "+levels[count-1].attackSpeed+" -> "+levels[count].attackSpeed;
        else
            return "S: "+levels[count-1].attackSpeed;
    }

    @Override
    public String getRange() {
        if (count<maximumCount())
            return "R: "+levels[count].range;
        else
            return "R: "+levels[count-1].range;
    }

    @Override
    public float getEnergy() {
        return 0;
    }

    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().GENE;
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public String effect() {if (count==0)
        return "Percent: %"+levels[count].criticOdds+"\nCritical damage: "+levels[count].criticRatio;
    else if (count<maximumCount())
        return "Percent: %"+levels[count-1].criticOdds+" -> %"+levels[count].criticOdds+"\nCritical damage: "+levels[count-1].criticRatio+" -> "+levels[count].criticRatio;
    else
        return "Percent: %"+levels[count-1].criticOdds+"\nCritical damage: "+levels[count-1].criticRatio;

    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public boolean enoughResource() {
        if (cost<=getResourceType().getCurrent())
            return true;
        else
            return false;
    }

    @Override
    public int maximumCount() {
        return levels.length;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        getResourceType().minusCurrent(cost);
        if (count==0){
            weaponInformation.type= WeaponInformation.Type.Melee;
            ZombieBuilder.getInstance().weaponCreators.add(weaponInformation);
        }

        weaponInformation.name="Critic Attack "+(count+1);


        weaponInformation.damage=String.valueOf(levels[count].damageRatio);
        weaponInformation.attRate=String.valueOf(levels[count].attackSpeed);
        weaponInformation.range=String.valueOf(levels[count].range);

        weaponInformation.detail="Percent: %"+levels[count].criticOdds+"\nCritical damage: "+levels[count].criticRatio;

        count++;
    }

    @Override
    public int getIndex() {
        return index;
    }
}
