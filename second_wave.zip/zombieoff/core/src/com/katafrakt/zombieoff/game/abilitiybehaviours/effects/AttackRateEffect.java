package com.katafrakt.zombieoff.game.abilitiybehaviours.effects;

import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;


public class AttackRateEffect extends AbilityEffect<AttackRateEffect> {
    public static Pool<AttackRateEffect> pool=new Pool<AttackRateEffect>() {
        @Override
        protected AttackRateEffect newObject() {
            return new AttackRateEffect();
        }
    };

    public AttackRateEffect(){
    }

    public AttackRateEffect init(float value){
        this.value=value;
        if (value>0)
            name="Attack rate increase";
        else
            name="Attack rate decrease";
        return this;
    }


    @Override
    public void entryEffect(AgentComponentV2 agent) {
        agent.creature.extraAttRate+=1*value;
    }

    @Override
    public void tickEffect(AgentComponentV2 agent) {

    }

    @Override
    public void leaveEffect(AgentComponentV2 agent) {
        agent.creature.extraAttRate-=1*value;

    }



    @Override
    public AttackRateEffect clone() {
        return pool.obtain().init(value);
    }

    @Override
    public Pool<AttackRateEffect> getPool() {
        return pool;
    }

    @Override
    public void free() {
        pool.free(this);
    }
}
