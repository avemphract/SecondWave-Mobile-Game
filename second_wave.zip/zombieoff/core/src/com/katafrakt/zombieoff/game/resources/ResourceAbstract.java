package com.katafrakt.zombieoff.game.resources;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;

public abstract class ResourceAbstract {
    public Color color;
    public Texture colorTexture;
    public boolean isAvailable=true;

    public boolean hasCapacity;
    public float capacity;
    public final float INITIAL_CAPACITY;
    public float addCapacity;
    public float multiplierCapacityUpgrade;
    public float multiplierCapacityPrestige;
    public float multiplierCapacityTrophy;

    //public float efficientUpgrade;
    public float efficientTrophy;
    public float efficientPrestige;

    protected float current;


    public ResourceAbstract(Color color,float INITIAL_CAPACITY,boolean hasCapacity) {
        this.color=color;
        this.INITIAL_CAPACITY = INITIAL_CAPACITY;
        this.hasCapacity=hasCapacity;

        createTexture();
    }

    public abstract String name();



    public void setCapacity(){
        capacity=(INITIAL_CAPACITY+addCapacity)*(multiplierCapacityUpgrade+1)*(multiplierCapacityPrestige+1)*(multiplierCapacityTrophy+1);
    }
    public float getCurrent(){return current;}
    public void addCurrent(float addition){
        current+=addition*(1+efficientPrestige+efficientTrophy);
        if (current>capacity)
            current=capacity;
    }
    public void minusCurrent(float subtraction){
        current-=subtraction;
    }
    public void production(float deltaTime){
        addCurrent(getProduction()*deltaTime);
    }
    public abstract float getProduction();


    public abstract void saveValues();
    public abstract void loadValues();

    protected void createTexture(){
        Pixmap pixmap=new Pixmap(1,1, Pixmap.Format.RGB888);
        pixmap.setColor(color);
        pixmap.fill();
        colorTexture=new Texture(pixmap);
        pixmap.dispose();
    }
}
