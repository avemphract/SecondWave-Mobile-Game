package com.katafrakt.zombieoff.game.upgradebehaviours.prestige_upgrades;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;

public class GeneCapacityPrestige implements ResourceUpgrade {
    private static final String TAG = GeneCapacityPrestige.class.getSimpleName();
    int index = UpgradeManager.setIndex();
    int count;
    float cost;
    float value=0.20f;

    private void setCost(){cost=count;}
    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().PRESTIGE;
    }

    @Override
    public String getName() {
        return "Increase brain capacity  +%20";
    }

    @Override
    public String effect() {
        return "";
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public boolean enoughResource() {
        if (cost<=getResourceType().getCurrent())
            return true;
        else
            return false;
    }

    @Override
    public int maximumCount() {
        return 1000;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        getResourceType().minusCurrent(cost);
        ResourceType.getInstance().GENE.multiplierCapacityPrestige += value;
        count++;
        setCost();
    }

    @Override
    public int getIndex() {
        return index;
    }
}
