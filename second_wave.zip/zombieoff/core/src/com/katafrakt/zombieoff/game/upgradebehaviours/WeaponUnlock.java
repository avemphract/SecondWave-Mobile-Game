package com.katafrakt.zombieoff.game.upgradebehaviours;

public interface WeaponUnlock extends ResourceUpgrade {
    public String getType();

    public String getTitle();
    public String getDamage();
    public String getAttRate();
    public String getRange();


    public float getEnergy();

}
