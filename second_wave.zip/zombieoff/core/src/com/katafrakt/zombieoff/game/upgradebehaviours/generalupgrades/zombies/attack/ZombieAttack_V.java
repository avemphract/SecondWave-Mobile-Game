package com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.attack;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.player.ZombieBuilder;

public class ZombieAttack_V implements ResourceUpgrade {
    public static final String NAME = ZombieAttack_V.class.getName();
    int index = UpgradeManager.setIndex();
    float cost;
    int count;
    int value=15;

    private void setCost(){
        cost=count*1000;
    }

    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().BLOOD;
    }

    @Override
    public String getName() {
        return "Smooth edges";
    }

    @Override
    public String effect() {
        return "+"+value+" zombie attack";
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public boolean enoughResource() {
        if (cost<=getResourceType().getCurrent())
            return true;
        else
            return false;
    }

    @Override
    public int maximumCount() {
        return 30;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        getResourceType().minusCurrent(cost);
        ZombieBuilder.getInstance().builder.attAddition+=value;
        count++;
        setCost();
    }

    @Override
    public int getIndex() {
        return index;
    }
}
