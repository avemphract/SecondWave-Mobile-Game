package com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_V;

public class GetAttackedTime_Regen_I {
}
