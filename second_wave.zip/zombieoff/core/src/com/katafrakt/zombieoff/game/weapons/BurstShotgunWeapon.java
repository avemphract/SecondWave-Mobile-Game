package com.katafrakt.zombieoff.game.weapons;

import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.game.weapons.hitbehaviour.HitBehaviour;

public class BurstShotgunWeapon extends ShotgunWeapon {
    float burstTime;
    int burstCount;
    int currentBurst;
    public BurstShotgunWeapon(Recommended recommended, HitBehaviour hitBehaviour, float attackSpeed, float damageRatio, int range, float accuracy, float bulletVelocity, int shotgunBullet, float burstTime, int burstCount) {
        super(recommended, hitBehaviour, attackSpeed, damageRatio, range, accuracy, bulletVelocity, shotgunBullet);
        this.burstTime=burstTime;
        this.burstCount=burstCount;
    }
    public BurstShotgunWeapon(Level level){
        super(level.recommended,level.hitBehaviour,level.attackSpeed,level.damageRatio,level.range,level.accuracy,level.bulletVelocity,level.shotgunBullet);
        this.burstTime=level.burstTime;
        this.burstCount=level.burstCount;
    }
    public BurstShotgunWeapon(Level level,WeaponGraphics weaponGraphics){
        super(level.recommended,level.hitBehaviour,level.attackSpeed,level.damageRatio,level.range,level.accuracy,level.bulletVelocity,level.shotgunBullet);
        this.burstTime=level.burstTime;
        this.burstCount=level.burstCount;
        this.weaponGraphics=weaponGraphics;
    }

    @Override
    public void attack(CreatureComponent attacker, CreatureComponent target) {
        if (currentBurst>=burstCount){
            currentBurst=1;
        }
        else currentBurst++;
        super.attack(attacker, target);
    }

    @Override
    public float getAttackRate(CreatureComponent attacker) {
        if (currentBurst>=burstCount){
            return 1/(attackRate*attacker.getAttRate());
        }else {
            return burstTime;
        }
    }

    public static class Level{
        public Recommended recommended;
        public HitBehaviour hitBehaviour;
        public float attackSpeed;
        public float damageRatio;
        public int range;
        public float accuracy;
        public float bulletVelocity;
        public int shotgunBullet;
        public float burstTime;
        public int burstCount;

        public Level(Recommended recommended, HitBehaviour hitBehaviour ,float attackSpeed, float damageRatio, int range, float accuracy, float bulletVelocity, int shotgunBullet, float burstTime, int burstCount) {
            this.recommended=recommended;
            this.hitBehaviour=hitBehaviour;
            this.attackSpeed = attackSpeed;
            this.damageRatio = damageRatio;
            this.range = range;
            this.accuracy = accuracy;
            this.bulletVelocity = bulletVelocity;
            this.shotgunBullet = shotgunBullet;
            this.burstTime = burstTime;
            this.burstCount = burstCount;
        }
    }
}
