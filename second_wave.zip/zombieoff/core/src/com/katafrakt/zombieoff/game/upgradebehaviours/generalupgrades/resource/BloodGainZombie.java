package com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.resource;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;

public class BloodGainZombie implements ResourceUpgrade {
    public static final String NAME= BloodGainZombie.class.getName();
    int index= UpgradeManager.setIndex();
    int count;
    float value=0.05f;
    float cost;

    @Override
    public String getName() {
        return "Reusable Blood";
    }

    @Override
    public String effect() {
        return "0.05f Blood gain ratio from zombies";
    }


    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().BLOOD;
    }

    @Override
    public boolean enoughResource() {
        if (cost<=getResourceType().getCurrent())
            return true;
        else
            return false;
    }

    @Override
    public int maximumCount() {
        return 10;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public void upgrade() {
        getResourceType().minusCurrent(cost);
        ResourceType.getInstance().BLOOD.zombieGainRate+=value;
        count++;
    }

    @Override
    public int getIndex() {
        return index;
    }
}
