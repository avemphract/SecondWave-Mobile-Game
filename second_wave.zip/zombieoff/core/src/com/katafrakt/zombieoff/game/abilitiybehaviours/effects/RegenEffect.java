package com.katafrakt.zombieoff.game.abilitiybehaviours.effects;

import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;

public class RegenEffect extends AbilityEffect<RegenEffect> {
    public static Pool<RegenEffect> pool=new Pool<RegenEffect>() {
        @Override
        protected RegenEffect newObject() {
            return new RegenEffect();
        }
    };

    private RegenEffect(){

    }
    public RegenEffect init(float value){
        this.value=value;
        return this;
    }

    @Override
    public void entryEffect(AgentComponentV2 agent) {
        agent.creature.extraRegen+=value;
    }

    @Override
    public void tickEffect(AgentComponentV2 agent) {

    }

    @Override
    public void leaveEffect(AgentComponentV2 agent) {
        agent.creature.extraRegen-=value;
    }

    @Override
    public RegenEffect clone() {
        return pool.obtain().init(value);
    }

    @Override
    public Pool<RegenEffect> getPool() {
        return pool;
    }

    @Override
    public void free() {
        pool.free(this);
    }

}
