package com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit;

import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.graphics.FloatingTextComponent;
import com.katafrakt.zombieoff.game.abilitiybehaviours.CloneableAbilityController;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.AbilityEffect;
import com.katafrakt.zombieoff.game.weapons.Weapon;

public class OneTime extends CloneableAbilityController<OneTime> {
    public static Pool<OneTime> pool=new Pool<OneTime>() {
        @Override
        protected OneTime newObject() {
            return new OneTime();
        }
    };

    public OneTime init(AbilityEffect<?> abilityEffect){
        this.abilityEffect=abilityEffect;
        types.clear();
        types.add(Type.UPDATE);
        return this;
    }

    @Override
    public void enter(AgentComponentV2<? extends Weapon> agentComponent) {
        abilityEffect.entryEffect(agentComponent);
        agentComponent.abilities.get(Type.UPDATE).removeValue(this,false);
        FloatingTextComponent floatingTextComponent= Mappers.floatingTextComponents.get(agentComponent.entity);
        if (floatingTextComponent!=null)
            floatingTextComponent.addText(abilityEffect.name,1f);

    }

    @Override
    public void update(AgentComponentV2<? extends Weapon> agentComponent, Type type) {
        if (type==Type.UPDATE){
            enter(agentComponent);
        }
    }

    @Override
    public void leave(AgentComponentV2<? extends Weapon> agentComponent) {
        abilityEffect.leaveEffect(agentComponent);
        pool.free(this);
    }

    @Override
    public Pool<OneTime> getPool() {
        return pool;
    }

    @Override
    public CloneableAbilityController<OneTime> clone() {
        return pool.obtain().init( abilityEffect.clone());
    }
}
