package com.katafrakt.zombieoff.game.upgradebehaviours.weapon_creators;

import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.math.Vector2;
import com.katafrakt.zombieoff.entities.BulletType;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponCreator;
import com.katafrakt.zombieoff.game.weapons.BurstRangedWeapon;
import com.katafrakt.zombieoff.game.weapons.BurstShotgunWeapon;
import com.katafrakt.zombieoff.game.weapons.ShotgunWeapon;
import com.katafrakt.zombieoff.game.weapons.StandardRangedWeapon;
import com.katafrakt.zombieoff.game.weapons.Weapon;
import com.katafrakt.zombieoff.game.weapons.WeaponGraphics;
import com.katafrakt.zombieoff.game.weapons.hitbehaviour.AreaEffectHitBehaviour;
import com.katafrakt.zombieoff.game.weapons.hitbehaviour.MultiTargetHitBehaviour;
import com.katafrakt.zombieoff.game.weapons.hitbehaviour.ShrapnelHitBehaviour;
import com.katafrakt.zombieoff.game.weapons.hitbehaviour.SingleTargetHitBehaviour;
import com.katafrakt.zombieoff.game.weapons.zombie.melee.BasicAttack;
import com.katafrakt.zombieoff.managers.AssetOrganizer;

import org.jetbrains.annotations.NotNull;

public enum WeaponTag implements WeaponCreator {
    PISTON_I{
        StandardRangedWeapon.Level level=new StandardRangedWeapon.Level(Weapon.Recommended.LOW, SingleTargetHitBehaviour.pool.obtain(), BulletType.LINE,0.8f,0.40f,6,40,50);
        WeaponGraphics weaponGraphics=new WeaponGraphics(textureAtlas.findRegion("piston_1"),new Vector2(7,6),new Vector2(7,6),new Vector2(7,6),new Vector2(6,6));
        @Override
        public Weapon getWeapon() {
            return new StandardRangedWeapon(level,weaponGraphics);
        }
    },
    PISTON_II(){
        StandardRangedWeapon.Level level=new StandardRangedWeapon.Level(Weapon.Recommended.LOW, SingleTargetHitBehaviour.pool.obtain(), BulletType.LINE,0.4f,0.85f,6,45,200);
        WeaponGraphics weaponGraphics=new WeaponGraphics(textureAtlas.findRegion("piston_2"),new Vector2(7,6),new Vector2(7,6),new Vector2(7,6),new Vector2(6,6));
        @Override
        public Weapon getWeapon() {
            return new StandardRangedWeapon(level,weaponGraphics);
        }
    },
    PISTON_III(){
        StandardRangedWeapon.Level level=new StandardRangedWeapon.Level(Weapon.Recommended.LOW, SingleTargetHitBehaviour.pool.obtain(), BulletType.LINE, 0.5f, 0.8f, 7, 50, 200);
        WeaponGraphics weaponGraphics=new WeaponGraphics(textureAtlas.findRegion("piston_3"),new Vector2(7.5f,5.5f),new Vector2(7.5f,5.5f),new Vector2(7,6),new Vector2(6,6));

        @Override
        public Weapon getWeapon() {
            return new StandardRangedWeapon(level,weaponGraphics);
        }
    },
    PISTON_IV(){
        StandardRangedWeapon.Level level=new StandardRangedWeapon.Level(Weapon.Recommended.LOW, SingleTargetHitBehaviour.pool.obtain(), BulletType.LINE, 0.75f, 0.7f, 6, 50, 200);
        WeaponGraphics weaponGraphics=new WeaponGraphics(textureAtlas.findRegion("piston_4"),new Vector2(7,5.5f),new Vector2(7,5.5f),new Vector2(7,6),new Vector2(6,6));

        @Override
        public Weapon getWeapon() {
            return new StandardRangedWeapon(level,weaponGraphics);
        }
    },

    RAPID_FIRE_I{
        BurstRangedWeapon.Level level=new BurstRangedWeapon.Level(Weapon.Recommended.MEDIUM,SingleTargetHitBehaviour.pool.obtain(), BulletType.LINE,0.8f,0.7f,12,60,150,0.05f,3);
        WeaponGraphics weaponGraphics=new WeaponGraphics(textureAtlas.findRegion("rapid_fire_1"),new Vector2(4.5f,6),new Vector2(10,7),new Vector2(7,6),new Vector2(6,6));

        @Override
        public Weapon getWeapon() {
            return new BurstRangedWeapon(level,weaponGraphics);
        }
    },
    RAPID_FIRE_II{
        BurstRangedWeapon.Level level=new BurstRangedWeapon.Level(Weapon.Recommended.MEDIUM,SingleTargetHitBehaviour.pool.obtain(),BulletType.LINE,0.8f,0.75f,14,55,150,0.05f,4);
        WeaponGraphics weaponGraphics=new WeaponGraphics(textureAtlas.findRegion("rapid_fire_2"),new Vector2(4.5f,6),new Vector2(10,7),new Vector2(4,6),new Vector2(3f,6));

        @Override
        public Weapon getWeapon() {
            return new BurstRangedWeapon(level,weaponGraphics);
        }
    },
    RAPID_FIRE_III{

        BurstRangedWeapon.Level level=new BurstRangedWeapon.Level(Weapon.Recommended.MEDIUM, SingleTargetHitBehaviour.pool.obtain(),BulletType.LINE,0.8f,0.75f,16,65,160,0.05f,5);
        WeaponGraphics weaponGraphics=new WeaponGraphics(textureAtlas.findRegion("rapid_fire_3"),new Vector2(4.5f,6),new Vector2(10,7),new Vector2(4,6),new Vector2(3f,6));

        @Override
        public Weapon getWeapon() {
            return new BurstRangedWeapon(level,weaponGraphics);
        }
    },
    RAPID_FIRE_IV{
        BurstRangedWeapon.Level level=new BurstRangedWeapon.Level(Weapon.Recommended.MEDIUM, SingleTargetHitBehaviour.pool.obtain(),BulletType.LINE,1,0.80f,14,70,200,0.05f,4);
        WeaponGraphics weaponGraphics=new WeaponGraphics(textureAtlas.findRegion("rapid_fire_4"),new Vector2(4,6.5f),new Vector2(9.5f,7.5f),new Vector2(4,6),new Vector2(4.5f,6));

        @Override
        public Weapon getWeapon() {
            return new BurstRangedWeapon(level,weaponGraphics);
        }
    },

    LONG_RANGE_I{
        StandardRangedWeapon.Level level=new StandardRangedWeapon.Level(Weapon.Recommended.HIGH,MultiTargetHitBehaviour.pool.obtain().init(2), BulletType.LINE,0.2f,0.5f,14,75,400);
        WeaponGraphics weaponGraphics=new WeaponGraphics(textureAtlas.findRegion("long_range_1"),new Vector2(6.5f,5.5f),new Vector2(11,6.5f),new Vector2(4,7),new Vector2(5.5f,8));

        @Override
        public Weapon getWeapon() {
            return new StandardRangedWeapon(level,weaponGraphics);
        }
    },
    LONG_RANGE_II{
        StandardRangedWeapon.Level level=new StandardRangedWeapon.Level(Weapon.Recommended.HIGH,MultiTargetHitBehaviour.pool.obtain().init(2), BulletType.LINE,0.2f,0.5f,14,75,400);
        WeaponGraphics weaponGraphics=new WeaponGraphics(textureAtlas.findRegion("long_range_2"),new Vector2(5,5),new Vector2(10,6),new Vector2(4,7),new Vector2(5.5f,8));

        @Override
        public Weapon getWeapon() {
            return new StandardRangedWeapon(level,weaponGraphics);
        }
    },
    LONG_RANGE_III{
        StandardRangedWeapon.Level level=new StandardRangedWeapon.Level(Weapon.Recommended.HIGH, MultiTargetHitBehaviour.pool.obtain().init(4),BulletType.LINE,0.12f,5f,24,90,500);
        WeaponGraphics weaponGraphics=new WeaponGraphics(textureAtlas.findRegion("long_range_3"),new Vector2(5,5.5f),new Vector2(11,6),new Vector2(4,7),new Vector2(5.5f,8));

        @Override
        public Weapon getWeapon() {
            return new StandardRangedWeapon(level,weaponGraphics);
        }
    },
    LONG_RANGE_IV{
        StandardRangedWeapon.Level level=new StandardRangedWeapon.Level(Weapon.Recommended.HIGH, MultiTargetHitBehaviour.pool.obtain().init(4),BulletType.LINE,0.12f,5f,24,90,500);
        WeaponGraphics weaponGraphics=new WeaponGraphics(textureAtlas.findRegion("long_range_4"),new Vector2(5.5f,4.5f),new Vector2(12f,6f),new Vector2(4,7),new Vector2(5.5f,8));

        @Override
        public Weapon getWeapon() {
            return new StandardRangedWeapon(level,weaponGraphics);
        }
    },

    SHOTGUN_I{
        ShotgunWeapon.Level level=new ShotgunWeapon.Level(Weapon.Recommended.LOW,SingleTargetHitBehaviour.pool.obtain(),0.35f,1,4,20,150,3);
        WeaponGraphics weaponGraphics=new WeaponGraphics(textureAtlas.findRegion("shotgun_1"),new Vector2(4,5),new Vector2(10,6),new Vector2(5,6),new Vector2(4,6));
        @Override
        public Weapon getWeapon() {
            return new ShotgunWeapon(level,weaponGraphics);
        }
    },
    SHOTGUN_II{
        ShotgunWeapon.Level level=new ShotgunWeapon.Level(Weapon.Recommended.LOW,SingleTargetHitBehaviour.pool.obtain(),0.40f,1,4,20,150,5);
        WeaponGraphics weaponGraphics=new WeaponGraphics(textureAtlas.findRegion("shotgun_2"),new Vector2(4,5.5f),new Vector2(8,6),new Vector2(5,6),new Vector2(4,6));

        @Override
        public Weapon getWeapon() {
            return new ShotgunWeapon(level,weaponGraphics);
        }
    },
    SHOTGUN_III{
        ShotgunWeapon.Level level=new ShotgunWeapon.Level(Weapon.Recommended.LOW, SingleTargetHitBehaviour.pool.obtain(),0.45f,1,4,20,150,7);
        WeaponGraphics weaponGraphics=new WeaponGraphics(textureAtlas.findRegion("shotgun_3"),new Vector2(3,5.5f),new Vector2(8,5),new Vector2(5,6),new Vector2(4,6));

        @Override
        public Weapon getWeapon() {
            return new ShotgunWeapon(level,weaponGraphics);
        }
    },
    SHOTGUN_IV{
        ShotgunWeapon.Level level=new ShotgunWeapon.Level(Weapon.Recommended.LOW, SingleTargetHitBehaviour.pool.obtain(),0.6f,1,4,20,150,5);
        WeaponGraphics weaponGraphics=new WeaponGraphics(textureAtlas.findRegion("shotgun_4"),new Vector2(6,5),new Vector2(9.5f,4.5f),new Vector2(5,6),new Vector2(4,6));

        @Override
        public Weapon getWeapon() {
            return new ShotgunWeapon(level,weaponGraphics);
        }
    },

    BURST_SHOTGUN{
        BurstShotgunWeapon.Level level=new BurstShotgunWeapon.Level(Weapon.Recommended.LOW,SingleTargetHitBehaviour.pool.obtain(),0.3f,0.4f,5,20,90,5,0.1f,3);
        WeaponGraphics weaponGraphics=new WeaponGraphics(textureAtlas.findRegion("burst_shotgun"),new Vector2(5.5f,5),new Vector2(11,6),new Vector2(7,6),new Vector2(6,6));
        @Override
        public Weapon getWeapon() {
            return new BurstShotgunWeapon(level,weaponGraphics);
        }
    },
    MACHINE_GUN{
        StandardRangedWeapon.Level level=new StandardRangedWeapon.Level(Weapon.Recommended.MEDIUM, SingleTargetHitBehaviour.pool.obtain(), BulletType.LINE,5f,1,15,20,200);
        WeaponGraphics weaponGraphics=new WeaponGraphics(textureAtlas.findRegion("machine_gun"),new Vector2(4.5f,5),new Vector2(10,7),new Vector2(7,6),new Vector2(6,6));
        @Override
        public Weapon getWeapon() {
            return new StandardRangedWeapon(level,weaponGraphics);
        }
    },
    GRENADE_THROWER{
        BurstRangedWeapon.Level level=new BurstRangedWeapon.Level(Weapon.Recommended.MEDIUM, AreaEffectHitBehaviour.pool.obtain().init(3),BulletType.LINE, 1.5f,1.5f,14,-210,70,0.02f,8);
        WeaponGraphics weaponGraphics=new WeaponGraphics(textureAtlas.findRegion("grenade_thrower"),new Vector2(6,5),new Vector2(13.5f,5.5f),new Vector2(7,6),new Vector2(6,6));
        @Override
        public Weapon getWeapon() {
            return new BurstRangedWeapon(level,weaponGraphics);
        }
    },
    ROCKET_LAUNCHER{
        StandardRangedWeapon.Level level=new StandardRangedWeapon.Level(Weapon.Recommended.MEDIUM, AreaEffectHitBehaviour.pool.obtain().init(6), BulletType.LINE,0.3f,3,15,40,100);
        WeaponGraphics weaponGraphics=new WeaponGraphics(textureAtlas.findRegion("rocket_launcher"),new Vector2(6,4.5f),new Vector2(10,6.5f),new Vector2(8,2),new Vector2(8,2));

        @Override
        public Weapon getWeapon() {
            return new StandardRangedWeapon(level,weaponGraphics);
        }
    },
    SHRAPNEL_RAPID{
        BurstRangedWeapon.Level level=new BurstRangedWeapon.Level(Weapon.Recommended.MEDIUM, ShrapnelHitBehaviour.pool.obtain().init(1,1), BulletType.LINE,1,0.5f,15,40,200,0.05f,3);
        WeaponGraphics weaponGraphics=new WeaponGraphics(textureAtlas.findRegion("shrapnel_rapid"),new Vector2(5,5.5f),new Vector2(12,6.5f),new Vector2(7,6),new Vector2(6,6));
        @Override
        public Weapon getWeapon() {
            return new BurstRangedWeapon(level,weaponGraphics);
        }
    },/*
    SHRAPNEL_RIFLE{
        @Override
        public Weapon getWeapon() {
            return null;
        }
    }*/
    ;
    TextureAtlas textureAtlas=AssetOrganizer.getInstance().get("atlases/human_ranged_weapons.atlas",TextureAtlas.class);

}
