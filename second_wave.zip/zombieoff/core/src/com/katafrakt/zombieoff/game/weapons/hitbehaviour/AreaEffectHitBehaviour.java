package com.katafrakt.zombieoff.game.weapons.hitbehaviour;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.creatures.BulletComponent;
import com.katafrakt.zombieoff.entities.BulletOwner;
import com.katafrakt.zombieoff.game.abilitiybehaviours.CloneableAbilityController;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.utilities.Utility;


public class AreaEffectHitBehaviour implements HitBehaviour, Pool.Poolable {
    public static Pool<AreaEffectHitBehaviour> pool=new Pool<AreaEffectHitBehaviour>() {
        @Override
        protected AreaEffectHitBehaviour newObject() {
            return new AreaEffectHitBehaviour();
        }
    };
    Array<Entity> creature=new Array<>();
    int radius;

    public AreaEffectHitBehaviour(){}
    public AreaEffectHitBehaviour init(int radius) {
        this.radius =radius;
        creature.clear();
        return this;
    }
    @Override
    public void hit(BulletComponent bulletComponent) {

        TransformComponent transform= Mappers.transformComponents.get(bulletComponent.entity);
        Array<Point> points= Utility.pointArrayPool.obtain();
        points=MapManager.getInstance().pointGraph.getAreaPoints(points,MapManager.getInstance().pointGraph.nearestPoint(transform.pos), radius +1);
        Mappers.particleComponents.get(bulletComponent.entity).addExplosion(radius);

        for (Point point:points){
            if (bulletComponent.bulletOwner == BulletOwner.HUMAN_BULLET){
                creature.addAll(point.zombies);
            }
            else {
                creature.addAll(point.humans);
            }
        }
        Utility.pointArrayPool.free(points);

        for (Entity entity:creature){
            TransformComponent targetTransform = Mappers.transformComponents.get(entity);
            if (targetTransform.distance(transform)< radius*Point.UNIT){
                for (CloneableAbilityController abilityController:bulletComponent.abilityControllers)
                    Mappers.agentComponents(entity).addAbility(abilityController.clone());
                Mappers.creatureComponents.get(entity).takeDamageBlood(bulletComponent.damage);
            }
        }

    }

    @Override
    public HitBehaviour clone() {
        AreaEffectHitBehaviour areaEffectHitBehaviour=pool.obtain();
        areaEffectHitBehaviour.init(radius);
        return areaEffectHitBehaviour;
    }

    @Override
    public Pool getPool() {
        return pool;
    }

    @Override
    public void reset() {}
}
