package com.katafrakt.zombieoff.game.weapons.zombie.melee;

import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.weapons.MeleeWeapon;

public class BurstAttack extends MeleeWeapon {
    int burstCount;
    int totalShot;
    public BurstAttack(float attackSpeed, float damageRatio, int range, int burstCount) {
        super(attackSpeed,damageRatio, range);
        this.burstCount=burstCount;
    }
    public BurstAttack(Level level){
        super(level.attackSpeed,level.damageRatio,level.range);
        this.burstCount=level.burstCount;
    }

    @Override
    public void attack(CreatureComponent attacker, CreatureComponent target) {
        totalShot++;
        for(AbilityController abilityController:abilityControllers)
            Mappers.agentComponents(target.entity).addAbility(abilityController);
        target.takeDamageBlood(attacker.getDamage()*damageRatio);//Todo
    }

    @Override
    public float getAttackRate(CreatureComponent attacker) {
        if (totalShot%burstCount==0){
            return 1/(attackRate*attacker.getAttRate());
        }else {
            return 0.1f;
        }
    }
    public static class Level{
        public float attackSpeed;
        public float damageRatio;
        public int range;
        public int burstCount;

        public Level(float attackSpeed, float damageRatio, int range, int burstCount){
            this.attackSpeed=attackSpeed;
            this.damageRatio=damageRatio;
            this.range=range;
            this.burstCount=burstCount;
        }
    }
}
