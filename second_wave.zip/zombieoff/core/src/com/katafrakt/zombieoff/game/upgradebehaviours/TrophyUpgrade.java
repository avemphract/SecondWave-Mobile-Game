package com.katafrakt.zombieoff.game.upgradebehaviours;

import com.katafrakt.zombieoff.ui.desicions.ChangeInterface;

public interface TrophyUpgrade extends UpgradeBehaviour {

    String requirementName();
    float currentResource();
    void adjustEvent(ChangeInterface changeInterface);
}
