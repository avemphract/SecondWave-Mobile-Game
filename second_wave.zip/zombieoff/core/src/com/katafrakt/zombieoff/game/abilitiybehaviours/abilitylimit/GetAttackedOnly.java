package com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit;

import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.graphics.FloatingTextComponent;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.AbilityEffect;
import com.katafrakt.zombieoff.game.weapons.Weapon;

public class GetAttackedOnly extends AbilityController<GetAttackedOnly> {
    public static Pool<GetAttackedOnly> pool=new Pool<GetAttackedOnly>() {
        @Override
        protected GetAttackedOnly newObject() {
            return new GetAttackedOnly();
        }
    };

    public GetAttackedOnly init(AbilityEffect<?> abilityEffect){
        this.abilityEffect=abilityEffect;
        types.clear();
        types.add(Type.GET_ATTACKED);
        return this;
    }

    @Override
    public void enter(AgentComponentV2<? extends Weapon> agentComponent) {
        abilityEffect.entryEffect(agentComponent);
        FloatingTextComponent floatingTextComponent= Mappers.floatingTextComponents.get(agentComponent.entity);
        if (floatingTextComponent!=null)
            floatingTextComponent.addText(abilityEffect.name,1f);

    }

    @Override
    public void update(AgentComponentV2<? extends Weapon> agentComponent, Type type) {
        if (Type.GET_ATTACKED==type){
            enter(agentComponent);
        }
    }

    @Override
    public void leave(AgentComponentV2<?> agentComponent) {
        abilityEffect.leaveEffect(agentComponent);
    }

    @Override
    public Pool<GetAttackedOnly> getPool() {
        return pool;
    }
}
