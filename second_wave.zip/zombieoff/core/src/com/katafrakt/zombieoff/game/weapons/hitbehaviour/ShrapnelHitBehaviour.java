package com.katafrakt.zombieoff.game.weapons.hitbehaviour;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ashley.components.BoundComponent;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.creatures.BulletComponent;
import com.katafrakt.zombieoff.entities.BulletOwner;
import com.katafrakt.zombieoff.entities.bullets.Bullet;
import com.katafrakt.zombieoff.managers.BulletFactory;
import com.katafrakt.zombieoff.managers.EngineEdited;
import com.katafrakt.zombieoff.managers.GeneralOrganizer;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.utilities.Utility;

public class ShrapnelHitBehaviour implements HitBehaviour {
    public static Pool<ShrapnelHitBehaviour> pool=new Pool<ShrapnelHitBehaviour>() {
        @Override
        protected ShrapnelHitBehaviour newObject() {
            return new ShrapnelHitBehaviour();

        }
    };

    Array<Entity> creatures=new Array<>();
    Array<Vector2> vector2s=new Array<>();
    int bulletCount;
    float shrapnelRange;
    Bullet.Builder builder=new Bullet.Builder();
    public ShrapnelHitBehaviour(){}
    public ShrapnelHitBehaviour(int bulletCount, float shrapnelRange) {
        this.bulletCount=bulletCount;
        this.shrapnelRange=shrapnelRange;
    }
    public ShrapnelHitBehaviour init(int bulletCount, float shrapnelRange){
        this.bulletCount=bulletCount;
        this.shrapnelRange=shrapnelRange;
        creatures.clear();
        vector2s.clear();
        vectorSet();
        return this;
    }

    @Override
    public void hit(BulletComponent bulletComponent) {
        TransformComponent transform= Mappers.transformComponents.get(bulletComponent.entity);
        Array<Point> points= Utility.pointArrayPool.obtain();
        points=MapManager.getInstance().pointGraph.getAreaPoints(points,MapManager.getInstance().pointGraph.nearestPoint(transform.pos),2);
        for (Point point:points){
            if (bulletComponent.bulletOwner == BulletOwner.HUMAN_BULLET){
                creatures.addAll(point.zombies);
            }
            else {
                creatures.addAll(point.humans);
            }
        }

        for (int i=0;i<vector2s.size;i++){
            builder.set(bulletComponent.bulletOwner,bulletComponent.bulletType,SingleTargetHitBehaviour.pool.obtain(),transform.pos.x,transform.pos.y,2,2,vector2s.get(i).scl(bulletComponent.speed.len()),bulletComponent.damage,16*shrapnelRange/bulletComponent.speed.len(),bulletComponent.abilityControllers);
            BulletFactory.getInstance().createBullet(builder);
        }

        for (Entity entity: creatures){
            TransformComponent targetTransform= entity.getComponent(TransformComponent.class);
            BoundComponent targetBound= entity.getComponent(BoundComponent.class);
            if (targetTransform.pos.x-targetBound.width/2<transform.pos.x && transform.pos.x<targetTransform.pos.x+targetBound.width/2){
                if (targetTransform.pos.y-targetBound.height/2<transform.pos.y && transform.pos.y<targetTransform.pos.y+targetBound.height/2){
                    Mappers.creatureComponents.get(entity).takeDamageBlood(bulletComponent.damage);
                    break;
                }
            }
        }//for
    }
    public void vectorSet(){
        float angle= GeneralOrganizer.getInstance().random.nextFloat()*360;
        for (int i=0;i<bulletCount;i++){
            vector2s.add(new Vector2(1,0).rotateDeg(angle+i*360/bulletCount));
        }
    }

    @Override
    public HitBehaviour clone() {
        ShrapnelHitBehaviour shrapnelHitBehaviour=pool.obtain();
        shrapnelHitBehaviour.init(bulletCount,shrapnelRange);
        return shrapnelHitBehaviour;
    }

    @Override
    public Pool getPool() {
        return pool;
    }
}
