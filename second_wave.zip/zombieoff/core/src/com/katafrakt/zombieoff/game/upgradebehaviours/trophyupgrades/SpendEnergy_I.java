package com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades;

import com.katafrakt.zombieoff.game.upgradebehaviours.TrophyUpgrade;
import com.katafrakt.zombieoff.player.PlayerStatics;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.ui.desicions.ChangeInterface;

public class SpendEnergy_I implements TrophyUpgrade {
    public static final String NAME = SpendEnergy_I.class.getName();
    int index = UpgradeManager.setIndex();
    int count;
    int cost=1000;

    @Override
    public String requirementName() {
        return "Use Energy";
    }

    @Override
    public float currentResource() {
        return PlayerStatics.getInstance().spendEnergy.get();//Sonra
    }

    @Override
    public void adjustEvent(ChangeInterface changeInterface) {
        PlayerStatics.EventFloat.addListener(PlayerStatics.getInstance().spendEnergy,changeInterface);
    }

    @Override
    public String getName() {
        return "Active";
    }

    @Override
    public String effect() {
        return "+%5 Energy capacity";
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public boolean enoughResource() {
        return false; //Sonra
    }

    @Override
    public int maximumCount() {
        return 1;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        //Sonra
    }

    @Override
    public int getIndex() {
        return index;
    }
}
