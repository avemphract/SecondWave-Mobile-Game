package com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.resource;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;

public class EnergyCapacity_I implements ResourceUpgrade {
    public static final String NAME= EnergyCapacity_I.class.getName();
    int index= UpgradeManager.setIndex();
    int count;
    float value=4f;
    float cost;

    private void setCost() {
        cost=(count+1)*150;
    }
    public String getName() {
        return "Extra Cell";
    }

    @Override
    public String effect() {
        return "+4 Energy Capacity";
    }


    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().BLOOD;
    }

    @Override
    public boolean enoughResource() {
        if (cost<=getResourceType().getCurrent())
            return true;
        else
            return false;
    }

    @Override
    public int maximumCount() {
        return 20;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public void upgrade() {
        getResourceType().minusCurrent(cost);
        ResourceType.getInstance().ENERGY.addCapacity +=value;
        ResourceType.getInstance().ENERGY.setCapacity();
        count++;
        setCost();
    }


    @Override
    public int getIndex() {
        return index;
    }
}
