package com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.AbilityEffect;
import com.katafrakt.zombieoff.game.weapons.Weapon;

public class AttackToTimeLimit extends AbilityController<AttackToTimeLimit> {
    private static final String TAG=AttackToTimeLimit.class.getSimpleName();
    public static Pool<AttackToTimeLimit> pool=new Pool<AttackToTimeLimit>() {
        @Override
        protected AttackToTimeLimit newObject() {
            return new AttackToTimeLimit();
        }
    };

    float time;

    public AttackToTimeLimit init(AbilityEffect<?> abilityEffect, float time) {
        this.abilityEffect=abilityEffect;
        types.clear();
        types.add(Type.ATTACK);
        this.time=time;
        return this;
    }

    @Override
    public void enter(AgentComponentV2<? extends Weapon> agentComponent) {

    }

    @Override
    public void update(AgentComponentV2<? extends Weapon> agentComponent, Type type) {
        if (type==Type.ATTACK){
            agentComponent.primaryWeapon.abilityControllers.add(TimeLimit.pool.obtain().init(abilityEffect,time));
            Gdx.app.log(TAG,"dsa");
            //agentComponent.primaryWeapon.abilityControllers.add(new TimeLimit().init(abilityEffect,time));
            //AgentComponent.getAgentComponent(agentComponent.target).abilities.get(Type.UPDATE).add(new TimeLimit(abilityEffect,time));
        }
    }

    @Override
    public void leave(AgentComponentV2<? extends Weapon> agentComponent) {

    }

    @Override
    public Pool<AttackToTimeLimit> getPool() {
        return pool;
    }
}
