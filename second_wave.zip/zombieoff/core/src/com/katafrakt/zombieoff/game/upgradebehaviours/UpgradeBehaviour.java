package com.katafrakt.zombieoff.game.upgradebehaviours;

public interface UpgradeBehaviour {
    String getName();
    String effect();

    float requiredResource();
    boolean enoughResource();
    int maximumCount();
    int currentCount();
    void upgrade();

    int getIndex();
}
