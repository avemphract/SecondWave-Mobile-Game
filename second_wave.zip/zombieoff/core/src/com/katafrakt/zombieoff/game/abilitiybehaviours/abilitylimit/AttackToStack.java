package com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.utils.ArrayMap;
import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.AbilityEffect;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.weapons.Weapon;

public class AttackToStack extends AbilityController<AttackToStack> {
    public static Pool<AttackToStack> pool=new Pool<AttackToStack>() {
        @Override
        protected AttackToStack newObject() {
            return new AttackToStack();
        }
    };
    ArrayMap<Entity,Integer> map=new ArrayMap<>();
    AbilityCreator abilityCreator;
    int stackLimit;
    int currentStack;

    public AttackToStack init(AbilityEffect<?> abilityEffect, int stackLimit,AbilityCreator abilityCreator){
        this.abilityEffect=abilityEffect;
        this.abilityCreator=abilityCreator;
        this.stackLimit=stackLimit;
        currentStack=0;

        types.clear();
        types.add(Type.ATTACK);


        return this;
    }

    @Override
    public void enter(AgentComponentV2<? extends Weapon> agentComponent) {

    }

    @Override
    public void update(AgentComponentV2<? extends Weapon> agentComponent, Type type) {
        if (type == Type.ATTACK && currentStack<stackLimit){
            agentComponent.primaryWeapon.abilityControllers.add(OneTime.pool.obtain().init(abilityEffect));
            currentStack++;
        }
    }

    @Override
    public void leave(AgentComponentV2<? extends Weapon> agentComponent) {

    }

    @Override
    public Pool<AttackToStack> getPool() {
        return pool;
    }
}
