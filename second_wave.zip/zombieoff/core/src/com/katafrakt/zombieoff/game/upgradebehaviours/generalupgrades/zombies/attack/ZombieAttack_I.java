package com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.attack;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.player.ZombieBuilder;

public class ZombieAttack_I implements ResourceUpgrade {
    public static final String NAME= ZombieAttack_I.class.getSimpleName();
    int index= UpgradeManager.setIndex();
    int count;
    float cost;
    int variable=1;

    private void setCost(){
        cost=(count+2)*200;
    }

    @Override
    public String getName() {
        return "Zombies muscle";
    }

    @Override
    public String effect() {
        return "+"+variable+" Zombie attack";
    }

    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().BLOOD;
    }

    @Override
    public boolean enoughResource() {
        if (cost<=getResourceType().getCurrent())
            return true;
        else
            return false;
    }

    @Override
    public int maximumCount() {
        return 30;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public void upgrade() {
        getResourceType().minusCurrent(cost);
        ZombieBuilder.getInstance().builder.attAddition+=variable;
        count++;
        setCost();
    }

    @Override
    public int getIndex(){
        return index;
    }
}
