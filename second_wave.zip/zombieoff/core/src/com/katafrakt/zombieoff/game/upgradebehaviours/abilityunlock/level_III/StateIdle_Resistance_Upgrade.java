package com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_III;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.StateType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit.StateOnly;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.ReductionEffect;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.player.ZombieBuilder;

public class StateIdle_Resistance_Upgrade implements ResourceUpgrade {
    public static final String TAG=StateIdle_Resistance_Upgrade.class.getSimpleName();
    int index= UpgradeManager.setIndex();
    int count;

    float[] cost=new float[]{10,15,20,25,30};
    float[] value=new float[]{5,10,20,30,50};
    float[] energy=new float[]{1,1,2,3,4};


    AbilityCreator abilityCreator=new AbilityCreator() {
        @Override
        public AbilityController getAbility() {
            return StateOnly.pool.obtain().init(ReductionEffect.pool.obtain().init(value[count]), StateType.IDLE);
        }
    };


    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().GENE;
    }

    @Override
    public String getName() {
        if (count==0)
            return "Get reduction while idling "+(count);
        else if (count<maximumCount())
            return "Get reduction while idling "+(count)+" -> "+(count+1);
        else
            return "Get reduction while idling "+(count);
    }

    @Override
    public String effect() {
        if (count==0)
            return "Reduction increases by "+value[count]+" while idling\nEnergy requirement: "+energy[count];
        else if (count<maximumCount())
            return "Reduction increases by "+value[count-1]+" -> "+value[count]+" while idling\nEnergy requirement: "+energy[count-1]+" -> "+energy[count];
        else
            return "Reduction increases by "+value[count-1]+" while idling\nEnergy requirement: "+energy[count-1];
    }

    @Override
    public float requiredResource() {
        return cost[count];
    }

    @Override
    public boolean enoughResource() {
        if (requiredResource()<=getResourceType().getCurrent())
            return true;
        else return false;
    }

    @Override
    public int maximumCount() {
        return 5;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        getResourceType().minusCurrent(requiredResource());

        if (count==0){
            abilityCreator.index=index;
            abilityCreator.name="Get reduction while idling";
            ZombieBuilder.getInstance().abilityCreators.add(abilityCreator);
        }
        abilityCreator.level=count+1;
        abilityCreator.energy=energy[count];
        abilityCreator.effect="Reduction increases by "+value[count]+" while idling";

        count++;
    }

    @Override
    public int getIndex() {
        return index;
    }
}
