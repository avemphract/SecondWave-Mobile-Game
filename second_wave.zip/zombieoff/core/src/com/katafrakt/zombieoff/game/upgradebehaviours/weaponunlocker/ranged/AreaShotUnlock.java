package com.katafrakt.zombieoff.game.upgradebehaviours.weaponunlocker.ranged;

public class AreaShotUnlock {
    public static final String NAME = AreaShotUnlock.class.getSimpleName();
}
