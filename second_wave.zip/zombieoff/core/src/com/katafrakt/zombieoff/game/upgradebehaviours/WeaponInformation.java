package com.katafrakt.zombieoff.game.upgradebehaviours;

import com.katafrakt.zombieoff.game.weapons.Weapon;

public abstract class WeaponInformation implements WeaponCreator {
    public enum Type{Melee(),Area(),Ranged()}

    public float index;
    public float energy;

    public String name;
    public Type type;

    public String damage;
    public String attRate;
    public String range;

    public String detail;

}
