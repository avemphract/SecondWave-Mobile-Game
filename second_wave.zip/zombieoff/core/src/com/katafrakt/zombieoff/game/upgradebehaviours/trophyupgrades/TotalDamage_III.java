package com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades;

import com.katafrakt.zombieoff.game.upgradebehaviours.TrophyUpgrade;
import com.katafrakt.zombieoff.player.PlayerStatics;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.ui.desicions.ChangeInterface;

public class TotalDamage_III implements TrophyUpgrade {
    public static final String NAME = TotalDamage_III.class.getName();
    int index = UpgradeManager.setIndex();
    int count;
    float cost;

    @Override
    public String requirementName() {
        return "Total damage";
    }

    @Override
    public float currentResource() {
        return PlayerStatics.getInstance().totalDamage.get();
    }

    @Override
    public void adjustEvent(ChangeInterface changeInterface) {
        PlayerStatics.EventFloat.addListener(PlayerStatics.getInstance().totalDamage,changeInterface);
    }

    @Override
    public String getName() {
        return "Devastator";
    }

    @Override
    public String effect() {
        return "+%12 Damage";
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public boolean enoughResource() {
        return false;//Todo:
    }

    @Override
    public int maximumCount() {
        return 1;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        //Todo:
    }

    @Override
    public int getIndex() {
        return index;
    }
}
