package com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_lV;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;

public class AttackTo_Freeze_I implements ResourceUpgrade {
    @Override
    public ResourceAbstract getResourceType() {
        return null;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public String effect() {
        return null;
    }

    @Override
    public float requiredResource() {
        return 0;
    }

    @Override
    public boolean enoughResource() {
        return false;
    }

    @Override
    public int maximumCount() {
        return 0;
    }

    @Override
    public int currentCount() {
        return 0;
    }

    @Override
    public void upgrade() {

    }

    @Override
    public int getIndex() {
        return 0;
    }
}
