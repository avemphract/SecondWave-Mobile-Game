package com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.resource;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;

public class BloodTickle_I implements ResourceUpgrade {
    public static final String NAME= BloodTickle_I.class.getName();
    int index= UpgradeManager.setIndex();
    int count;
    float value=1f;
    float cost;


    private void setCost() {
        cost=(count+3)*200;
    }

    @Override
    public String getName() {
        return "Blood Transfer";
    }

    @Override
    public String effect() {
        return "+1 Gain Rate";
    }


    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().BLOOD;
    }

    @Override
    public boolean enoughResource() {
        if (cost<=getResourceType().getCurrent())
            return true;
        else
            return false;
    }

    @Override
    public int maximumCount() {
        return 10;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public void upgrade() {
        getResourceType().minusCurrent(cost);
        ResourceType.getInstance().BLOOD.addProductionRate+=value;
        count++;
        setCost();
    }

    @Override
    public int getIndex() {
        return index;
    }
}
