package com.katafrakt.zombieoff.game.upgradebehaviours;

import com.katafrakt.zombieoff.game.weapons.Weapon;

public interface WeaponCreator {
    public Weapon getWeapon();
}
