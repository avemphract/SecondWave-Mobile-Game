package com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.attack;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.player.ZombieBuilder;

public class ZombieAttack_IV implements ResourceUpgrade {
    public static final String NAME = ZombieAttack_IV.class.getName();
    int index= UpgradeManager.setIndex();
    int count;
    float cost;
    int variable=10;

    public void setCost(){
        cost=(count+5)*300;
    }

    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().BLOOD;
    }

    @Override
    public String getName() {
        return "Spiky Teeth";
    }

    @Override
    public String effect() {
        return "+"+variable+" Zombie attack";
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public boolean enoughResource() {
        if (cost<=getResourceType().getCurrent())
            return true;
        else
            return false;
    }

    @Override
    public int maximumCount() {
        return 30;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        getResourceType().minusCurrent(cost);
        ZombieBuilder.getInstance().builder.attAddition+=variable;
        count++;
        setCost();
    }

    @Override
    public int getIndex() {
        return index;
    }
}
