package com.katafrakt.zombieoff.game.weapons.hitbehaviour;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ashley.components.BoundComponent;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.creatures.BulletComponent;
import com.katafrakt.zombieoff.entities.BulletOwner;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.utilities.Utility;

public class MultiTargetHitBehaviour implements HitBehaviour {
    public static Pool<MultiTargetHitBehaviour> pool=new Pool<MultiTargetHitBehaviour>() {
        @Override
        protected MultiTargetHitBehaviour newObject() {
            return new MultiTargetHitBehaviour();
        }
    };

    int count;
    Array<Entity> creatures=new Array<>();
    public MultiTargetHitBehaviour(){}
    public MultiTargetHitBehaviour(int count){
        this.count=count;
    }
    public MultiTargetHitBehaviour init(int count){
        this.count=count;
        creatures.clear();
        return this;
    }
    @Override
    public void hit(BulletComponent bulletComponent) {
        TransformComponent transform= Mappers.transformComponents.get(bulletComponent.entity);
        Array<Point> points= Utility.pointArrayPool.obtain();
        points=MapManager.getInstance().pointGraph.getAreaPoints(points,MapManager.getInstance().pointGraph.nearestPoint(transform.pos),2);
        for (Point point:points){
            if (bulletComponent.bulletOwner == BulletOwner.HUMAN_BULLET){
                creatures.addAll(point.zombies);
            }
            else {
                creatures.addAll(point.humans);
            }
        }
        Utility.pointArrayPool.free(points);
        for (Entity entity:creatures){
            TransformComponent targetTransform= entity.getComponent(TransformComponent.class);
            BoundComponent targetBound= entity.getComponent(BoundComponent.class);
            if (targetTransform.pos.x-targetBound.width/2<transform.pos.x && transform.pos.x<targetTransform.pos.x+targetBound.width/2){
                if (targetTransform.pos.y-targetBound.height/2<transform.pos.y && transform.pos.y<targetTransform.pos.y+targetBound.height/2){
                    for (AbilityController abilityController:bulletComponent.abilityControllers)
                        Mappers.agentComponents(entity).addAbility(abilityController);

                    Mappers.creatureComponents.get(entity).takeDamageBlood(bulletComponent.damage);
                    count--;
                    if (count<=0)
                        break;
                }
            }
        }//for

    }

    @Override
    public HitBehaviour clone() {
        MultiTargetHitBehaviour areaEffectHitBehaviour=pool.obtain();
        areaEffectHitBehaviour.init(count);
        return areaEffectHitBehaviour;
    }

    @Override
    public Pool getPool() {
        return pool;
    }
}
