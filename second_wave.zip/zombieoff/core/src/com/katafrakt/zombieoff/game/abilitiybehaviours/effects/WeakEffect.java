package com.katafrakt.zombieoff.game.abilitiybehaviours.effects;

import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;

public class WeakEffect extends AbilityEffect<WeakEffect> {
    public static Pool<WeakEffect> pool=new Pool<WeakEffect>() {
        @Override
        protected WeakEffect newObject() {
            return new WeakEffect();
        }
    };


    public WeakEffect() {
        name="Weakened";
    }
    public WeakEffect init(float value){
        this.value=value;
        return this;
    }

    @Override
    public void entryEffect(AgentComponentV2 agent) {
        agent.creature.extraDamage+=-value;
    }

    @Override
    public void tickEffect(AgentComponentV2 agent) {

    }

    @Override
    public void leaveEffect(AgentComponentV2 agent) {
        agent.creature.extraDamage+=-value;
    }

    @Override
    public WeakEffect clone() {
        return pool.obtain().init(value);
    }

    @Override
    public Pool<WeakEffect> getPool() {
        return pool;
    }

    @Override
    public void free() {
        pool.free(this);
    }

}
