package com.katafrakt.zombieoff.game;

import com.katafrakt.zombieoff.game.resources.Blood;
import com.katafrakt.zombieoff.game.resources.Brain;
import com.katafrakt.zombieoff.game.resources.Energy;
import com.katafrakt.zombieoff.game.resources.Gene;
import com.katafrakt.zombieoff.game.resources.Prestige;
import com.katafrakt.zombieoff.managers.PreferenceManager;


public class ResourceType {
    /*ENERGY{
        //Production when update
        public float initProductionRate=100;               //1
        public float addProductionRate;                     //2
        public float multiplierProductionRate;          //3
        public float multiplierProductionRateTrophy;    //4

        public float getProduction(float delta){
            return ( initProductionRate + addProductionRate ) * (multiplierProductionRate + 1) * (multiplierProductionRateTrophy + 1) * delta;
        }

        @Override
        public float getVariable(int i){
            if (i==0)
                return 4;
            else if (i==ENERGY_INIT_PRODUCTION_RATE)
                return initProductionRate;
            else if (i==ENERGY_ADD_PRODUCTION_RATE)
                return addProductionRate;
            else if (i== ENERGY_MULTIPLIER_PRODUCTION_RATE)
                return multiplierProductionRate;
            else if (i == ENERGY_MULTIPLIER_PRODUCTION_RATE_TROPHY)
                return multiplierProductionRateTrophy;
            else {
                Gdx.app.log(TAG,"Wrong get variable");
                return 0;
            }
        }

        @Override
        public void setVariable(int i, float variable){
            if (i==ENERGY_INIT_PRODUCTION_RATE)
                initProductionRate = variable;
            else if (i==ENERGY_ADD_PRODUCTION_RATE)
                addProductionRate = variable;
            else if (i== ENERGY_MULTIPLIER_PRODUCTION_RATE)
                multiplierProductionRate = variable;
            else if (i== ENERGY_MULTIPLIER_PRODUCTION_RATE_TROPHY)
                multiplierProductionRateTrophy = variable;
            else {
                Gdx.app.log(TAG,"Wrong set variable");
            }
        }

    },
    BLOOD{
        public float addProductionRate=10;                   //1
        public float multiplierProductionRatePrestige; //2
        public float zombieGainRate;                    //3

        public float getProduction(float delta){
            return addProductionRate * (multiplierProductionRatePrestige + 1) *delta;
        }

        @Override
        public float getVariable(int i) {
            if (i==0)
                return 3;
            else if (i == BLOOD_ADD_PRODUCTION_RATE)
                return addProductionRate;
            else if (i == BLOOD_MULTIPLIER_PRODUCTION_PRESTIGE)
                return multiplierProductionRatePrestige;
            else if (i == BLOOD_ZOMBIE_GAIN_RATE)
                return zombieGainRate;
            else {
                Gdx.app.log(TAG,"Wrong get variable");
                return 0;
            }
        }

        @Override
        public void setVariable(int i, float variable) {
            if (i == BLOOD_ADD_PRODUCTION_RATE)
                addProductionRate = variable;
            else if (i == BLOOD_MULTIPLIER_PRODUCTION_PRESTIGE)
                multiplierProductionRatePrestige = variable;
            else if (i == BLOOD_ZOMBIE_GAIN_RATE)
                zombieGainRate = variable;
            else {
                Gdx.app.log(TAG,"Wrong set variable");
            }
        }
    },
    GENE {
        float geneAddProduction=2f;
        @Override
        public float getProduction(float deltaTime) {
            return geneAddProduction*deltaTime;
        }

        @Override
        public float getVariable(int i) {
            if (i == 0)
                return 1;
            if (i == GENE_ADD_PRODUCTION)
                return geneAddProduction;
            else {
                Gdx.app.log(TAG,"Wrong get variable");
                return 0;
            }
        }

        @Override
        public void setVariable(int i, float variable) {
            if (i == GENE_ADD_PRODUCTION)
                geneAddProduction=variable;
            else {
                Gdx.app.log(TAG,"Wrong set variable");
            }
        }
    },
    PRESTIGE {
        @Override
        public float getProduction(float deltaTime) {
            return 0;
        }

        @Override
        public void setVariable(int i, float variable) {

        }
    };

    private static final String TAG = ResourceType.class.getSimpleName();

    public boolean isAvailable;

    public float initial;

    public float capacity;
    public float addCapacity;
    public float multiplierCapacity;
    public float multiplierCapacityPrestige;
    public float multiplierCapacityTrophy;//EnergySpend TotalBlood

    public float efficient=1;
    public float efficientTrophy=1;
    public float efficientPrestige=1;

    private float current=100;

    public void set(boolean isAvailable, float initial, float additional, float multiplier,float prestigeMultiplier, float trophyMultiplier, float current) {
        this.isAvailable = isAvailable;
        this.initial = initial;
        this.addCapacity = additional;
        this.multiplierCapacity = multiplier;
        this.multiplierCapacityPrestige=prestigeMultiplier;
        this.multiplierCapacityTrophy = trophyMultiplier;
        setCapacity();

        this.current = current;

    }

    public float getCurrent() {
        return current;
    }

    public void addCurrent(float addition) {
        current+=addition*(efficient + efficientPrestige + efficientTrophy);
        if (this == ResourceType.BLOOD){
            PlayerStatics.getInstance().totalBlood.add(addition);
            //PlayerStatics.getInstance().totalBlood+=addition;//TotalBlood
        }
        if (current>capacity)
            current=capacity;
    }

    public void minusCurrent(float subtraction){
        current-=subtraction;
        if (this == ResourceType.ENERGY){
            PlayerStatics.getInstance().spendEnergy.add(subtraction);
            //PlayerStatics.getInstance().spendEnergy+=subtraction;//SpendEnergy
        }
    }

    public void setCapacity(){
        capacity=(initial+ addCapacity) * (multiplierCapacity+1) * (multiplierCapacityTrophy+1)*(multiplierCapacityPrestige+1);
    }

    public abstract float getProduction(float deltaTime);

    public float getVariable(int i){
        if (i==0)
            return 0;
        else {
            Gdx.app.log(TAG,"Empty variables");
            return -1;
        }
    }

    public abstract void setVariable(int i, float variable);

    public static final float ENERGY_INITIAL_CAPACITY=10;
    public static final float BLOOD_INITIAL_CAPACITY=1000;
    public static final float GENE_INITIAL_CAPACITY=100;

    public static final int ENERGY_INIT_PRODUCTION_RATE=1;
    public static final int ENERGY_ADD_PRODUCTION_RATE=2;
    public static final int ENERGY_MULTIPLIER_PRODUCTION_RATE =3;
    public static final int ENERGY_MULTIPLIER_PRODUCTION_RATE_TROPHY=4;


    public static final int BLOOD_ADD_PRODUCTION_RATE=1;
    public static final int BLOOD_MULTIPLIER_PRODUCTION_PRESTIGE =2;
    public static final int BLOOD_ZOMBIE_GAIN_RATE=3;

    public static final int GENE_ADD_PRODUCTION=1;*/

    private static ResourceType resourceType;
    private ResourceType(){
        ENERGY=new Energy();
        BLOOD=new Blood();
        BRAIN=new Brain();
        GENE=new Gene();
        PRESTIGE=new Prestige();
    }
    public static ResourceType getInstance(){if (resourceType==null)resourceType=new ResourceType();return resourceType;}
    public Energy ENERGY;
    public Blood BLOOD;
    public Brain BRAIN;
    public Gene GENE;

    public Prestige PRESTIGE;

    public void dispose() {
        BLOOD.saveValues();
        ENERGY.saveValues();
        BRAIN.saveValues();
        GENE.saveValues();
        PRESTIGE.saveValues();
        PreferenceManager.getInstance().prefs.flush();
    }
}
