package com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit;

import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.graphics.FloatingTextComponent;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.AbilityEffect;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.weapons.Weapon;

public class Stack extends AbilityController<Stack> {
    public static Pool<Stack> pool=new Pool<Stack>() {
        @Override
        protected Stack newObject() {
            return new Stack();
        }
    };
    public AbilityCreator abilityCreator;
    public AttackToStack attackToStack;

    public Stack init(AbilityCreator abilityCreator,AttackToStack attackToStack, AbilityEffect<?> abilityEffect, int stackLimit){
        this.abilityEffect=abilityEffect;
        this.abilityCreator=abilityCreator;
        this.attackToStack=attackToStack;

        types.clear();
        types.add(Type.UPDATE);
        return this;
    }
    @Override
    public void enter(AgentComponentV2<? extends Weapon> agentComponent) {
        abilityEffect.entryEffect(agentComponent);
        agentComponent.abilities.get(Type.UPDATE).removeValue(this,false);
        FloatingTextComponent floatingTextComponent= Mappers.floatingTextComponents.get(agentComponent.entity);
        if (floatingTextComponent!=null)
            floatingTextComponent.addText(abilityEffect.name,1f);


    }

    @Override
    public void update(AgentComponentV2<? extends Weapon> agentComponent, Type type) {
        if (type==Type.UPDATE){
            if (agentComponent.stacks.get(abilityCreator).size<attackToStack.stackLimit)
                enter(agentComponent);
            else
                agentComponent.abilities.get(Type.UPDATE).removeValue(this,false);
        }
    }

    @Override
    public void leave(AgentComponentV2<? extends Weapon> agentComponent) {

    }

    @Override
    public Pool<Stack> getPool() {
        return pool;
    }
}
