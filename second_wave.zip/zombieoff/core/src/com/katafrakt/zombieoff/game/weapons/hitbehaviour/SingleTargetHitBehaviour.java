package com.katafrakt.zombieoff.game.weapons.hitbehaviour;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ashley.components.BoundComponent;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.creatures.BulletComponent;
import com.katafrakt.zombieoff.entities.BulletOwner;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.managers.MapManager;

public class SingleTargetHitBehaviour implements HitBehaviour {
    private static final String TAG=SingleTargetHitBehaviour.class.getSimpleName();
    public static Pool<SingleTargetHitBehaviour> pool= new Pool<SingleTargetHitBehaviour>() {
        @Override
        protected SingleTargetHitBehaviour newObject() {
            return new SingleTargetHitBehaviour();
        }
    };

    public SingleTargetHitBehaviour(){}
    @Override
    public void hit(BulletComponent bulletComponent) {
        Array<Entity> creatures=new Array<>();

        creatures.clear();
        TransformComponent transform=Mappers.transformComponents.get(bulletComponent.entity);
        Array<Point> points=MapManager.getInstance().pointGraph.nearestPoint(transform.pos.x,transform.pos.y).rangeArrayMap.get(2);//MapManager.getInstance().pointGraph.getAreaPoints(points,MapManager.getInstance().pointGraph.nearestPoint(transform.pos),2);
        for (Point point:points){
            if (bulletComponent.bulletOwner == BulletOwner.HUMAN_BULLET){
                creatures.addAll(point.zombies);
            }
            else {
                creatures.addAll(point.humans);
            }
        }

        for (Entity targetEntity: creatures){
            TransformComponent targetTransform= Mappers.transformComponents.get(targetEntity);
            BoundComponent targetBound= Mappers.boundComponents.get(targetEntity);
            if (targetTransform.pos.x-targetBound.width/2<transform.pos.x && transform.pos.x<targetTransform.pos.x+targetBound.width/2){
                if (targetTransform.pos.y-targetBound.height/2<transform.pos.y && transform.pos.y<targetTransform.pos.y+targetBound.height/2){
                    for (AbilityController abilityController:bulletComponent.abilityControllers)
                        Mappers.agentComponentV2(targetEntity).addAbility(abilityController);
                    Mappers.creatureComponents.get(targetEntity).takeDamageBlood(bulletComponent.damage);
                    break;
                }
            }
        }//for
    }

    @Override
    public HitBehaviour clone() {
        return pool.obtain();
    }

    @Override
    public Pool getPool() {
        return pool;
    }
}
