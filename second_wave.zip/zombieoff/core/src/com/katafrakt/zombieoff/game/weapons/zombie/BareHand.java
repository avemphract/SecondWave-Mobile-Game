package com.katafrakt.zombieoff.game.weapons.zombie;

import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.game.weapons.MeleeWeapon;

public class BareHand extends MeleeWeapon {
    public BareHand() {
        super(2, 1,1);
    }

    @Override
    public void attack(CreatureComponent attacker, CreatureComponent target) {

    }
}
