package com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades;

import com.katafrakt.zombieoff.game.upgradebehaviours.TrophyUpgrade;
import com.katafrakt.zombieoff.player.PlayerStatics;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.ui.desicions.ChangeInterface;

public class TotalImprovement_IV implements TrophyUpgrade {
    public static final String NAME=TotalImprovement_IV.class.getName();
    int index = UpgradeManager.setIndex();
    int count;
    float cost;

    @Override
    public String requirementName() {
        return "Reach total improvements";
    }

    @Override
    public float currentResource() {
        return PlayerStatics.getInstance().totalImprovement.get();
    }

    @Override
    public void adjustEvent(ChangeInterface changeInterface) {
        PlayerStatics.EventFloat.addListener(PlayerStatics.getInstance().totalImprovement,changeInterface);
    }

    @Override
    public String getName() {
        return "Master";
    }

    @Override
    public String effect() {
        return "-%10 Imp cost reduc";
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public boolean enoughResource() {
        return false;
    }

    @Override
    public int maximumCount() {
        return 1;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        //Sonra
    }

    @Override
    public int getIndex() {
        return index;
    }
}
