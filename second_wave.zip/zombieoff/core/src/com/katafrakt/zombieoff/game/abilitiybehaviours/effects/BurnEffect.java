package com.katafrakt.zombieoff.game.abilitiybehaviours.effects;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.game.abilitiybehaviours.StatusTypes;

public class BurnEffect extends AbilityEffect<BurnEffect> {
    private static final String TAG=BurnEffect.class.getSimpleName();
    public static Pool<BurnEffect> pool=new Pool<BurnEffect>() {
        @Override
        protected BurnEffect newObject() {
            return new BurnEffect();
        }
    };

    public BurnEffect(){
        name="Burn effect";
    }

    public BurnEffect init(float value) {
        this.value=value;
        return this;
    }

    @Override
    public void entryEffect(AgentComponentV2 agent) {
        Gdx.app.log(TAG,"Burn Effect entry");
    }

    @Override
    public void tickEffect(AgentComponentV2 agent) {
        Mappers.particleComponents.get(agent.entity).addStatus(StatusTypes.BURNING).getEmitters().first().addParticles(1);

        agent.creature.takeDamageBloodless((agent.creature.maxHp*value* Gdx.graphics.getDeltaTime()));
    }

    @Override
    public void leaveEffect(AgentComponentV2 agent) {
    }

    @Override
    public BurnEffect clone() {
        return pool.obtain().init(value);
    }

    @Override
    public Pool<BurnEffect> getPool() {
        return pool;
    }

    @Override
    public void free() {
        pool.free(this);
    }

}
