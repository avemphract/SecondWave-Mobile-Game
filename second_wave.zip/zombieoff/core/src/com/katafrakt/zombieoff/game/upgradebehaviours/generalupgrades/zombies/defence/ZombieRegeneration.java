package com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.defence;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;

//Increase Regen
public class ZombieRegeneration implements ResourceUpgrade {
    public static final String NAME = ZombieRegeneration.class.getName();
    int index= UpgradeManager.setIndex();
    int count;
    float cost;

    private void setCost(){
        cost=count*800;
    }
    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().BLOOD;
    }

    @Override
    public String getName() {
        return "Live cells";
    }

    @Override
    public String effect() {
        return "+0.2% health regen per second";
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public boolean enoughResource() {
        if (cost<=getResourceType().getCurrent())
            return true;
        else
            return false;
    }

    @Override
    public int maximumCount() {
        return 10;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        getResourceType().minusCurrent(cost);
        //ToDo
        count++;
        setCost();
    }

    @Override
    public int getIndex() {
        return index;
    }
}
