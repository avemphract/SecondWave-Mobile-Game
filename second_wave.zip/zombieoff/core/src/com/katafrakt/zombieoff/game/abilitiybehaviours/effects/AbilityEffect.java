package com.katafrakt.zombieoff.game.abilitiybehaviours.effects;

import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;

import org.jetbrains.annotations.NotNull;

public abstract class AbilityEffect<T extends AbilityEffect<?>> implements Comparable<AbilityEffect<?>> {
    public float value;
    public String name;

    public abstract void entryEffect(AgentComponentV2<?> agent);
    public abstract void tickEffect(AgentComponentV2<?> agent);
    public abstract void leaveEffect(AgentComponentV2<?> agent);
    public abstract T clone();
    public abstract Pool<T> getPool();
    public abstract void free();

    @Override
    public int compareTo(@NotNull AbilityEffect<?> abilityEffect) {
        if (value>abilityEffect.value)
            return 1;
        else if (value<abilityEffect.value)
            return -1;
        return 0;
    }
}
