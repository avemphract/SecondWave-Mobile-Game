package com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_III;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit.GetAttackedOnly;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.AwareIncEffect;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.player.ZombieBuilder;

public class GetAttacked_Aware_Upgrade implements ResourceUpgrade {
    public static final String NAME = GetAttacked_Aware_Upgrade.class.getSimpleName();
    int index= UpgradeManager.setIndex();
    int count;

    float[] cost=new float[]{10,15,20,25,30};
    int[] value=new int[]{2,4,6,8,10};
    float[] energy=new float[]{1,1,2,3,4};

    AbilityCreator abilityCreator =new AbilityCreator() {
        @Override
        public AbilityController getAbility() {
            return GetAttackedOnly.pool.obtain().init(AwareIncEffect.pool.obtain().init(value[count]));
        }
    };

    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().GENE;
    }

    @Override
    public String getName() {
        if (count==0)
            return "Increase aware range when get attacked "+(count+1);
        else if (count<maximumCount())
            return "Increase aware range when get attacked "+(count)+" -> "+(count+1);
        else
            return "Increase aware range when get attacked "+(count);
    }

    @Override
    public String effect() {
        if (count==0)
            return "Aware radius increases by "+1+" per attacked and limit "+value[count]+"\nEnergy requirement: "+energy[count];
        else if (count<maximumCount())
            return "Aware radius increases by "+1+" per attacked and limit "+value[count-1]+" -> "+value[count]+"\nEnergy requirement: "+energy[count-1]+" -> "+energy[count];
        else
            return "Aware radius increases by "+1+" per attacked and limit "+value[count-1]+"\nEnergy requirement: "+energy[count-1];
    }

    @Override
    public float requiredResource() {
        return cost[count];
    }

    @Override
    public boolean enoughResource() {
        if (requiredResource()<=getResourceType().getCurrent())
            return true;
        else return false;
    }

    @Override
    public int maximumCount() {
        return 5;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        getResourceType().minusCurrent(requiredResource());

        if (count==0){
            abilityCreator.index=index;
            abilityCreator.name="Fire explosion when died";
            ZombieBuilder.getInstance().abilityCreators.add(abilityCreator);
        }
        abilityCreator.level=count+1;
        abilityCreator.energy=energy[count];
        abilityCreator.effect = "Aware radius increase by "+1+" per attacked and limit "+value[count]+"\nEnergy requirement: "+energy[count];

        count++;
    }

    @Override
    public int getIndex() {
        return 0;
    }
}
