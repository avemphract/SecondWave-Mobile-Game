package com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.defence;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;

public class ZombieSpawnRate_E implements ResourceUpgrade {
    public static final String NAME=ZombieSpawnRate_E.class.getName();
    int index = UpgradeManager.setIndex();
    int count;
    float cost;
    int value=1;

    private void setCost(){
        cost=(count)*500;
    }

    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().BLOOD;
    }

    @Override
    public String getName() {
        return "Spawn focused";
    }

    @Override
    public String effect() {
        return "+1 spawn rate per energy";
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public boolean enoughResource() {
        if (cost<=getResourceType().getCurrent())
            return true;
        else
            return false;
    }

    @Override
    public int maximumCount() {
        return 10;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        getResourceType().minusCurrent(cost);
        //ToDo
        count++;
        setCost();
    }

    @Override
    public int getIndex() {
        return index;
    }
}
