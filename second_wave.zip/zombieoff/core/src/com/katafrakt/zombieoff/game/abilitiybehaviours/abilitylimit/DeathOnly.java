package com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit;

import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.AbilityEffect;
import com.katafrakt.zombieoff.game.weapons.Weapon;

public class DeathOnly extends AbilityController<DeathOnly> {
    private static final String TAG=DeathOnly.class.getSimpleName();
    public static Pool<DeathOnly> pool=new Pool<DeathOnly>() {
        @Override
        protected DeathOnly newObject() {
                return new DeathOnly();
        }
    };

    public DeathOnly(){}

    public DeathOnly init(AbilityEffect<?> abilityEffect) {
        this.abilityEffect=abilityEffect;
        types.clear();
        types.add(Type.DIED);
        isActive=false;
        return this;
    }

    @Override
    public void enter(AgentComponentV2<? extends Weapon> agentComponent) {
        abilityEffect.entryEffect(agentComponent);
        isActive=true;
    }

    @Override
    public void update(AgentComponentV2<? extends Weapon> agentComponent, Type type) {
        if (type==Type.DIED){
            if (!isActive)
                abilityEffect.entryEffect(agentComponent);
            abilityEffect.tickEffect(agentComponent);
        }
    }

    @Override
    public void leave(AgentComponentV2<? extends Weapon> agentComponent) {

    }

    @Override
    public Pool<DeathOnly> getPool() {
        return pool;
    }
}
