package com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.graphics.FloatingTextComponent;
import com.katafrakt.zombieoff.game.StateType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.AbilityEffect;
import com.katafrakt.zombieoff.game.weapons.Weapon;

public class StateTimeLimit extends AbilityController<StateTimeLimit> {
    private static final String TAG=StateTimeLimit.class.getSimpleName();
    public static Pool<StateTimeLimit> pool=new Pool<StateTimeLimit>() {
        @Override
        protected StateTimeLimit newObject() {
            return new StateTimeLimit();
        }
    };
    StateType stateType;
    float time;
    float remainTime;

    public StateTimeLimit(){}

    public StateTimeLimit init(AbilityEffect<?> abilityEffect, StateType stateType, float time) {
        this.abilityEffect=abilityEffect;
        types.clear();
        types.add(Type.STATE);
        this.stateType=stateType;
        this.time=time;
        return this;
    }

    @Override
    public void enter(AgentComponentV2<? extends Weapon> agentComponent) {
        remainTime=time;
        isActive=true;
        types.add(Type.UPDATE);
        abilityEffect.entryEffect(agentComponent);
        agentComponent.abilities.get(Type.UPDATE).add(this);

        FloatingTextComponent floatingTextComponent= Mappers.floatingTextComponents.get(agentComponent.entity);
        if (floatingTextComponent!=null)
            floatingTextComponent.addText(abilityEffect.name,1f);

    }

    @Override
    public void update(AgentComponentV2<? extends Weapon> agentComponent, Type type) {
        Gdx.app.log(TAG,"isActive:"+isActive+" remainTime:"+remainTime);
        if (type==Type.STATE){
            if ((isActive)&&(stateType==agentComponent.currentState)){
                remainTime=time;
            }
            else if (stateType==agentComponent.currentState){
                enter(agentComponent);
            }
            else if (isActive){
                leave(agentComponent);
            }
        }
        else if (type==Type.UPDATE){
            remainTime-= Gdx.graphics.getDeltaTime();
            abilityEffect.tickEffect(agentComponent);
            if (remainTime<0){
                leave(agentComponent);
            }
        }

    }

    @Override
    public void leave(AgentComponentV2<? extends Weapon> agentComponent) {
        isActive=false;
        remainTime=0;
        types.removeValue(Type.UPDATE,false);
        abilityEffect.leaveEffect(agentComponent);
        agentComponent.abilities.get(Type.UPDATE).removeValue(this,false);
    }

    @Override
    public Pool<StateTimeLimit> getPool() {
        return pool;
    }
}
