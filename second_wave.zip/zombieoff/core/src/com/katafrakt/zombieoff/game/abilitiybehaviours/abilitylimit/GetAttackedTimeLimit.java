package com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.graphics.FloatingTextComponent;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.AbilityEffect;
import com.katafrakt.zombieoff.game.weapons.Weapon;

public class GetAttackedTimeLimit extends AbilityController<GetAttackedTimeLimit> {
    public static final String TAG=GetAttackedTimeLimit.class.getSimpleName();
    public static Pool<GetAttackedTimeLimit> pool=new Pool<GetAttackedTimeLimit>() {
        @Override
        protected GetAttackedTimeLimit newObject() {
            return new GetAttackedTimeLimit();
        }
    };

    float time;
    float remainTime;

    public GetAttackedTimeLimit init(AbilityEffect<?> abilityEffect,float time){
        this.abilityEffect=abilityEffect;
        types.clear();
        types.add(Type.GET_ATTACKED);
        this.time=time;
        return this;
    }

    @Override
    public void enter(AgentComponentV2<? extends Weapon> agentComponent) {
        abilityEffect.entryEffect(agentComponent);
        remainTime=time;
        types.add(Type.UPDATE);
        agentComponent.abilities.get(Type.UPDATE).add(this);
        isActive=true;

        FloatingTextComponent floatingTextComponent= Mappers.floatingTextComponents.get(agentComponent.entity);
        if (floatingTextComponent!=null)
            floatingTextComponent.addText(abilityEffect.name,1f);

    }

    @Override
    public void update(AgentComponentV2<? extends Weapon> agentComponent, Type type) {
        if (type==Type.GET_ATTACKED){
            if (!isActive){
                enter(agentComponent);
            }else {
                remainTime=time;
            }
        }
        else if (type==Type.UPDATE){
            remainTime-= Gdx.graphics.getDeltaTime();
            abilityEffect.tickEffect(agentComponent);
            if (remainTime<0)
                leave(agentComponent);
        }

    }

    @Override
    public void leave(AgentComponentV2<? extends Weapon> agentComponent) {
        abilityEffect.leaveEffect(agentComponent);
        agentComponent.abilities.get(Type.UPDATE).removeValue(this,false);
        types.removeValue(Type.UPDATE,false);
        isActive=false;
    }

    @Override
    public Pool<GetAttackedTimeLimit> getPool() {
        return pool;
    }
}
