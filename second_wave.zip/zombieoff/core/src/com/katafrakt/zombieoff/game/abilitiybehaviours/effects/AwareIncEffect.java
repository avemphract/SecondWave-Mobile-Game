package com.katafrakt.zombieoff.game.abilitiybehaviours.effects;

import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;

public class AwareIncEffect extends AbilityEffect<AwareIncEffect> {
    private static final String TAG=AwareIncEffect.class.getSimpleName();
    public static Pool<AwareIncEffect> pool=new Pool<AwareIncEffect>() {
        @Override
        protected AwareIncEffect newObject() {
            return new AwareIncEffect();
        }
    };

    int limit;
    int current;

    public AwareIncEffect(){
        name="Aware radius increase";
    }

    public AwareIncEffect init(int limit){
        this.limit=limit;
        return this;
    }


    @Override
    public void entryEffect(AgentComponentV2 agent) {
        if (current<limit){
            agent.awareRadius++;
            current++;
        }
    }

    @Override
    public void tickEffect(AgentComponentV2 agent) {

    }

    @Override
    public void leaveEffect(AgentComponentV2 agent) {
        if (current>0){
            agent.awareRadius--;
            current--;
        }
    }

    @Override
    public AwareIncEffect clone() {
        return pool.obtain().init(limit);
    }

    @Override
    public Pool<AwareIncEffect> getPool() {
        return pool;
    }

    @Override
    public void free() {
        pool.free(this);
    }
}
