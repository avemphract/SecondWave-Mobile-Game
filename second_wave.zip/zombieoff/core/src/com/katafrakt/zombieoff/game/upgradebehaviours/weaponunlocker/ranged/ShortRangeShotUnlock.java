package com.katafrakt.zombieoff.game.upgradebehaviours.weaponunlocker.ranged;

public class ShortRangeShotUnlock {
}
