package com.katafrakt.zombieoff.game.resources;

import com.badlogic.gdx.graphics.Color;
import com.katafrakt.zombieoff.managers.PreferenceManager;

public class Blood extends ResourceAbstract {

    final String NAME ="Blood";

    public float addProductionRate=10000;
    public float multiplierProductionRatePrestige;
    public float zombieGainRate;

    public Blood() {
        super(Color.SCARLET,100,true);
        loadValues();
        setCapacity();
    }

    @Override
    public String name() {
        return NAME;
    }


    @Override
    public float getProduction() {
        return addProductionRate*(multiplierProductionRatePrestige+1);
    }

    @Override
    public void saveValues() {
        PreferenceManager.getInstance().prefs.putFloat(ADD_CAPACITY,addCapacity);
        PreferenceManager.getInstance().prefs.putFloat(MULTIPLIER_CAPACITY_UPGRADE,multiplierCapacityUpgrade);
        PreferenceManager.getInstance().prefs.putFloat(MULTIPLIER_CAPACITY_PRESTIGE,multiplierCapacityPrestige);
        PreferenceManager.getInstance().prefs.putFloat(MULTIPLIER_CAPACITY_TROPHY,multiplierCapacityTrophy);

        PreferenceManager.getInstance().prefs.putFloat(EFFICIENT_TROPHY,efficientTrophy);
        PreferenceManager.getInstance().prefs.putFloat(EFFICIENT_PRESTIGE,efficientPrestige);

        PreferenceManager.getInstance().prefs.putFloat(CURRENT,current);

        PreferenceManager.getInstance().prefs.putFloat(ADD_PRODUCTION_RATE,addProductionRate);
        PreferenceManager.getInstance().prefs.putFloat(MULTIPLIER_PRODUCTION_RATE_PRESTIGE,multiplierProductionRatePrestige);
        PreferenceManager.getInstance().prefs.putFloat(ZOMBIE_GAIN_RATE,zombieGainRate);
    }

    @Override
    public void loadValues() {
        addCapacity = PreferenceManager.getInstance().prefs.getFloat(ADD_CAPACITY,addCapacity);
        multiplierCapacityUpgrade = PreferenceManager.getInstance().prefs.getFloat(MULTIPLIER_CAPACITY_UPGRADE,multiplierCapacityUpgrade);
        multiplierCapacityPrestige = PreferenceManager.getInstance().prefs.getFloat(MULTIPLIER_CAPACITY_PRESTIGE,multiplierCapacityPrestige);
        multiplierCapacityTrophy = PreferenceManager.getInstance().prefs.getFloat(MULTIPLIER_CAPACITY_TROPHY,multiplierCapacityTrophy);

        efficientTrophy = PreferenceManager.getInstance().prefs.getFloat(EFFICIENT_TROPHY,efficientTrophy);
        efficientPrestige = PreferenceManager.getInstance().prefs.getFloat(EFFICIENT_PRESTIGE,efficientPrestige);

        current = PreferenceManager.getInstance().prefs.getFloat(CURRENT,current);

        //addProductionRate = PreferenceManager.getInstance().prefs.getFloat(ADD_PRODUCTION_RATE,addProductionRate);
        multiplierProductionRatePrestige = PreferenceManager.getInstance().prefs.getFloat(MULTIPLIER_PRODUCTION_RATE_PRESTIGE,multiplierProductionRatePrestige);
        zombieGainRate = PreferenceManager.getInstance().prefs.getFloat(ZOMBIE_GAIN_RATE,zombieGainRate);

    }

    private static final String ADD_CAPACITY="BLOOD_ADD_CAPACITY";
    private static final String MULTIPLIER_CAPACITY_UPGRADE="BLOOD_MULTIPLIER_CAPACITY_UPGRADE";
    private static final String MULTIPLIER_CAPACITY_PRESTIGE="BLOOD_MULTIPLIER_CAPACITY_PRESTIGE";
    private static final String MULTIPLIER_CAPACITY_TROPHY="BLOOD_MULTIPLIER_CAPACITY_";

    private static final String EFFICIENT_TROPHY="BLOOD_EFFICIENT_TROPHY";
    private static final String EFFICIENT_PRESTIGE="BLOOD_EFFICIENT_PRESTIGE";

    private static final String CURRENT="BLOOD_CURRENT";

    private static final String ADD_PRODUCTION_RATE="BLOOD_ADD_PRODUCTION_RATE";
    private static final String MULTIPLIER_PRODUCTION_RATE_PRESTIGE="BLOOD_MULTIPLIER_PRODUCTION_RATE_PRESTIGE";
    private static final String ZOMBIE_GAIN_RATE="ZOMBIE_GAIN_RATE";
}
