package com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades;

import com.katafrakt.zombieoff.game.upgradebehaviours.TrophyUpgrade;
import com.katafrakt.zombieoff.player.PlayerStatics;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.ui.desicions.ChangeInterface;

public class TotalBlood_II implements TrophyUpgrade {
    public static final String NAME =TotalBlood_II.class.getName();
    int index = UpgradeManager.setIndex();
    int count;
    int cost=10000;

    @Override
    public String requirementName() {
        return "Gain Blood";
    }

    @Override
    public float currentResource() {
        return PlayerStatics.getInstance().totalBlood.get();//Sonra doldurulacak
    }

    @Override
    public void adjustEvent(ChangeInterface changeInterface) {
        PlayerStatics.EventFloat.addListener(PlayerStatics.getInstance().totalBlood,changeInterface);
    }

    @Override
    public String getName() {
        return "Gory";
    }

    @Override
    public String effect() {
        return "+%30 Blood capacity";
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public boolean enoughResource() {
        return false;//sonra dolduralacak
    }

    @Override
    public int maximumCount() {
        return 1;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        //Sonra doldurulacak
    }

    @Override
    public int getIndex() {
        return index;
    }
}
