package com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_I;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.StateType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit.StateTimeLimit;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.SpeedEffect;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.player.ZombieBuilder;

public class StateTimeFollow_Speed_Upgrade implements ResourceUpgrade {
    public static final String NAME = StateTimeFollow_Speed_Upgrade.class.getSimpleName();
    int index = UpgradeManager.setIndex();
    int count;
    float[] cost=new float[]{10,20,30,40,50};
    float[] value=new float[]{1,2,3,4,5};
    float[] energy=new float[]{1,1.5f,2,2.5f,3};

    float time=1;

    AbilityCreator abilityCreator=new AbilityCreator() {
        @Override
        public AbilityController getAbility() {
            return StateTimeLimit.pool.obtain().init(SpeedEffect.pool.obtain().init(value[count-1]), StateType.FOLLOW,time);
        }
    };

    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().GENE;
    }

    @Override
    public String getName() {
        if (count==0)
            return "Temporary speed follow state "+(count+1);
        else if (count<maximumCount())
            return "Temporary speed follow state "+(count)+"->"+(count+1);
        else
            return "Temporary speed follow state "+(count);
    }

    @Override
    public String effect() {
        if (count==0)
            return "Increase "+value[count]+" speed when enter follow state for 1 second\nEnergy requirement "+energy[count];
        else if (count<maximumCount())
            return "Increase "+value[count-1]+" -> "+value[count]+" speed when enter follow state for 1 second\nEnergy requirement "+energy[count-1]+"->"+energy[count];
        else
            return "Increase "+value[count-1]+" speed when enter follow state for 1 second\nEnergy requirement "+energy[count-1];

    }

    @Override
    public float requiredResource() {
        return cost[count];
    }

    @Override
    public boolean enoughResource() {
        if (requiredResource()<=getResourceType().getCurrent())
            return true;
        else return false;
    }

    @Override
    public int maximumCount() {
        return 5;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        getResourceType().minusCurrent(requiredResource());

        if (count==0){
            abilityCreator.index=index;
            abilityCreator.name="Temporary speed follow state I";
            ZombieBuilder.getInstance().abilityCreators.add(abilityCreator);
        }

        abilityCreator.level=count+1;
        abilityCreator.energy=energy[count];
        abilityCreator.effect="Increase "+value[count]+" speed when enter follow state for 1 second";

        count++;

    }

    @Override
    public int getIndex() {
        return index;
    }
}
