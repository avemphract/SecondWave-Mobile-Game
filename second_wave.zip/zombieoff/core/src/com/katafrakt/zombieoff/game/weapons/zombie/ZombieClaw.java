package com.katafrakt.zombieoff.game.weapons.zombie;

import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.game.weapons.MeleeWeapon;
import com.katafrakt.zombieoff.game.weapons.zombie.ranged.AcidicSpit;

public class ZombieClaw extends MeleeWeapon {
    public static final String NAME= AcidicSpit.class.getSimpleName();


    public ZombieClaw() {
        super(2f, 1, 1);
    }


    @Override
    public void attack(CreatureComponent attacker, CreatureComponent target) {
        target.takeDamageBlood(attacker.getDamage()*damageRatio);
    }

}
