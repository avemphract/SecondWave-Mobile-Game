package com.katafrakt.zombieoff.game.upgradebehaviours.prestige_upgrades;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;

public class ReduceSpawnCooldownPrestige implements ResourceUpgrade {
    private static final String TAG = ReduceSpawnCooldownPrestige.class.getSimpleName();
    int index = UpgradeManager.setIndex();
    int count;
    float cost;
    float value;

    private void setCost(){
        cost=count;
    }


    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().PRESTIGE;
    }

    @Override
    public String getName() {
        return "Reduce zombie cooldown  -0.1s";
    }

    @Override
    public String effect() {
        return "";
    }

    @Override
    public float requiredResource() {
        return 0;
    }

    @Override
    public boolean enoughResource() {
        return false;
    }

    @Override
    public int maximumCount() {
        return 0;
    }

    @Override
    public int currentCount() {
        return 0;
    }

    @Override
    public void upgrade() {

    }

    @Override
    public int getIndex() {
        return 0;
    }
}
