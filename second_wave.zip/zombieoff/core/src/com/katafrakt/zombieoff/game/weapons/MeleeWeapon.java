package com.katafrakt.zombieoff.game.weapons;

import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.game.abilitiybehaviours.CloneableAbilityController;

public class MeleeWeapon extends Weapon {
    public MeleeWeapon(float attackSpeed, float damageRatio, int range) {
        super(Type.MELEE,Recommended.MELEE, attackSpeed, damageRatio, range);
    }

    @Override
    public void attack(CreatureComponent attacker, CreatureComponent target) {
        target.takeDamageBlood(attacker.getDamage()*damageRatio);
        for (CloneableAbilityController<?> abilityController:abilityControllers){
            Mappers.agentComponentV2(target.entity).addAbility(abilityController.clone());
        }
        abilityControllers.clear();
    }
}
