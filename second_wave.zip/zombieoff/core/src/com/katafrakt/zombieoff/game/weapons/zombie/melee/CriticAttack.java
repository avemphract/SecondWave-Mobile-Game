package com.katafrakt.zombieoff.game.weapons.zombie.melee;

import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.weapons.MeleeWeapon;

public class CriticAttack extends MeleeWeapon {
    float criticOdds;
    float criticRatio;
    public CriticAttack(float attackSpeed,  float damageRatio, int range, float criticOdds, float criticRatio) {
        super(attackSpeed, damageRatio, range);
        this.criticOdds=criticOdds;
        this.criticRatio=criticRatio;
    }
    public CriticAttack(Level level){
        super(level.attackSpeed,level.damageRatio,level.range);
        this.criticOdds=level.criticOdds;
        this.criticRatio=level.criticRatio;
    }

    @Override
    public void attack(CreatureComponent attacker, CreatureComponent target) {
        for(AbilityController abilityController:abilityControllers)
            Mappers.agentComponents(target.entity).addAbility(abilityController);

        if (random.nextFloat()<criticRatio)
            target.takeDamageBlood(attacker.getDamage()*damageRatio);
        else
            target.takeDamageBlood(attacker.getDamage()*damageRatio*criticRatio);

    }

    public static class Level{
        public float attackSpeed;
        public float damageRatio;
        public int range;
        public float criticOdds;
        public float criticRatio;

        public Level(float attackSpeed, float damageRatio, int range, float criticOdds, float criticRatio) {
            this.attackSpeed = attackSpeed;
            this.damageRatio=damageRatio;
            this.range = range;
            this.criticOdds = criticOdds;
            this.criticRatio = criticRatio;
        }
    }
}
