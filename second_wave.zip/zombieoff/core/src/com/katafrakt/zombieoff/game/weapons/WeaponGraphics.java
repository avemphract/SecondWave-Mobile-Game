package com.katafrakt.zombieoff.game.weapons;

import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;

public class WeaponGraphics {
    public TextureRegion weaponTexture;
    public Vector2 firstHand;
    public Vector2 secondHand;
    public Vector2 position;
    public Vector2 origin;
    //public int width,height;

    public WeaponGraphics( TextureRegion weaponTexture, Vector2 firstHand, Vector2 secondHand, Vector2 position, Vector2 origin) {
        this.weaponTexture = weaponTexture;
        this.firstHand = firstHand;
        this.secondHand = secondHand;
        this.position=position;
        this.origin=origin;
    }
}
