package com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades;

import com.katafrakt.zombieoff.game.upgradebehaviours.TrophyUpgrade;
import com.katafrakt.zombieoff.player.PlayerStatics;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.ui.desicions.ChangeInterface;

public class TotalTrophies_III implements TrophyUpgrade {
    public static final String NAME=TotalTrophies_III.class.getName();
    int index = UpgradeManager.setIndex();
    int count;
    float cost;

    @Override
    public String requirementName() {
        return "Reach total trophies";
    }

    @Override
    public float currentResource() {
        return PlayerStatics.getInstance().totalTrophy.get();
    }

    @Override
    public void adjustEvent(ChangeInterface changeInterface) {
        PlayerStatics.EventFloat.addListener(PlayerStatics.getInstance().totalTrophy,changeInterface);
    }

    @Override
    public String getName() {
        return "Genius";
    }

    @Override
    public String effect() {
        return "Detail panel";
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public boolean enoughResource() {
        return false;//Sonra
    }

    @Override
    public int maximumCount() {
        return 1;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        //Sonra
    }

    @Override
    public int getIndex() {
        return index;
    }
}
