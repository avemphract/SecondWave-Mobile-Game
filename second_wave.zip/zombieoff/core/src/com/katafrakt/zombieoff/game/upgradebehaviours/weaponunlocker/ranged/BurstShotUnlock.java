package com.katafrakt.zombieoff.game.upgradebehaviours.weaponunlocker.ranged;

public class BurstShotUnlock {
    public static final String NAME = BurstShotUnlock.class.getSimpleName();
}
