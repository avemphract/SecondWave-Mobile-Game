package com.katafrakt.zombieoff.game.abilitiybehaviours;

import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.AbilityEffect;
import com.katafrakt.zombieoff.game.weapons.Weapon;

public abstract class AbilityController<T extends AbilityController<?>> implements Pool.Poolable {

    public enum Type{
        UPDATE,STATE,ATTACK,GET_ATTACKED,DIED
    }
    public AbilityEffect<?> abilityEffect;
    public boolean whenShutErase=false;
    public boolean isActive=false;
    public boolean isDefinitive=false;

    public Array<Type> types=new Array<>();

    public AbilityController(){

    }

    public abstract void enter(AgentComponentV2<? extends Weapon> agentComponent);
    public abstract void update(AgentComponentV2<? extends Weapon> agentComponent,Type type);
    public abstract void leave(AgentComponentV2<? extends Weapon> agentComponent);


    public abstract Pool<T> getPool();


    @Override
    public void reset() {
        abilityEffect.free();
    }
}
