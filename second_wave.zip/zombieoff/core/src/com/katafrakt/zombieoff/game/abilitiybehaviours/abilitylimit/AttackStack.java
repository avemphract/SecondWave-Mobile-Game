package com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit;

public class AttackStack {
}
