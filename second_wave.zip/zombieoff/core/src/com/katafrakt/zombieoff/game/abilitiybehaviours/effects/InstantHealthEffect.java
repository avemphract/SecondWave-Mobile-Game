package com.katafrakt.zombieoff.game.abilitiybehaviours.effects;

import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;

public class InstantHealthEffect extends AbilityEffect<InstantHealthEffect> {
    public static Pool<InstantHealthEffect> pool=new Pool<InstantHealthEffect>() {
        @Override
        protected InstantHealthEffect newObject() {
            return new InstantHealthEffect();
        }
    };



    public InstantHealthEffect init(float value){
        this.value=value;
        if (value>0)
            name="Heal";
        else
            name="Harm";


        return this;
    }

    @Override
    public void entryEffect(AgentComponentV2 agent) {
        agent.creature.currentHp+=value;

    }

    @Override
    public void tickEffect(AgentComponentV2 agent) {

    }

    @Override
    public void leaveEffect(AgentComponentV2 agent) {

    }

    @Override
    public InstantHealthEffect clone() {
        return pool.obtain().init(value);
    }

    @Override
    public Pool<InstantHealthEffect> getPool() {
        return pool;
    }

    @Override
    public void free() {
        pool.free(this);
    }
}
