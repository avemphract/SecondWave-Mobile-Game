package com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.attack;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;

public class ZombieAttackRate implements ResourceUpgrade {
    public static final String NAME = ZombieAttackRate.class.getName();
    int index = UpgradeManager.setIndex();
    float cost=100;
    int count=0;
    int value=1;

    private void setCost(){
        cost=250*count;
    }
    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().BLOOD;
    }

    @Override
    public String getName() {
        return "Flexible attacking";
    }

    @Override
    public String effect() {
        return "+%1 attack rate";
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public boolean enoughResource() {
        if (cost<=getResourceType().getCurrent())
            return true;
        else
            return false;
    }

    @Override
    public int maximumCount() {
        return 30;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        count++;
        setCost();
    }

    @Override
    public int getIndex() {
        return index;
    }
}
