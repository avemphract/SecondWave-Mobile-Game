package com.katafrakt.zombieoff.game.weapons;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.entities.BulletType;
import com.katafrakt.zombieoff.entities.bullets.Bullet;
import com.katafrakt.zombieoff.game.weapons.hitbehaviour.HitBehaviour;
import com.katafrakt.zombieoff.managers.BulletFactory;
import com.katafrakt.zombieoff.managers.EngineEdited;
import com.katafrakt.zombieoff.player.PlayerStatics;

public class ShotgunWeapon extends RangedWeapon {
    float size=2;
    int shotgunBullet;
    Vector3 base=new Vector3();
    Vector2[] bulletTargets;
    Bullet.Builder builder=new Bullet.Builder();
    Vector2 speed=new Vector2();

    public ShotgunWeapon(Recommended recommended, HitBehaviour hitBehaviour, float attackSpeed, float damageRatio, int range, float accuracy, float bulletVelocity, int shotgunBullet) {
        super(recommended, hitBehaviour,BulletType.LINE, attackSpeed, damageRatio, range, accuracy, bulletVelocity);
        this.shotgunBullet=shotgunBullet;
        bulletTargets=new Vector2[shotgunBullet];
        for (int i=0;i<bulletTargets.length;i++)
            bulletTargets[i]=new Vector2();
    }
    public ShotgunWeapon(Level level){
        super(level.recommended, level.hitBehaviour,BulletType.LINE, level.attackSpeed, level.damageRatio, level.range, level.accuracy, level.bulletVelocity);
        this.shotgunBullet=level.bulletCount;
        bulletTargets=new Vector2[shotgunBullet];
        for (int i=0;i<bulletTargets.length;i++)
            bulletTargets[i]=new Vector2();
    }
    public ShotgunWeapon(Level level,WeaponGraphics weaponGraphics){
        super(level.recommended, level.hitBehaviour,BulletType.LINE, level.attackSpeed, level.damageRatio, level.range, level.accuracy, level.bulletVelocity);
        this.shotgunBullet=level.bulletCount;
        bulletTargets=new Vector2[shotgunBullet];
        for (int i=0;i<bulletTargets.length;i++)
            bulletTargets[i]=new Vector2();
        this.weaponGraphics=weaponGraphics;
    }

    @Override
    public void attack(CreatureComponent attacker, CreatureComponent target) {
        TransformComponent transformComponent= Mappers.transformComponents.get(attacker.entity);
        TransformComponent targetTransform= Mappers.transformComponents.get(target.entity);

        getShotgunRandomizer(targetTransform.pos,transformComponent.pos,attacker.accuracy);
        for (int i=0;i<shotgunBullet;i++){
            PlayerStatics.getInstance().bulletFired.add(+1);
            speed.set(bulletTargets[i].x,bulletTargets[i].y);
            float time=speed.len()/bulletVelocity*base.z;
            speed=speed.scl(bulletVelocity/speed.len());
            builder.set(attacker.entityType.getBullet(),bulletType,hitBehaviour,transformComponent.pos.x,transformComponent.pos.y,2,2,speed,attacker.getDamage()*damageRatio,time,abilityControllers);
            BulletFactory.getInstance().createBullet(builder);
        }
    }

    public void getShotgunRandomizer(Vector2 target, Vector2 pos, float skill){
        base.set(bulletRandomizer(target, pos, skill));
        float ang=(random.nextFloat()+0.9f)*5;
        for (int i=0;i<shotgunBullet;i++){
            bulletTargets[i].set(base.x,base.y).rotate((shotgunBullet/2f-i)*ang);
        }
    }
    public static class Level{
        public Recommended recommended;
        public HitBehaviour hitBehaviour;
        public float attackSpeed;
        public float damageRatio;
        public int range;
        public float accuracy;
        public int bulletVelocity;
        public int bulletCount;

        public Level(Recommended recommended, HitBehaviour hitBehaviour, float attackSpeed, float damageRatio, int range, float accuracy, int bulletVelocity, int bulletCount) {
            this.recommended = recommended;
            this.hitBehaviour=hitBehaviour;
            this.attackSpeed = attackSpeed;
            this.damageRatio = damageRatio;
            this.range = range;
            this.accuracy = accuracy;
            this.bulletVelocity = bulletVelocity;
            this.bulletCount = bulletCount;
        }
    }
}
