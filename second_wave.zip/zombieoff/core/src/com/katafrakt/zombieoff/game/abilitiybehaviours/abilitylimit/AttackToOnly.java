package com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit;

import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.AbilityEffect;
import com.katafrakt.zombieoff.game.weapons.Weapon;

public class AttackToOnly extends AbilityController<AttackToOnly> {
    public static Pool<AttackToOnly> pool=new Pool<AttackToOnly>() {
        @Override
        protected AttackToOnly newObject() {
            return new AttackToOnly();
        }
    };

    public AttackToOnly init(AbilityEffect<?> abilityEffect){
        this.abilityEffect=abilityEffect;
        types.clear();
        types.add(Type.ATTACK);
        return this;
    }


    @Override
    public void enter(AgentComponentV2<? extends Weapon> agentComponent) {

    }

    @Override
    public void update(AgentComponentV2<? extends Weapon> agentComponent, Type type) {
        if (type == Type.ATTACK){
            agentComponent.primaryWeapon.abilityControllers.add(OneTime.pool.obtain().init(abilityEffect));
        }
    }

    @Override
    public void leave(AgentComponentV2<? extends Weapon> agentComponent) {

    }

    @Override
    public Pool<AttackToOnly> getPool() {
        return pool;
    }
}
