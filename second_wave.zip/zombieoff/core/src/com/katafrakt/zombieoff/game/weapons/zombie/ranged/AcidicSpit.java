package com.katafrakt.zombieoff.game.weapons.zombie.ranged;

import com.katafrakt.zombieoff.entities.BulletType;
import com.katafrakt.zombieoff.game.weapons.StandardRangedWeapon;
import com.katafrakt.zombieoff.game.weapons.hitbehaviour.SingleTargetHitBehaviour;

public class AcidicSpit extends StandardRangedWeapon {
    public static final String NAME=AcidicSpit.class.getSimpleName();

    public AcidicSpit() {
        super(Recommended.LOW, new  SingleTargetHitBehaviour(), BulletType.LINE, 0.3f, 1, 15,60,20);
    }
}
