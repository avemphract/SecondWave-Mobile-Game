package com.katafrakt.zombieoff.game.upgradebehaviours.weaponunlocker.ranged;

public class LongRangeShotUnlock {
    private static final String NAME= LongRangeShotUnlock.class.getSimpleName();

}
