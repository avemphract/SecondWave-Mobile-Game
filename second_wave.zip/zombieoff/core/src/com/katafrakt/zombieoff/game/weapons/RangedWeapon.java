package com.katafrakt.zombieoff.game.weapons;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.katafrakt.zombieoff.entities.BulletType;
import com.katafrakt.zombieoff.game.weapons.hitbehaviour.HitBehaviour;
import com.katafrakt.zombieoff.managers.GeneralOrganizer;

public abstract class RangedWeapon extends Weapon {
    private static final String TAG=RangedWeapon.class.getSimpleName();


    public float accuracy;
    public float bulletVelocity;
    public HitBehaviour hitBehaviour;
    public BulletType bulletType;

    public RangedWeapon(Recommended recommended, HitBehaviour hitBehaviour,BulletType bulletType, float attackSpeed, float damageRatio, int range, float accuracy, float bulletVelocity) {
        super(Type.RANGED,recommended, attackSpeed, damageRatio, range);
        random= GeneralOrganizer.getInstance().random;
        this.accuracy=accuracy;
        this.bulletVelocity = bulletVelocity;
        this.hitBehaviour=hitBehaviour;
        this.bulletType=bulletType;
    }

    protected Vector3 bulletRandomizer(Vector2 target, Vector2 pos, float skill){
        //float dis=(float) Math.pow(Math.pow(target.x-pos.x,2)+Math.pow(target.y-pos.y,2),0.5f);
        float randomizer1= (float) (Math.PI/16*(1-2*random.nextFloat())*((100-skill)/100));
        float randomizer2= (float) (Math.PI/16*(1-2*random.nextFloat())*((200-skill)/200)*((100-accuracy)/100));
        float angle= target.angleRad(new Vector2(-target.x+pos.x,-target.y+pos.y));//+randomizer1+randomizer2;
        Vector2 direction=new Vector2(target.x-pos.x,target.y-pos.y).rotateRad(randomizer1+randomizer2);
        //Gdx.app.log(TAG,"Ang: "+target.angleRad(pos));
        return new Vector3(direction.x,direction.y,random.nextFloat()/5+0.9f);
    }
}
