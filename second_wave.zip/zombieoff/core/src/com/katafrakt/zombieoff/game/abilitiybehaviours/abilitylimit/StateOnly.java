package com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit;

import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.game.StateType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.AbilityEffect;
import com.katafrakt.zombieoff.game.weapons.Weapon;

public class StateOnly extends AbilityController<StateOnly> {
    public static Pool<StateOnly> pool=new Pool<StateOnly>() {
        @Override
        protected StateOnly newObject() {
            return new StateOnly();
        }
    };
    StateType stateType;

    public StateOnly init(AbilityEffect<?> abilityEffect, StateType stateType) {
        this.abilityEffect=abilityEffect;
        types.clear();
        types.add(Type.STATE);
        this.stateType=stateType;
        return this;
    }

    @Override
    public void enter(AgentComponentV2<? extends Weapon> agentComponent) {
        abilityEffect.entryEffect(agentComponent);
        isActive=true;
    }

    @Override
    public void update(AgentComponentV2<? extends Weapon> agentComponent,Type type) {
        if (!isActive &&(stateType==agentComponent.currentState))
            enter(agentComponent);
        else if (isActive &&!(stateType==agentComponent.currentState))
            leave(agentComponent);

    }

    @Override
    public void leave(AgentComponentV2<? extends Weapon> agentComponent) {
        abilityEffect.leaveEffect(agentComponent);
        isActive=false;
    }

    @Override
    public Pool<StateOnly> getPool() {
        return pool;
    }


}
