package com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_III;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit.AttackOnly;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.IncMaxHealthEffect;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.player.ZombieBuilder;

public class Attack_IncMaxHealth_Upgrade implements ResourceUpgrade {
    public static final String NAME = Attack_IncMaxHealth_Upgrade.class.getSimpleName();
    int index= UpgradeManager.setIndex();
    int count;

    float[] cost= new float[]{};
    float[] value= new float[]{};
    float[] energy=new float[]{};

    AbilityCreator abilityCreator=new AbilityCreator() {
        @Override
        public AbilityController getAbility() {
            return AttackOnly.pool.obtain().init(IncMaxHealthEffect.pool.obtain().init(value[count-1]));
        }
    };

    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().GENE;
    }

    @Override
    public String getName() {
        if (count==0)
            return "Increase max health per attack "+(count+1);
        else if (count<maximumCount())
            return "Increase max health per attack "+count+" -> "+(count+1);
        else
            return "Increase max health per attack "+(count);
    }

    @Override
    public String effect() {
        if (count==0)
            return "Increase max health "+value[count]+" per attack\nEnergy requirement: "+energy[count];
        else if (count<maximumCount())
            return "Increase max health "+value[count-1]+" -> "+value[count]+" per attack\nEnergy requirement: "+energy[count-1]+" -> "+energy[count];
        else
            return "Increase max health "+value[count-1]+" per attack\nEnergy requirement: "+energy[count-1];

    }

    @Override
    public float requiredResource() {
        return cost[count];
    }

    @Override
    public boolean enoughResource() {
        return requiredResource() <= getResourceType().getCurrent();
    }

    @Override
    public int maximumCount() {
        return 5;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        if (count==0){
            abilityCreator.index=index;
            abilityCreator.name="Increase max health per attack";
            ZombieBuilder.getInstance().abilityCreators.add(abilityCreator);
        }
        abilityCreator.level = count+1;
        abilityCreator.energy = energy[count];
        abilityCreator.effect = "Increase max health "+value[count]+" per attack";

    }

    @Override
    public int getIndex() {
        return index;
    }
}
