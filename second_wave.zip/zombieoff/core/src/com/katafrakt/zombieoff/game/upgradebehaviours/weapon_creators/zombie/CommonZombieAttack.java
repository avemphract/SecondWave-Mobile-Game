package com.katafrakt.zombieoff.game.upgradebehaviours.weapon_creators.zombie;

import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponInformation;
import com.katafrakt.zombieoff.game.weapons.MeleeWeapon;
import com.katafrakt.zombieoff.game.weapons.Weapon;

public class CommonZombieAttack extends WeaponInformation {
    public CommonZombieAttack() {
        index=-2;
        energy=0;

        name="Common Attack";
        type=Type.Melee;

        damage="1";
        attRate="0.35";
        range="1";
    }

    @Override
    public Weapon getWeapon() {
        return new MeleeWeapon(0.35f,1,1);
    }

}
