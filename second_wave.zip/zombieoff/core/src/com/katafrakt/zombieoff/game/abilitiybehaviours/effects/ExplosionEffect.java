package com.katafrakt.zombieoff.game.abilitiybehaviours.effects;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.game.abilitiybehaviours.CloneableAbilityController;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.utilities.Utility;

public class ExplosionEffect extends AbilityEffect<ExplosionEffect> {
    public static Pool<ExplosionEffect> pool=new Pool<ExplosionEffect>() {
        @Override
        protected ExplosionEffect newObject() {
            return new ExplosionEffect();
        }
    };

    CloneableAbilityController abilityController;
    Array<Entity> targetCreatures=new Array<>();
    int area;
    public ExplosionEffect(){
        name="Effect explode";
    }

    public ExplosionEffect init(CloneableAbilityController abilityController, int area) {
        this.abilityController=abilityController;
        this.area=area;
        return this;
    }

    @Override
    public void entryEffect(AgentComponentV2 agent) {
        Array<Point> points= Utility.pointArrayPool.obtain();
        points=MapManager.getInstance().pointGraph.getAreaPoints(points,MapManager.getInstance().pointGraph.nearestPoint(agent.transform.pos),area);
        if (agent.creature.entityType.member==0)
            for (Point point:points)
                targetCreatures.addAll(point.zombies);

        if (agent.creature.entityType.member==1)
            for (Point point:points)
                targetCreatures.addAll(point.humans);
            Utility.pointArrayPool.free(points);
        for (Entity entity:targetCreatures){
            Mappers.agentComponents(entity).addAbility(abilityController);
        }
    }

    @Override
    public void tickEffect(AgentComponentV2 agent) {

    }

    @Override
    public void leaveEffect(AgentComponentV2 agent) {

    }

    @Override
    public ExplosionEffect clone() {
        return pool.obtain().init(abilityController.clone(),area);
    }


    @Override
    public Pool<ExplosionEffect> getPool() {
        return null;
    }

    @Override
    public void free() {
        pool.free(this);
    }
}
