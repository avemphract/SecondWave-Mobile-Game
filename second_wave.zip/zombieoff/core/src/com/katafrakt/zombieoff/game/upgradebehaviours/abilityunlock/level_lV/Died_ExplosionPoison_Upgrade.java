package com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_lV;

public class Died_ExplosionPoison_Upgrade {
}
