package com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.attack;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.player.ZombieBuilder;

//Increase Aware Range
public class ZombieAwareRange implements ResourceUpgrade {
    public static final String NAME= ZombieAwareRange.class.getName();
    int index= UpgradeManager.setIndex();
    int count;
    float cost=50;
    int value=5;

    private void setCost(){
        cost=(float) Math.pow(20,count+1);
    }

    @Override
    public String getName() {
        return "Refresh eyes";
    }

    @Override
    public String effect() {
        return "+5 zombie aware range";
    }


    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().BLOOD;
    }

    @Override
    public boolean enoughResource() {
        if (cost<=getResourceType().getCurrent())
            return true;
        else
            return false;
    }

    @Override
    public int maximumCount() {
        return 10;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public void upgrade() {
        getResourceType().minusCurrent(cost);
        ZombieBuilder.getInstance().builder.awaAddition+=value;
        count++;
        setCost();
    }

    @Override
    public int getIndex(){
        return index;
    }
}
