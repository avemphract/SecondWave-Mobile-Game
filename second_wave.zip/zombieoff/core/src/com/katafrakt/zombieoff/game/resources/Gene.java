package com.katafrakt.zombieoff.game.resources;

import com.badlogic.gdx.graphics.Color;
import com.katafrakt.zombieoff.managers.PreferenceManager;

public class Gene extends ResourceAbstract {
    final String NAME="Gene";
    //public float addProductionRate=0.1f;

    public Gene() {
        super(Color.GOLDENROD,50,true);
        isAvailable=true;
        loadValues();
        setCapacity();
    }

    @Override
    public String name() {
        return NAME;
    }

    @Override
    public float getProduction() {return 1;
    }

    @Override
    public void saveValues() {
        PreferenceManager.getInstance().prefs.putFloat(ADD_CAPACITY,addCapacity);
        PreferenceManager.getInstance().prefs.putFloat(MULTIPLIER_CAPACITY_UPGRADE,multiplierCapacityUpgrade);
        PreferenceManager.getInstance().prefs.putFloat(MULTIPLIER_CAPACITY_PRESTIGE,multiplierCapacityPrestige);
        PreferenceManager.getInstance().prefs.putFloat(MULTIPLIER_CAPACITY_TROPHY,multiplierCapacityTrophy);

        PreferenceManager.getInstance().prefs.putFloat(EFFICIENT_TROPHY,efficientTrophy);
        PreferenceManager.getInstance().prefs.putFloat(EFFICIENT_PRESTIGE,efficientPrestige);

        PreferenceManager.getInstance().prefs.putFloat(CURRENT,current);

    }

    @Override
    public void loadValues() {
        addCapacity=PreferenceManager.getInstance().prefs.getFloat(ADD_CAPACITY);
        multiplierCapacityUpgrade=PreferenceManager.getInstance().prefs.getFloat(MULTIPLIER_CAPACITY_UPGRADE);
        multiplierCapacityPrestige=PreferenceManager.getInstance().prefs.getFloat(MULTIPLIER_CAPACITY_PRESTIGE);
        multiplierCapacityTrophy=PreferenceManager.getInstance().prefs.getFloat(MULTIPLIER_CAPACITY_TROPHY);

        efficientTrophy=PreferenceManager.getInstance().prefs.getFloat(EFFICIENT_TROPHY);
        efficientPrestige=PreferenceManager.getInstance().prefs.getFloat(EFFICIENT_PRESTIGE);

        current=PreferenceManager.getInstance().prefs.getFloat(CURRENT);

    }

    private static final String ADD_CAPACITY="GENE_ADD_CAPACITY";
    private static final String MULTIPLIER_CAPACITY_UPGRADE="GENE_MULTIPLIER_CAPACITY_UPGRADE";
    private static final String MULTIPLIER_CAPACITY_PRESTIGE="GENE_MULTIPLIER_CAPACITY_PRESTIGE";
    private static final String MULTIPLIER_CAPACITY_TROPHY="GENE_MULTIPLIER_CAPACITY_";

    private static final String EFFICIENT_TROPHY="GENE_EFFICIENT_TROPHY";
    private static final String EFFICIENT_PRESTIGE="GENE_EFFICIENT_PRESTIGE";

    private static final String CURRENT="GENE_CURRENT";

}
