package com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.defence;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.player.ZombieBuilder;

public class ZombieHealth_IV implements ResourceUpgrade {
    public static final String NAME = ZombieHealth_IV.class.getName();
    int index= UpgradeManager.setIndex();
    int count;
    float cost;
    int value;
    private void setCost(){

    }
    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().BLOOD;
    }

    @Override
    public String getName() {
        return "Fresher organ";
    }

    @Override
    public String effect() {
        return "+"+value+" zombie health";
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public boolean enoughResource() {
        if (cost<=getResourceType().getCurrent())
            return true;
        else
            return false;
    }

    @Override
    public int maximumCount() {
        return 30;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        getResourceType().minusCurrent(cost);
        ZombieBuilder.getInstance().builder.hpAddition+=value;
        count++;
        setCost();
    }

    @Override
    public int getIndex() {
        return index;
    }
}
