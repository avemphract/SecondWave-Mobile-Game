package com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.graphics.FloatingTextComponent;
import com.katafrakt.zombieoff.game.abilitiybehaviours.CloneableAbilityController;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.AbilityEffect;
import com.katafrakt.zombieoff.game.weapons.Weapon;

import org.jetbrains.annotations.NotNull;

public class TimeLimit extends CloneableAbilityController<TimeLimit> implements Comparable<TimeLimit> {
    private static final String TAG=TimeLimit.class.getSimpleName();
    public static Pool<TimeLimit> pool=new Pool<TimeLimit>() {
        @Override
        protected TimeLimit newObject() {
            Gdx.app.log(TAG,"Created new object");
            return new TimeLimit();
        }
    };

    float time;
    float remainTime;

    public TimeLimit(){}

    public TimeLimit init(AbilityEffect<?> abilityEffect, float time) {
        this.abilityEffect=abilityEffect;
        types.clear();
        types.add(Type.UPDATE);
        this.time = time;
        isActive=false;
        isDefinitive=true;
        return this;
    }

    @Override
    public void enter(AgentComponentV2<? extends Weapon> agentComponent) {
        abilityEffect.entryEffect(agentComponent);
        remainTime = time;
        isActive=true;
        FloatingTextComponent floatingTextComponent=Mappers.floatingTextComponents.get(agentComponent.entity);
        Gdx.app.log(TAG,"Time:"+remainTime);
        if (floatingTextComponent!=null&&agentComponent.timedEffects.get(abilityEffect.getClass()).size==1){
            floatingTextComponent.addText(abilityEffect.name,1f);
        }
    }

    @Override
    public void update(AgentComponentV2<? extends Weapon> agentComponent, Type type) {
        if (isActive==false){
            enter(agentComponent);
        }
        if (agentComponent.timedEffects.get(abilityEffect.getClass()).first()==this)
            abilityEffect.tickEffect(agentComponent);
        else
            Gdx.app.log(TAG,"Deactive");
        remainTime-=Gdx.graphics.getDeltaTime();
        if (remainTime <0){
            leave(agentComponent);
        }
    }

    @Override
    public void leave(AgentComponentV2<? extends Weapon> agentComponent) {
        abilityEffect.leaveEffect(agentComponent);
        //agentComponent.abilities.get(Type.UPDATE).removeValue(this,false);
        agentComponent.removeAbility(this);
        isActive=false;
        Gdx.app.log(TAG,"Time end: "+agentComponent.abilities.get(Type.UPDATE).size);
        pool.free(this);
    }

    @Override
    public Pool<TimeLimit> getPool() {
        return pool;
    }

    @Override
    public CloneableAbilityController<TimeLimit> clone() {
        return pool.obtain().init(abilityEffect.clone(),time);
    }

    @Override
    public int compareTo(@NotNull TimeLimit timeLimit) {
        return Float.compare(this.abilityEffect.value, timeLimit.abilityEffect.value);
    }
}
