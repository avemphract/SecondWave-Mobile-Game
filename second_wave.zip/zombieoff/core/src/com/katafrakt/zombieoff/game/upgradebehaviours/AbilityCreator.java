package com.katafrakt.zombieoff.game.upgradebehaviours;

import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;

public abstract class AbilityCreator {
    public float index;
    public int level;
    public float energy;
    public String name;
    public String effect;

    public abstract AbilityController getAbility();

}
