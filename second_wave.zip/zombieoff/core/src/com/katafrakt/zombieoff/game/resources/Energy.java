package com.katafrakt.zombieoff.game.resources;

import com.badlogic.gdx.graphics.Color;
import com.katafrakt.zombieoff.managers.PreferenceManager;

public class Energy extends ResourceAbstract {
    final String NAME ="Energy";

    public final float INIT_PRODUCTION_RATE=10000;
    public float addProductionRate;
    public float multiplierProductionRatePrestige;
    public float multiplierProductionRateTrophy;

    public Energy() {
        super(Color.ROYAL,10,true);
        loadValues();
        setCapacity();
    }

    @Override
    public String name() {
        return NAME;
    }

    @Override
    public float getProduction() {
        return (INIT_PRODUCTION_RATE+addProductionRate)*(multiplierProductionRatePrestige+1)*(multiplierProductionRateTrophy+1);
    }

    @Override
    public void saveValues() {
        PreferenceManager.getInstance().prefs.putFloat(ADD_CAPACITY,addCapacity);
        PreferenceManager.getInstance().prefs.putFloat(MULTIPLIER_CAPACITY_UPGRADE,multiplierCapacityUpgrade);
        PreferenceManager.getInstance().prefs.putFloat(MULTIPLIER_CAPACITY_PRESTIGE,multiplierCapacityPrestige);
        PreferenceManager.getInstance().prefs.putFloat(MULTIPLIER_CAPACITY_TROPHY,multiplierCapacityTrophy);

        PreferenceManager.getInstance().prefs.putFloat(EFFICIENT_TROPHY,efficientTrophy);
        PreferenceManager.getInstance().prefs.putFloat(EFFICIENT_PRESTIGE,efficientPrestige);

        PreferenceManager.getInstance().prefs.putFloat(ADD_PRODUCTION_RATE,addProductionRate);
        PreferenceManager.getInstance().prefs.putFloat(MULTIPLIER_PRODUCTION_RATE_PRESTIGE,multiplierProductionRatePrestige);
        PreferenceManager.getInstance().prefs.putFloat(MULTIPLIER_PRODUCTION_RATE_TROPHY,multiplierProductionRateTrophy);
    }

    @Override
    public void loadValues() {
        addCapacity = PreferenceManager.getInstance().prefs.getFloat(ADD_CAPACITY,addCapacity);
        multiplierCapacityUpgrade = PreferenceManager.getInstance().prefs.getFloat(MULTIPLIER_CAPACITY_UPGRADE,multiplierCapacityUpgrade);
        multiplierCapacityPrestige = PreferenceManager.getInstance().prefs.getFloat(MULTIPLIER_CAPACITY_PRESTIGE,multiplierCapacityPrestige);
        multiplierCapacityTrophy = PreferenceManager.getInstance().prefs.getFloat(MULTIPLIER_CAPACITY_TROPHY,multiplierCapacityTrophy);

        efficientTrophy = PreferenceManager.getInstance().prefs.getFloat(EFFICIENT_TROPHY,efficientTrophy);
        efficientPrestige = PreferenceManager.getInstance().prefs.getFloat(EFFICIENT_PRESTIGE,efficientPrestige);

        addProductionRate = PreferenceManager.getInstance().prefs.getFloat(ADD_PRODUCTION_RATE,addProductionRate);
        multiplierProductionRatePrestige = PreferenceManager.getInstance().prefs.getFloat(MULTIPLIER_PRODUCTION_RATE_PRESTIGE,multiplierProductionRatePrestige);
        multiplierProductionRateTrophy = PreferenceManager.getInstance().prefs.getFloat(MULTIPLIER_PRODUCTION_RATE_TROPHY);
    }

    private static final String ADD_CAPACITY="ENERGY_ADD_CAPACITY";
    private static final String MULTIPLIER_CAPACITY_UPGRADE="ENERGY_MULTIPLIER_CAPACITY_UPGRADE";
    private static final String MULTIPLIER_CAPACITY_PRESTIGE="ENERGY_MULTIPLIER_CAPACITY_PRESTIGE";
    private static final String MULTIPLIER_CAPACITY_TROPHY="ENERGY_MULTIPLIER_CAPACITY_";

    private static final String EFFICIENT_TROPHY="ENERGY_EFFICIENT_TROPHY";
    private static final String EFFICIENT_PRESTIGE="ENERGY_EFFICIENT_PRESTIGE";

    private static final String ADD_PRODUCTION_RATE="ENERGY_ADD_PRODUCTION_RATE";
    private static final String MULTIPLIER_PRODUCTION_RATE_PRESTIGE="ENERGY_MULTIPLIER_PRODUCTION_RATE_PRESTIGE";
    private static final String MULTIPLIER_PRODUCTION_RATE_TROPHY="ENERGY_MULTIPLIER_PRODUCTION_RATE_TROPHY";

}
