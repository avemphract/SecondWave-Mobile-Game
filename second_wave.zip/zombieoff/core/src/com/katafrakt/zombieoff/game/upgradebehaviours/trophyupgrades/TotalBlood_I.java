package com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades;

import com.katafrakt.zombieoff.game.upgradebehaviours.TrophyUpgrade;
import com.katafrakt.zombieoff.player.PlayerStatics;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.ui.desicions.ChangeInterface;

public class TotalBlood_I implements TrophyUpgrade {
    public static final String NAME = TotalBlood_I.class.getName();
    int index= UpgradeManager.setIndex();
    int count;
    int cost=4000;

    @Override
    public String requirementName() {
        return "Gain blood";
    }

    @Override
    public float currentResource() {
        return PlayerStatics.getInstance().totalBlood.get();//Sonra dolduralacak
    }

    @Override
    public void adjustEvent(ChangeInterface changeInterface) {
        PlayerStatics.EventFloat.addListener(PlayerStatics.getInstance().totalBlood,changeInterface);
    }

    @Override
    public String getName() {
        return "Bloody";
    }

    @Override
    public String effect() {
        return "+%20 Blood capacity";
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public boolean enoughResource() {
        return false;//Sonra doldurulacak
    }

    @Override
    public int maximumCount() {
        return 1;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        //Sonra dolduralacak
    }

    @Override
    public int getIndex() {
        return index;
    }
}
