package com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit;

import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.graphics.FloatingTextComponent;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.AbilityEffect;
import com.katafrakt.zombieoff.game.weapons.Weapon;

public class AttackOnly extends AbilityController<AttackOnly> {
    public static Pool<AttackOnly> pool=new Pool<AttackOnly>() {
        @Override
        protected AttackOnly newObject() {
            return new AttackOnly();
        }
    };


    public AttackOnly init(AbilityEffect<?> abilityEffect){
        this.abilityEffect=abilityEffect;
        types.clear();
        types.add(Type.ATTACK);
        return this;
    }

    @Override
    public void enter(AgentComponentV2<?> agentComponent) {
        abilityEffect.entryEffect(agentComponent);

        FloatingTextComponent floatingTextComponent= Mappers.floatingTextComponents.get(agentComponent.entity);
        if (floatingTextComponent!=null)
            floatingTextComponent.addText(abilityEffect.name,1f);
    }

    @Override
    public void update(AgentComponentV2<? extends Weapon> agentComponent, Type type) {
        if (type==Type.ATTACK) {
            enter(agentComponent);
        }
    }

    @Override
    public void leave(AgentComponentV2<? extends Weapon> agentComponent) {

    }

    @Override
    public Pool<AttackOnly> getPool() {
        return pool;
    }
}
