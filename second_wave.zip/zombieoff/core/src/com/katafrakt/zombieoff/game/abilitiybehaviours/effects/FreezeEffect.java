package com.katafrakt.zombieoff.game.abilitiybehaviours.effects;

import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.game.abilitiybehaviours.StatusTypes;

public class FreezeEffect extends AbilityEffect<FreezeEffect> {
    public static Pool<FreezeEffect> pool=new Pool<FreezeEffect>() {
        @Override
        protected FreezeEffect newObject() {
            return new FreezeEffect();
        }
    };

    public FreezeEffect() {

        name="Freeze effect";
    }
    public FreezeEffect init(float value){
        this.value=value;
        return this;
    }

    @Override
    public void entryEffect(AgentComponentV2 agent) {
        agent.creature.extraSpeed+=-agent.creature.speed*value;
    }

    @Override
    public void tickEffect(AgentComponentV2 agent) {
        Mappers.particleComponents.get(agent.entity).addStatus(StatusTypes.FREEZE).getEmitters().first().addParticles(1);
    }

    @Override
    public void leaveEffect(AgentComponentV2 agent) {
        agent.creature.extraSpeed+=+agent.creature.speed*value;
    }

    @Override
    public FreezeEffect clone() {
        return pool.obtain().init(value);
    }

    @Override
    public Pool<FreezeEffect> getPool() {
        return pool;
    }

    @Override
    public void free() {
        pool.free(this);
    }

}
