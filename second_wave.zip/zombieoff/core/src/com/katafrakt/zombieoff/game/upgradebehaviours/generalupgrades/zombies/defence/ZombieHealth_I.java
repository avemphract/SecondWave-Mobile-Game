package com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.defence;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.player.ZombieBuilder;

public class ZombieHealth_I implements ResourceUpgrade {
    public static final String NAME= ZombieHealth_I.class.getName();
    int index= UpgradeManager.setIndex();
    int count;
    float cost=100;
    int value=5;

    private void setCost(){
        cost=100*count;
    }

    @Override
    public String getName() {
        return "Strong Bones";
    }

    @Override
    public String effect() {
        return "+"+value+" zombie health";
    }


    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().BLOOD;
    }

    @Override
    public boolean enoughResource() {
        if (cost<=getResourceType().getCurrent())
            return true;
        else
            return false;
    }

    @Override
    public int maximumCount() {
        return 30;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public void upgrade() {
        getResourceType().minusCurrent(cost);
        ZombieBuilder.getInstance().builder.hpAddition+=value;
        count++;
        setCost();
    }

    @Override
    public int getIndex(){
        return index;
    }
}
