package com.katafrakt.zombieoff.game.tree;

import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.game.upgradebehaviours.UpgradeBehaviour;

public class TreeNode<T extends UpgradeBehaviour> {
    private static final String TAG=TreeNode.class.getSimpleName();
    public T object;
    boolean isComplete;
    boolean isAncestor=false;

    Array<TreeNode<T>> children=new Array<>();

    Array<Pair> parentPrerequisite=new Array<>();

    public TreeNode(T object){
        this.object=object;
    }
    public TreeNode(boolean isAncestor){
        this.isAncestor=isAncestor;
    }

    public boolean isAvailable(){
        boolean available=true;
        if (parentPrerequisite.size==0)
            return true;

        for (Pair pair:parentPrerequisite){
            if (pair.treeNode.object.currentCount()<=pair.require){
                available=false;
            }
        }

        return available;
    }
    public void addPrerequisite(Pair... pairs){
        for (Pair pair:pairs){
            parentPrerequisite.add(pair);
        }
    }
    public void addChildren(TreeNode<T>... objects){
        for (TreeNode<T> object:objects)
            children.add(object);
    }


    public Array<TreeNode<T>> getChildren(){
        return children;
    }

    public void getUpgradeBehaviours(Array<UpgradeBehaviour> behaviours){
        if (behaviours.contains(object,true))
            return;
        if (isAvailable()){
            if (isAncestor){
                if (children.size!=0) {
                    for (TreeNode<T> treeNode : children) {
                        treeNode.getUpgradeBehaviours(behaviours);
                    }
                }
            }//isAncestor==true
            else {
                //Gdx.app.log(TAG,object.getName()+" "+isAvailable());
                behaviours.add(object);
                if (children.size!=0)
                    for (TreeNode<T> treeNode:children){
                        treeNode.getUpgradeBehaviours(behaviours);
                    }
            }//isAncestor==false
        }//isAvailable
    }

    public static Pair createPair(TreeNode treeNode, int i){
        return new Pair(treeNode,i);
    }
    public static class Pair{
        TreeNode treeNode;
        int require;
        public Pair(TreeNode treeNode, int require){
            this.treeNode=treeNode;
            this.require=require;
        }
    }
}
