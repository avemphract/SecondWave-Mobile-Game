package com.katafrakt.zombieoff.game.abilitiybehaviours.effects;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.graphics.ParticleEffectComponent;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.utilities.Utility;

public class ExplosionDamage extends AbilityEffect<ExplosionDamage> {
    private static final String TAG= ExplosionDamage.class.getSimpleName();
    public static Pool<ExplosionDamage> pool=new Pool<ExplosionDamage>() {
        @Override
        protected ExplosionDamage newObject() {
            return new ExplosionDamage();
        }
    };
    Array<Entity> targetCreatures=new Array<>();
    public int area;
    float damage;

    public float x,y;

    public ExplosionDamage(){
        name="Explode";
    }


    public ExplosionDamage init(int area, float damage){
        this.area=area;
        this.damage=damage;
        targetCreatures.clear();
        return this;
    }

    @Override
    public void entryEffect(AgentComponentV2 agent) {
        Array<Point> points= Utility.pointArrayPool.obtain();
        points=MapManager.getInstance().pointGraph.getAreaPoints(points,MapManager.getInstance().pointGraph.nearestPoint(agent.transform.pos),area);
        if (agent.creature.entityType.member==0)
            for (Point point:points){
                targetCreatures.addAll(point.zombies);}

        if (agent.creature.entityType.member==1)
            for (Point point:points){
                targetCreatures.addAll(point.humans);
            }
        Utility.pointArrayPool.free(points);
        for (Entity entity:targetCreatures){
            Mappers.creatureComponents.get(entity).takeDamageBlood(damage);
        }
        agent.entity.getComponent(ParticleEffectComponent.class).addExplosion(area);
        x=agent.transform.pos.x;
        y=agent.transform.pos.y;
    }

    @Override
    public void tickEffect(AgentComponentV2 agent) {
    }

    @Override
    public void leaveEffect(AgentComponentV2 agent) {

    }

    @Override
    public ExplosionDamage clone() {
        return pool.obtain().init(area,damage);
    }

    @Override
    public Pool<ExplosionDamage> getPool() {
        return pool;
    }

    @Override
    public void free() {
        pool.free(this);
    }
}
