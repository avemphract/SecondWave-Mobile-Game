package com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_II;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit.AttackToTimeLimit;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.PoisonEffect;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.player.ZombieBuilder;

public class AttackToTime_Poison_Upgrade implements ResourceUpgrade {
    public static final String NAME = AttackToTime_Poison_Upgrade.class.getSimpleName();
    int index = UpgradeManager.setIndex();
    int count;
    float[] cost=new float[]{10,20,30,40,50};
    float[] value=new float[]{0.01f,0.02f,0.03f,0.04f,0.05f};
    float[] energy=new float[]{1,2,3,4,5};

    AbilityCreator abilityCreator=new AbilityCreator() {
        @Override
        public AbilityController getAbility() {
            return AttackToTimeLimit.pool.obtain().init(PoisonEffect.pool.obtain().init(value[count-1]),1);
        }
    };

    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().GENE;
    }

    @Override
    public String getName() {
        if (count==0)
            return "Attack with poison effect "+(count+1);
        else if (count<maximumCount())
            return "Attack with poison effect"+(count)+"->"+(count+1);
        else
            return "Attack with poison effect"+(count);

    }

    @Override
    public String effect() {
        if (count==0)
            return "Every attack has "+value[count]+" current health per second for 1 second\nEnergy requirement " + energy[count];
        else if (count<maximumCount())
            return "Every attack has "+value[count-1]+"->"+value[count]+" current health per second for 1 second\nEnergy requirement "+ energy[count-1]+"->"+energy[count];
        else
            return "Every attack has "+value[count-1]+" current health per second for 1 second\nEnergy requirement "+energy[count-1];

    }

    @Override
    public float requiredResource() {
        return cost[count];
    }

    @Override
    public boolean enoughResource() {
        if (requiredResource()<=getResourceType().getCurrent())
            return true;
        else return false;
    }

    @Override
    public int maximumCount() {
        return 5;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        getResourceType().minusCurrent(requiredResource());

        if (count==0){
            abilityCreator.index=index;
            abilityCreator.name="Attack with poison effect I";
            ZombieBuilder.getInstance().abilityCreators.add(abilityCreator);
        }

        abilityCreator.level=count+1;
        abilityCreator.energy=energy[count];
        abilityCreator.effect="Every attack has "+value[count]+" current health per second for 1 second";

        count++;
    }

    @Override
    public int getIndex() {
        return index;
    }
}
