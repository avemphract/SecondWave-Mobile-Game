package com.katafrakt.zombieoff.game.weapons;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.entities.BulletType;
import com.katafrakt.zombieoff.entities.bullets.Bullet;
import com.katafrakt.zombieoff.game.StateType;
import com.katafrakt.zombieoff.game.weapons.hitbehaviour.HitBehaviour;
import com.katafrakt.zombieoff.managers.BulletFactory;
import com.katafrakt.zombieoff.managers.EngineEdited;
import com.katafrakt.zombieoff.player.PlayerStatics;

public class StandardRangedWeapon extends RangedWeapon {
    private static final String TAG =  StandardRangedWeapon.class.getSimpleName();
    float size=2;
    Bullet.Builder builder=new Bullet.Builder();
    Vector2 speed=new Vector2();

    public StandardRangedWeapon(Recommended recommended, HitBehaviour hitBehaviour, BulletType bulletType, float attackSpeed, float damageRatio, int range, float accuracy, float bulletVelocity) {
        super(recommended, hitBehaviour,bulletType,attackSpeed, damageRatio, range, accuracy, bulletVelocity);
    }
    public StandardRangedWeapon(Level level){
        super(level.recommended,level.hitBehaviour,level.bulletType,level.attackSpeed,level.damageRatio,level.range,level.accuracy,level.bulletVelocity);
    }
    public StandardRangedWeapon(Level level,WeaponGraphics weaponGraphics){
        super(level.recommended,level.hitBehaviour,level.bulletType,level.attackSpeed,level.damageRatio,level.range,level.accuracy,level.bulletVelocity);
        this.weaponGraphics=weaponGraphics;
        Gdx.app.log(TAG,"Created");
    }

    @Override
    public void attack(CreatureComponent attacker, CreatureComponent target) {
        TransformComponent transformComponent= Mappers.transformComponents.get(attacker.entity);
        TransformComponent targetTransform= Mappers.transformComponents.get(target.entity);

        PlayerStatics.getInstance().bulletFired.add(+1);
        Vector3 bulletTarget=bulletRandomizer(targetTransform.pos,transformComponent.pos,attacker.accuracy);
        speed.set(bulletTarget.x,bulletTarget.y);
        float time=speed.len()/bulletVelocity*bulletTarget.z;
        speed=speed.scl(bulletVelocity/speed.len());
        builder.set(attacker.entityType.getBullet(),bulletType, hitBehaviour,transformComponent.pos.x,transformComponent.pos.y,2,2,speed,attacker.getDamage()*damageRatio,time,abilityControllers);
        BulletFactory.getInstance().createBullet(builder);
        abilityControllers.clear();


    }

    public static class Level{
        public Recommended recommended;
        public HitBehaviour hitBehaviour;
        public BulletType bulletType;
        public float attackSpeed;
        public float damageRatio;
        public int range;
        public float accuracy;
        public float bulletVelocity;

        public Level(Recommended recommended, HitBehaviour hitBehaviour,BulletType bulletType, float attackSpeed, float damageRatio, int range, float accuracy, float bulletVelocity) {
            this.recommended = recommended;
            this.hitBehaviour = hitBehaviour;
            this.bulletType = bulletType;
            this.attackSpeed = attackSpeed;
            this.damageRatio = damageRatio;
            this.range = range;
            this.accuracy = accuracy;
            this.bulletVelocity = bulletVelocity;
        }
    }
}
