package com.katafrakt.zombieoff.game.upgradebehaviours.prestige_upgrades;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;

public class UnlockAutoZombieUpgradesPrestige implements ResourceUpgrade {
    private static final String TAG = UnlockAutoZombieUpgradesPrestige.class.getSimpleName();
    int index = UpgradeManager.setIndex();
    int count;
    float cost;


    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().PRESTIGE;
    }

    @Override
    public String getName() {
        return "Auto upgrade unlock";
    }

    @Override
    public String effect() {
        return "";
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public boolean enoughResource() {
        return false;
    }

    @Override
    public int maximumCount() {
        return 1;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        //ToDo
    }

    @Override
    public int getIndex() {
        return index;
    }
}
