package com.katafrakt.zombieoff.game.weapons.zombie.melee;

import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.weapons.MeleeWeapon;

public class BasicAttack extends MeleeWeapon {
    public BasicAttack(float attackSpeed, float damageRatio, int range) {
        super(attackSpeed, damageRatio, range);
    }
    public BasicAttack(Level level){
        super(level.attackSpeed,level.damageRatio,level.range);
    }

    @Override
    public void attack(CreatureComponent attacker, CreatureComponent target) {
        for(AbilityController abilityController:abilityControllers)
            Mappers.agentComponents(target.entity).addAbility(abilityController);
        target.takeDamageBlood(attacker.getDamage()*damageRatio);//Todo
    }

    public static class Level{
        public float attackSpeed;
        public float damageRatio;
        public int range;
        public Level(float attackSpeed, float damageRatio, int range){
            this.attackSpeed=attackSpeed;
            this.damageRatio=damageRatio;
            this.range=range;

        }
    }
}
