package com.katafrakt.zombieoff.game.upgradebehaviours;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;

public interface ResourceUpgrade extends UpgradeBehaviour {

    ResourceAbstract getResourceType();
}
