package com.katafrakt.zombieoff.game.abilitiybehaviours.effects;

import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;

public class ReductionEffect extends AbilityEffect<ReductionEffect> {
    public static Pool<ReductionEffect> pool=new Pool<ReductionEffect>() {
        @Override
        protected ReductionEffect newObject() {
            return new ReductionEffect();
        }
    };
    private ReductionEffect(){}

    public ReductionEffect init(float value){
        this.value=value;
        return this;
    }

    @Override
    public void entryEffect(AgentComponentV2 agent) {
        agent.creature.reduction+=value;
    }

    @Override
    public void tickEffect(AgentComponentV2 agent) {

    }

    @Override
    public void leaveEffect(AgentComponentV2 agent) {
        agent.creature.reduction-=value;
    }

    @Override
    public ReductionEffect clone() {
        return pool.obtain().init(value);
    }

    @Override
    public Pool<ReductionEffect> getPool() {
        return pool;
    }

    @Override
    public void free() {
        pool.free(this);
    }
}
