package com.katafrakt.zombieoff.game.weapons;

import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.game.abilitiybehaviours.CloneableAbilityController;

import java.util.Random;

public abstract class Weapon {

    public enum Type{
        RANGED,MELEE
    }

    public enum Recommended{
        MELEE(0,1),LOW(0,6),MEDIUM(7,15),HIGH(16,30);
        public int min,max;
        public int[] queue;
        Recommended(int min, int max){
            this.min=min;
            this.max=max;
            queue=new int[max-min+1];
            diff();
        }
        void diff(){
            if (max==1){
                queue[0]=0;
                queue[1]=1;
            }
            else if (max==4){
                queue[0]=0;
                queue[1]=1;
                queue[2]=2;
                queue[3]=3;
                queue[4]=4;
                queue[5]=5;
                queue[6]=6;
            }
            else if (max==15){
                queue[0]=11;
                queue[1]=10;
                queue[2]=12;
                queue[3]=9;
                queue[4]=13;
                queue[5]=8;
                queue[6]=14;
                queue[7]=7;
                queue[8]=15;
            }
            else if (max==30){
                queue[0]=23;
                queue[1]=22;
                queue[2]=24;
                queue[3]=21;
                queue[4]=25;
                queue[5]=20;
                queue[6]=26;
                queue[7]=19;
                queue[8]=27;
                queue[9]=18;
                queue[10]=28;
                queue[11]=17;
                queue[12]=29;
                queue[13]=16;
                queue[14]=30;
            }
        }
    }

    public WeaponGraphics weaponGraphics;
    protected Random random;
    public Recommended recommended;

    public Type type;
    protected float attackRate;
    public float damageRatio;
    public int range;
    public Array<CloneableAbilityController> abilityControllers=new Array<>();


    public Weapon(Type type,Recommended recommended, float attackRate ,float damageRatio, int range){
        this.type=type;
        this.recommended=recommended;
        this.attackRate = attackRate;
        this.damageRatio=damageRatio;
        this.range=range;
    }

    public abstract void attack(CreatureComponent attacker, CreatureComponent target);
    public float getAttackRate(CreatureComponent attacker){
        return 1/(attackRate*attacker.getAttRate());
    }

}
