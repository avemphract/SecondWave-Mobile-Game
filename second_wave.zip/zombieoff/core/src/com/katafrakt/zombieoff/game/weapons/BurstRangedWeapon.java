package com.katafrakt.zombieoff.game.weapons;

import com.badlogic.gdx.math.Vector2;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.entities.BulletType;
import com.katafrakt.zombieoff.entities.bullets.Bullet;
import com.katafrakt.zombieoff.game.weapons.hitbehaviour.HitBehaviour;
import com.katafrakt.zombieoff.player.PlayerStatics;

public class BurstRangedWeapon extends StandardRangedWeapon {
    Bullet.Builder builder=new Bullet.Builder();
    Vector2 speed=new Vector2();
    float burstTime;
    int burstCount;
    int currentBurst;

    public BurstRangedWeapon(Recommended recommended, HitBehaviour hitBehaviour, BulletType bulletType, float attackSpeed, float damageRatio, int range, float accuracy, float bulletVelocity, float burstTime, int burstCount) {
        super(recommended, hitBehaviour, bulletType, attackSpeed, damageRatio, range, accuracy ,bulletVelocity);
        this.burstTime=burstTime;
        this.burstCount=burstCount;
    }

    public BurstRangedWeapon(Level level){
        super(level.recommended, level.hitBehaviour,level.bulletType,level.attackSpeed,level.damageRatio,level.range,level.accuracy,level.bulletVelocity);
        this.burstTime=level.burstTime;
        this.burstCount=level.burstCount;
    }
    public BurstRangedWeapon(Level level,WeaponGraphics weaponGraphics){
        super(level.recommended, level.hitBehaviour,level.bulletType,level.attackSpeed,level.damageRatio,level.range,level.accuracy,level.bulletVelocity);
        this.burstTime=level.burstTime;
        this.burstCount=level.burstCount;
        this.weaponGraphics=weaponGraphics;
    }

    @Override
    public void attack(CreatureComponent attacker, CreatureComponent target) {
        //PlayerStatics.getInstance().bulletFired++;//BulletFired
        PlayerStatics.getInstance().bulletFired.add(+1);
        if (currentBurst>=burstCount){
            currentBurst=1;
        }
        else currentBurst++;
        super.attack(attacker,target);
    }

    @Override
    public float getAttackRate(CreatureComponent attacker) {
        if (currentBurst>=burstCount){
            return (1/(attackRate*attacker.getAttRate()));
        }else {
            return burstTime;
        }
    }

    public static class Level{
        public Recommended recommended;
        public HitBehaviour hitBehaviour;
        public BulletType bulletType;
        public float attackSpeed;
        public float damageRatio;
        public int range;
        public float accuracy;
        public float bulletVelocity;
        public float burstTime;
        public int burstCount;

        public Level(Recommended recommended, HitBehaviour hitBehaviour,BulletType bulletType, float attackSpeed, float damageRatio, int range, float accuracy, float bulletVelocity, float burstTime, int burstCount) {
            this.recommended = recommended;
            this.hitBehaviour=hitBehaviour;
            this.bulletType=bulletType;
            this.attackSpeed = attackSpeed;
            this.damageRatio=damageRatio;
            this.range = range;
            this.accuracy = accuracy;
            this.bulletVelocity = bulletVelocity;
            this.burstTime = burstTime;
            this.burstCount = burstCount;
        }
    }
}
