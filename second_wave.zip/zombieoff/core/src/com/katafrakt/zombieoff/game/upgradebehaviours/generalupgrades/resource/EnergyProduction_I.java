package com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.resource;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;

public class EnergyProduction_I implements ResourceUpgrade {
    public static final String NAME= EnergyProduction_I.class.getName();
    int index= UpgradeManager.setIndex();
    int count;
    float cost;
    float value=0.1f;

    private void setCost() {
        cost=(count+2)*250;
    }

    @Override
    public String getName() {
        return "Wind Mill";
    }

    @Override
    public String effect() {
        return "+0.1 Energy production";
    }


    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().BLOOD;
    }

    @Override
    public boolean enoughResource() {
        if (cost<=getResourceType().getCurrent())
            return true;
        else
            return false;
    }

    @Override
    public int maximumCount() {
        return 30;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public void upgrade() {
        getResourceType().minusCurrent(cost);
        ResourceType.getInstance().ENERGY.addProductionRate+=value;
        count++;
        setCost();
    }


    @Override
    public int getIndex() {
        return index;
    }
}
