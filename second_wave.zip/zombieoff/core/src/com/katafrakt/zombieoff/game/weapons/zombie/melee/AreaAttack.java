package com.katafrakt.zombieoff.game.weapons.zombie.melee;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ArrayMap;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agents.AgentComponent;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.weapons.MeleeWeapon;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.utilities.Utility;

public class AreaAttack extends MeleeWeapon {
    int area;
    ArrayMap<Integer,Array<CreatureComponent>> hashMap=new ArrayMap<>();
    public AreaAttack(float attackSpeed, float damageRatio, int range, int area) {
        super(attackSpeed, damageRatio, range);
        this.area=area;
        for (int i=0;i<=area;i++){
            hashMap.put(i,new Array<CreatureComponent>());
        }
    }
    public AreaAttack(Level level){
        super(level.attackSpeed, level.damageRatio,level.range);
        this.area= level.area;
    }

    @Override
    public void attack(CreatureComponent attacker, CreatureComponent target) {
        for (int i=0;i<=area;i++){
            Array<Point> points= Utility.pointArrayPool.obtain();
            points=MapManager.getInstance().pointGraph.getRangePoints(points,MapManager.getInstance().pointGraph.nearestPoint(Mappers.transformComponents.get(target.entity).pos),i);
            for (int j=0;j<points.size;j++){
                for (Entity human:points.get(j).humans){
                    CreatureComponent humanCreature= Mappers.creatureComponents.get(human);
                    AgentComponent humanAgent=Mappers.agentComponents(human);
                    if (i<area/2){
                        for(AbilityController abilityController:abilityControllers){
                            //Gdx.app.log("TAG",abilityController.getClass().getSimpleName());
                            humanAgent.addAbility(abilityController);
                        }
                        humanCreature.takeDamageBlood(attacker.getDamage()*damageRatio);//ToDo
                    }
                    else {
                        humanCreature.takeDamageBlood(attacker.getDamage()*damageRatio/2);//ToDo
                    }
                }
            }
            Utility.pointArrayPool.free(points);
        }
    }

    public static class Level{
        public float attackSpeed;
        public float damageRatio;
        public int range;
        public int area;
        public Level(float attackSpeed, float damageRatio, int range, int area){
            this.attackSpeed=attackSpeed;
            this.damageRatio=damageRatio;
            this.range=range;
            this.area=area;
        }
    }
}
