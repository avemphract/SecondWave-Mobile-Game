package com.katafrakt.zombieoff.game.resources;

import com.badlogic.gdx.graphics.Color;
import com.katafrakt.zombieoff.managers.PreferenceManager;

public class Prestige extends ResourceAbstract {
    final String NAME="Prestige";
    public Prestige() {
        super(Color.NAVY,0,false);
        setCapacity();
    }

    @Override
    public String name() {
        return NAME;
    }

    @Override
    public float getProduction() {
        return 0;
    }

    @Override
    public void saveValues() {
        PreferenceManager.getInstance().prefs.putFloat(CURRENT,current);
    }

    @Override
    public void loadValues() {
        current=PreferenceManager.getInstance().prefs.getFloat(CURRENT);
    }

    private static final String CURRENT="PRESTIGE_CURRENT";
}
