package com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.defence;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;

public class ZombieReduction implements ResourceUpgrade {
    public static final String NAME = ZombieReduction.class.getName();
    int index = UpgradeManager.setIndex();
    int count;
    float cost;
    int value;

    private void setCost(){
        cost=count*200;
    }
    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().BLOOD;
    }

    @Override
    public String getName() {
        return "Effective skin";
    }

    @Override
    public String effect() {
        return "+%"+value+" zombie attack";
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public boolean enoughResource() {
        if (cost<=getResourceType().getCurrent())
            return true;
        else
            return false;
    }

    @Override
    public int maximumCount() {
        return 20;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        getResourceType().minusCurrent(cost);
        //ToDo
        count++;
        setCost();
    }

    @Override
    public int getIndex() {
        return index;
    }
}
