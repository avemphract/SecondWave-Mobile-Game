package com.katafrakt.zombieoff.game.upgradebehaviours.weaponunlocker.melee;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponInformation;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponUnlock;
import com.katafrakt.zombieoff.game.weapons.Weapon;
import com.katafrakt.zombieoff.game.weapons.zombie.melee.BasicAttack;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.player.ZombieBuilder;

public class PowerAttackUnlock implements WeaponUnlock {
    public static final String NAME= PowerAttackUnlock.class.getSimpleName();

    BasicAttack.Level level0 = new BasicAttack.Level(0.25f,2,1);
    BasicAttack.Level level1 = new BasicAttack.Level(0.25f,2.5f,1);
    BasicAttack.Level level2 = new BasicAttack.Level(0.25f,3f,1);

    BasicAttack.Level[] levels=new BasicAttack.Level[]{level0,level1,level2};

    WeaponInformation weaponInformation =new WeaponInformation() {
        @Override
        public Weapon getWeapon() {
            return new BasicAttack(levels[count]);
        }
    };

    int index= UpgradeManager.setIndex();
    int count;
    float cost=10;


    @Override
    public String getType() {
        return "Melee";
    }

    @Override
    public String getTitle() {
        if (count==0)
            return "Power Attack "+(count+1);
        else if (count<maximumCount())
            return "Power Attack "+(count)+"->"+(count+1);
        else
            return "Power Attack "+(count);
    }

    @Override
    public String getDamage() {
        if (count==0)
            return "D: "+levels[count].damageRatio;
        else if (count<maximumCount())
            return "D: "+levels[count-1].damageRatio+"->"+levels[count].damageRatio;
        else
            return "D: "+levels[count-1].damageRatio;
    }

    @Override
    public String getAttRate() {
        if (count==0)
            return "S: "+levels[count].attackSpeed;
        else if (count<maximumCount())
            return "S: "+levels[count-1].attackSpeed;
        else
            return "S: "+levels[count-1].attackSpeed;
    }

    @Override
    public String getRange() {
        if (count<maximumCount())
            return "R: "+levels[count].range;
        else
            return "R: "+levels[count-1].range;
    }

    @Override
    public float getEnergy() {
        return 0;
    }

    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().GENE;
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public String effect() {
        return "Common Attack";
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public boolean enoughResource() {
        if (cost<=getResourceType().getCurrent())
            return true;
        else
            return false;
    }

    @Override
    public int maximumCount() {
        return levels.length;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {

        getResourceType().minusCurrent(cost);
        if (count==0){
            weaponInformation.type= WeaponInformation.Type.Melee;
            ZombieBuilder.getInstance().weaponCreators.add(weaponInformation);
        }
        weaponInformation.name="Power Attack "+(count+1);


        weaponInformation.damage=String.valueOf(levels[count].damageRatio);
        weaponInformation.attRate=String.valueOf(levels[count].attackSpeed);
        weaponInformation.range=String.valueOf(levels[count].range);

        weaponInformation.detail="Common attack";

        count++;
    }

    @Override
    public int getIndex() {
        return index;
    }
}
