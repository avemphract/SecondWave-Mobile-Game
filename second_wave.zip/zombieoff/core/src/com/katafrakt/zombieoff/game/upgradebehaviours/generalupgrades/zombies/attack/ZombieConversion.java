package com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.attack;

import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.player.UpgradeManager;

public class ZombieConversion implements ResourceUpgrade {
    public static final String NAME = ZombieConversion.class.getName();
    int index = UpgradeManager.setIndex();
    int count;
    float cost;
    int value;

    public void setCost(){

    }

    @Override
    public ResourceAbstract getResourceType() {
        return ResourceType.getInstance().BLOOD;
    }

    @Override
    public String getName() {
        return "Zombie conversion";
    }

    @Override
    public String effect() {
        return "%xx chance to turn into zombie who killed human";
    }

    @Override
    public float requiredResource() {
        return cost;
    }

    @Override
    public boolean enoughResource() {
        if (cost<=getResourceType().getCurrent())
            return true;
        else
            return false;
    }

    @Override
    public int maximumCount() {
        return 10;
    }

    @Override
    public int currentCount() {
        return count;
    }

    @Override
    public void upgrade() {
        getResourceType().minusCurrent(cost);
        count++;
        setCost();
    }

    @Override
    public int getIndex() {
        return index;
    }
}
