package com.katafrakt.zombieoff.game.weapons;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.entities.BulletType;
import com.katafrakt.zombieoff.entities.bullets.Bullet;
import com.katafrakt.zombieoff.game.weapons.hitbehaviour.HitBehaviour;
import com.katafrakt.zombieoff.managers.BulletFactory;
import com.katafrakt.zombieoff.managers.EngineEdited;
import com.katafrakt.zombieoff.player.PlayerStatics;

public class SprayWeapon extends RangedWeapon {
    Vector2 speed=new Vector2();
    Bullet.Builder builder=new Bullet.Builder();
    int bulletCount;
    int size=2;

    public SprayWeapon(Recommended recommended, HitBehaviour hitBehaviour, BulletType bulletType, float attackSpeed, float damageRatio, int range, float accuracy, float bulletVelocity, int bulletCount) {
        super(recommended, hitBehaviour,bulletType, attackSpeed, damageRatio, range, accuracy, bulletVelocity);
        this.bulletCount=bulletCount;
    }
    public SprayWeapon(Level level){
        super(level.recommended, level.hitBehaviour, level.bulletType, level.attackSpeed, level.damageRation,level.range,level.accuracy,level.bulletVelocity);
    }

    @Override
    public void attack(CreatureComponent attacker, CreatureComponent target) {
        TransformComponent transformComponent= Mappers.transformComponents.get(attacker.entity);
        TransformComponent targetTransform=Mappers.transformComponents.get(target.entity);

        for (int i=0;i<bulletCount;i++){
            PlayerStatics.getInstance().bulletFired.add(+1);
            Vector3 bulletTarget=bulletRandomizer(targetTransform.pos,transformComponent.pos,attacker.accuracy);
            speed.set(bulletTarget.x,bulletTarget.y);
            float time=speed.len()/bulletVelocity*bulletTarget.z;
            speed=speed.scl(bulletVelocity/speed.len()*(random.nextFloat()+0.5f));
            builder.set(attacker.entityType.getBullet(),bulletType,hitBehaviour,transformComponent.pos.x,transformComponent.pos.y,2,2,speed,attacker.getDamage()*damageRatio,time,abilityControllers);
            BulletFactory.getInstance().createBullet(builder);

        }
    }

    @Override
    protected Vector3 bulletRandomizer(Vector2 target, Vector2 pos, float skill) {
        float randomizer1= (float) (Math.PI/16*(1-2*random.nextFloat())*((100-skill)/100))*2;
        float randomizer2= (float) (Math.PI/16*(1-2*random.nextFloat())*((200-skill)/200)*((100-accuracy)/100));
        float angle= target.angleRad(new Vector2(-target.x+pos.x,-target.y+pos.y));//+randomizer1+randomizer2;
        Vector2 direction=new Vector2(target.x-pos.x,target.y-pos.y).rotateRad(randomizer1+randomizer2);
        //Gdx.app.log(TAG,"Ang: "+target.angleRad(pos));
        return new Vector3(direction.x,direction.y,random.nextFloat()+0.5f);
    }

    @Override
    public float getAttackRate(CreatureComponent attacker) {
        return 1/(attackRate*attacker.getAttRate());
    }

    public static class Level{
        public Recommended recommended;
        public HitBehaviour hitBehaviour;
        public BulletType bulletType;
        public float attackSpeed;
        public float damageRation;
        public int range;
        public float accuracy;
        public float bulletVelocity;

        public Level(Recommended recommended, HitBehaviour hitBehaviour, BulletType bulletType, float attackSpeed, float damageRation, int range, float accuracy, float bulletVelocity) {
            this.recommended = recommended;
            this.hitBehaviour = hitBehaviour;
            this.bulletType = bulletType;
            this.attackSpeed = attackSpeed;
            this.damageRation = damageRation;
            this.range = range;
            this.accuracy = accuracy;
            this.bulletVelocity = bulletVelocity;
        }
    }
}
