package com.katafrakt.zombieoff.game.abilitiybehaviours;

public abstract class CloneableAbilityController<T extends AbilityController<T>> extends AbilityController<T> {
    public abstract CloneableAbilityController clone();
}
