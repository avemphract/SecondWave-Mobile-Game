package com.katafrakt.zombieoff.ui.desicions;

import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Touchable;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Stack;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.game.upgradebehaviours.UpgradeBehaviour;
import com.katafrakt.zombieoff.managers.AssetOrganizer;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.ui.DecisionsUI;
import com.katafrakt.zombieoff.ui.PlayerHud;

public class AbilityDecision extends Table implements DecisionInterface {
    private static final String TAG= AbilityDecision.class.getSimpleName();

    PlayerHud playerHud;
    DecisionsUI decisionsUI;
    UpgradeManager upgradeManager;
    TextureAtlas external;
    Skin defaultSkin;

    Table title;
    Button closeButton;

    Table information;
    UpgradeManager.AbilityLevel abilityLevel =UpgradeManager.getInstance().abilityLevel;
        Label abilityLabel;
        Image levelImage;
        Label currentPoint;
        Label nextPoint;

    ScrollPane scrollPane;
    Table content;

    Array<UpgradeBehaviour> abilityUpgrades = new Array<>();
    Array<UpgradeTable> abilityTables = new Array<>();

    float fontSize=1;
    public AbilityDecision(PlayerHud playerHud, DecisionsUI decisionsUI){
        this.playerHud=playerHud;
        this.decisionsUI=decisionsUI;

        defaultSkin=decisionsUI.defaultSkin;

        upgradeManager=UpgradeManager.getInstance();
        external= AssetOrganizer.getInstance().get("atlases/externaldrawable.atlas",TextureAtlas.class);
        //title
            title= new Table();
                closeButton=decisionsUI.closeButtonA;
                Label titleText=new Label("Abilities", playerHud.firstLabel);
                titleText.setFontScale(fontSize);
            title.add(titleText).align(Align.topRight).grow();
            title.add(closeButton).align(Align.topLeft);
        add(title).fillX().expandX().pad(5,5,5,5);
        row();
        //information

            information=new Table();
                abilityLabel=new Label("Ability level: "+abilityLevel.currentAbilityLevel, playerHud.secondLabel);
                abilityLabel.setFontScale(fontSize);
            information.add(abilityLabel).colspan(2).expandX().fillX();
            information.row();


                levelImage=new Image(AssetOrganizer.getInstance().get("atlases/colors.atlas",TextureAtlas.class).findRegion("Yellow"));
                levelImage.setHeight(20);
            information.add(levelImage).colspan(2).fillX().expandX().height(10);
            information.row();

                currentPoint=new Label("Current: "+abilityLevel.currentAbilityPoint, playerHud.secondLabel);
                currentPoint.setFontScale(fontSize);
            information.add(currentPoint).align(Align.left);

                nextPoint=new Label("Required: "+abilityLevel.abilityLevelPoints[abilityLevel.currentAbilityLevel+1], playerHud.secondLabel);
                nextPoint.setFontScale(fontSize);
            information.add(nextPoint).align(Align.right);


        add(information).fillX().expandX().pad(5,5,5,5);
        row();
        //content
            content=new Table();
        //add(content).fillX().expandY().align(Align.top);

        scrollPane=new ScrollPane(content);
        scrollPane.getActor().setWidth(getWidth());
        scrollPane.getStyle().background=playerHud.passiveGray;
        add(scrollPane).fillX().expandY().align(Align.top);

        resetUpgrade();

        background(playerHud.blueRounded);
    }

    private void resetUpgrade(){
        upgradeManager.setUpgradeBehaviours();
        for(UpgradeBehaviour upgradeBehaviour:UpgradeManager.getInstance().abilityArray){
            if (abilityUpgrades.contains(upgradeBehaviour,true))
                continue;
            abilityUpgrades.add(upgradeBehaviour);
            abilityTables.add(new UpgradeTable(upgradeBehaviour));
        }

        content.clearChildren();
        for(UpgradeTable upgradeTable:abilityTables){
            content.add(upgradeTable).expandX().fill().minHeight(150).pad(5,5,5,5);
            content.row();
        }

        abilityLabel.setText("Ability level: "+abilityLevel.currentAbilityLevel);
        levelImage.setScaleX((abilityLevel.currentAbilityPoint - abilityLevel.abilityLevelPoints[abilityLevel.currentAbilityLevel])/(abilityLevel.abilityLevelPoints[abilityLevel.currentAbilityLevel+1] - abilityLevel.abilityLevelPoints[abilityLevel.currentAbilityLevel]));
        currentPoint.setText("Current: "+abilityLevel.currentAbilityPoint);
        nextPoint.setText("Required: "+abilityLevel.abilityLevelPoints[abilityLevel.currentAbilityLevel+1]);

    }

    @Override
    public void show() {
        resetUpgrade();
    }

    @Override
    public void render(float delta) {
        for (UpgradeTable upgradeTable:abilityTables)
            upgradeTable.render();
    }

    @Override
    public void resize(int width, int height) {

    }


    class UpgradeTable extends Table{
        Stack buttonStack;
        Button button=new Button(playerHud.activeGray, playerHud.checkedGray);
        Label buttonText;
        Image buttonImage;

        Label name,cost,count,effect;
        ResourceUpgrade resourceUpgrade;

        Table firstRow;
        Table secondRow;

        boolean isCompleted;

        public UpgradeTable(final UpgradeBehaviour upgradeBehaviour){
            background(playerHud.activeGray);
            resourceUpgrade= (ResourceUpgrade) upgradeBehaviour;
            //setDebug(true);
                firstRow=new Table();
                    name=new Label(resourceUpgrade.getName(), playerHud.secondLabel);
                    name.setFontScale(fontSize);
                firstRow.add(name).fillX().expandX();
                    /*count=new Label(resourceUpgrade.currentCount()+"/"+resourceUpgrade.maximumCount(),skin);
                    count.setWrap(true);
                    count.setFontScale(fontSize);
                firstRow.add(count).fillX().align(Align.right);*/
            add(firstRow).expandX().fillX().pad(10).align(Align.topLeft);
            row();

                secondRow=new Table();
                    effect=new Label(resourceUpgrade.effect(), playerHud.thirdLabel);
                    effect.setWrap(true);
                    effect.setFontScale(fontSize);
                    effect.getGlyphLayout().height=5;
                secondRow.add(effect).fillX().expandX();
            add(secondRow).expandY().fillX().pad(10).align(Align.left);
            row();

                buttonStack = new Stack();
                    //buttonImage=new Image(AssetOrganizer.getInstance().get("atlases/colors.atlas",TextureAtlas.class).findRegion("Black"));
                    buttonImage=new Image(resourceUpgrade.getResourceType().colorTexture);
                    //buttonImage.setColor(0.9f,0.9f,0.2f,0.5f);
                    buttonImage.setTouchable(Touchable.disabled);
                buttonStack.add(buttonImage);
                        buttonText=new Label(resourceUpgrade.getResourceType().getCurrent()+"/"+resourceUpgrade.requiredResource(), playerHud.thirdLabel);
                        buttonText.setFontScale(fontSize);
                        buttonText.setTouchable(Touchable.disabled);
                    button.add(buttonText);
                buttonStack.add(button);
            add(buttonStack).align(Align.bottom);

            getCell(buttonStack).fillX().center().pad(5);

            button.addListener(new ClickListener(){
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    super.clicked(event, x, y);
                    if (resourceUpgrade.enoughResource()){
                        abilityLevel.addPoint(resourceUpgrade.requiredResource());
                        resourceUpgrade.upgrade();
                        resetLabels();
                        resetUpgrade();
                    }
                }
            });

            buttonImage.setSize(button.getWidth()/2,button.getHeight());
            //setDebug(true,false);
        }

        private void resetLabels(){
            name.setText(resourceUpgrade.getName());
            name.setWrap(true);
            effect.setText(resourceUpgrade.effect());
            effect.setWrap(true);
            if (resourceUpgrade.currentCount()==resourceUpgrade.maximumCount()){
                button.setTouchable(Touchable.disabled);
                isCompleted=true;
                buttonText.setText("Completed");

                buttonStack.removeActor(buttonImage);
            }
        }

        private int prev;
        private void render(){
            if (isCompleted)
                return;

            if (resourceUpgrade.enoughResource()){
                buttonImage.setScaleX(1);
                if (resourceUpgrade.currentCount()==0)
                    buttonText.setText("Buy: "+resourceUpgrade.requiredResource());
                else
                    buttonText.setText("Unlock: "+resourceUpgrade.requiredResource());
            }
            else {
                float ratio=resourceUpgrade.getResourceType().getCurrent()/resourceUpgrade.requiredResource();
                buttonText.setText("Require: "+((int)resourceUpgrade.getResourceType().getCurrent())+"/"+resourceUpgrade.requiredResource());
                buttonImage.setScaleX(ratio);
            }
        }
    }
}
