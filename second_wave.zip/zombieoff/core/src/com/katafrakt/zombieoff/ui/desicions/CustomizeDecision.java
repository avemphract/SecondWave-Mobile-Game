package com.katafrakt.zombieoff.ui.desicions;

import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.ButtonGroup;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ArrayMap;
import com.badlogic.gdx.utils.ObjectMap;
import com.badlogic.gdx.utils.Sort;
import com.katafrakt.zombieoff.entities.EntityType;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponInformation;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.player.ZombieBuilder;
import com.katafrakt.zombieoff.ui.DecisionsUI;
import com.katafrakt.zombieoff.ui.PlayerHud;

import org.jetbrains.annotations.NotNull;


public class CustomizeDecision extends Table implements DecisionInterface {
    private static final String TAG= CustomizeDecision.class.getSimpleName();

    UpgradeManager upgradeManager;
    PlayerHud playerHud;
    DecisionsUI decisionsUI;
    Skin defaultSkin;

    Table title;

    ZombieTypeButtons zombieTypeButtons;


    float fontSize=1;


    public CustomizeDecision(PlayerHud playerHud, DecisionsUI decisionsUI){
        this.playerHud=playerHud;
        this.decisionsUI=decisionsUI;
        this.defaultSkin =decisionsUI.defaultSkin;
        upgradeManager=UpgradeManager.getInstance();


        setFillParent(true);

            title=new Table();
                //closeButton
                Label titleText=new Label("Customize", playerHud.firstLabel);
                titleText.setFontScale(fontSize);
            title.add(titleText).expandX().align(Align.left);
            title.add(decisionsUI.closeButtonC);
        add(title).fillX().expandX().pad(5);
        row();

            zombieTypeButtons=new ZombieTypeButtons();
        add(zombieTypeButtons).fillX().expand().align(Align.top);

        background(playerHud.blueRounded);

    }


    @Override
    public void show(){
        zombieTypeButtons.show();
        zombieTypeButtons.setContent();
    }

    @Override
    public void render(float delta) {

    }

    @Override
    public void resize(int width, int height) {

    }

    class ZombieTypeButtons extends Table {
        ButtonGroup<Button> buttonGroup = new ButtonGroup<Button>();

        ArrayMap<Button, CategoryButtons> map = new ArrayMap<>();

        Table buttons = new Table();
        Table content = new Table();

        public ZombieTypeButtons() {
            buttonGroup.setMaxCheckCount(1);
            buttonGroup.setMinCheckCount(1);
            for (final EntityType entityType : ZombieBuilder.getInstance().unlockedTypes) {
                Button button = new Button(playerHud.passiveGray, playerHud.activeGray, playerHud.checkedGray);
                button.add(new Label(entityType.getName(), playerHud.secondLabel));
                buttonGroup.add(button);

                final CategoryButtons categoryButtons = new CategoryButtons(entityType);

                map.put(button,categoryButtons);

                button.addListener(new ClickListener() {
                    @Override
                    public void clicked(InputEvent event, float x, float y) {
                        super.clicked(event, x, y);
                        content.clear();

                        if (map.get(buttonGroup.getChecked()).abilityOrWeapon.getChecked()==map.get(buttonGroup.getChecked()).weaponButton)
                            map.get(buttonGroup.getChecked()).setWeaponTable();
                        else
                            map.get(buttonGroup.getChecked()).setAbilityTable();

                        content.add(categoryButtons).fillX().expandX();
                    }
                });

                buttons.add(button).fillX().expandX();
            }

            content.add(map.firstValue());

            add(buttons).expandX().fillX();
            row();
            add(content).fillX().expand().pad(5,5,5,5);

        }

        public void setContent(){
            content.clear();
            if (map.get(buttonGroup.getChecked()).abilityOrWeapon.getChecked()==map.get(buttonGroup.getChecked()).weaponButton)
                map.get(buttonGroup.getChecked()).setWeaponTable();
            else
                map.get(buttonGroup.getChecked()).setAbilityTable();
            content.add(map.get(buttonGroup.getChecked())).expandX().fillX();

        }

        public void show(){
            for (ObjectMap.Entry<Button, CategoryButtons> entry:map){
                entry.value.createAbilityTable();
                entry.value.createWeaponTable();
            }
        }

        class CategoryButtons extends Table {
            EntityType entityType;
            Sort sort=new Sort();

            Array<AbilityCreator> abilityCreators = new Array<>();
            public Array<AbilityTable> abilityTables = new Array<>();
            Array<WeaponInformation> weaponCreators = new Array<>();
            public Array<WeaponTable> weaponTables = new Array<>();

            ButtonGroup<Button> abilityGroup=new ButtonGroup<>();
            ButtonGroup<Button> weaponGroup=new ButtonGroup<Button>();

            ButtonGroup<Button> abilityOrWeapon = new ButtonGroup<>();

            Table textTable;
                Table row1;
                Label health;
                Label damage;
                Label speed;
                Label awareRange;

                Table row2;
                Label abilityLimit;
                Label weaponLimit;
                Label energyRequirement;

            Table buttons;
            public Button abilityButton;
            public Button weaponButton;

            ScrollPane scrollPane;
            Table content;

            public CategoryButtons(final EntityType entityType) {
                this.entityType = entityType;

                    textTable=new Table();
                        row1=new Table();
                            health=new Label("Hp: "+(int)ZombieBuilder.getInstance().builderMap.get(entityType).getHp(), playerHud.thirdLabel);
                            health.setFontScale(fontSize);
                        row1.add(health).expandX().align(Align.left);
                            damage=new Label("Dmg: "+ZombieBuilder.getInstance().builderMap.get(entityType).getAtt(), playerHud.thirdLabel);
                            damage.setFontScale(fontSize);
                        row1.add(damage).expandX().align(Align.left);
                            speed=new Label("Spd: "+ZombieBuilder.getInstance().builderMap.get(entityType).getSpe(), playerHud.thirdLabel);
                            speed.setFontScale(fontSize);
                        row1.add(speed).expandX().align(Align.left);
                            awareRange=new Label("Awa: "+ZombieBuilder.getInstance().builderMap.get(entityType).getAwa(), playerHud.thirdLabel);
                            awareRange.setFontScale(fontSize);
                        row1.add(awareRange).expandX().align(Align.left);
                    textTable.add(row1).pad(5).growX();
                    textTable.row();

                        row2=new Table();
                            abilityLimit=new Label("Ability: "+ZombieBuilder.getInstance().builderMap.get(entityType).abilityLimit, playerHud.thirdLabel);
                            abilityLimit.setFontScale(fontSize);
                        row2.add(abilityLimit).expandX().align(Align.left);
                            weaponLimit=new Label("Weapon: "+ZombieBuilder.getInstance().builderMap.get(entityType).weaponLimit, playerHud.thirdLabel);
                            weaponLimit.setFontScale(fontSize);
                        row2.add(weaponLimit).expandX().align(Align.left);
                            energyRequirement=new Label("Energy: "+ZombieBuilder.getInstance().builderMap.get(entityType).getEne(), playerHud.thirdLabel);
                            energyRequirement.setFontScale(fontSize);
                        row2.add(energyRequirement).expandX().align(Align.left);
                    textTable.add(row2).pad(5).growX();

                add(textTable).expandX().fillX().pad(0,0,3,0);
                row();

                    buttons=new Table();
                        abilityButton = new Button(playerHud.passiveGray, playerHud.activeGray, playerHud.checkedGray);
                            Label abilityLabel = new Label("Abilities", playerHud.secondLabel);
                            abilityLabel.setFontScale(fontSize);
                        abilityButton.add(abilityLabel);
                    buttons.add(abilityButton).expandX().fillX();

                        weaponButton = new Button(playerHud.passiveGray, playerHud.activeGray, playerHud.checkedGray);
                            Label weaponLabel = new Label("Weapons", playerHud.secondLabel);
                            weaponLabel.setFontScale(fontSize);
                        weaponButton.add(weaponLabel);
                    buttons.add(weaponButton).expandX().fillX();
                add(buttons).growX();

                row();
                    content=new Table();
                scrollPane=new ScrollPane(content);
                add(scrollPane).expand().fillX();

                abilityButton.addListener(new ClickListener() {
                    @Override
                    public void clicked(InputEvent event, float x, float y) {
                        super.clicked(event, x, y);
                        setAbilityTable();
                    }
                });
                weaponButton.addListener(new ClickListener(){
                    @Override
                    public void clicked(InputEvent event, float x, float y) {
                        super.clicked(event, x, y);
                        setWeaponTable();
                    }
                });


                abilityOrWeapon.add(abilityButton,weaponButton);


                abilityOrWeapon.setMinCheckCount(1);
                abilityOrWeapon.setMaxCheckCount(1);

            }

            public void resetTextTable(){
                health.setText("Hp: "+(int)ZombieBuilder.getInstance().builderMap.get(entityType).getHp());
                damage.setText("Dmg: "+ZombieBuilder.getInstance().builderMap.get(entityType).getAtt());
                speed.setText("Spd: "+ZombieBuilder.getInstance().builderMap.get(entityType).getSpe());
                awareRange.setText("Awa: "+ZombieBuilder.getInstance().builderMap.get(entityType).getAwa());

                abilityLimit.setText("Ability: "+ZombieBuilder.getInstance().builderMap.get(entityType).abilities.size+"/"+ZombieBuilder.getInstance().builderMap.get(entityType).abilityLimit);
                weaponLimit.setText("Weapon: "+ZombieBuilder.getInstance().builderMap.get(entityType).weaponLimit);
                energyRequirement.setText("Energy: "+ZombieBuilder.getInstance().builderMap.get(entityType).getEne());

            }

            public void createAbilityTable() {
                abilityGroup.setMaxCheckCount(ZombieBuilder.getInstance().builderMap.get(entityType).abilityLimit);
                abilityGroup.setMinCheckCount(0);
                for (AbilityCreator abilityCreator : ZombieBuilder.getInstance().abilityCreators) {
                    if (abilityCreators.contains(abilityCreator, false)){
                        continue;
                    }

                    AbilityTable abilityTable = new AbilityTable(abilityCreator,this);
                    abilityGroup.add(abilityTable.button);

                    abilityCreators.add(abilityCreator);
                    abilityTables.add(abilityTable);
                }
            }
            public void createWeaponTable(){
                weaponGroup.setMaxCheckCount(ZombieBuilder.getInstance().builderMap.get(entityType).weaponLimit);
                weaponGroup.setMinCheckCount(1);
                for (WeaponInformation weaponInformation : ZombieBuilder.getInstance().weaponCreators){
                    if (weaponCreators.contains(weaponInformation,false)){
                        continue;
                    }
                    if (!entityType.weaponTypes.contains(weaponInformation.type,false))
                        continue;

                    WeaponTable weaponTable=new WeaponTable(weaponInformation,this);
                    weaponGroup.add(weaponTable.button);

                    weaponCreators.add(weaponInformation);
                    weaponTables.add(weaponTable);

                }
            }

            private void setAbilityTable() {
                sort.sort(abilityTables);
                content.clear();
                for (AbilityTable abilityTable:abilityTables){
                    abilityTable.change();
                    if (ZombieBuilder.getInstance().builderMap.get(entityType).abilities.contains(abilityTable.abilityCreator,false))
                        abilityTable.button.setChecked(true);
                    content.add(abilityTable).height(130).expandX().fillX().pad(5,1,5,1);
                    content.row();

                }
            }

            private void setWeaponTable(){
                content.clear();
                for (WeaponTable weaponTable:weaponTables){
                    weaponTable.change();
                    if (ZombieBuilder.getInstance().builderMap.get(entityType).weapons.contains(weaponTable.weaponInformation,false))
                        weaponTable.button.setChecked(true);
                    content.add(weaponTable).height(130).expandX().fillX().pad(5,1,5,1);
                    content.row();
                }
            }
        }
    }

    class AbilityTable extends Table implements Comparable<AbilityTable>{
        public AbilityCreator abilityCreator;
        ZombieTypeButtons.CategoryButtons categoryButtons;

        Table table;
        Label title;
        Label level;
        Label details;
        Label energy;

        public Button button;

        public AbilityTable(AbilityCreator abilityCreator, final ZombieTypeButtons.CategoryButtons categoryButtons){
            background(playerHud.passiveGray);
            this.abilityCreator=abilityCreator;
            this.categoryButtons=categoryButtons;

                table=new Table();
                    title=new Label(abilityCreator.name, playerHud.secondLabel);
                    title.setFontScale(fontSize);
                table.add(title).fillX().expandX().align(Align.top).pad(3,3,0,3);
                    level=new Label("abilityCreator.level", playerHud.secondLabel);
                    level.setFontScale(fontSize);
                table.add(level).align(Align.right).pad(3,3,0,3);
                table.row();

                    details=new Label(abilityCreator.effect, playerHud.thirdLabel);
                    details.setWrap(true);
                    details.setFontScale(fontSize);
                table.add(details).grow().pad(0,3,0,3);
                table.row();
                    energy=new Label("Required: "+abilityCreator.energy, playerHud.secondLabel);
                    energy.setFontScale(fontSize);
                table.add(energy).expandX().pad(0,3,3,3).align(Align.left);
            add(table).expandX().fill().expandY().align(Align.top).pad(5,5,5,5);

                button=new Button(playerHud.passiveGray,playerHud.activeGray,playerHud.activeBlue);
            add(button).expandY().fillY().align(Align.right);

            button.addListener(new ClickListener(){
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    super.clicked(event, x, y);
                    AbilityTable.this.clicked();
                    categoryButtons.resetTextTable();
                }
            });
        }

        private void clicked(){
            ZombieBuilder.getInstance().builderMap.get(categoryButtons.entityType).abilities.clear();
            for (AbilityTable abilityTable:categoryButtons.abilityTables){
                if (abilityTable.button.isChecked()){
                    ZombieBuilder.getInstance().builderMap.get(categoryButtons.entityType).abilities.add(abilityTable.abilityCreator);
                }
            }
        }

        public void change(){
            level.setText(abilityCreator.level);
            details.setText(abilityCreator.effect);
            energy.setText("Required: "+abilityCreator.energy);
        }


        @Override
        public int compareTo(@NotNull AbilityTable abilityTable) {
            if (abilityCreator.index>abilityTable.abilityCreator.index)
                return -1;
            else{
                return 1;
            }
        }
    }

    class WeaponTable extends Table implements Comparable<WeaponTable> {
        public WeaponInformation weaponInformation;
        ZombieTypeButtons.CategoryButtons categoryButtons;

        Table content;
            Table row1;
                Label name;
                Label type;

            Table row2;
                Label damage;
                Label attRate;
                Label range;

            Table row3;
                Label details;

            Table row4;
                Label energy;

        Button button;

        public WeaponTable(WeaponInformation weaponInformation, final ZombieTypeButtons.CategoryButtons categoryButtons){
            background(playerHud.passiveGray);
            this.weaponInformation = weaponInformation;
            this.categoryButtons=categoryButtons;

            content=new Table();
                row1=new Table();
                    name=new Label(weaponInformation.name, playerHud.secondLabel);
                row1.add(name).expandX().align(Align.left);
                    type=new Label(weaponInformation.type.name(), playerHud.secondLabel);
                row1.add(type).expandX().align(Align.right);
            content.add(row1).fillX().expandX().align(Align.top).pad(0,0,5,0);
            content.row();

                row2=new Table();
                    damage=new Label("Dmg: "+ weaponInformation.damage, playerHud.thirdLabel);
                row2.add(damage).align(Align.left);
                    attRate=new Label("Rate: "+ weaponInformation.attRate, playerHud.thirdLabel);
                row2.add(attRate).expandX().align(Align.center);
                    range=new Label("Range"+ weaponInformation.range, playerHud.thirdLabel);
                row2.add(range).align(Align.right);
            content.add(row2).fillX().align(Align.top).pad(0,0,0,0);
            content.row();

                row3=new Table();
                    details=new Label(weaponInformation.detail, playerHud.thirdLabel);
                    details.setWrap(true);
                row3.add(details).growX();
            content.add(row3).fillX().expand().pad(0,0,0,0);
            content.row();

                row4=new Table();
                    energy=new Label("Required energy: "+ weaponInformation.energy, playerHud.thirdLabel);
                row4.add(energy).expandX().align(Align.left);
            content.add(row4).fillX().align(Align.bottom);

            add(content).grow().pad(5,5,5,10);
                button=new Button(playerHud.passiveGray,playerHud.activeGray,playerHud.activeBlue);
            add(button).fill();

            background(playerHud.passiveGray);

            button.addListener(new ClickListener(){
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    super.clicked(event, x, y);
                    WeaponTable.this.clicked();
                    categoryButtons.resetTextTable();
                }
            });

        }


        private void clicked(){
            ZombieBuilder.getInstance().builderMap.get(categoryButtons.entityType).weapons.clear();
            for (WeaponTable weaponTable:categoryButtons.weaponTables){
                if (weaponTable.button.isChecked()){
                    ZombieBuilder.getInstance().builderMap.get(categoryButtons.entityType).weapons.add(weaponTable.weaponInformation);
                }
            }
        }

        public void change(){
            name.setText(weaponInformation.name);
            type.setText(weaponInformation.type.name());

            damage.setText("Dmg: "+ weaponInformation.damage);
            attRate.setText("Rate: "+ weaponInformation.attRate);
            range.setText("Range: "+ weaponInformation.range);

            details.setText(weaponInformation.detail);
        }

        @Override
        public int compareTo(@NotNull WeaponTable weaponTable) {
            if (weaponInformation.index>weaponTable.weaponInformation.index)
                return -1;
            else{
                return 1;
            }
        }
    }
}
