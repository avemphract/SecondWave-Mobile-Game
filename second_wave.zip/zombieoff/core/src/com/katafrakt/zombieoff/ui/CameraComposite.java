package com.katafrakt.zombieoff.ui;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.katafrakt.zombieoff.Main;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.game.weapons.Weapon;
import com.katafrakt.zombieoff.managers.MapManager;

public class CameraComposite implements InputProcessor {
    private static final String TAG=CameraComposite.class.getSimpleName();
    private OrthographicCamera camera;

    private boolean locked;
    private TransformComponent entityTarget;
    private Vector2 target;

    float width,height;

    public CameraComposite(OrthographicCamera camera){
        this.camera=camera;
        locked=false;
        camera.zoom=12;
    }
    public void setInitialPosition(float x, float y){
        if (y%2==1)
            camera.position.set(x,y+0.5f,0);
        else
            camera.position.set(x,x,0);

    }

    public void update(){
        if (locked) {
            if (entityTarget != null) {
                camera.position.set(entityTarget.pos.x,entityTarget.pos.y,0);
            } else if (target != null) {
                camera.position.set(target.x,target.y,0);
            }
        }

        camera.update();

    }
    public void resize(float width,float height){
        this.width= width;
        this.height= height;
    }

    public float getMinWidth(){
        return camera.position.x-camera.zoom*camera.viewportWidth/2;
    }
    public float getMaxWidth(){
        return camera.position.x+camera.zoom*camera.viewportWidth/2;
    }
    public float getMinHeight(){
        return camera.position.y-camera.zoom*camera.viewportHeight/2;
    }
    public float getMaxHeight(){
        return camera.position.y+camera.zoom*camera.viewportHeight/2;
    }

    @Override
    public boolean keyDown(int keycode) {
        return false;
    }

    @Override
    public boolean keyUp(int keycode) {
        return false;
    }

    @Override
    public boolean keyTyped(char character) {
        return false;
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        lastMousePosition=null;
        //Gdx.app.log(TAG,"W:"+camera.zoom*camera.viewportWidth);
        //Gdx.app.log(TAG,"Screen:"+screenX+","+screenY);
        if (button==0){
            //Gdx.app.log(TAG,camera.unproject(new Vector3(screenX,screenY,0)).toString());
        }
        /*if (button==1){
            //Gdx.app.log(TAG,"CameraPosition:"+camera.position.x+","+camera.position.y);
            Gdx.app.log(TAG,"TopLeft:"+(camera.position.x-camera.viewportWidth*currentZoom/20)+","+(camera.position.y+camera.viewportHeight*currentZoom/20));
            Gdx.app.log(TAG,"BottomRight"+(camera.position.x+camera.viewportWidth*currentZoom/20)+","+(camera.position.y-camera.viewportHeight*currentZoom/20));
        }*/
        return false;

    }

    float[] lastMousePosition;
    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        float posX= (screenX*(camera.viewportWidth/width)*camera.zoom);
        float posY= (screenY*(camera.viewportHeight/height)*camera.zoom);
        if (!locked){
            if (lastMousePosition==null){
                lastMousePosition=new float[]{posX,posY};
            }
            else {
                camera.position.add(0,posY - lastMousePosition[1],0);
                camera.position.add(-posX + lastMousePosition[0],0,0);
                lastMousePosition[0]=posX;
                lastMousePosition[1]=posY;
                //Gdx.app.log(TAG,"CameraWidth:"+camera.viewportWidth*camera.zoom+" CameraHeight:"+camera.viewportHeight*camera.zoom);
            }
            //camera.position.x= MathUtils.clamp(camera.position.x,camera.viewportWidth/2*camera.zoom, MapManager.getInstance().mapPixelWidth-camera.viewportWidth/2*camera.zoom);
            //camera.position.y=MathUtils.clamp(camera.position.y,camera.viewportHeight/2*camera.zoom, MapManager.getInstance().mapPixelWidth-camera.viewportHeight/2*camera.zoom);
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseMoved(int screenX, int screenY) {
        return false;
    }

    @Override
    public boolean scrolled(float amountX, float amountY) {
        int amount= (int) amountY;
        if (((camera.zoom+2*amount)*camera.viewportWidth<MapManager.getInstance().mapPixelWidth)&&((camera.zoom+2*amount)*camera.viewportHeight<MapManager.getInstance().mapPixelHeight))
            camera.zoom+=2*amount;
        if (camera.zoom<1)
            camera.zoom=1;

        camera.position.x= MathUtils.clamp(camera.position.x,camera.viewportWidth/2*camera.zoom, MapManager.getInstance().mapPixelWidth-camera.viewportWidth/2*camera.zoom);
        camera.position.y=MathUtils.clamp(camera.position.y,camera.viewportHeight/2*camera.zoom, MapManager.getInstance().mapPixelWidth-camera.viewportHeight/2*camera.zoom);
        return true;
    }


    public OrthographicCamera getCamera(){
        return camera;
    }
    public void setTarget(Vector2 target) {
        this.target = target;
    }
    public void setTarget(Entity entity){
        this.entityTarget=entity.getComponent(TransformComponent.class);
    }
}
