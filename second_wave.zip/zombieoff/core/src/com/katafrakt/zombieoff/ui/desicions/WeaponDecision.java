package com.katafrakt.zombieoff.ui.desicions;

import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Touchable;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Stack;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.game.upgradebehaviours.UpgradeBehaviour;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponUnlock;
import com.katafrakt.zombieoff.managers.AssetOrganizer;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.ui.DecisionsUI;
import com.katafrakt.zombieoff.ui.PlayerHud;


public class WeaponDecision extends Table implements DecisionInterface {
    private static final String TAG= WeaponDecision.class.getSimpleName();
    PlayerHud playerHud;
    DecisionsUI decisionsUI;
    UpgradeManager upgradeManager;
    TextureAtlas external;
    Skin defaultSkin;

    Table title;
    Button closeButton;
    ScrollPane scrollPane;
    Table content;

    Array<UpgradeBehaviour> weaponUpgrades=new Array<>();
    Array<UpgradeTable> weaponTables =new Array<>();

    float fontSize=1;

    public WeaponDecision(PlayerHud playerHud, DecisionsUI decisionsUI){
        this.playerHud=playerHud;
        this.decisionsUI=decisionsUI;
        this.defaultSkin =decisionsUI.defaultSkin;
        upgradeManager=UpgradeManager.getInstance();
        external= AssetOrganizer.getInstance().get("atlases/externaldrawable.atlas",TextureAtlas.class);
        //title
            title=new Table(defaultSkin);
                closeButton=decisionsUI.closeButtonW;
                Label titleText=new Label("Weapons", playerHud.firstLabel);
                titleText.setFontScale(fontSize);
            title.add(titleText).align(Align.topRight).grow();
            title.add(closeButton).align(Align.topRight);
        add(title).fillX().expandX().pad(5,5,5,5);
        row();

        //content
            content=new Table();

        scrollPane=new ScrollPane(content);
        add(scrollPane).fillX().expandY().align(Align.top);
        scrollPane.getStyle().background=playerHud.passiveGray;

        resetUpgrade();
        background(playerHud.blueRounded);

    }

    private void resetUpgrade(){
        for (UpgradeBehaviour upgradeBehaviour:UpgradeManager.getInstance().weaponArray){
            if (weaponUpgrades.contains(upgradeBehaviour,false))
                continue;
            weaponUpgrades.add(upgradeBehaviour);
            weaponTables.add(new UpgradeTable((WeaponUnlock) upgradeBehaviour));
        }
        content.clearChildren();
        for (UpgradeTable upgradeTable:weaponTables) {
            content.add(upgradeTable).pad(5,5,5,5).expandX().fillX();
            content.row();
        }
    }

    @Override
    public void show() {
        resetUpgrade();
    }

    @Override
    public void render(float delta) {
        for (UpgradeTable upgradeTable:weaponTables){
            upgradeTable.render();
        }
    }

    @Override
    public void resize(int width, int height) {

    }

    class UpgradeTable extends Table{
        Stack buttonStack;
        Button button=new Button(playerHud.activeGray,playerHud.checkedGray);
        Label buttonText;
        Image buttonImage;

        Table firstRow;
        Label title,type;

        Table secondRow;
        Label damage,attRate,range;

        Table thirdRow;
        Label effect;

        WeaponUnlock weaponUnlock;

        boolean isCompleted;

        public UpgradeTable(final WeaponUnlock weaponUnlock){
            this.weaponUnlock=weaponUnlock;

            background(playerHud.activeGray);

                firstRow=new Table();
                    title=new Label(weaponUnlock.getTitle(), playerHud.secondLabel);
                    //title.setFontScale(fontSize);
                firstRow.add(title).expandX().align(Align.left);
                    type=new Label(weaponUnlock.getType(), playerHud.secondLabel);
                    type.setFontScale(fontSize);
                firstRow.add(type).align(Align.right);
            add(firstRow).fillX().expandX().pad(10,10,10,10);
            row();

                secondRow=new Table();
                    damage=new Label(weaponUnlock.getDamage(), playerHud.thirdLabel);
                    damage.setFontScale(fontSize);
                secondRow.add(damage).align(Align.left);
                    attRate=new Label(weaponUnlock.getAttRate(), playerHud.thirdLabel);
                    attRate.setFontScale(fontSize);
                secondRow.add(attRate).expandX().align(Align.center);
                    range=new Label(weaponUnlock.getRange(), playerHud.thirdLabel);
                    range.setFontScale(fontSize);
                secondRow.add(range).align(Align.right);
            add(secondRow).fillX().pad(5,10,5,10);
            row();

                thirdRow=new Table();
                    effect=new Label(weaponUnlock.effect(), playerHud.thirdLabel);
                    effect.setFontScale(fontSize);
                    effect.setWrap(true);
                thirdRow.add(effect).expand().fillX();
            add(thirdRow).fillX().expandY().pad(5,10,5,10);
            row();

                buttonStack = new Stack();
                    buttonImage=new Image(weaponUnlock.getResourceType().colorTexture);
                    buttonImage.setTouchable(Touchable.disabled);
                buttonStack.add(buttonImage);
                        buttonText=new Label(weaponUnlock.getResourceType().getCurrent()+"/"+weaponUnlock.requiredResource(), playerHud.thirdLabel);
                        buttonText.setFontScale(fontSize);
                        buttonText.setTouchable(Touchable.disabled);
                    button.add(buttonText).pad(2,2,2,2);
                buttonStack.add(button);
            add(buttonStack).align(Align.bottom).fillX().pad(5,5,5,5);
            row();

            button.addListener(new ClickListener(){
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    super.clicked(event, x, y);
                    if (weaponUnlock.enoughResource()){
                        weaponUnlock.upgrade();
                        resetLabels();
                        resetUpgrade();
                    }
                }
            });

        }
        private void resetLabels(){
            title.setText(weaponUnlock.getTitle());
            damage.setText(weaponUnlock.getDamage());
            attRate.setText(weaponUnlock.getAttRate());
            range.setText(weaponUnlock.getRange());
            effect.setText(weaponUnlock.effect());

            if (weaponUnlock.currentCount()==weaponUnlock.maximumCount()){
                button.setTouchable(Touchable.disabled);
                isCompleted=true;
                buttonText.setText("Completed");

                buttonStack.removeActor(buttonImage);
            }
        }


        public void render(){
            if (isCompleted)
                return;

            if (weaponUnlock.enoughResource()){
                if (weaponUnlock.currentCount()==0)
                    buttonText.setText("Unlock: "+weaponUnlock.requiredResource());
                else
                    buttonText.setText("Improve: "+weaponUnlock.requiredResource());

                buttonImage.setScaleX(1);
            }
            else {
                float ratio = weaponUnlock.getResourceType().getCurrent()/weaponUnlock.requiredResource();
                buttonImage.setScaleX(ratio);
                buttonText.setText("Require: "+((int)weaponUnlock.getResourceType().getCurrent())+"/"+((int)weaponUnlock.requiredResource()));
            }

        }
    }
}
