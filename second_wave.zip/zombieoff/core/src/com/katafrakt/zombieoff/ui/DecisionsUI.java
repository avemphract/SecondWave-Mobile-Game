package com.katafrakt.zombieoff.ui;

import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.math.Interpolation;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.actions.ParallelAction;
import com.badlogic.gdx.scenes.scene2d.actions.SequenceAction;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.ButtonGroup;
import com.badlogic.gdx.scenes.scene2d.ui.Container;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.managers.AssetOrganizer;
import com.katafrakt.zombieoff.ui.desicions.AbilityDecision;
import com.katafrakt.zombieoff.ui.desicions.CustomizeDecision;
import com.katafrakt.zombieoff.ui.desicions.DecisionInterface;
import com.katafrakt.zombieoff.ui.desicions.GeneralDecision;
import com.katafrakt.zombieoff.ui.desicions.OptionsDecision;
import com.katafrakt.zombieoff.ui.desicions.PrestigeDecision;
import com.katafrakt.zombieoff.ui.desicions.TrophyDecision;
import com.katafrakt.zombieoff.ui.desicions.WeaponDecision;

import org.jetbrains.annotations.NotNull;

public class DecisionsUI extends Container<Table> {
    private static final String TAG= DecisionsUI.class.getSimpleName();
    public Skin defaultSkin;
    public Skin customSkin;



    public BitmapFont titleFont;

    PlayerHud playerHud;

    public Button closeButtonGI;
    public Button closeButtonT;
    public Button closeButtonW;
    public Button closeButtonA;
    public Button closeButtonC;
    public Button closeButtonP;

    public Button closeButtonOpt;

    Table container;
    Table category;

    Container<Table> contentWrapper;

    GeneralDecision generalDecision;
    TrophyDecision trophyDecision;
    WeaponDecision weaponDecision;
    AbilityDecision abilityDecision;
    CustomizeDecision customizeDecision;
    PrestigeDecision prestigeDecision;

    OptionsDecision optionsDecision;


    Array<Table> contents=new Array<>();
    public ButtonGroup<CategoryButton> buttonGroup;

    float width;
    float height;

    public float conWidth;
    float conHeight;


    float fontSize=1;

    public DecisionsUI(PlayerHud playerHud){
        this.playerHud=playerHud;
        defaultSkin =AssetOrganizer.getInstance().assetManager.get("skin/uiskin.json",Skin.class);
        customSkin =AssetOrganizer.getInstance().get("skin/custom_skin.json",Skin.class);



        //firstLabel.font= AssetOrganizer.getInstance().get("skin/title.fnt",BitmapFont.class);


        width = playerHud.viewport.getWorldWidth();
        height = playerHud.viewport.getWorldHeight();

        conWidth=width*0.3f+150;
        conHeight=height;

        setSize(conWidth,conHeight);
        setPosition(width-conWidth/5,0);
        fill();

        createCloseButtons();

        contentWrapper=new Container<>();
            contentWrapper.fill();
        container =new Table(defaultSkin);
        buttonGroup=new ButtonGroup<>();
            buttonGroup.setMaxCheckCount(1);
            buttonGroup.setMinCheckCount(0);

        container.setFillParent(true);
        setActor(container);

        generalDecision = new GeneralDecision(playerHud,this);
            contents.add(generalDecision);
        trophyDecision = new TrophyDecision(playerHud,this);
            contents.add(trophyDecision);
        weaponDecision = new WeaponDecision(playerHud,this);
            contents.add(weaponDecision);
        abilityDecision = new AbilityDecision(playerHud,this);
            contents.add(abilityDecision);
        customizeDecision = new CustomizeDecision(playerHud,this);
            contents.add(customizeDecision);
        prestigeDecision = new PrestigeDecision(playerHud,this);
            contents.add(prestigeDecision);

        optionsDecision = new OptionsDecision(playerHud,this);
            contents.add(optionsDecision);


        category=new Table();
            CategoryButton cat1=new CategoryButton(generalDecision,"Improve",1);
            buttonGroup.add(cat1);

            CategoryButton cat2=new CategoryButton(trophyDecision,"Trophy",2);
            buttonGroup.add(cat2);

            CategoryButton cat3=new CategoryButton(weaponDecision,"Weapons",3);
            buttonGroup.add(cat3);

            CategoryButton cat4=new CategoryButton(abilityDecision,"Abilities",4);
            buttonGroup.add(cat4);

            CategoryButton cat5=new CategoryButton(customizeDecision,"Customize",5);
            buttonGroup.add(cat5);

            CategoryButton cat6=new CategoryButton(prestigeDecision,"Prestige",6);
            buttonGroup.add(cat6);

            CategoryButton cat7=new CategoryButton(optionsDecision,"Options",-1);
            buttonGroup.add(cat7);

        setCategoryButton();
        //category.setDebug(true);
        container.add(category).fillX().growY().width(conWidth/4);
        container.add(contentWrapper).grow().align(Align.top);


    }
    public void setCategoryButton(){
        boolean firstBack=true;
        category.clear();
        category.padTop(50);
        for (CategoryButton categoryButton:buttonGroup.getButtons()){
            if (categoryButton.top)
                category.add(categoryButton).fillX().expandX().pad(15,0,15,0).top();
            else{
                if (firstBack){
                    category.add().growY();
                    category.row();
                    firstBack=false;
                }
                category.add(categoryButton).fillX().expandX().pad(15,0,15,0).bottom();
            }
            category.row();
        }
    }

    public void createCloseButtons() {
        int topPad=8;
        int leftPad=20;
        closeButtonGI = new Button(playerHud.activeGray, playerHud.checkedGray, playerHud.activeGray);
        closeButtonGI.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                super.clicked(event, x, y);
                buttonGroup.uncheckAll();
                setCurrentContent();
            }
        });
        Label buttonTextGI = new Label("Close", playerHud.secondLabel);
        buttonTextGI.setFontScale(fontSize);
        closeButtonGI.add(buttonTextGI).pad(topPad, leftPad, topPad, leftPad);


        closeButtonT = new Button(playerHud.activeGray, playerHud.checkedGray, playerHud.activeGray);
        closeButtonT.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                super.clicked(event, x, y);
                buttonGroup.uncheckAll();
                setCurrentContent();
            }
        });
        Label buttonTextT = new Label("Close", playerHud.secondLabel);
        buttonTextT.setFontScale(fontSize);
        closeButtonT.add(buttonTextT).pad(topPad, leftPad, topPad, leftPad);


        closeButtonW = new Button(playerHud.activeGray, playerHud.checkedGray, playerHud.activeGray);
        closeButtonW.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                super.clicked(event, x, y);
                buttonGroup.uncheckAll();
                setCurrentContent();
            }
        });
        Label buttonTextW = new Label("Close", playerHud.secondLabel);
        buttonTextW.setFontScale(fontSize);
        closeButtonW.add(buttonTextW).pad(topPad, leftPad, topPad, leftPad);


        closeButtonA = new Button(playerHud.activeGray, playerHud.checkedGray, playerHud.activeGray);
        closeButtonA.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                super.clicked(event, x, y);
                buttonGroup.uncheckAll();
                setCurrentContent();
            }
        });
        Label buttonTextA = new Label("Close", playerHud.secondLabel);
        buttonTextA.setFontScale(fontSize);
        closeButtonA.add(buttonTextA).pad(topPad, leftPad, topPad, leftPad);


        closeButtonC = new Button(playerHud.activeGray, playerHud.checkedGray, playerHud.activeGray);
        closeButtonC.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                super.clicked(event, x, y);
                buttonGroup.uncheckAll();
                setCurrentContent();
            }
        });
        Label buttonTextC = new Label("Close", playerHud.secondLabel);
        buttonTextC.setFontScale(fontSize);
        closeButtonC.add(buttonTextC).pad(topPad, leftPad, topPad, leftPad);


        closeButtonP = new Button(playerHud.activeGray, playerHud.checkedGray, playerHud.activeGray);
        closeButtonP.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                super.clicked(event, x, y);
                buttonGroup.uncheckAll();
                setCurrentContent();
            }
        });
        Label buttonTextP = new Label("Close", playerHud.secondLabel);
        buttonTextP.setFontScale(fontSize);
        closeButtonP.add(buttonTextP).pad(topPad, leftPad, topPad, leftPad);

        closeButtonOpt = new Button(playerHud.activeGray,playerHud.checkedGray,playerHud.activeGray);
        closeButtonOpt.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y) {
                super.clicked(event, x, y);
                buttonGroup.uncheckAll();
                setCurrentContent();
            }
        });
        Label buttonTextOpt = new Label("Close",playerHud.secondLabel);
        buttonTextOpt.setFontScale(fontSize);
        closeButtonOpt.add(buttonTextOpt).pad(topPad, leftPad, topPad, leftPad);

    }

    public void setCurrentContent(){
        if (buttonGroup.getChecked()!=null){
            if (buttonGroup.getChecked().setTable instanceof DecisionInterface)
                ((DecisionInterface) buttonGroup.getChecked().setTable).show();
            contentWrapper.setActor(buttonGroup.getChecked().setTable);
            addAction(Actions.moveTo(width-conWidth,0,0.2f,Interpolation.circleOut));
        }
        else{
            ParallelAction parallelAction=new ParallelAction(new SequenceAction(Actions.delay(0.2f),Actions.removeActor(contentWrapper.getActor())),Actions.moveTo(width-conWidth/5,0,0.2f,Interpolation.circleOut));
            addAction(parallelAction);
        }
    }

    public void render(float delta){
        if (contentWrapper.getActor()!=null){
        ((DecisionInterface)contentWrapper.getActor()).render(delta);}
        //weapons.render(delta);
    }

    public void resize(int width,int height){
        conWidth=width*0.3f+200;
        conHeight=height;
        this.width=width;
        this.height=height;

        container.getCell(category).width(conWidth/5);
        setSize(conWidth,conHeight);
        if (buttonGroup.getChecked()==null)
            setPosition(width-conWidth/5,0);
        else{
            setPosition(width-conWidth/5,0);
            addAction(Actions.moveTo(width-conWidth,0));
        }

        generalDecision.resize(width,height);
        trophyDecision.resize(width,height);
        weaponDecision.resize(width,height);
        abilityDecision.resize(width,height);
        customizeDecision.resize(width,height);
        prestigeDecision.resize(width,height);
        optionsDecision.resize(width,height);

    }

    public class CategoryButton extends Button implements Comparable<CategoryButton>{

        Table setTable;
        String string;
        Label label;

        public boolean top;
        public int queue;

        public CategoryButton(final Table setTable, String string,int i){
            super(customSkin.get(ButtonStyle.class));
            this.string=string;
            this.setTable=setTable;
            background(playerHud.passiveGray);
            label=new Label(string, playerHud.firstLabel);
                label.setFontScale(fontSize);
            add(label).pad(10);
            setChecked(false);
            addListener(new ClickListener(){
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    super.clicked(event, x, y);
                    setCurrentContent();
                }//clicked
            });//ClickListener

            if (i>0){
                top =true;
                queue=i;
            }
            else {
                top =false;
                queue=-i;
            }

        }

        @Override
        public int compareTo(@NotNull CategoryButton categoryButton) {
            if (top ==true&&categoryButton.top ==true){
                if (queue>categoryButton.queue)
                    return 1;
                else
                    return -1;
            }
            else if (top ==true&&categoryButton.top ==false){
                return 1;
            }
            else if (top ==false &&categoryButton.top ==false){
                if (queue>categoryButton.queue)
                    return -1;
                else
                    return 1;
            }
            else if (top ==false&&categoryButton.top ==true){
                return -1;
            }

            return 0;
        }
    }
}
