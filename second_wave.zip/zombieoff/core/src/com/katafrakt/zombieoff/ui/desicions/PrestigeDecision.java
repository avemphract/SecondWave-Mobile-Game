package com.katafrakt.zombieoff.ui.desicions;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.game.upgradebehaviours.UpgradeBehaviour;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.ui.DecisionsUI;
import com.katafrakt.zombieoff.ui.PlayerHud;
import com.katafrakt.zombieoff.utilities.Utility;

public class PrestigeDecision extends Table implements DecisionInterface {
    private static final String TAG= PrestigeDecision.class.getSimpleName();
    PlayerHud playerHud;
    DecisionsUI decisionsUI;
    Skin defaultSkin;

    Table title;
    Button closeButton;
    Table information;
        Label currentPrestige;
        Label nextPrestige;
    ScrollPane scrollPane;
    Table content;

    float fontSize=1f;

    Array<ResourceUpgrade> prestigeUpgrades=new Array<>();
    Array<UpgradeTable> upgradeTables=new Array<>();

    public PrestigeDecision(PlayerHud playerHud, DecisionsUI decisionsUI){
        this.playerHud=playerHud;
        this.decisionsUI=decisionsUI;
        this.defaultSkin =decisionsUI.defaultSkin;

        background(playerHud.blueRounded);

        //title
            title=new Table();
                Label titleText=new Label("Prestige", playerHud.firstLabel);
                titleText.setFontScale(fontSize);
            title.add(titleText).left().growX().pad(5,5,5,5);
                closeButton=decisionsUI.closeButtonP;
            title.add(closeButton).align(Align.topRight).pad(5,5,5,5);
        add(title).fillX().expandX().top();
        row();

        //information
            information=new Table();
                Label label11=new Label("Prestige will grant:", playerHud.thirdLabel);
                label11.setFontScale(fontSize);
            information.add(label11).align(Align.left).pad(4,0,4,0);
                nextPrestige=new Label("45651 prestige", playerHud.thirdLabel);
                nextPrestige.setFontScale(fontSize);
                nextPrestige.setColor(Color.CYAN);
            information.add(nextPrestige).fillX().align(Align.right);
            information.row().expandX();

                Label label21 = new Label("This will reset upgrades, resources and levels but grant you prestige points", playerHud.thirdLabel);
                label21.setFontScale(fontSize);
                label21.setWrap(true);
            information.add(label21).colspan(2).fillX().align(Align.left).pad(4,0,4,0);
            information.row();

                Button prestigeButton = new Button(playerHud.passiveGray,playerHud.activeGray,playerHud.checkedGray);
                    Label buttonLabel=new Label("Prestige now", playerHud.secondLabel);
                    buttonLabel.setFontScale(fontSize);
                prestigeButton.add(buttonLabel);
            information.add(prestigeButton).colspan(2).fillX().pad(4,0,4,0);
            information.row();

                Label label31 = new Label("Current prestige:", playerHud.thirdLabel);
                label31.setFontScale(fontSize);
            information.add(label31).align(Align.left).pad(4,0,4,0);
                currentPrestige = new Label(ResourceType.getInstance().PRESTIGE.getCurrent()+" prestige", playerHud.thirdLabel);
                currentPrestige.setFontScale(fontSize);
                currentPrestige.setColor(Color.CYAN);
            information.add(currentPrestige).align(Align.right);

        add(information).fill().pad(2,2,2,2);
        row();
        //information.setDebug(true);
        //content

            content=new Table();
            scrollPane=new ScrollPane(content);
        add(scrollPane).fillX().expandY().top().pad(5,0,5,0);
        scrollPane.setOverscroll(false,false);
        scrollPane.getStyle().background=playerHud.passiveGray;

        for (ResourceUpgrade resourceUpgrade: UpgradeManager.getInstance().prestigeArray){
            prestigeUpgrades.add(resourceUpgrade);
            upgradeTables.add(new UpgradeTable(resourceUpgrade));
        }

        setContent();

    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        for (UpgradeTable upgradeTable:upgradeTables)
            upgradeTable.render();
    }

    @Override
    public void resize(int width, int height) {

    }

    private void setContent(){
        content.clearChildren();
        for (UpgradeTable upgradeTable:upgradeTables){
            content.add(upgradeTable).pad(3,5,3,5).expandX().fillX();
            content.row();
        }
    }

    public class UpgradeTable extends Table{
        Table button;
        Label buttonCons,buttonLabel;
        Drawable active,passive;

        Label name,count;
        Table cost;
            Label costText,costVariable;
        ResourceUpgrade resourceUpgrade;
        boolean isSoldOut;

        public UpgradeTable(UpgradeBehaviour tempUpgrade){
            super();
            this.resourceUpgrade=(ResourceUpgrade) tempUpgrade;
            active = new TextureRegionDrawable(new TextureRegion(resourceUpgrade.getResourceType().colorTexture));
            passive = new TextureRegionDrawable(new TextureRegion(Utility.createTextureFromColor(resourceUpgrade.getResourceType().color.cpy().add(0.6f,0.6f,0.6f,0))));

                name=new Label(resourceUpgrade.getName(), playerHud.secondLabel);
                name.setFontScale(fontSize);
            add(name).align(Align.left).pad(10).expand();

                count=new Label(resourceUpgrade.currentCount()+"", playerHud.thirdLabel);
                count.setFontScale(fontSize);
            add(count).align(Align.right).pad(10);
            row();

            cost=new Table();
                    costText = new Label("Cost: ", playerHud.thirdLabel);
                    costText.setFontScale(fontSize);
                cost.add(costText).align(Align.left).pad(10).expandX();

                    costVariable = new Label(+resourceUpgrade.requiredResource()+" prestige", playerHud.thirdLabel);
                    costVariable.setFontScale(fontSize);
                    costVariable.setColor(Color.CYAN);
                cost.add(costVariable).align(Align.right).pad(10);
            add(cost).colspan(2).fillX();
            row();
                button=new Table();
                //button.setBackground(new TextureRegionDrawable(new TextureRegion(resourceUpgrade.getResourceType().colorTexture)));
                    buttonCons=new Label("", playerHud.secondLabel);
                    buttonCons.setFontScale(fontSize);
                button.add(buttonCons).align(Align.left).pad(10).expandX().fillX();
                    buttonLabel=new Label("", playerHud.secondLabel);
                    buttonLabel.setFontScale(fontSize);
                    buttonLabel.setColor(Color.CYAN);
                button.add(buttonLabel).align(Align.right).pad(10);
            add(button).align(Align.left).pad(10).colspan(2).fillX().expandX();

            if (isSoldOut){
                buttonLabel.setText("Completed");
            }

            button.addListener(new ClickListener(){
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    super.clicked(event, x, y);
                    if (resourceUpgrade.enoughResource()){
                        resourceUpgrade.upgrade();
                        count.setText(resourceUpgrade.currentCount());
                    }
                }
            });

            setBackground(playerHud.activeGray);
        }

        public void changeContent(){
            costVariable.setText(resourceUpgrade.requiredResource()+" prestige");

            if (resourceUpgrade.requiredResource()>resourceUpgrade.getResourceType().getCurrent()){
                buttonCons.setText("Required: ");
                buttonLabel.setText((resourceUpgrade.requiredResource()-resourceUpgrade.getResourceType().getCurrent())+" Prestige");
                button.setBackground(passive);
            }
            else {
                buttonCons.setText("Buy:");
                buttonLabel.setText(resourceUpgrade.requiredResource()+" Prestige");
                button.setBackground(active);
            }
        }

        public void render(){
            changeContent();
        }

    }

}
