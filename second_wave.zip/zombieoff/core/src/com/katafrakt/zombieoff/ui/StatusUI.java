package com.katafrakt.zombieoff.ui;

import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.ui.Container;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Stack;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.resources.ResourceAbstract;
import com.katafrakt.zombieoff.managers.AssetOrganizer;
import com.katafrakt.zombieoff.managers.EngineEdited;
import com.katafrakt.zombieoff.player.ResourceSystem;

import java.text.DecimalFormat;

public class StatusUI extends Container<Table> {
    ResourceSystem resourceSystem;
    Bar energyBar, bloodBar,geneBar,brainBar;
    Array<Bar> bars=new Array<>();
    PlayerHud playerHud;
    Skin skin;

    DecimalFormat oneDecimal;
    DecimalFormat noDecimal;

    TextureAtlas textureAtlas;

    Table table;

    float conWidth;
    float conHeight;

    float fontSize=1f;

    public StatusUI(PlayerHud playerHud){
        this.playerHud=playerHud;
        resourceSystem =EngineEdited.initiate.resourceSystem;

        textureAtlas=AssetOrganizer.getInstance().get("atlases/colors.atlas",TextureAtlas.class);
        skin= AssetOrganizer.getInstance().get("skin/uiskin.json",Skin.class);

        oneDecimal=new DecimalFormat(); oneDecimal.setMaximumFractionDigits(1);
        noDecimal=new DecimalFormat(); noDecimal.setMaximumFractionDigits(0);

        float width = playerHud.viewport.getWorldWidth();
        float height = playerHud.viewport.getWorldHeight();


        setSize(conWidth,conHeight);
        setPosition(0,height-conHeight);


        table=new Table(skin);
                energyBar=new Bar(ResourceType.getInstance().ENERGY,"Energy",oneDecimal);
            table.add(energyBar).align(Align.left).expandX().fillX().pad(3);
            bars.add(energyBar);
            table.row();

                bloodBar=new Bar(ResourceType.getInstance().BLOOD,"Blood",noDecimal);
            table.add(bloodBar).align(Align.left).expandX().fillX().pad(3);
            bars.add(bloodBar);
            table.row();

            if (ResourceType.getInstance().GENE.isAvailable){
                geneBar=new Bar(ResourceType.getInstance().GENE,"Gene",noDecimal);
            table.add(geneBar).align(Align.left).expandX().fillX().pad(3);
            bars.add(geneBar);
            table.row();
            }

            if (ResourceType.getInstance().BRAIN.isAvailable){
                brainBar=new Bar(ResourceType.getInstance().BRAIN,"Brain",noDecimal);
            table.add(brainBar).align(Align.left).expandX().fillX().pad(3);
            bars.add(brainBar);
            table.row();
            }
        //table.pad(5,5,5,5);
        setActor(table);
        top();
        fillX();
        table.background(playerHud.activeGray);

    }

    public void render(float delta) {
        for (Bar bar:bars)
            bar.render();
    }

    public void resize(int width,int height){
        conWidth=240+width/8;
        conHeight=100+height/9;

        setSize(conWidth,conHeight);
        setPosition(0,height-conHeight);
    }

    public class Bar extends Table {
        ResourceAbstract resourceAbstract;
        DecimalFormat decimalFormat;
        Label name;
        Label amount;
        Stack barImage;

        Image background;
        Image foreground;

        public Bar(ResourceAbstract resourceAbstract, String name, DecimalFormat decimalFormat){
            super(skin);
            this.name=new Label(name,playerHud.secondLabel);
                this.name.setFontScale(fontSize);
            this.amount=new Label("",playerHud.thirdLabel);
                this.amount.setFontScale(fontSize);
            this.resourceAbstract=resourceAbstract;
            this.decimalFormat=decimalFormat;

            background=new Image(textureAtlas.findRegion("Black"));
            background.setSize(getWidth(),10);
            foreground=new Image(resourceAbstract.colorTexture);
            barImage=new Stack();
            barImage.add(background);   barImage.add(foreground);

            add(this.name).align(Align.left).pad(2,5,5,5);
            add(amount).align(Align.right).pad(2,5,5,5);
            row();

            add(barImage).align(Align.left).pad(5,5,5,5).expandX();
        }

        public void render(){
            amount.setText(decimalFormat.format(resourceAbstract.getCurrent())+"/"+decimalFormat.format(resourceAbstract.capacity));
            foreground.setSize((getWidth()-10)*resourceAbstract.getCurrent()/resourceAbstract.capacity,8);
        }
    }
}
