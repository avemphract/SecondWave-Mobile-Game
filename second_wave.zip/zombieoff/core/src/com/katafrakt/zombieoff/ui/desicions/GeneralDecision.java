package com.katafrakt.zombieoff.ui.desicions;

import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Touchable;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.ButtonGroup;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Stack;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Sort;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.game.upgradebehaviours.UpgradeBehaviour;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.ui.DecisionsUI;
import com.katafrakt.zombieoff.ui.PlayerHud;

import java.util.Comparator;

public class GeneralDecision extends Table implements DecisionInterface {
    private static final String TAG = GeneralDecision.class.getSimpleName();
    Comparator<UpgradeTable> comparator=new Comparator<UpgradeTable>() {
        @Override
        public int compare(UpgradeTable t1, UpgradeTable t2) {
            if (t1.upgradeBehaviour.currentCount()==t1.upgradeBehaviour.maximumCount()&&t2.upgradeBehaviour.currentCount()==t2.upgradeBehaviour.maximumCount()){
                if (t1.upgradeBehaviour.getIndex()>t2.upgradeBehaviour.getIndex())
                    return 1;
                else if (t1.upgradeBehaviour.getIndex()<t2.upgradeBehaviour.getIndex())
                    return -1;
                else
                    return 0;
            }
            else if (t1.upgradeBehaviour.currentCount()==t1.upgradeBehaviour.maximumCount())
                return 1;
            else if (t2.upgradeBehaviour.currentCount()==t2.upgradeBehaviour.maximumCount())
                return -1;

            if (t1.upgradeBehaviour.getIndex()>t2.upgradeBehaviour.getIndex())
                return 1;
            else if (t1.upgradeBehaviour.getIndex()<t2.upgradeBehaviour.getIndex())
                return -1;
            else
                return 0;
        }
    };
    Sort sort=new Sort();

    PlayerHud playerHud;
    DecisionsUI decisionsUI;

    Skin defaultSkin;
    Skin customSkin;

    UpgradeManager upgradeManager;

    Table title;
    Button closeButton;
    Table content;

    ContentCategory contentCategory;

    Array<ResourceUpgrade> zombieUpgrades=new Array<>();
    Array<UpgradeTable> zombieTables=new Array<>();

    Array<ResourceUpgrade> resourceUpgrades=new Array<>();
    Array<UpgradeTable> resourceTables=new Array<>();



    float fontSize=1f;
    int current=0;

    public GeneralDecision(PlayerHud playerHud, DecisionsUI decisionsUI){
        this.playerHud=playerHud;
        this.decisionsUI=decisionsUI;
        this.defaultSkin =decisionsUI.defaultSkin;
        this.customSkin=decisionsUI.customSkin;

        upgradeManager=UpgradeManager.getInstance();
        setFillParent(true);
        //title
            title=new Table(defaultSkin);
                closeButton=decisionsUI.closeButtonGI;
                Label titleText=new Label("Improvements", playerHud.firstLabel);
                //titleText.setFontScale(fontSize);
            title.add(titleText).align(Align.topRight).grow().padLeft(10);
            title.add(closeButton).align(Align.topRight);
            title.background(customSkin.getDrawable("drawable_3"));
        add(title).fillX().pad(5,5,5,5);
        row();

        //contentCategory
            contentCategory=new ContentCategory();
        add(contentCategory).expandX().fillX().pad(5,5,5,5).left();
        row();

        //content
            content=new Table();
        add(content).fillX().expand().align(Align.top);
        resetUpgrade();
        background(customSkin.getDrawable("drawable_4"));
        //ninePatchDrawable.getPatch().scale(5,5);

        //contentCategory.buttonGroup.getChecked().getClickListener().clicked(null,contentCategory.buttonGroup.getChecked().getX()+1,contentCategory.buttonGroup.getChecked().getY()+1);
        setContent(0);
    }
    public void resetUpgrade(){
        upgradeManager.setUpgradeBehaviours();
        for (UpgradeBehaviour upgradeBehaviour:UpgradeManager.getInstance().zombieUpArray){
            if (zombieUpgrades.contains((ResourceUpgrade) upgradeBehaviour,true))
                continue;
            zombieUpgrades.add((ResourceUpgrade) upgradeBehaviour);
            zombieTables.add(new UpgradeTable(upgradeBehaviour));
        }
        for (UpgradeBehaviour upgradeBehaviour:UpgradeManager.getInstance().resourceManArray){
            if (resourceUpgrades.contains((ResourceUpgrade) upgradeBehaviour,true))
                continue;
            resourceUpgrades.add((ResourceUpgrade) upgradeBehaviour);
            resourceTables.add(new UpgradeTable(upgradeBehaviour));
        }


    }

    public void setContent(int i){
        content.clearChildren();
        if (i==0){
            sort.sort(zombieTables,comparator);
            for (UpgradeTable upgradeTable:zombieTables){
                content.add(upgradeTable).pad(3,2,5,2).expandX().fillX();
                content.row();
            }
        }
        else {
            sort.sort(resourceTables,comparator);
            for (UpgradeTable upgradeTable:resourceTables){
                content.add(upgradeTable).pad(3,2,5,2).expandX().fillX();
                content.row();
            }
        }
    }
    @Override
    public void show(){
        resetUpgrade();
    }

    public void render(float delta){
        for(UpgradeTable upgradeTable:zombieTables)
            upgradeTable.render();
        for (UpgradeTable upgradeTable:resourceTables)
            upgradeTable.render();

    }

    @Override
    public void resize(int width, int height) {
        show();
    }

    class UpgradeTable extends Table{
        Stack buttonStack;
        Button button =new Button(playerHud.activeGray,playerHud.checkedGray);
        Image buttonImage;
        Label name,cost,count,effect;
        public ResourceUpgrade upgradeBehaviour;
        public UpgradeTable(UpgradeBehaviour tempBehaviour){
            super();
            upgradeBehaviour = (ResourceUpgrade)tempBehaviour;


                name=new Label(upgradeBehaviour.getName(), playerHud.secondLabel);
                name.setFontScale(fontSize);
            add(name).align(Align.left).pad(10).expand().fill();

                count=new Label(upgradeBehaviour.currentCount()+"/"+upgradeBehaviour.maximumCount(), playerHud.secondLabel);
                count.setFontScale(fontSize);
            add(count).align(Align.right).pad(5);
            row();

                effect=new Label(upgradeBehaviour.effect(), playerHud.thirdLabel);
                effect.setFontScale(fontSize);
            add(effect).align(Align.left).pad(5).expand().fill();


                cost=new Label(upgradeBehaviour.requiredResource()+" "+ upgradeBehaviour.getResourceType().name(), playerHud.thirdLabel);//cost
                cost.setFontScale(fontSize);
            add(cost).align(Align.right).pad(5);
            row();

                buttonStack=new Stack();
                        //button.add()
                    //buttonImage=new Image(ResourceManager.getInstance().getColor(upgradeBehaviour.getResourceType()));
                    buttonImage=new Image(upgradeBehaviour.getResourceType().colorTexture);
                    buttonImage.setTouchable(Touchable.disabled);
            buttonStack.add(buttonImage);
                buttonStack.add(button);
            add(buttonStack).fillX().colspan(2).pad(5).height(30);
            row();

            button.addListener(new ClickListener(){
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    if (upgradeBehaviour.enoughResource()){
                        upgradeBehaviour.upgrade();
                        setContent(current);
                        resetUpgrade();
                        changeContent();
                    }
                    super.clicked(event, x, y);
                }
            });

            setBackground(customSkin.getDrawable("drawable_6"));
            //setDebug(true);

        }
        public void changeContent(){
            if (upgradeBehaviour.currentCount()<upgradeBehaviour.maximumCount()){
                //setBackground(playerHud.passiveGray);
                cost.setText(upgradeBehaviour.requiredResource()+" "+ upgradeBehaviour.getResourceType().name());
            }
            else{
                //setBackground(playerHud.activeGray);
                setColor(1,1,1,0.5f);
                setTouchable(Touchable.disabled);
                cost.setText("maximum");
            }
            count.setText(upgradeBehaviour.currentCount()+"/"+upgradeBehaviour.maximumCount());
        }

        public void render(){
            float ratio= MathUtils.clamp(upgradeBehaviour.getResourceType().getCurrent()/upgradeBehaviour.requiredResource(),0,1); //buttonImage.getImageWidth();
            buttonImage.setSize(button.getWidth()*ratio-1, button.getHeight()-1);


        }
    }

    public class ContentCategory extends Table{
        ButtonGroup<Button> buttonGroup=new ButtonGroup<>();

        public Button zombieUpg;
        Label zombieUpgLabel;

        public Button resourceUpg;
        Label resourceManLabel;
        public ContentCategory(){
            //ZombieUpgrades
                zombieUpg=new Button(customSkin.get("toggle_left",Button.ButtonStyle.class));
                zombieUpg.setScale(2);
                zombieUpg.addListener(new ClickListener(){
                    @Override
                    public void clicked(InputEvent event, float x, float y) {
                        setContent(0);
                        current=0;
                        super.clicked(event, x, y);
                    }
                });
                    zombieUpgLabel=new Label("Zombies", playerHud.secondLabel);
                    zombieUpgLabel.setFontScale(fontSize);
                zombieUpg.add(zombieUpgLabel);
                zombieUpg.getCell(zombieUpgLabel).pad(5,5,5,5);
                zombieUpg.setChecked(true);
            add(zombieUpg).right().size(140,35).expandX();

            //ResourcesManager
                resourceUpg =new Button(customSkin.get("toggle_right",Button.ButtonStyle.class));
                resourceUpg.addListener(new ClickListener(){
                    @Override
                    public void clicked(InputEvent event, float x, float y) {
                        setContent(1);
                        current=1;
                        super.clicked(event, x, y);
                    }
                });
                    resourceManLabel=new Label("Resources", playerHud.secondLabel);
                    resourceManLabel.setFontScale(fontSize);
                resourceUpg.add(resourceManLabel);
                resourceUpg.getCell(resourceManLabel).pad(5,5,5,5);
            add(resourceUpg).left().size(140,35).expandX();

            buttonGroup.add(zombieUpg, resourceUpg);


        }
    }


}
