package com.katafrakt.zombieoff.ui.desicions;

import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Touchable;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.ButtonGroup;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Stack;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.game.upgradebehaviours.UpgradeBehaviour;
import com.katafrakt.zombieoff.managers.AssetOrganizer;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.ui.DecisionsUI;
import com.katafrakt.zombieoff.ui.PlayerHud;


public class Attachments extends Table implements DecisionInterface {
    PlayerHud playerHud;
    DecisionsUI decisionsUI;
    UpgradeManager upgradeManager;
    TextureAtlas external;
    Skin skin;

    Table title;
    Button closeButton;
    Table content;

    ContentCategory contentCategory;

    Array<UpgradeBehaviour> weaponUpgrades=new Array<>();
    Array<UpgradeTable> weaponTables=new Array<>();

    Array<UpgradeBehaviour> abilityUpgrades=new Array<>();
    Array<UpgradeTable> abilityTables=new Array<>();

    float fontSize=1;

    public Attachments(PlayerHud playerHud, DecisionsUI decisionsUI, Skin skin){
        this.playerHud=playerHud;
        this.decisionsUI=decisionsUI;
        this.skin=skin;
        upgradeManager=UpgradeManager.getInstance();
        external=AssetOrganizer.getInstance().get("atlases/externaldrawable.atlas",TextureAtlas.class);
        //title
            title=new Table(skin);
                closeButton=decisionsUI.closeButtonW;
                Label titleText=new Label("Attachments",skin);
                titleText.setFontScale(fontSize);
            title.add(titleText).align(Align.topRight).grow();
            title.add(closeButton).align(Align.topRight);
        add(title).fillX().pad(5,5,5,5);
        row();

        //contentCategory
            contentCategory=new ContentCategory();
        add(contentCategory).fillX().expandX().pad(5,5,5,5).left();
        row();

        //content
            content=new Table();
        add(content).fillX().expandY().align(Align.top);

        resetUpgrade();
        background(playerHud.blueRounded);

        for (UpgradeTable upgradeTable:weaponTables){
            content.add(upgradeTable).expandX().fillX();
            content.row();
        }


    }

    private void resetUpgrade(){
        upgradeManager.setUpgradeBehaviours();
        for (UpgradeBehaviour upgradeBehaviour:UpgradeManager.getInstance().weaponArray){
            if (weaponUpgrades.contains(upgradeBehaviour,true))
                continue;
            weaponUpgrades.add(upgradeBehaviour);
            weaponTables.add(new UpgradeTable(upgradeBehaviour));
        }
        //
    }

    private void setContent(){
        content.clearChildren();
        if (contentCategory.weapons==contentCategory.buttonGroup.getChecked()){
            for (UpgradeTable upgradeTable:weaponTables){
                content.add(upgradeTable).expandX().fillX();
                content.row();
            }
        }
        else {
            for (UpgradeTable upgradeTable:abilityTables){
                content.add(upgradeTable);
                content.row();
            }
        }
    }

    @Override
    public void show(){
        resetUpgrade();
    }

    public void render(float delta){
        for (UpgradeTable upgradeTable:weaponTables){
            upgradeTable.render();
        }
        for (UpgradeTable upgradeTable:abilityTables){
            upgradeTable.render();
        }
    }

    @Override
    public void resize(int width, int height) {

    }

    class UpgradeTable extends Table{
        Stack buttonStack;
        Button button=new Button(playerHud.activeGray,playerHud.checkedGray);
        Label buttonText;
        Image buttonImage;

        Image light;
        Label name,cost,count,effect;
        ResourceUpgrade resourceUpgrade;

        Table firstRow;
        Table secondRow;

        public UpgradeTable(final UpgradeBehaviour upgradeBehaviour){
            background(playerHud.activeGreen);
            resourceUpgrade= (ResourceUpgrade) upgradeBehaviour;
            //setDebug(true);
            firstRow=new Table();
                light=new Image(external.findRegion("light_off"));
            firstRow.add(light).padRight(5);

                name=new Label(resourceUpgrade.getName(),skin);
                name.setFontScale(fontSize);
            firstRow.add(name).fillX().expandX();

                count=new Label(resourceUpgrade.currentCount()+"/"+resourceUpgrade.maximumCount(),skin);
                count.setFontScale(fontSize);
            firstRow.add(count).fillX();

            add(firstRow).expandX().fillX().pad(5,2,0,2);
            row();

            secondRow=new Table();
                effect=new Label(resourceUpgrade.effect(),skin);
                effect.setFontScale(fontSize);
            secondRow.add(effect).fillX();

            add(secondRow).fillX();
            row();

                buttonStack = new Stack();
                buttonStack.add(button);
                    buttonImage=new Image(AssetOrganizer.getInstance().get("atlases/colors.atlas",TextureAtlas.class).findRegion("Black"));
                    buttonImage.setColor(0.9f,0.9f,0.2f,0.5f);
                    buttonImage.setTouchable(Touchable.disabled);
                buttonStack.add(buttonImage);
                    Table textWrapper=new Table();
                    buttonText=new Label(resourceUpgrade.getResourceType().getCurrent()+"/"+resourceUpgrade.requiredResource(),skin);
                    buttonText.setTouchable(Touchable.disabled);
                    textWrapper.add(buttonText);
                buttonStack.add(textWrapper);

            add(buttonStack);

            getCell(buttonStack).fillX().center().pad(4,4,4,4);;

            button.addListener(new ClickListener(){
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    super.clicked(event, x, y);
                    if (resourceUpgrade.enoughResource()){
                        resourceUpgrade.upgrade();
                        light.setDrawable(new TextureRegionDrawable(external.findRegion("light_on")));
                    }
                }
            });
        }

        public void render(){
            buttonImage.setScaleX(0.5f);
        }
    }

    public class ContentCategory extends Table{
        ButtonGroup buttonGroup=new ButtonGroup();

        Button weapons;
        Label weaponsLabel;
        Button abilities;
        Label abilitiesLabel;

        public ContentCategory(){
            //weapon
                weapons=new Button(playerHud.passiveRed,playerHud.activeRed,playerHud.checkedRed);
                weapons.addListener(new ClickListener(){
                    @Override
                    public void clicked(InputEvent event, float x, float y) {
                        super.clicked(event, x, y);
                        setContent();
                    }
                });
                    weaponsLabel=new Label("Weapons",skin);
                    weaponsLabel.setFontScale(fontSize);
                weapons.add(weaponsLabel);
            add(weapons).left().padLeft(20).size(100,20);

            add(new Table()).expandX().fillX();
            //abilities
                abilities=new Button(playerHud.passiveRed,playerHud.activeRed,playerHud.checkedRed);
                abilities.addListener(new ClickListener(){
                    @Override
                    public void clicked(InputEvent event, float x, float y) {
                        super.clicked(event, x, y);
                        setContent();
                    }
                });
                    abilitiesLabel=new Label("Abilities",skin);
                    abilitiesLabel.setFontScale(fontSize);
                abilities.add(abilitiesLabel);
            add(abilities).left().padRight(20).size(100,20);

            buttonGroup.add(weapons,abilities);
            buttonGroup.setMinCheckCount(1);
            buttonGroup.setMaxCheckCount(1);
            }
        }
}
