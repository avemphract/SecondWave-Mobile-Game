package com.katafrakt.zombieoff.ui.desicions;

public interface ChangeInterface {
    public void change();
}
