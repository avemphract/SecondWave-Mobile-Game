package com.katafrakt.zombieoff.ui.desicions;

public interface DecisionInterface {
    void show();
    void render(float delta);
    void resize(int width,int height);
}
