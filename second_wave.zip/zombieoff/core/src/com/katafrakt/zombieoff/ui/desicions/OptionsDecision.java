package com.katafrakt.zombieoff.ui.desicions;

import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.CheckBox;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.Align;
import com.katafrakt.zombieoff.managers.PreferenceManager;
import com.katafrakt.zombieoff.ui.DecisionsUI;
import com.katafrakt.zombieoff.ui.PlayerHud;

public class OptionsDecision extends Table implements DecisionInterface {
    private static final String TAG = OptionsDecision.class.getSimpleName();

    PlayerHud playerHud;
    DecisionsUI decisionsUI;

    Skin defaultSkin;
    Skin customSkin;

    Table title;
    Button closeButton;
    Table content;

    float fontSize=1;

    public OptionsDecision(PlayerHud playerHud, DecisionsUI decisionsUI) {
        this.playerHud=playerHud;
        this.decisionsUI=decisionsUI;
        this.defaultSkin=decisionsUI.defaultSkin;
        this.customSkin=decisionsUI.customSkin;

        //title
            title=new Table(defaultSkin);
                closeButton=decisionsUI.closeButtonOpt;
                Label titleText=new Label("Options",playerHud.firstLabel);
                titleText.setFontScale(fontSize);
            title.add(titleText).align(Align.topRight).grow().padLeft(10);
            title.add(closeButton).align(Align.right);
            title.background(customSkin.getDrawable("drawable_3"));
        add(title).fillX().pad(5,5,5,5);
        row();

        //content
            content=new Table();
        add(content).fillX().expand().align(Align.top).pad(10,10,10,10);
        background(customSkin.getDrawable("drawable_4"));

        //Floating text
                Label floatingLabel=new Label("Floating text: ",playerHud.secondLabel);
                floatingLabel.setFontScale(fontSize);
            content.add(floatingLabel).align(Align.left).expandX();
                final CheckBox floatingCheck=new CheckBox("",defaultSkin);
                floatingCheck.addListener(new ClickListener(){
                    @Override
                    public void clicked(InputEvent event, float x, float y) {
                        super.clicked(event, x, y);
                    }
                });
            content.add(floatingCheck).align(Align.right);
            content.row();
        //Particle effect
                Label particleLabel=new Label("Particle effect: ",playerHud.secondLabel);
                particleLabel.setFontScale(fontSize);
            content.add(particleLabel).align(Align.left).expandX();
                CheckBox particleCheck=new CheckBox("",defaultSkin);
                content.add(particleCheck).align(Align.right);

    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {

    }

    @Override
    public void resize(int width, int height) {

    }

}
