package com.katafrakt.zombieoff.ui.desicions;

import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Stack;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.game.upgradebehaviours.TrophyUpgrade;
import com.katafrakt.zombieoff.game.upgradebehaviours.UpgradeBehaviour;
import com.katafrakt.zombieoff.managers.AssetOrganizer;
import com.katafrakt.zombieoff.player.PlayerStatics;
import com.katafrakt.zombieoff.player.UpgradeManager;
import com.katafrakt.zombieoff.ui.DecisionsUI;
import com.katafrakt.zombieoff.ui.PlayerHud;

public class TrophyDecision extends Table implements DecisionInterface {
    private static final String TAG= TrophyDecision.class.getSimpleName();

    PlayerHud playerHud;
    DecisionsUI decisionsUI;
    Skin defaultSkin;
    UpgradeManager upgradeManager;

    Table title;
    Button closeButton;
    ScrollPane scrollPane;
    Table content;

    Array<UpgradeBehaviour> trophyUpgrades=new Array<>();
    Array<TrophyTable> trophyTables=new Array<>();

    float fontSize=1;

    public TrophyDecision(PlayerHud playerHud, DecisionsUI decisionsUI){
        this.playerHud=playerHud;
        this.decisionsUI=decisionsUI;
        this.defaultSkin =decisionsUI.defaultSkin;
        upgradeManager=UpgradeManager.getInstance();
        background(playerHud.blueRounded);

            title=new Table();
                Label titleText=new Label("Trophies", playerHud.firstLabel);
                titleText.setFontScale(fontSize);
            title.add(titleText).left().expandX().fillX();
                closeButton=decisionsUI.closeButtonT;
            title.add(closeButton);
        add(title).fillX().expandX().pad(5,5,5,5).top();
        row();

            content=new Table();
            scrollPane=new ScrollPane(content);
        add(scrollPane).fillX().expand().top();
        scrollPane.setOverscroll(false,false);
        scrollPane.setFlickScroll(true);

    }

    private void resetUpgrades(){
        content.clearChildren();
        UpgradeManager.getInstance().setUpgradeBehaviours();
        for (UpgradeBehaviour upgradeBehaviour:UpgradeManager.getInstance().trophyArray){
            if (trophyUpgrades.contains(upgradeBehaviour,true))
                continue;
            trophyUpgrades.add(upgradeBehaviour);
            trophyTables.add(new TrophyTable((TrophyUpgrade) upgradeBehaviour));

        }
        for (TrophyTable trophyTable : trophyTables){
            content.add(trophyTable).width(decisionsUI.conWidth*4/5-30).pad(5,5,5,5).fillX().top();
            content.row();
        }
    }

    @Override
    public void show(){
        resetUpgrades();
    }

    public void render(float delta){
        for (TrophyTable trophyTable : trophyTables)
            trophyTable.render();
    }

    @Override
    public void resize(int width, int height) {
        show();
    }

    public class TrophyTable extends Table implements ChangeInterface{
        Table textTable;
        Stack stack;
        Label name,effect,cost,costType;
        Image progress;
        TrophyUpgrade trophyUpgrade;

        public TrophyTable(final TrophyUpgrade trophyUpgrade){
            super();
            this.trophyUpgrade=trophyUpgrade;
            if (trophyUpgrade.currentCount()<trophyUpgrade.maximumCount()){
                setBackground(playerHud.passiveGray);
            }
            else {
                setBackground(playerHud.activeGray);
            }

            addListener(new ClickListener(){
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    super.clicked(event, x, y);
                    if (trophyUpgrade.enoughResource()){
                        trophyUpgrade.upgrade();
                    }
                }
            });

                stack=new Stack();
                    progress=new Image(AssetOrganizer.getInstance().get("atlases/colors.atlas", TextureAtlas.class).findRegion("Blue"));
                    progress.setColor(0.9f,0.2f,0.2f,0.5f);
                stack.add(progress);

                textTable=new Table();
                    name=new Label(trophyUpgrade.getName(), playerHud.secondLabel);
                    name.setFontScale(fontSize);
                textTable.add(name).left().fillX().expandX().pad(15,10,10,0);
                    effect=new Label(trophyUpgrade.effect(), playerHud.secondLabel);
                    effect.setFontScale(fontSize);
                textTable.add(effect).right().pad(15,10,10,10);
                textTable.row();

                    cost=new Label(trophyUpgrade.currentResource()+"/"+trophyUpgrade.requiredResource(), playerHud.secondLabel);
                    cost.setFontScale(fontSize);
                textTable.add(cost).left().fillX().pad(10,10,15,10);

                    costType=new Label(trophyUpgrade.requirementName(), playerHud.secondLabel);
                    costType.setFontScale(fontSize);
                textTable.add(costType).right().pad(10,10,15,10);
                stack.add(textTable);
            add(stack);
            getCell(stack).grow();
            PlayerStatics.getInstance().totalImprovement.listeners.add(this);
            trophyUpgrade.adjustEvent(this);
            change();
        }
        public void render(){
        }

        @Override
        public void change() {
            progress.setScaleX(trophyUpgrade.currentResource()/trophyUpgrade.requiredResource());
            cost.setText((int) trophyUpgrade.currentResource()+"/"+(int) trophyUpgrade.requiredResource());
        }
    }
}
