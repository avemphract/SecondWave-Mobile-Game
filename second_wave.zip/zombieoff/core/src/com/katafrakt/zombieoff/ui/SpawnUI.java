package com.katafrakt.zombieoff.ui;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Container;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Stack;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.entities.EntityType;
import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.managers.AssetOrganizer;
import com.katafrakt.zombieoff.player.ZombieBuilder;


public class SpawnUI extends Container<Table> {
    private static final String TAG=SpawnUI.class.getSimpleName();
    ZombieBuilder zombieBuilder;

    PlayerHud playerHud;
    Table container;
    Skin skin;
    TextureAtlas zombieAtlas;
    TextureAtlas symbolAtlas;
    TextureAtlas colorsAtlas;

    EntityType selectedType;
    Array<Unit> units=new Array<>();
    Table cancel;

    float width;
    float height;

    float conWidth;
    float conHeight;

    public SpawnUI(PlayerHud playerHud){
        super();
        this.playerHud=playerHud;
        zombieBuilder=ZombieBuilder.getInstance();

        container=new Table(skin);
        zombieAtlas =AssetOrganizer.getInstance().get("atlases/zombies.atlas",TextureAtlas.class);
        colorsAtlas=AssetOrganizer.getInstance().get("atlases/colors.atlas",TextureAtlas.class);
        symbolAtlas=AssetOrganizer.getInstance().get("atlases/symbols.atlas",TextureAtlas.class);

        width=playerHud.viewport.getWorldWidth();
        height=playerHud.viewport.getWorldHeight();

        conWidth=60;
        conHeight=height-200;

        setSize(conWidth,conHeight);
        setPosition(0,80);


        for (EntityType entityType:ZombieBuilder.getInstance().unlockedTypes){
            units.add(new Unit(entityType));
        }
        /*
        units.add(new Unit(EntityType.BASIC_ZOMBIE));
        units.add(new Unit(EntityType.GIANT_ZOMBIE));
        units.add(new Unit(EntityType.RANGED_ZOMBIE));
*/

        for (Unit unit:units){
            container.add(unit).left().top().padTop(5);
            container.row();
        }
        setCancel();
        container.add(cancel);

        setActor(container);
    }

    public void setCancel(){
        cancel=new Table(skin);
        Image cancelImage=new Image(symbolAtlas.findRegion("cancel"));
        cancelImage.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y) {
                super.clicked(event, x, y);
                playerHud.touchType= PlayerHud.TouchType.SELECT;
                cancel.setVisible(false);
                for (Unit unit:units){
                    unit.imageWrapper.background(playerHud.blueFrame2);
                }
            }
        });
        cancel.add(cancelImage).size(conWidth-10,conWidth-10).padTop(13);
    }

    public void render(float delta){
        for (Unit unit:units){
            unit.render();
        }
    }

    public void resize(int width,int height){
        conWidth=30+width/32;
        conHeight=height-205;

        setSize(conWidth,conHeight);
        setPosition(0,85);
    }

    public class Unit extends Table{

        Drawable active,passive;

        EntityType entityType;

        public Table imageWrapper;
        public Stack stack;
        Image energy,status;

        Unit(final EntityType entityType){
            super();
            this.entityType=entityType;
            imageWrapper=new Table();
            imageWrapper.background(playerHud.blueFrame2);
                stack=new Stack();
                    //Image image=new Image(zombieAtlas.findRegion(entityType.atlas_name));
                    //if (image==null)
                        Image image=new Image(symbolAtlas.findRegion("cancel"));
                stack.add(image);
                    status=new Image();
                stack.add(status);
            imageWrapper.add(stack);
            imageWrapper.getCell(stack).grow();

            energy=new Image(colorsAtlas.findRegion("Blue"));


            active=new TextureRegionDrawable(colorsAtlas.findRegion("Black")).tint(new Color(0,0,0,0));
            passive=new TextureRegionDrawable(colorsAtlas.findRegion("Black")).tint(new Color(0,0,0,0.5f));


            addListener(new ClickListener(){
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    super.clicked(event, x, y);
                    selectedType=entityType;
                    playerHud.touchType= PlayerHud.TouchType.SPAWN;
                    cancel.setVisible(true);
                    for (Unit unit:units){
                        if (unit==Unit.this)
                            unit.imageWrapper.background(playerHud.blueFrame1);
                        else
                            unit.imageWrapper.background(playerHud.blueFrame2);
                    }
                }
            });


            add(imageWrapper).size(conWidth-10,conWidth-10);
            row();
            add(energy).fillX().expandX().padTop(5);

        }
        public void render(){
            float ratio= MathUtils.clamp(ResourceType.getInstance().ENERGY.getCurrent()/zombieBuilder.builderMap.get(entityType).getEne(),0,1);
            energy.setSize(ratio*getWidth(),4);

            if (ratio==1)
                status.setDrawable(active);
            else
                status.setDrawable(passive);
        }
    }
}
