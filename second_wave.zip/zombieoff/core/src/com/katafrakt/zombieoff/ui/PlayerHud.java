package com.katafrakt.zombieoff.ui;

import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.NinePatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.utils.NinePatchDrawable;
import com.badlogic.gdx.scenes.scene2d.utils.TiledDrawable;
import com.badlogic.gdx.utils.viewport.ExtendViewport;
import com.badlogic.gdx.utils.viewport.FillViewport;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.katafrakt.zombieoff.Main;
import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.managers.AssetOrganizer;
import com.katafrakt.zombieoff.managers.EngineEdited;
import com.katafrakt.zombieoff.managers.EntityFactory;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.player.ZombieBuilder;
import com.katafrakt.zombieoff.utilities.EntityList;

public class PlayerHud implements InputProcessor {
    public enum TouchType{SELECT,SPAWN}
    public TouchType touchType=TouchType.SELECT;
    public Stage stage;

    EntityFactory entityFactory;
    OrthographicCamera camera;
    public Viewport viewport;

    StatusUI statusUI;
    EntityUI entityUI;
    DecisionsUI decisionsUI;
    SpawnUI spawnUI;

    Vector2 tempVector=new Vector2();

    FreeTypeFontGenerator freeTypeFontGenerator= AssetOrganizer.getInstance().get("skin/vcr_font_generator.ttf",FreeTypeFontGenerator.class);
    FreeTypeFontGenerator.FreeTypeFontParameter freeTypeFontParameter=new FreeTypeFontGenerator.FreeTypeFontParameter();

    public Label.LabelStyle firstLabel;
    public Label.LabelStyle secondLabel;
    public Label.LabelStyle thirdLabel;
    public Label.LabelStyle forthLabel;

    public NinePatchDrawable grey;

    public NinePatchDrawable passiveBlue,activeBlue,checkedBlue;
    public NinePatchDrawable passiveRed,activeRed,checkedRed;
    public NinePatchDrawable passiveGreen,activeGreen,checkedGreen;
    public NinePatchDrawable passiveYellow,activeYellow,checkedYellow;
    public NinePatchDrawable passiveGray,activeGray,checkedGray;

    public TiledDrawable linedraw_blue,linedraw_red,linedraw_green,linedraw_yellow,linedraw_gray;


    public NinePatchDrawable brownEllipse,brownRounded,blueEllipse,blueRounded;

    public NinePatchDrawable blueFrame1,blueFrame2,blueFrame3;

    TextureAtlas externalDrawable;

    public PlayerHud(OrthographicCamera camera){
        this.camera=camera;
        this.viewport =new ScreenViewport();
        //this.screenViewport=screenViewport;
        entityFactory=EntityFactory.getInstance();
        stage=new Stage(viewport);

        setFonts();
        setDrawable();
        externalDrawable=AssetOrganizer.getInstance().get("atlases/externaldrawable.atlas",TextureAtlas.class);

        spawnUI=new SpawnUI(this); stage.addActor(spawnUI); //spawnUI.align(Align.center);
        decisionsUI =new DecisionsUI(this); stage.addActor(decisionsUI);// decisionsUI.right();
        statusUI=new StatusUI(this); stage.addActor(statusUI);
        entityUI=new EntityUI(this); stage.addActor(entityUI);

    }
    public void setFonts(){
        firstLabel =new Label.LabelStyle();
        freeTypeFontParameter.size=24;
        firstLabel.font= freeTypeFontGenerator.generateFont(freeTypeFontParameter);

        secondLabel= new Label.LabelStyle();
        freeTypeFontParameter.size=18;
        secondLabel.font=freeTypeFontGenerator.generateFont(freeTypeFontParameter);

        thirdLabel= new Label.LabelStyle();
        freeTypeFontParameter.size=15;
        thirdLabel.font=freeTypeFontGenerator.generateFont(freeTypeFontParameter);

        forthLabel= new Label.LabelStyle();
        freeTypeFontParameter.size=12;
        forthLabel.font=freeTypeFontGenerator.generateFont(freeTypeFontParameter);
    }
    public void setDrawable(){
        TextureAtlas textureAtlas= AssetOrganizer.getInstance().get("atlases/buttonpatch.atlas",TextureAtlas.class);
        TextureAtlas externalAtlas=AssetOrganizer.getInstance().get("atlases/externaldrawable.atlas",TextureAtlas.class);
        Texture texture=AssetOrganizer.getInstance().get("ninepatch.png",Texture.class);

        grey=new NinePatchDrawable(new NinePatch(texture,15,15,15,15));

        passiveBlue=new NinePatchDrawable(new NinePatch(textureAtlas.findRegion("passive_blue"),1,1,1,1));
        activeBlue=new NinePatchDrawable(new NinePatch(textureAtlas.findRegion("active_blue"),1,1,1,1));
        checkedBlue=new NinePatchDrawable(new NinePatch(textureAtlas.findRegion("checked_blue"),1,1,1,1));

        passiveRed=new NinePatchDrawable(new NinePatch(textureAtlas.findRegion("passive_red"),1,1,1,1));
        activeRed=new NinePatchDrawable(new NinePatch(textureAtlas.findRegion("active_red"),1,1,1,1));
        checkedRed=new NinePatchDrawable(new NinePatch(textureAtlas.findRegion("checked_red"),1,1,1,1));

        passiveGreen=new NinePatchDrawable(new NinePatch(textureAtlas.findRegion("passive_green"),1,1,1,1));
        activeGreen=new NinePatchDrawable(new NinePatch(textureAtlas.findRegion("active_green"),1,1,1,1));
        checkedGreen=new NinePatchDrawable(new NinePatch(textureAtlas.findRegion("checked_green"),1,1,1,1));

        passiveYellow=new NinePatchDrawable(new NinePatch(textureAtlas.findRegion("passive_yellow"),1,1,1,1));
        activeYellow=new NinePatchDrawable(new NinePatch(textureAtlas.findRegion("active_yellow"),1,1,1,1));
        checkedYellow=new NinePatchDrawable(new NinePatch(textureAtlas.findRegion("checked_yellow"),1,1,1,1));

        passiveGray=new NinePatchDrawable(new NinePatch(textureAtlas.findRegion("passive_gray"),1,1,1,1));
        activeGray=new NinePatchDrawable(new NinePatch(textureAtlas.findRegion("active_gray"),1,1,1,1));
        checkedGray=new NinePatchDrawable(new NinePatch(textureAtlas.findRegion("checked_gray"),1,1,1,1));

        linedraw_blue=new TiledDrawable(textureAtlas.findRegion("linedraw_blue"));
        linedraw_red=new TiledDrawable(textureAtlas.findRegion("linedraw_red"));
        linedraw_green=new TiledDrawable(textureAtlas.findRegion("linedraw_green"));
        linedraw_yellow=new TiledDrawable(textureAtlas.findRegion("linedraw_yellow"));
        linedraw_gray=new TiledDrawable(textureAtlas.findRegion("linedraw_gray"));




        brownEllipse=new NinePatchDrawable(new NinePatch(externalAtlas.findRegion("brown_ellipse"),10,10,6,6));
        blueEllipse=new NinePatchDrawable(new NinePatch(externalAtlas.findRegion("blue_ellipse"),10,10,6,6));
        brownRounded=new NinePatchDrawable(new NinePatch(externalAtlas.findRegion("brown_rounded"),9,9,8,8));
        blueRounded=new NinePatchDrawable(new NinePatch(externalAtlas.findRegion("blue_rounded"),9,9,8,8));

        blueFrame1=new NinePatchDrawable(new NinePatch(externalAtlas.findRegion("blue_frame_1"),2,2,2,2));
        blueFrame2=new NinePatchDrawable(new NinePatch(externalAtlas.findRegion("blue_frame_2"),2,2,2,2));
        blueFrame3=new NinePatchDrawable(new NinePatch(externalAtlas.findRegion("blue_frame_3"),7,7,7,7));

        blueEllipse.getPatch().scale(2,2);
        blueRounded.getPatch().scale(2,2);
        brownRounded.getPatch().scale(2,2);
        brownEllipse.getPatch().scale(2,2);

        blueFrame3.getPatch().scale(4,4);

        passiveGray.getPatch().scale(2,2);
        activeGray.getPatch().scale(2,2);
        checkedGray.getPatch().scale(2,2);

        passiveBlue.getPatch().scale(2,2);


    }
    public void render(float delta) {

        statusUI.render(delta);
        spawnUI.render(delta);
        decisionsUI.render(delta);
        camera.update();
        stage.act();
        stage.draw();
    }
    public void resize(int width, int height) {
        viewport.update(width,height,true);


        statusUI.resize(width,height);
        entityUI.resize(width, height);
        decisionsUI.resize(width, height);
        spawnUI.resize(width, height);
    }
    @Override
    public boolean keyDown(int keycode) {
        if (keycode == Input.Keys.SPACE){
            EngineEdited.initiate.setPause(!EngineEdited.initiate.getPause());
            return true;
        }

        return false;
    }

    @Override
    public boolean keyUp(int keycode) {
        return false;
    }

    @Override
    public boolean keyTyped(char character) {
        return false;
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        if (button==0){
            Vector3 pos=camera.unproject(new Vector3(screenX,screenY,0));
            if (touchType==TouchType.SELECT){
                entityUI.setEntity(EntityList.entityList.getFromCoordinate(tempVector.set(pos.x,pos.y)));
            }
            else if (touchType==TouchType.SPAWN){
                if (ZombieBuilder.getInstance().builderMap.get(spawnUI.selectedType).getEne() <= ResourceType.getInstance().ENERGY.getCurrent()){
                    if (MapManager.getInstance().pointGraph.getPoint(pos.x,pos.y)==null)
                        return true;
                    EngineEdited.initiate.addEntity(entityFactory.createEntity(spawnUI.selectedType,pos.x,pos.y));
                    ResourceType.getInstance().ENERGY.minusCurrent(ZombieBuilder.getInstance().builderMap.get(spawnUI.selectedType).getEne());
                }
            }
            return true;
        }
        if (button==1){
            EngineEdited.initiate.removeEntityMember(1);
        }
        return false;
    }

    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        return false;
    }

    @Override
    public boolean mouseMoved(int screenX, int screenY) {
        return false;
    }

    @Override
    public boolean scrolled(float amountX, float amountY) {
        return false;
    }


}
