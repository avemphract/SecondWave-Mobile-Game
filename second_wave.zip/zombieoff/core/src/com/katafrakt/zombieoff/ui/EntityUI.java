package com.katafrakt.zombieoff.ui;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.math.Interpolation;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.ui.Container;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Align;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.managers.AssetOrganizer;

public class EntityUI extends Container<Table> {
    private static final String TAG=EntityUI.class.getSimpleName();

    private TextureAtlas textureAtlas;

    Skin skin;
    public static EntityUI entityUI;
    private static Entity entity;
    public static Entity getEntity(){
        return entity;
    }

    TextureAtlas atlas;

    PlayerHud playerHud;
    Table conTable;
        Table healthTable;
            Image healthImage;
        Table detailTable;
            Label row1;
            Label row2;
            Label row3;
            Label row4;


    float width;
    float height;
    float conWidth;
    float conHeight;

    float fontSize=1f;

    public EntityUI(PlayerHud playerHud){
        this.playerHud=playerHud;
        entityUI=this;
        textureAtlas=AssetOrganizer.getInstance().get("atlases/zombies.atlas",TextureAtlas.class);
        skin= AssetOrganizer.getInstance().get("skin/uiskin.json",Skin.class);
        atlas=AssetOrganizer.getInstance().get("atlases/colors.atlas",TextureAtlas.class);
        width= playerHud.viewport.getWorldWidth();
        height=playerHud.viewport.getWorldHeight();

        conWidth=250;
        conHeight=80;
        setSize(conWidth,conHeight);
        setPosition(0,0);

        conTable=new Table();
            healthTable=new Table();
                healthImage=new Image(playerHud.activeGreen);
                healthImage.setSize(conWidth,10);
            healthTable.background(new TextureRegionDrawable(atlas.findRegion("White")));
            healthTable.add(healthImage).growX().align(Align.bottomLeft).size(conWidth,10);
        conTable.add(healthTable).growX().pad(3,3,0,3).align(Align.top);
        conTable.row();

            detailTable=new Table();

                row1=new Label("", playerHud.secondLabel);
                row1.setFontScale(fontSize);
            detailTable.add(row1).pad(5).align(Align.left);
            detailTable.row();

                row2 =new Label("",playerHud.thirdLabel);
                row2.setFontScale(fontSize);
            detailTable.add(row2).pad(5).fillX().align(Align.left);
            detailTable.row();

                row3 =new Label("",playerHud.thirdLabel);
                row3.setFontScale(fontSize);
            detailTable.add(row3).pad(5).align(Align.left);
            detailTable.row();

                row4 =new Label("",playerHud.thirdLabel);
                row4.setFontScale(fontSize);
            detailTable.add(row4).pad(5).align(Align.left);

        conTable.add(detailTable).pad(5).align(Align.topLeft).expandY();
        conTable.background(playerHud.passiveGray);
        setActor(conTable);

        fill().align(Align.left);

    }

    public void resize(int width,int height){
        conWidth=220+width/8;
        conHeight=100;
        setSize(conWidth,conHeight);
        setPosition(5,5);
    }

    public void setEntity(Entity entity){
        EntityUI.entity= entity;
        if (entity!=null){
            if (Mappers.agentComponentV2(entity).primaryWeapon!=null)
                row2.setText("Weapon: " +Mappers.agentComponentV2(entity).primaryWeapon.getClass().getSimpleName());
            else
                row2.setText("Weapon: none");

            row4.setText("Type: "+Mappers.creatureComponents.get(entity).entityType.getName());

            entityStateChange();
            entityHealthChange(Mappers.creatureComponents.get(entity));

            addAction(Actions.moveTo(5,5,0.3f, Interpolation.circleOut));
        }
        else {
            addAction(Actions.moveTo(-conWidth-10,5,0.3f,Interpolation.circleOut));
        }
    }
    public void entityStateChange(){
        row3.setText("Status: "+Mappers.agentComponentV2(entity).stateMachine.getCurrentState().toString());
    }
    public void entityHealthChange(CreatureComponent creatureComponent){
        if (creatureComponent.currentHp>0){
            row1.setText("Health: "+creatureComponent.currentHp+"/"+creatureComponent.maxHp);
            healthImage.setSize(creatureComponent.currentHp/creatureComponent.maxHp*healthTable.getWidth(),healthTable.getHeight());
        }
        else{
            row1.setText("Health: 0/"+creatureComponent.maxHp);
            healthImage.setSize(0,healthTable.getHeight());
        }
    }
}
