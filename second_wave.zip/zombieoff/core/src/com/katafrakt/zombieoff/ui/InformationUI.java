package com.katafrakt.zombieoff.ui;

import com.badlogic.gdx.scenes.scene2d.ui.Container;
import com.badlogic.gdx.scenes.scene2d.ui.Table;

public class InformationUI extends Container<Table> {





    
}
