package com.katafrakt.zombieoff.ashley.systems;

import com.badlogic.ashley.core.Entity;
import com.badlogic.ashley.core.Family;
import com.badlogic.ashley.systems.IteratingSystem;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.VelocityComponent;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.managers.EngineEdited;
import com.katafrakt.zombieoff.ui.EntityUI;
import com.katafrakt.zombieoff.utilities.EntityList;

public class CreatureSystem extends IteratingSystem {
    private static final String TAG = CreatureSystem.class.getSimpleName();

    public CreatureSystem() {
        super(Family.all(CreatureComponent.class).get());
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);

    }

    @Override
    protected void processEntity(Entity entity, float deltaTime) {
        CreatureComponent creatureComponent= Mappers.creatureComponents.get(entity);

        if (creatureComponent.currentHp<=0 && creatureComponent.isAlive) {
            creatureComponent.isAlive=false;
            creatureComponent.die(Mappers.agentComponentV2(entity));

            entity.remove(VelocityComponent.class);
        }
        else if (!creatureComponent.isAlive){
            creatureComponent.deathTime+=deltaTime;
        }
        if (creatureComponent.deathTime>5){
            if (EntityUI.getEntity()==entity)
                EntityUI.entityUI.setEntity(null);
            EngineEdited.initiate.removeEntity(entity);
            EntityList.entityList.remove(entity);
        }
        //Gdx.app.log(TAG,"Human number:"+CreatureComponent.humanCreatures.size+" Zombie number:"+CreatureComponent.zombieCreatures.size);
    }
}
