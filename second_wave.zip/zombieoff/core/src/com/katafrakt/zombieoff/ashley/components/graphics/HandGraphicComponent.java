package com.katafrakt.zombieoff.ashley.components.graphics;

import com.badlogic.ashley.core.Component;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.katafrakt.zombieoff.game.weapons.WeaponGraphics;

public class HandGraphicComponent implements Component {
    public TextureRegion handTexture;

    public HandGraphicComponent(TextureRegion handTexture) {
        this.handTexture = handTexture;
    }
}
