package com.katafrakt.zombieoff.ashley.systems.graphics.entity;

import com.badlogic.ashley.core.Entity;
import com.badlogic.ashley.core.Family;
import com.badlogic.ashley.systems.IteratingSystem;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.creatures.BulletComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.GraphicsComponent;
import com.katafrakt.zombieoff.ui.CameraComposite;

public class BulletRendererSystem extends IteratingSystem {
    Array<Entity> entities=new Array<>();
    SpriteBatch spriteBatch;
    CameraComposite cameraComposite;

    public BulletRendererSystem(SpriteBatch spriteBatch, CameraComposite cameraComposite) {
        super(Family.all(BulletComponent.class, GraphicsComponent.class).get());
        this.spriteBatch=spriteBatch;
        this.cameraComposite=cameraComposite;

    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        spriteBatch.begin();
        for (Entity entity:entities){
            GraphicsComponent gc= Mappers.graphicsComponents.get(entity);
            TransformComponent tc= Mappers.transformComponents.get(entity);

            if (gc.textureRegion==null){
                continue;
            }
            if (gc.width==0||gc.height==0){
                gc.width=gc.textureRegion.getRegionWidth();
                gc.height=gc.textureRegion.getRegionHeight();
            }

            float originX=gc.width/2,originY=gc.height/2;

            spriteBatch.draw(gc.textureRegion,tc.pos.x-originX+gc.x_offset,tc.pos.y-originY+gc.y_offset,
                    originX,originY,
                    gc.width,gc.height,
                    tc.scale,tc.scale,
                    tc.rotation);
        }
        spriteBatch.end();
        entities.clear();
    }

    @Override
    protected void processEntity(Entity entity, float deltaTime) {
        entities.add(entity);
    }
}
