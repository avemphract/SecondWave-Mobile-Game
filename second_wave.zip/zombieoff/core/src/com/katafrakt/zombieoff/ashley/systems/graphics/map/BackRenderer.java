package com.katafrakt.zombieoff.ashley.systems.graphics.map;

import com.badlogic.ashley.core.EntitySystem;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;

public class BackRenderer extends EntitySystem {
    OrthographicCamera camera;
    OrthogonalTiledMapRenderer mapRenderer;
    public BackRenderer(OrthographicCamera camera, OrthogonalTiledMapRenderer mapRenderer){
        super();
        this.camera=camera;
        this.mapRenderer=mapRenderer;
        mapRenderer.setView(camera);
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        mapRenderer.setView(camera);
        mapRenderer.render();
    }
}
