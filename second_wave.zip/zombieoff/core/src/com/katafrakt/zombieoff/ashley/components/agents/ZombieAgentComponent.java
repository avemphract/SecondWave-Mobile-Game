package com.katafrakt.zombieoff.ashley.components.agents;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.ai.fsm.DefaultStateMachine;
import com.badlogic.gdx.ai.fsm.State;
import com.badlogic.gdx.ai.msg.Telegram;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ai.states.ZombieState;
import com.katafrakt.zombieoff.game.AnimationName;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponInformation;
import com.katafrakt.zombieoff.game.weapons.MeleeWeapon;
import com.katafrakt.zombieoff.game.weapons.zombie.melee.AreaAttack;
import com.katafrakt.zombieoff.game.weapons.zombie.melee.BasicAttack;
import com.katafrakt.zombieoff.managers.GeneralOrganizer;

public class ZombieAgentComponent extends AgentComponent<MeleeWeapon> {

    public BasicAttack.Level level=new BasicAttack.Level(1,1,2);
    private AreaAttack.Level areaL=new AreaAttack.Level(1,0,1,1);
    public ZombieAgentComponent(Entity entity, Array<WeaponInformation> weaponCreators, Array<AbilityCreator> abilityUnlocks, int awareRadius) {
        super(entity,weaponCreators,abilityUnlocks,awareRadius);
        animationName= AnimationName.WALK_DOWN;
        currentTime= GeneralOrganizer.getInstance().random.nextFloat()*4;
    }

    @Override
    public void addedEngine() {
        super.addedEngine();
        currentPoint.zombies.add(entity);
        ZombieState.IDLE.enter(this);
        stateMachine= new DefaultStateMachine<ZombieAgentComponent, State<ZombieAgentComponent>>(this, ZombieState.IDLE);
    }

    @Override
    public boolean handleMessage(Telegram msg) {
        return false;
    }
}
