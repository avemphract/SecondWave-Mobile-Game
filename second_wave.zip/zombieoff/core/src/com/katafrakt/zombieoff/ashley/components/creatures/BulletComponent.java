package com.katafrakt.zombieoff.ashley.components.creatures;

import com.badlogic.ashley.core.Component;
import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.entities.BulletOwner;
import com.katafrakt.zombieoff.entities.BulletType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.CloneableAbilityController;
import com.katafrakt.zombieoff.game.weapons.hitbehaviour.HitBehaviour;

public class BulletComponent implements Component, Pool.Poolable {
    private static final String TAG = BulletComponent.class.getSimpleName();
    public HitBehaviour hitBehaviour;
    public Array<CloneableAbilityController> abilityControllers=new Array<>();
    public Vector2 speed=new Vector2();
    public Entity entity;
    public float damage;
    public float totalTime;
    public float remainTime;
    public BulletOwner bulletOwner;
    public BulletType bulletType;

    public float progress;
    public Vector2 norm;
    public boolean rot=MathUtils.randomBoolean();

    public boolean isDeath;
    public float deathTime;

    public void set(Entity entity, BulletOwner bulletOwner, BulletType bulletType, HitBehaviour hitBehaviour, Vector2 speed, float damage, float remainTime){
        this.entity=entity;
        this.hitBehaviour=hitBehaviour;
        this.bulletType=bulletType;
        this.speed.set(speed);
        this.damage=damage;
        this.remainTime=remainTime;
        totalTime=remainTime;
        this.bulletOwner = bulletOwner;
        this.isDeath=false;
        this.deathTime=3;
        norm=new Vector2(speed.rotate90(1)).nor();
        speed.rotate90(-1);
    }

    public void hit(){
        hitBehaviour.hit(this);

    }

    @Override
    public void reset() {
        speed.set(0,0);
        for (CloneableAbilityController abilityController:abilityControllers)
            abilityController.getPool().free(abilityController);
        abilityControllers.clear();
        hitBehaviour.getPool().free(hitBehaviour);

    }
}
