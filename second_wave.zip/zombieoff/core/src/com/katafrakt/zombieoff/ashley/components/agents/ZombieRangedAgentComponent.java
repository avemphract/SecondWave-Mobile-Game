package com.katafrakt.zombieoff.ashley.components.agents;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.ai.fsm.DefaultStateMachine;
import com.badlogic.gdx.ai.fsm.State;
import com.badlogic.gdx.ai.msg.Telegram;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ai.states.ZombieRangedState;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponInformation;
import com.katafrakt.zombieoff.game.weapons.RangedWeapon;

public class ZombieRangedAgentComponent extends AgentComponent<RangedWeapon> {
    private static final String TAG = ZombieRangedAgentComponent.class.getSimpleName();

    public ZombieRangedAgentComponent(Entity entity, Array<WeaponInformation> weaponCreators, Array<AbilityCreator> abilityUnlocks, int awareRadius) {
        super(entity, weaponCreators, abilityUnlocks, awareRadius);
        debugPath=true;
    }

    @Override
    public boolean handleMessage(Telegram msg) {
        return false;
    }

    @Override
    public void addedEngine() {
        super.addedEngine();
        currentPoint.zombies.add(entity);
        ZombieRangedState.IDLE.enter(this);
        stateMachine= new DefaultStateMachine<ZombieRangedAgentComponent, State<ZombieRangedAgentComponent>>(this,ZombieRangedState.IDLE);
    }
}
