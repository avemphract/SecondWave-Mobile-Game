package com.katafrakt.zombieoff.ashley.systems;

import com.badlogic.ashley.core.Entity;
import com.badlogic.ashley.core.Family;
import com.badlogic.ashley.systems.IteratingSystem;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.math.Interpolation;
import com.badlogic.gdx.math.MathUtils;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.creatures.BulletComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.DebugGraphicsComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.GraphicsComponent;
import com.katafrakt.zombieoff.entities.bullets.Bullet;
import com.katafrakt.zombieoff.managers.BulletFactory;
import com.katafrakt.zombieoff.managers.EngineEdited;
import com.katafrakt.zombieoff.managers.GeneralOrganizer;

import java.util.Random;


public class BulletSystem extends IteratingSystem {
    private static final String TAG=BulletSystem.class.getSimpleName();

    Random random;
    public BulletSystem() {
        super(Family.all(BulletComponent.class).get());
        random = GeneralOrganizer.getInstance().random;
    }

    @Override
    protected void processEntity(Entity entity, float deltaTime) {
        BulletComponent bulletComponent= Mappers.bulletComponents.get(entity);
        TransformComponent transformComponent= Mappers.transformComponents.get(entity);



        if (!bulletComponent.isDeath){
            bulletComponent.remainTime-=deltaTime;
            if (bulletComponent.remainTime < 0){
                bulletComponent.hit();
                bulletComponent.isDeath=true;
                if (Mappers.debugGraphicsComponents.get(entity)!=null)
                    entity.getComponent(DebugGraphicsComponent.class).isActive=false;
                if (Mappers.graphicsComponents.get(entity) != null)
                    Mappers.graphicsComponents.get(entity).textureRegion=null;
            }
            else
            switch (bulletComponent.bulletType){
                case LINE:
                    transformComponent.pos.x+=bulletComponent.speed.x*deltaTime;
                    transformComponent.pos.y+=bulletComponent.speed.y*deltaTime;
                    break;
                case AIRBORNE:
                    transformComponent.pos.x+=bulletComponent.speed.x *deltaTime* (1 - Interpolation.circleIn.apply(1-bulletComponent.remainTime/(bulletComponent.totalTime)))*1.27f;
                    transformComponent.pos.y+=bulletComponent.speed.y *deltaTime* (1 - Interpolation.circleIn.apply(1-bulletComponent.remainTime/(bulletComponent.totalTime)))*1.27f;
                    transformComponent.rotation+=deltaTime*180;
                    transformComponent.scale=1.5f-Math.abs(bulletComponent.totalTime/2-bulletComponent.remainTime)/bulletComponent.totalTime;
                    break;
                case UNDERGROUND:
                    if (bulletComponent.rot){
                        bulletComponent.progress+=deltaTime*10;
                        if (bulletComponent.progress>1)
                            bulletComponent.rot=false;
                    }
                    else {
                        bulletComponent.progress-=deltaTime*10;
                        if (bulletComponent.progress<-1)
                            bulletComponent.rot=true;
                    }
                    float velx=bulletComponent.speed.x*deltaTime+ bulletComponent.norm.x*(bulletComponent.progress);
                    float vely=bulletComponent.speed.y*deltaTime+ bulletComponent.norm.y*(bulletComponent.progress);
                    transformComponent.pos.x+=velx;
                    transformComponent.pos.y+=vely;

                    transformComponent.rotation= MathUtils.atan2(vely,velx);
                    break;
            }
        }

        else if (bulletComponent.deathTime > 0){
            bulletComponent.deathTime-=deltaTime;
        }
        else {
            BulletFactory.pool.free(((Bullet)entity));
        }

    }
}
