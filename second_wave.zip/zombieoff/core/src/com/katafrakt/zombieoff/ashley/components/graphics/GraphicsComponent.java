package com.katafrakt.zombieoff.ashley.components.graphics;

import com.badlogic.ashley.core.Component;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class GraphicsComponent implements Component {
    public TextureRegion textureRegion;
    public int width,height;
    public int x_offset,y_offset;
    public int renderOrder;//High equal high priorty
    public GraphicsComponent(){}
    public GraphicsComponent(int x_offset,int y_offset){
        this.x_offset=x_offset;
        this.y_offset=y_offset;
    }
    public GraphicsComponent(TextureRegion textureRegion){
        this.textureRegion=textureRegion;
        width=textureRegion.getRegionWidth();
        height=textureRegion.getRegionHeight();
    }
    public GraphicsComponent init(TextureRegion textureRegion, int width, int height){
        this.textureRegion=textureRegion;
        this.width=width;
        this.height=height;
        return this;
    }

}
