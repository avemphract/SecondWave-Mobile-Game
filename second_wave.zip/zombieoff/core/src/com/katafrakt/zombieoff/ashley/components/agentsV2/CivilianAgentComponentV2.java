package com.katafrakt.zombieoff.ashley.components.agentsV2;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.ai.fsm.DefaultStateMachine;
import com.badlogic.gdx.ai.msg.Telegram;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ai.statesV2.CivilianStateV2;
import com.katafrakt.zombieoff.game.AnimationName;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponInformation;
import com.katafrakt.zombieoff.game.weapons.Weapon;

public class CivilianAgentComponentV2 extends HumanAgentComponentV2<Weapon> {


    public CivilianAgentComponentV2(Entity entity, Array<WeaponCreator> weaponCreators, Array<AbilityCreator> abilityCreators, int awareRadius) {
        super(entity,weaponCreators,abilityCreators, awareRadius);
        animationName= AnimationName.WAIT_DOWN;
    }

    @Override
    public void addedEngine() {
        super.addedEngine();
        stateMachine=new DefaultStateMachine(this,CivilianStateV2.WAIT);
    }

    @Override
    public boolean handleMessage(Telegram msg) {
        return false;
    }
}
