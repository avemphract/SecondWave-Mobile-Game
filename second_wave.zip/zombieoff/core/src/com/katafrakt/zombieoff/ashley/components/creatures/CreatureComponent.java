package com.katafrakt.zombieoff.ashley.components.creatures;

import com.badlogic.ashley.core.Component;
import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.utils.ArrayMap;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.graphics.FloatingTextComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.ParticleEffectComponent;
import com.katafrakt.zombieoff.entities.EntityType;
import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.abilitiybehaviours.StatusTypes;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.AbilityEffect;
import com.katafrakt.zombieoff.player.PlayerStatics;
import com.katafrakt.zombieoff.player.ResourceSystem;
import com.katafrakt.zombieoff.ui.EntityUI;

public class CreatureComponent implements Component {
    private static final String TAG=CreatureComponent.class.getSimpleName();
    ResourceSystem resourceSystem = PlayerStatics.getInstance().resourceSystem;


    public ArrayMap<StatusTypes, AbilityEffect> status=new ArrayMap<>();

    public Entity entity;
    public EntityType entityType;

    public float accuracy=100;

    public float maxHp;
    public float currentHp;

    public float extraAttRate;
    public float getAttRate(){return 1+extraAttRate;}

    public float damage=10;
    public float extraDamage;
    public float getDamage(){return damage+extraDamage;}

    public float speed;
    public float extraSpeed;
    public float getSpeed(){return speed+extraSpeed;}

    public float regen;
    public float extraRegen;
    public float getRegen(){return regen+extraRegen;}

    public float reduction;
    public float extraReduction;
    public float getReduction(){return reduction+extraReduction; }

    public boolean isAlive=true;
    public float deathTime=0;

    public CreatureComponent(Entity entity, EntityType entityType, float maxHp, float damage, float speed, float regen, float reduction){
        this.entity=entity;
        this.maxHp=maxHp;
        this.damage=damage;
        this.speed=speed;
        this.regen=regen;
        this.reduction=reduction;
        currentHp=maxHp;
        this.entityType=entityType;
    }

    public void takeDamageBlood(float damage){

        damage=(1-getReduction())*damage;
        if (entity.getComponent(ParticleEffectComponent.class)!=null){
            //entity.getComponent(ParticleEffectComponent.class).addBlood((int) (100*damage/maxHp));
        }
        if (currentHp<=damage)
            currentHp=0;
        else
            currentHp-=damage;

        if (entityType.member==0){
            PlayerStatics.getInstance().totalDamage.add(damage);
            //PlayerStatics.getInstance().totalDamage+=damage;//TotalDamage
        }
        if (entity== EntityUI.getEntity())
            EntityUI.entityUI.entityHealthChange(this);

        Mappers.agentComponentV2(entity).updateAbilities(AbilityController.Type.GET_ATTACKED);

        if (Mappers.floatingTextComponents.has(entity))
            Mappers.floatingTextComponents.get(entity).addText(FloatingTextComponent.Type.HEALTH,-damage);
            //Gdx.app.log(TAG,"Zombie health: "+currentHp/maxHp+" D:"+damage);
    }
    public void takeDamageBloodless(float damage){

        damage=(1-getReduction())*damage;
        if (currentHp<=damage)
            currentHp=0;
        else
            currentHp-=damage;

        if (entityType.member==0){
            PlayerStatics.getInstance().totalDamage.add(damage);
            //PlayerStatics.getInstance().totalDamage+=damage;//TotalDamage
        }
        if (entity== EntityUI.getEntity())
            EntityUI.entityUI.entityHealthChange(this);

        Mappers.agentComponentV2(entity).updateAbilities(AbilityController.Type.GET_ATTACKED);

    }

    public void die(AgentComponentV2 agentComponent){
        if (entityType.member==0){
            ResourceType.getInstance().BLOOD.addCurrent(maxHp);
            PlayerStatics.getInstance().humanDeath.add(+1);
            agentComponent.currentPoint.humans.removeValue(entity,true);
        }
        else if (entityType.member==1){
            ResourceType.getInstance().BLOOD.addCurrent(maxHp * ResourceType.getInstance().BLOOD.zombieGainRate);
            agentComponent.currentPoint.zombies.removeValue(entity,true);
        }
        else {
            Gdx.app.log(TAG,"Error");
        }
        agentComponent.updateAbilities(AbilityController.Type.DIED);
        PlayerStatics.getInstance().totalDeath.put(entityType,PlayerStatics.getInstance().totalDeath.get(entityType)+1);
        //playerStatus.blood.setCurrentResource(playerStatus.blood.getCurrentResource()+maxHp/10);
    }
}