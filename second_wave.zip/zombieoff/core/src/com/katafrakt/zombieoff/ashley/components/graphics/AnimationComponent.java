package com.katafrakt.zombieoff.ashley.components.graphics;

import com.badlogic.ashley.core.Component;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.game.AnimationName;
import com.katafrakt.zombieoff.managers.GeneralOrganizer;

import java.util.HashMap;

public class AnimationComponent implements Component {

    private static final String TAG=AnimationComponent.class.getSimpleName();

    public boolean stop=false;
    public HashMap<AnimationName,Animation<TextureRegion>> animations=new HashMap<>();

    public void addConstant(AnimationName animationName,TextureRegion[] keyframes){
        animations.put(animationName,createConstant(keyframes));
    }
    public void addLoop(AnimationName animationName, float frameDuration, TextureRegion[] keyFrames){
        //Gdx.app.log(TAG,"Animation added: "+animationName);
        animations.put(animationName, createLoop(frameDuration,keyFrames));
    }
    public void addOne(AnimationName animationName,float frameDuration, TextureRegion[] keyFrames){
        animations.put(animationName,createOne(frameDuration,keyFrames));
    }

    private AnimationConstant createConstant(TextureRegion[] keyframes){
        return new AnimationConstant(keyframes);
    }
    private AnimationLoop createLoop(float frameDuration, TextureRegion[] keyFrames){
        return new AnimationLoop(frameDuration,keyFrames, Animation.PlayMode.LOOP);
    }
    private AnimationOneTime createOne(float frameDuration, TextureRegion[] keyFrames){
        return new AnimationOneTime(frameDuration,keyFrames, Animation.PlayMode.NORMAL);
    }

    public class AnimationConstant extends Animation<TextureRegion>{

        public AnimationConstant(TextureRegion[] keyFrames) {
            super(1, new Array<TextureRegion>(keyFrames), PlayMode.NORMAL);
        }

        @Override
        public TextureRegion getKeyFrame(float stateTime) {
            return super.getKeyFrame(0);
        }
    }
    public class AnimationLoop extends Animation<TextureRegion>{
        float startTime;
        public AnimationLoop(float frameDuration, TextureRegion[] keyFrames, PlayMode playMode) {
            super(frameDuration, new Array<TextureRegion>(keyFrames) , playMode);
            startTime=GeneralOrganizer.getInstance().random.nextFloat()*frameDuration;
        }

        @Override
        public TextureRegion getKeyFrame(float stateTime) {
            return super.getKeyFrame(stateTime-startTime);
        }
    }
    public class AnimationOneTime extends Animation<TextureRegion>{
        boolean firstLoop=false;
        float time;

        public AnimationOneTime(float frameDuration, TextureRegion[] keyFrames, PlayMode playMode) {
            super(frameDuration, new Array<TextureRegion>(keyFrames), playMode);
        }

        @Override
        public TextureRegion getKeyFrame(float stateTime) {
            if (stop)
                return super.getKeyFrame(0);
            else {
                if (firstLoop==true){
                    time=stateTime;
                    firstLoop=false;
                }
                if (time+getFrameDuration()*getKeyFrames().length<stateTime){
                    time=stateTime;
                    firstLoop=false;
                    return super.getKeyFrame(0);
                }
                if ((stateTime-time)>getFrameDuration()*(getKeyFrames().length-1)){
                    stop=true;
                    firstLoop=true;
                }
                return super.getKeyFrame(stateTime-time+getFrameDuration());
            }
        }
    }
}
