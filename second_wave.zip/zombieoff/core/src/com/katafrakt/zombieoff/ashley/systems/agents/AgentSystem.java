package com.katafrakt.zombieoff.ashley.systems.agents;

import com.badlogic.ashley.core.Entity;
import com.badlogic.ashley.core.Family;
import com.badlogic.ashley.systems.IteratingSystem;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agents.AgentComponent;
import com.katafrakt.zombieoff.ashley.components.agents.CivilianAgentComponent;
import com.katafrakt.zombieoff.ashley.components.agents.MercenaryAgentComponent;
import com.katafrakt.zombieoff.ashley.components.agents.PoliceAgentComponent;
import com.katafrakt.zombieoff.ashley.components.agents.VeteranAgentComponent;
import com.katafrakt.zombieoff.ashley.components.agents.ZombieAgentComponent;
import com.katafrakt.zombieoff.ashley.components.agents.ZombieRangedAgentComponent;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.game.weapons.Weapon;
import com.katafrakt.zombieoff.managers.GeneralOrganizer;

public class AgentSystem extends IteratingSystem {
    private final static String TAG=AgentSystem.class.getSimpleName();

    public AgentSystem() {
        super(Family.one(ZombieAgentComponent.class, ZombieRangedAgentComponent.class,
                CivilianAgentComponent.class, PoliceAgentComponent.class, MercenaryAgentComponent.class, VeteranAgentComponent.class).get());
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
    }

    @Override
    protected void processEntity(Entity entity, float deltaTime) {
        AgentComponent<? extends Weapon> agent=Mappers.agentComponents(entity);
        CreatureComponent creature= Mappers.creatureComponents.get(entity);

        if (creature.isAlive&&GeneralOrganizer.getInstance().random.nextFloat()>0.97f)
            agent.stateMachine.update();
    }
}
