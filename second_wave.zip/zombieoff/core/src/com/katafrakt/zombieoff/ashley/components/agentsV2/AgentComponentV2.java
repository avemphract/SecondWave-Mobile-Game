package com.katafrakt.zombieoff.ashley.components.agentsV2;

import com.badlogic.ashley.core.Component;
import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.ai.fsm.State;
import com.badlogic.gdx.ai.fsm.StateMachine;
import com.badlogic.gdx.ai.msg.Telegraph;
import com.badlogic.gdx.ai.pfa.GraphPath;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ArrayMap;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ashley.components.Init;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.VelocityComponent;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.game.AnimationName;
import com.katafrakt.zombieoff.game.StateType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit.Stack;
import com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit.TimeLimit;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.AbilityEffect;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponInformation;
import com.katafrakt.zombieoff.game.weapons.Weapon;
import com.katafrakt.zombieoff.managers.GeneralOrganizer;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.utilities.SortingArray;

import java.util.Iterator;

public abstract class AgentComponentV2<E extends Weapon> implements Telegraph, Init, Component {
    private static final String TAG=AgentComponentV2.class.getSimpleName();

    public E primaryWeapon;
    public AnimationName.Direction direction= AnimationName.Direction.DOWN;
    public AnimationName animationName=AnimationName.WAIT_DOWN;
    public StateMachine<? extends AgentComponentV2<?>,State<? extends AgentComponentV2<?>>> stateMachine;

    //abilities
    public ArrayMap<AbilityController.Type,Array<AbilityController<?>>> abilities=new ArrayMap<AbilityController.Type,Array<AbilityController<?>>>();
    public StateType currentState=StateType.IDLE;

    {
        abilities.put(AbilityController.Type.UPDATE,new Array<AbilityController<?>>());
        abilities.put(AbilityController.Type.STATE,new Array<AbilityController<?>>());
        abilities.put(AbilityController.Type.ATTACK,new Array<AbilityController<?>>());
        abilities.put(AbilityController.Type.GET_ATTACKED,new Array<AbilityController<?>>());
        abilities.put(AbilityController.Type.DIED,new Array<AbilityController<?>>());
    }

    public ArrayMap<Class<? extends AbilityEffect>, SortingArray<TimeLimit>> timedEffects= new ArrayMap<Class<? extends AbilityEffect>, SortingArray<TimeLimit>>(){
        @Override
        public SortingArray<TimeLimit> get(Class<? extends AbilityEffect> key) {
            if (super.get(key)==null)
                put(key,new SortingArray<TimeLimit>());
            return super.get(key);
        }
    };
    public ArrayMap<AbilityCreator,Array<Stack>> stacks=new ArrayMap<AbilityCreator, Array<Stack>>(){
        @Override
        public Array<Stack> get(AbilityCreator key) {
            if (super.get(key)==null)
                put(key,new Array<Stack>());
            return super.get(key);
        }
    };

    //next update
    public float nextTick=GeneralOrganizer.getInstance().random.nextFloat();
    public float lastAttackTime;

    //Properties
    public int awareRadius;
    public int count=0;
    public int scanRate=5;

    //positioning
    public GraphPath<Point> path;
    public Point currentPoint;
    public Point nextPoint;
    public Point targetPoint;
    public Iterator<Point> iterator;
    public Vector2 nextPosition=new Vector2();


    //own
    public Entity entity;
    public TransformComponent transform;
    public CreatureComponent creature;
    public VelocityComponent velocityComponent;

    //target
    public Entity target;
    public TransformComponent targetTransform;
    public CreatureComponent targetCreature;
    public AgentComponentV2<? extends Weapon> targetAgent;

    public AgentComponentV2(Entity entity, Array<WeaponCreator> weaponCreators, Array<AbilityCreator> abilityCreators, int awareRadius) {
        this.entity = entity;
        this.awareRadius=awareRadius;
        if (!weaponCreators.isEmpty())
            primaryWeapon= (E) weaponCreators.get(0).getWeapon();
        for (AbilityCreator abilityUnlock:abilityCreators){
            addAbility(abilityUnlock.getAbility());
        }
        this.awareRadius=awareRadius;
    }

    @Override
    public void addedEngine() {
        transform=Mappers.transformComponents.get(entity);
        creature=Mappers.creatureComponents.get(entity);
        velocityComponent=Mappers.velocityComponents.get(entity);
        currentPoint= MapManager.getInstance().pointGraph.nearestPoint(Mappers.transformComponents.get(entity).pos);

    }

    public void addAbility(AbilityController<?> abilityController){
        for (AbilityController.Type type :abilityController.types)
            abilities.get(type).add(abilityController);
        if (abilityController instanceof TimeLimit)
            timedEffects.get(abilityController.abilityEffect.getClass()).add((TimeLimit) abilityController);
        if (abilityController instanceof Stack)
            stacks.get(((Stack)abilityController).abilityCreator).add((Stack) abilityController);

    }
    public void removeAbility(AbilityController<?> abilityController){
        for (AbilityController.Type type :abilityController.types)
            abilities.get(type).removeValue(abilityController,false);
        if (abilityController instanceof TimeLimit)
            timedEffects.get(abilityController.abilityEffect.getClass()).removeValue((TimeLimit) abilityController,false);
        if (abilityController instanceof Stack)
            stacks.get(((Stack)abilityController).abilityCreator).removeValue((Stack) abilityController,false);
    }

    public void updateAbilities(AbilityController.Type type){
        if (type== AbilityController.Type.UPDATE)
            for (AbilityController<?> ability:abilities.get(type)) {
                //Gdx.app.log(TAG,"AbilityUpdate: "+ability.getClass().getSimpleName());
                ability.update(this, type);
            }
        else if (type == AbilityController.Type.STATE){
            for (AbilityController<?> ability:abilities.get(type)){
                ability.update(this,type);
            }
        }
        else if (type == AbilityController.Type.ATTACK){
            for (AbilityController<?> ability:abilities.get(type)){
                ability.update(this,type);
            }
        }
        else if (type == AbilityController.Type.GET_ATTACKED){
            for (AbilityController<?> ability:abilities.get(type)){
                ability.update(this,type);
            }
        }
        else if (type == AbilityController.Type.DIED){
            for (AbilityController<?> ability:abilities.get(type)){
                ability.update(this,type);
            }
        }
    }


}
