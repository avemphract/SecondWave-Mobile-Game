package com.katafrakt.zombieoff.ashley.systems.graphics.entity;

import com.badlogic.ashley.core.Entity;
import com.badlogic.ashley.core.Family;
import com.badlogic.ashley.systems.IteratingSystem;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ashley.components.BoundComponent;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.graphics.DebugGraphicsComponent;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.ExplosionDamage;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.ui.EntityUI;


public class DebugRendererSystem extends IteratingSystem {

    Array<Entity> entities;
    public Array<ExplosionDamage> explosions;
    ShapeRenderer shapeRenderer;
    SpriteBatch spriteBatch;
    Camera camera;

    public DebugRendererSystem(ShapeRenderer shapeRenderer, SpriteBatch spriteBatch, Camera camera) {
        super(Family.all(DebugGraphicsComponent.class, TransformComponent.class).get());
        entities=new Array<>();
        explosions=new Array<>();
        this.shapeRenderer=shapeRenderer;
        this.spriteBatch=spriteBatch;
        this.camera=camera;
        shapeRenderer.setAutoShapeType(true);
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);

        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);

        shapeRenderer.begin();

        shapeRenderer.set(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setProjectionMatrix(camera.combined);
        shapeRenderer.setColor(Color.DARK_GRAY);

        for (Entity entity:entities){
            DebugGraphicsComponent dgc= Mappers.debugGraphicsComponents.get(entity);
            TransformComponent tc= Mappers.transformComponents.get(entity);
            BoundComponent bc= Mappers.boundComponents.get(entity);
            shapeRenderer.setColor(dgc.colorOut);
            shapeRenderer.rect(tc.pos.x-bc.width/2,tc.pos.y-bc.height/2,bc.width,bc.height);


        }
        /*
        for (Entity entity:entities){
            DebugGraphicsComponent dgc= Mappers.debugGraphicsComponents.get(entity);
            TransformComponent tc= Mappers.transformComponents.get(entity);
            BoundComponent bc=Mappers.boundComponents.get(entity);
            if (Mappers.creatureComponents.has(entity)){
                shapeRenderer.setColor(Color.BLACK);
                shapeRenderer.set(ShapeRenderer.ShapeType.Line);
                shapeRenderer.rect((int)(tc.pos.x-bc.width/2),(int)(tc.pos.y-bc.height/2),bc.width,bc.height);
            }
            shapeRenderer.setColor(dgc.colorIn);
            shapeRenderer.circle(tc.pos.x,tc.pos.y,1);
        }*/

        if (EntityUI.getEntity()!=null){
            AgentComponentV2<?> agentComponentV2=Mappers.agentComponentV2(EntityUI.getEntity());
            shapeRenderer.set(ShapeRenderer.ShapeType.Line);
            shapeRenderer.setColor(Color.GOLDENROD);
            shapeRenderer.circle(agentComponentV2.transform.pos.x,agentComponentV2.transform.pos.y,agentComponentV2.awareRadius*Point.UNIT);
            shapeRenderer.setColor(Color.SCARLET);
            shapeRenderer.circle(agentComponentV2.transform.pos.x,agentComponentV2.transform.pos.y,agentComponentV2.primaryWeapon.range*Point.UNIT);

            if (agentComponentV2.path!=null){
                for (int i=0;i<agentComponentV2.path.getCount();i++){
                    shapeRenderer.circle(agentComponentV2.path.get(i).x,agentComponentV2.path.get(i).y,3);
                }
            }
            shapeRenderer.set(ShapeRenderer.ShapeType.Line);
            if (agentComponentV2.targetTransform!=null){
                shapeRenderer.setColor(Color.BLACK);
                shapeRenderer.circle(agentComponentV2.targetTransform.pos.x,agentComponentV2.targetTransform.pos.y,5);
            }
        }


        MapManager.getInstance().pointGraph.render(shapeRenderer);

        spriteBatch.begin();
        spriteBatch.setProjectionMatrix(camera.combined);
        MapManager.getInstance().pointGraph.drawString(spriteBatch);
        spriteBatch.end();

        entities.clear();
        shapeRenderer.end();
    }

    @Override
    protected void processEntity(Entity entity, float deltaTime) {
        if (Mappers.debugGraphicsComponents.get(entity).isActive)
            entities.add(entity);
    }
}
