package com.katafrakt.zombieoff.ashley.components;

import com.badlogic.ashley.core.Component;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Pool;

public class TransformComponent implements Component, Pool.Poolable {
    public Vector2 pos;
    public float rotation;
    public float scale=1;

    public TransformComponent(){
        pos=new Vector2();
    }
    public TransformComponent(float x,float y){
        pos= new Vector2(x,y);
    }


    public float distance(TransformComponent targetTransform){
        return (float) Math.pow(Math.pow(pos.x-targetTransform.pos.x,2)+Math.pow(pos.y-targetTransform.pos.y,2),0.5f);

    }

    @Override
    public void reset() {
        pos.setZero();
    }

    public void init(float x, float y) {
        pos=pos.set(x,y);
    }
}
