package com.katafrakt.zombieoff.ashley.components.agents;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.ai.msg.Telegram;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponInformation;
import com.katafrakt.zombieoff.game.weapons.Weapon;

public abstract class HumanAgentComponent<T extends Weapon> extends AgentComponent<T> {
    public float awareness;

    public HumanAgentComponent(Entity entity, Array<WeaponInformation> weaponCreators, Array<AbilityCreator> abilityUnlocks, int awareRadius) {
        super(entity,weaponCreators,abilityUnlocks,awareRadius);
    }

    @Override
    public void addedEngine() {
        super.addedEngine();
        currentPoint.humans.add(entity);
    }

    @Override
    public boolean handleMessage(Telegram msg) {
        stateMachine.handleMessage(msg);
        return false;
    }
}
