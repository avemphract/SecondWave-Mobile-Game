package com.katafrakt.zombieoff.ashley.components.agents;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.ai.fsm.DefaultStateMachine;
import com.badlogic.gdx.ai.fsm.State;
import com.badlogic.gdx.ai.msg.MessageManager;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ai.states.PoliceState;
import com.katafrakt.zombieoff.entities.EntityType;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponInformation;
import com.katafrakt.zombieoff.game.weapons.Weapon;

public class PoliceAgentComponent extends HumanAgentComponent<Weapon> {

    public Array<Entity> inRange=new Array<>();
    public Point initialPoint;
    public Vector2 direction=new Vector2();


    public boolean idleMoveIsActive;
    public boolean messaged;
    public float remainTimeToIdle;
    public float counter;

    public PoliceAgentComponent(Entity entity, Array<WeaponInformation> weaponCreators, Array<AbilityCreator> abilityUnlocks, int awareRadius) {
        super(entity,weaponCreators,abilityUnlocks,awareRadius);
    }

    @Override
    public void addedEngine() {
        super.addedEngine();
        PoliceState.IDLE.enter(this);
        stateMachine=new DefaultStateMachine<PoliceAgentComponent, State<PoliceAgentComponent>>(this, PoliceState.IDLE);
        MessageManager.getInstance().addListener(this,EntityType.POLICE.toInteger());
    }
}
