package com.katafrakt.zombieoff.ashley.systems;

import com.badlogic.ashley.core.Entity;
import com.badlogic.ashley.core.Family;
import com.badlogic.ashley.systems.IteratingSystem;
import com.badlogic.gdx.math.MathUtils;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.VelocityComponent;

public class VelocitySystem extends IteratingSystem {
    private static final String TAG=VelocitySystem.class.getSimpleName();
    public VelocitySystem() {
        super(Family.all(TransformComponent.class, VelocityComponent.class).get());
    }

    @Override
    protected void processEntity(Entity entity, float deltaTime) {
        TransformComponent tc= Mappers.transformComponents.get(entity);
        VelocityComponent vc=Mappers.velocityComponents.get(entity);
        deltaTime= MathUtils.clamp(deltaTime,0.001f,0.5f);
        tc.pos.add(vc.speed.x*deltaTime,vc.speed.y*deltaTime);
    }
}
