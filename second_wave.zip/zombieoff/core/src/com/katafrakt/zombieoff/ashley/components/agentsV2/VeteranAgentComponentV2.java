package com.katafrakt.zombieoff.ashley.components.agentsV2;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.ai.fsm.DefaultStateMachine;
import com.badlogic.gdx.ai.msg.Telegram;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ai.statesV2.VeteranStateV2;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponInformation;
import com.katafrakt.zombieoff.game.weapons.RangedWeapon;

public class VeteranAgentComponentV2 extends HumanAgentComponentV2<RangedWeapon> {
    public float nextAttack;
    public float nextWalk;

    public VeteranAgentComponentV2(Entity entity, Array<WeaponCreator> weaponCreators, Array<AbilityCreator> abilityCreators, int awareRadius) {
        super(entity, weaponCreators, abilityCreators, awareRadius);
    }

    @Override
    public void addedEngine() {
        super.addedEngine();
        stateMachine=new DefaultStateMachine(this,VeteranStateV2.WAIT);

    }

    @Override
    public boolean handleMessage(Telegram msg) {
        return false;
    }
}
