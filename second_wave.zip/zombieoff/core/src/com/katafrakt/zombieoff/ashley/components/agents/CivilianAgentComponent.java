package com.katafrakt.zombieoff.ashley.components.agents;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.ai.fsm.DefaultStateMachine;
import com.badlogic.gdx.ai.fsm.State;
import com.badlogic.gdx.ai.msg.Telegram;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ai.states.CivilianState;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponInformation;
import com.katafrakt.zombieoff.game.weapons.Weapon;

public class CivilianAgentComponent extends HumanAgentComponent<Weapon> {
    private static final String TAG=CivilianAgentComponent.class.getSimpleName();

    //Idling
    public boolean targetPosActive;
    public Vector2 direction=new Vector2();
    //public static BurstRangedWeapon.Level builder=new BurstRangedWeapon.Level(Weapon.Recommended.MEDIUM,new SingleTargetHitBehaviour(),1,10,1,12,85,60,0.1f,4);


    public CivilianAgentComponent(Entity entity, Array<WeaponInformation> weaponCreators, Array<AbilityCreator> abilityUnlocks, int awareRadius) {
        super(entity,weaponCreators,abilityUnlocks,awareRadius);

    }

    @Override
    public void addedEngine() {
        super.addedEngine();
        CivilianState.IDLE.enter(this);
        stateMachine= new DefaultStateMachine<CivilianAgentComponent, State<CivilianAgentComponent>>(this,CivilianState.IDLE);

    }

    @Override
    public boolean handleMessage(Telegram msg) {
        return false;
    }
}
