package com.katafrakt.zombieoff.ashley.systems.graphics;

import com.badlogic.ashley.core.Entity;
import com.badlogic.ashley.core.Family;
import com.badlogic.ashley.systems.IteratingSystem;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ashley.components.BoundComponent;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.FloatingTextComponent;
import com.katafrakt.zombieoff.managers.AssetOrganizer;
import com.katafrakt.zombieoff.utilities.FloatingText;

public class FloatingTextSystem extends IteratingSystem {
    private static final String TAG=FloatingTextComponent.class.getSimpleName();

    SpriteBatch spriteBatch;
    FreeTypeFontGenerator freeTypeFontGenerator= AssetOrganizer.getInstance().get("skin/vcr_font_generator.ttf",FreeTypeFontGenerator.class);
    FreeTypeFontGenerator.FreeTypeFontParameter freeTypeFontParameter=new FreeTypeFontGenerator.FreeTypeFontParameter();

    BitmapFont bitmapFont;

    Array<FloatingText> array=new Array<>();

    public FloatingTextSystem(SpriteBatch spriteBatch, BitmapFont bitmapFont) {
        super(Family.all(FloatingTextComponent.class, TransformComponent.class).get());
        this.spriteBatch=spriteBatch;
        freeTypeFontParameter.size=16;

        this.bitmapFont=freeTypeFontGenerator.generateFont(freeTypeFontParameter);
        this.bitmapFont.getData().setScale(0.4f);
        this.bitmapFont.setUseIntegerPositions(false);

    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);

        spriteBatch.begin();
        for (FloatingText floatingText:array){
            if (floatingText.remainTime<0.4f)
                bitmapFont.setColor(1,1,1,(0.3f+floatingText.remainTime)/0.7f);
            else
                bitmapFont.setColor(1,1,1,1);

            bitmapFont.draw(spriteBatch,floatingText.text,(int)floatingText.pos.x,(int)floatingText.pos.y+10-floatingText.remainTime*10,0, Align.center,false);
        }
        spriteBatch.end();
        array.clear();
    }

    @Override
    protected void processEntity(Entity entity, float deltaTime) {
        FloatingTextComponent floatingTextComponent= Mappers.floatingTextComponents.get(entity);
        if (!floatingTextComponent.floatingTextList
                .isEmpty()){
            for (FloatingText floatingText:floatingTextComponent.floatingTextList){
                if (floatingText.pos ==null){
                    TransformComponent transformComponent=Mappers.transformComponents.get(entity);
                    BoundComponent boundComponent = Mappers.boundComponents.get(entity);
                    floatingText.pos =new Vector2(transformComponent.pos.x,transformComponent.pos.y-floatingTextComponent.floatingTextList.indexOf(floatingText,false)*4+boundComponent.height);

                }
                floatingText.remainTime -=deltaTime;
                if (floatingText.remainTime<0){
                    floatingTextComponent.floatingTextList.removeValue(floatingText,false);
                    FloatingTextComponent.pool.free(floatingText);
                }
                else {
                    array.add(floatingText);
                }

            }

        }

    }
}
