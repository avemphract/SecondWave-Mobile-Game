package com.katafrakt.zombieoff.ashley.systems.agents;

import com.badlogic.ashley.core.Entity;
import com.badlogic.ashley.core.Family;
import com.badlogic.ashley.systems.IteratingSystem;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.utils.async.AsyncExecutor;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.agentsV2.CivilianAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.agentsV2.MercenaryAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.agentsV2.PoliceAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.agentsV2.RangedZombieAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.agentsV2.VeteranAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.agentsV2.ZombieAgentComponentV2;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;

public class AgentV2System extends IteratingSystem {
    private static final String TAG=AgentV2System.class.getSimpleName();
    public static float totalTime=0;
    public AgentV2System() {
        super(Family.one(CivilianAgentComponentV2.class, PoliceAgentComponentV2.class, VeteranAgentComponentV2.class, MercenaryAgentComponentV2.class,
                ZombieAgentComponentV2.class, RangedZombieAgentComponentV2.class).get());
    }
    public AsyncExecutor executor;

    int i=0;
    @Override
    public void update(float deltaTime) {
        deltaTime= MathUtils.clamp(deltaTime,0.001f,0.5f);
        totalTime +=deltaTime;
        //executor=new AsyncExecutor(999);
        super.update(deltaTime);
        //executor.dispose();
    }

    @Override
    protected void processEntity(Entity entity, float deltaTime) {
        AgentComponentV2 agentComponentV2=Mappers.agentComponentV2(entity);
        agentComponentV2.updateAbilities(AbilityController.Type.UPDATE);
        if(agentComponentV2.nextTick<totalTime&&agentComponentV2.creature.isAlive){

            //MapManager.getInstance().pointGraph.renderLoad();
            agentComponentV2.stateMachine.update();
            //if (entity== EntityUI.getEntity())
            //Gdx.app.log(TAG,MathUtils.log2((int) (endTime-startTime))+" "+agentComponentV2.creature.entityType.name+" "+agentComponentV2.currentState.name()+" required time");
        }
    }
}
