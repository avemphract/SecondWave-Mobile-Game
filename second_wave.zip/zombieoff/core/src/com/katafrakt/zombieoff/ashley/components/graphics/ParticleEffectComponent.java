package com.katafrakt.zombieoff.ashley.components.graphics;

import com.badlogic.ashley.core.Component;
import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.graphics.g2d.ParticleEffectPool;
import com.badlogic.gdx.utils.ObjectMap;
import com.badlogic.gdx.utils.OrderedMap;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ashley.components.Init;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.entities.ParticleType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.StatusTypes;

public class ParticleEffectComponent implements Component, Init {
    private static final String TAG=ParticleEffectComponent.class.getSimpleName();

    public OrderedMap<StatusTypes, OrderedMap.Entry<ParticleEffectPool.PooledEffect,Float>> statusEffects = new OrderedMap<StatusTypes, ObjectMap.Entry<ParticleEffectPool.PooledEffect, Float>>();
    public Entity entity;
    TransformComponent transformComponent;
    public OrderedMap<ParticleEffectPool.PooledEffect,Float> effects = new OrderedMap<ParticleEffectPool.PooledEffect, Float>();

    public ParticleEffectComponent(){}
    public ParticleEffectComponent(Entity entity){
        this.entity=entity;
    }

    @Override
    public void addedEngine() {
        transformComponent=entity.getComponent(TransformComponent.class);
    }

    public void init(Entity entity){
        effects.clear();
        this.entity=entity;
        transformComponent=entity.getComponent(TransformComponent.class);

    }

    public void addBlood(int ratio){
        //Gdx.app.log(TAG,string);
        ParticleEffectPool.PooledEffect bloodParticle = ParticleType.BLOOD.getParticle();
        effects.put(bloodParticle, 1.5f);
        //Gdx.app.log(TAG,"Entity: "+entity.getComponent(CreatureComponent.class).entityType.name());
        bloodParticle.getEmitters().get(0).getSpawnWidth().setHigh(Mappers.boundComponents.get(entity).width);
        bloodParticle.getEmitters().get(0).getSpawnHeight().setHigh(Mappers.boundComponents.get(entity).height/2);
        bloodParticle.getEmitters().get(0).setPosition(transformComponent.pos.x,transformComponent.pos.y+Mappers.boundComponents.get(entity).height/4);
        bloodParticle.getEmitters().get(0).start();
        bloodParticle.getEmitters().get(0).addParticles(ratio);
    }
    public void addExplosion(int radius){
        ParticleEffectPool.PooledEffect explosionParticle = ParticleType.EXPLOSION.getParticle();
        effects.put(explosionParticle,10f);
        explosionParticle.getEmitters().get(0).getVelocity().setHigh(0,(radius)*Point.UNIT);
        explosionParticle.getEmitters().get(0).getVelocity().setLow(0,0);
        explosionParticle.getEmitters().get(0).getXScale().setHigh(radius+1,radius+1);
        explosionParticle.getEmitters().get(0).getXScale().setLow(1,1);
        explosionParticle.getEmitters().get(0).setPosition(transformComponent.pos.x,transformComponent.pos.y);
        explosionParticle.getEmitters().get(0).start();
        explosionParticle.getEmitters().get(0).addParticles((radius)*radius*10);
    }

    public ParticleEffectPool.PooledEffect addStatus(StatusTypes statusTypes){
        if (statusEffects.get(statusTypes)==null){
            ObjectMap.Entry<ParticleEffectPool.PooledEffect,Float> pair=new ObjectMap.Entry<>();
            pair.key=statusTypes.getParticleEffect();
            pair.key.getEmitters().get(0).getSpawnWidth().setHigh(Mappers.boundComponents.get(entity).width);
            pair.key.getEmitters().get(0).getSpawnHeight().setHigh(Mappers.boundComponents.get(entity).height);
            pair.key.start();
            pair.value=1f;
            statusEffects.put(statusTypes,pair);
        }
        else {
            statusEffects.get(statusTypes).value=1f;
        }
        return statusEffects.get(statusTypes).key;
    }

}
