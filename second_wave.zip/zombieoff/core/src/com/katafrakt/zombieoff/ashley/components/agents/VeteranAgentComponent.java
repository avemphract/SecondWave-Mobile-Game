package com.katafrakt.zombieoff.ashley.components.agents;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.ai.fsm.DefaultStateMachine;
import com.badlogic.gdx.ai.fsm.State;
import com.badlogic.gdx.ai.msg.Telegram;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ai.states.VeteranState;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit.AttackToTimeLimit;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.BurnEffect;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponInformation;
import com.katafrakt.zombieoff.game.weapons.RangedWeapon;

public class VeteranAgentComponent extends HumanAgentComponent<RangedWeapon> {

    public boolean targetPosActive;

    public VeteranAgentComponent(Entity entity, Array<WeaponInformation> weaponCreators, Array<AbilityCreator> abilityUnlocks, int awareRadius) {
        super(entity,weaponCreators,abilityUnlocks,awareRadius);

        abilities.get(AbilityController.Type.ATTACK).add(AttackToTimeLimit.pool.obtain().init(BurnEffect.pool.obtain().init(0.01f),8f));
        //weapons.add(new SprayWeapon(Weapon.Recommended.LOW,new ShrapnelHitBehaviour(5,3),40f,1,8,-1210,50,1));
        //weapons.add(new StandardRangedWeapon(Weapon.Recommended.MEDIUM,new SingleTargetHitBehaviour(),1f,2,17,80,400));

    }

    @Override
    public void addedEngine() {
        super.addedEngine();
        VeteranState.IDLE.enter(this);
        stateMachine= new DefaultStateMachine<VeteranAgentComponent, State<VeteranAgentComponent>>(this, VeteranState.IDLE);

    }

    @Override
    public boolean handleMessage(Telegram msg) {
        return super.handleMessage(msg);
    }
}
