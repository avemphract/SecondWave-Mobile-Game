package com.katafrakt.zombieoff.ashley.components;

import com.badlogic.ashley.core.ComponentMapper;
import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.Gdx;
import com.katafrakt.zombieoff.ashley.components.agents.AgentComponent;
import com.katafrakt.zombieoff.ashley.components.agents.CivilianAgentComponent;
import com.katafrakt.zombieoff.ashley.components.agents.MercenaryAgentComponent;
import com.katafrakt.zombieoff.ashley.components.agents.PoliceAgentComponent;
import com.katafrakt.zombieoff.ashley.components.agents.VeteranAgentComponent;
import com.katafrakt.zombieoff.ashley.components.agents.ZombieAgentComponent;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.agentsV2.CivilianAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.agentsV2.MercenaryAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.agentsV2.PoliceAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.agentsV2.RangedZombieAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.agentsV2.VeteranAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.agentsV2.ZombieAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.creatures.BulletComponent;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.AnimationComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.DebugGraphicsComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.FloatingTextComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.GraphicsComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.HandGraphicComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.ParticleEffectComponent;
import com.katafrakt.zombieoff.game.weapons.Weapon;

import org.jetbrains.annotations.NotNull;


public class Mappers {
    private static final String TAG=Mappers.class.getSimpleName();
    //Graphics
    public static ComponentMapper<DebugGraphicsComponent> debugGraphicsComponents=ComponentMapper.getFor(DebugGraphicsComponent.class);
    public static ComponentMapper<GraphicsComponent> graphicsComponents=ComponentMapper.getFor(GraphicsComponent.class);
    public static ComponentMapper<HandGraphicComponent> handGraphicComponents=ComponentMapper.getFor(HandGraphicComponent.class);
    public static ComponentMapper<AnimationComponent> animationComponents=ComponentMapper.getFor(AnimationComponent.class);
    public static ComponentMapper<ParticleEffectComponent> particleComponents=ComponentMapper.getFor(ParticleEffectComponent.class);
    public static ComponentMapper<FloatingTextComponent> floatingTextComponents=ComponentMapper.getFor(FloatingTextComponent.class);

    public static ComponentMapper<TransformComponent> transformComponents=ComponentMapper.getFor(TransformComponent.class);
    public static ComponentMapper<BoundComponent> boundComponents=ComponentMapper.getFor(BoundComponent.class);
    public static ComponentMapper<BulletComponent> bulletComponents=ComponentMapper.getFor(BulletComponent.class);
    public static ComponentMapper<CreatureComponent> creatureComponents=ComponentMapper.getFor(CreatureComponent.class);

    public static ComponentMapper<CivilianAgentComponent> civilianAgentComponents=ComponentMapper.getFor(CivilianAgentComponent.class);
    public static ComponentMapper<PoliceAgentComponent> policeAgentComponents=ComponentMapper.getFor(PoliceAgentComponent.class);
    public static ComponentMapper<MercenaryAgentComponent> mercenaryAgentComponents=ComponentMapper.getFor(MercenaryAgentComponent.class);
    public static ComponentMapper<VeteranAgentComponent> veteranAgentComponents=ComponentMapper.getFor(VeteranAgentComponent.class);

    public static ComponentMapper<CivilianAgentComponentV2> civilianAgentComponentV2s=ComponentMapper.getFor(CivilianAgentComponentV2.class);
    public static ComponentMapper<PoliceAgentComponentV2> policeAgentComponentV2=ComponentMapper.getFor(PoliceAgentComponentV2.class);
    public static ComponentMapper<MercenaryAgentComponentV2> mercenaryAgentComponentV2=ComponentMapper.getFor(MercenaryAgentComponentV2.class);
    public static ComponentMapper<VeteranAgentComponentV2> veteranAgentComponentV2=ComponentMapper.getFor(VeteranAgentComponentV2.class);

    public static ComponentMapper<ZombieAgentComponentV2> zombieAgentComponentV2s=ComponentMapper.getFor(ZombieAgentComponentV2.class);
    public static ComponentMapper<RangedZombieAgentComponentV2> rangedZombieAgentComponentV2s=ComponentMapper.getFor(RangedZombieAgentComponentV2.class);
    public static ComponentMapper<VelocityComponent> velocityComponents=ComponentMapper.getFor(VelocityComponent.class);

    public static ComponentMapper<ZombieAgentComponent> zombieAgentComponents=ComponentMapper.getFor(ZombieAgentComponent.class);
    //public static ComponentMapper<ZombieRangedAgentComponent> zombieRangedAgentComponents=ComponentMapper.getFor(ZombieRangedAgentComponent.class);

    @NotNull
    public static  AgentComponent<? extends Weapon> agentComponents(Entity entity){
        if (civilianAgentComponents.has(entity))
            return civilianAgentComponents.get(entity);
        else if (policeAgentComponents.has(entity))
            return policeAgentComponents.get(entity);
        else if (mercenaryAgentComponents.has(entity))
            return mercenaryAgentComponents.get(entity);
        else if (veteranAgentComponents.has(entity))
            return veteranAgentComponents.get(entity);

        else if (zombieAgentComponents.has(entity))
            return zombieAgentComponents.get(entity);
        Gdx.app.log(TAG,"Entity hasnt agent");
        return null;
    }


    public static AgentComponentV2<? extends Weapon> agentComponentV2(Entity entity){
        if (civilianAgentComponentV2s.has(entity))
            return civilianAgentComponentV2s.get(entity);
        else if (policeAgentComponentV2.has(entity))
            return policeAgentComponentV2.get(entity);
        else if (veteranAgentComponentV2.has(entity))
            return veteranAgentComponentV2.get(entity);
        else if (mercenaryAgentComponentV2.has(entity))
            return mercenaryAgentComponentV2.get(entity);

        else if (zombieAgentComponentV2s.has(entity))
            return zombieAgentComponentV2s.get(entity);
        else if (rangedZombieAgentComponentV2s.has(entity))
            return rangedZombieAgentComponentV2s.get(entity);
        Gdx.app.log(TAG,"Entity hasnt agent2"+entity.toString());
        return null;
    }
}
