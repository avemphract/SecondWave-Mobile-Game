package com.katafrakt.zombieoff.ashley.components;

import com.badlogic.ashley.core.Component;

public class BoundComponent implements Component {
    public float width;
    public float height;
    public BoundComponent(){}
    public BoundComponent(float width,float height){
        this.width=width;
        this.height=height;
    }
    public void init(float width,float height){
        this.width=width;
        this.height=height;
    }
}
