package com.katafrakt.zombieoff.ashley.components.agents;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ai.fsm.DefaultStateMachine;
import com.badlogic.gdx.ai.fsm.State;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ArrayMap;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ai.states.MercenaryState;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponInformation;
import com.katafrakt.zombieoff.game.weapons.RangedWeapon;
import com.katafrakt.zombieoff.game.weapons.Weapon;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.utilities.RangeGenerator;

import java.util.Iterator;

public class MercenaryAgentComponent extends HumanAgentComponent<RangedWeapon> {
    private static final String TAG = MercenaryAgentComponent.class.getSimpleName();
    public HashMapReform primaryMap;
    public HashMapReform secondaryMap;

    public Vector2 direction=new Vector2();
    public Point initialPoint;

    public boolean idleMoveIsActive;
    public float lastWeaponAttackRate;

    public Weapon secondaryWeapon;


    public MercenaryAgentComponent(Entity entity, Array<WeaponInformation> weaponCreators, Array<AbilityCreator> abilityUnlocks, int awareRadius) {
        super(entity,weaponCreators,abilityUnlocks,awareRadius);
        secondaryWeapon=weaponCreators.get(1).getWeapon();

        primaryMap=new HashMapReform(primaryWeapon);
        secondaryMap=new HashMapReform(secondaryWeapon);

        Gdx.app.log(TAG,"PrimaryWeapon: "+weaponCreators.get(0).getClass().getSimpleName());
        Gdx.app.log(TAG,"SecondaryWeapon: "+weaponCreators.get(1).getClass().getSimpleName());
    }

    @Override
    public void addedEngine() {
        super.addedEngine();
        MercenaryState.IDLE.enter(this);
        initialPoint= MapManager.getInstance().pointGraph.nearestPoint(Mappers.transformComponents.get(entity).pos);
        stateMachine= new DefaultStateMachine<MercenaryAgentComponent, State<MercenaryAgentComponent>>(this, MercenaryState.IDLE);
        primaryMap.setPoints(currentPoint);
        secondaryMap.setPoints(currentPoint);
    }

    public class HashMapReform extends ArrayMap<Integer,Array<Point>> {
        Weapon weapon;
        public HashMapReform(Weapon weapon){
            super();
            this.weapon=weapon;
            for (int i=0;i<=Math.max(weapon.range,weapon.recommended.max);i++)
                this.put(i,new Array<Point>());
        }

        public void setPoints(Point position){
            for (int i=0;i<=weapon.range;i++){
                for (Integer[] integers:RangeGenerator.getInstance().circleLine.get(i)){
                    Point point=MapManager.getInstance().pointGraph.pointTable.get(position.tableX+integers[0],position.tableY+integers[1]);
                    if (point==null)
                        continue;
                    if (weapon instanceof RangedWeapon){
                        switch (((RangedWeapon)weapon).bulletType){
                            case AIRBORNE:
                                if (point.roofed)
                                    continue;
                                break;
                            case LINE:
                                if (MapManager.getInstance().pointGraph.anyObstacle(position,point))
                                    continue;
                                break;
                            case UNDERGROUND:
                                break;
                        }
                    }
                    //Gdx.app.log(TAG,"Points: "+point.x+","+point.y);
                    get(i).add(point);
                }
            }
        }

        public Entity getFirstly(){
            for (int i=weapon.recommended.min;i<Math.min(weapon.range,weapon.recommended.max);i++){
                for (Point point:get(i)){
                    //Gdx.app.log(TAG,"Point: "+point.x+","+point.y);
                    if (point.zombies.size>0){
                        return point.zombies.random();
                    }
                }
            }
            return null;
        }
        public Entity getSecondly(){
            for (int i=0;i<weapon.recommended.min;i++){
                for (Point point:get(i)){
                    if (point.zombies.size>0){
                        return point.zombies.random();
                    }
                }
            }
            if (weapon.range>weapon.recommended.max)
                for (int i=Math.min(weapon.range,weapon.recommended.max);i<=weapon.range;i++){
                    for (Point point:get(i)){
                        if (point.zombies.size>0){
                            return point.zombies.random();
                        }
                    }
                }

            return null;
        }

        public void clear(){
            for (Array<Point> array:values()){
                array.clear();
            }
        }


        @Override
        public boolean isEmpty() {
            Iterator<Array<Point>> iterator = this.values().iterator();
            //Gdx.app.log(TAG,"Size"+this.size);
            while (iterator.hasNext()){
                for (Point point:iterator.next()){

                    if (point.zombies.size>0)
                        return false;
                }
            }
            return true;
        }

    }
}
