package com.katafrakt.zombieoff.ashley.components.agentsV2;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponInformation;
import com.katafrakt.zombieoff.game.weapons.Weapon;

public abstract class HumanAgentComponentV2<E extends Weapon> extends AgentComponentV2<E> {
    public float awareness;

    public HumanAgentComponentV2(Entity entity, Array<WeaponCreator> weaponCreators, Array<AbilityCreator> abilityCreators, int awareRadius) {
        super(entity,weaponCreators,abilityCreators, awareRadius);
    }

    @Override
    public void addedEngine() {
        super.addedEngine();
        currentPoint.humans.add(entity);
    }
}
