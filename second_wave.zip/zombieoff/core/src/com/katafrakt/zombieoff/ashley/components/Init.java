package com.katafrakt.zombieoff.ashley.components;

public interface Init {
    public void addedEngine();
}
