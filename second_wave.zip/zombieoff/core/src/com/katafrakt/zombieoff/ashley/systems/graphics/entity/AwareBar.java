package com.katafrakt.zombieoff.ashley.systems.graphics.entity;

import com.badlogic.ashley.core.Entity;
import com.badlogic.ashley.core.Family;
import com.badlogic.ashley.systems.IteratingSystem;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.katafrakt.zombieoff.ashley.components.BoundComponent;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;

import java.util.ArrayList;

public class AwareBar extends IteratingSystem {
    private static final String TAG=AwareBar.class.getSimpleName();
    ShapeRenderer shapeRenderer;
    ArrayList<Entity> entities;
    public AwareBar(ShapeRenderer shapeRenderer) {
        super(Family.all(CreatureComponent.class).get());
        this.shapeRenderer=shapeRenderer;
        entities=new ArrayList<>();
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        for (Entity entity:entities){
            BoundComponent bc = Mappers.boundComponents.get(entity);
            TransformComponent tc= Mappers.transformComponents.get(entity);
            CreatureComponent cc=Mappers.creatureComponents.get(entity);

            shapeRenderer.setColor(Color.DARK_GRAY);
            shapeRenderer.rect(tc.pos.x-bc.width/2,tc.pos.y+bc.height/2+2,bc.width,1);

            shapeRenderer.setColor(Color.GREEN);
            shapeRenderer.rect(tc.pos.x-bc.width/2,tc.pos.y+bc.height/2+2,bc.width*cc.currentHp/cc.maxHp,1);

        }
        shapeRenderer.end();
        entities.clear();
    }

    @Override
    protected void processEntity(Entity entity, float deltaTime) {
        entities.add(entity);
    }
}
