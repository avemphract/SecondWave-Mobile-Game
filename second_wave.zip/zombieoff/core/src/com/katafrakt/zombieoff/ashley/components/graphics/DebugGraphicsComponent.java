package com.katafrakt.zombieoff.ashley.components.graphics;

import com.badlogic.ashley.core.Component;
import com.badlogic.gdx.graphics.Color;

public class DebugGraphicsComponent implements Component {
    public boolean isActive;
    public Color colorOut;
    public Color colorIn;

    public DebugGraphicsComponent(){
        isActive=true;
        colorOut =new Color(0,1,0,1);
        colorIn = new Color(0,1,0,1);
    }
}
