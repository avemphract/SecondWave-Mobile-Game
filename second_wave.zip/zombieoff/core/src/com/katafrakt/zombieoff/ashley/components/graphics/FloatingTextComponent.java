package com.katafrakt.zombieoff.ashley.components.graphics;

import com.badlogic.ashley.core.Component;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.utilities.FloatingText;

public class FloatingTextComponent implements Component {
    public enum Type{
        HEALTH(" health");

        Type(String string) {
            this.string = string;
        }
        public final String string;
    }
    public static Pool<FloatingText> pool=new Pool<FloatingText>() {
        @Override
        protected FloatingText newObject() {
            return new FloatingText();
        }
    };
    public FloatingTextList floatingTextList= new FloatingTextList();
    public FloatingTextComponent(){

    }
    public void addText(Type type, float value){
        switch (type){
            case HEALTH:
                FloatingText temp=floatingTextList.isContainType(Type.HEALTH);
                if (temp==null){
                    floatingTextList.add(pool.obtain().init(type,value,1f,null));
                }
                else {
                    temp.value +=value;
                    temp.setText();
                }
                break;
        }
    }
    public void addText(String string, float value){
        floatingTextList.add(pool.obtain().init(string,value,null));
    }



    public static class FloatingTextList extends Array<FloatingText>{
        public FloatingText isContainType(Type type){
            for (FloatingText floatingText :this) {
                if (floatingText.type ==type)
                    return floatingText;
            }
            return null;
        }
    }
}