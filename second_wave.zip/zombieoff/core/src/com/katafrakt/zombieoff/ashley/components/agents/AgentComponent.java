package com.katafrakt.zombieoff.ashley.components.agents;

import com.badlogic.ashley.core.Component;
import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.ai.fsm.StateMachine;
import com.badlogic.gdx.ai.msg.Telegraph;
import com.badlogic.gdx.ai.pfa.GraphPath;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ArrayMap;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ashley.components.Init;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.game.AnimationName;
import com.katafrakt.zombieoff.game.StateType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit.Stack;
import com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit.TimeLimit;
import com.katafrakt.zombieoff.game.abilitiybehaviours.effects.AbilityEffect;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponInformation;
import com.katafrakt.zombieoff.game.weapons.Weapon;
import com.katafrakt.zombieoff.managers.GeneralOrganizer;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.utilities.SortingArray;

import java.util.Iterator;

public abstract class AgentComponent<E extends Weapon> implements Telegraph,Component,Init {
    private static final String TAG= AgentComponent.class.getSimpleName();
    public static int findTargetTime=2;
    public E primaryWeapon;
    public AnimationName animationName=AnimationName.WAIT_DOWN;
    public ArrayMap<AbilityController.Type,Array<AbilityController<?>>> abilities=new ArrayMap<AbilityController.Type,Array<AbilityController<?>>>();
    {
        abilities.put(AbilityController.Type.UPDATE,new Array<AbilityController<?>>());
        abilities.put(AbilityController.Type.STATE,new Array<AbilityController<?>>());
        abilities.put(AbilityController.Type.ATTACK,new Array<AbilityController<?>>());
        abilities.put(AbilityController.Type.GET_ATTACKED,new Array<AbilityController<?>>());
        abilities.put(AbilityController.Type.DIED,new Array<AbilityController<?>>());
    }

    public ArrayMap<Class<? extends AbilityEffect>, SortingArray<TimeLimit>> timedEffects= new ArrayMap<Class<? extends AbilityEffect>, SortingArray<TimeLimit>>(){
        @Override
        public SortingArray<TimeLimit> get(Class<? extends AbilityEffect> key) {
            if (super.get(key)==null)
                put(key,new SortingArray<TimeLimit>());
            return super.get(key);
        }
    };
    public ArrayMap<AbilityCreator,Array<Stack>> stacks=new ArrayMap<AbilityCreator, Array<Stack>>(){
        @Override
        public Array<Stack> get(AbilityCreator key) {
            if (super.get(key)==null)
                put(key,new Array<Stack>());
            return super.get(key);
        }
    };


    public StateMachine stateMachine;
    public StateType currentState=StateType.IDLE;

    public float x,y;

    public float count=1;
    public float currentTime= GeneralOrganizer.getInstance().random.nextFloat()*findTargetTime;
    public float nextAttackTime;

    //Follow Target
    public GraphPath<Point> path;
    public Point currentPoint;
    public Point nextPoint;
    public Point targetPoint;
    public Iterator<Point> iterator;

    //public Vector2 nextPosition=new Vector2();
    public Vector2 targetPosition =new Vector2();
    public Vector2 direction=new Vector2();

    public float startTime;
    public float progressTime;


    public int awareRadius;

    //own
    public Entity entity;
    public TransformComponent transform;
    public CreatureComponent creature;

    //target
    public Entity target;
    public TransformComponent targetTransform;
    public CreatureComponent targetCreature;
    public AgentComponent<? extends Weapon> targetAgent;

    public boolean debugPath;
    public boolean newPoint;

    public AgentComponent(Entity entity, Array<WeaponInformation> weaponCreators, Array<AbilityCreator> abilityUnlocks, int awareRadius){
        this.entity=entity;
        /*for (WeaponCreator weaponCreator:weaponCreators){
            weapons.add(weaponCreator.getWeapon());
        }*/
        if (!weaponCreators.isEmpty())
            primaryWeapon= (E) weaponCreators.get(0).getWeapon();

        for (AbilityCreator abilityUnlock:abilityUnlocks){
            addAbility(abilityUnlock.getAbility());
        }
        this.awareRadius=awareRadius;

    }

    @Override
    public void addedEngine() {
        transform=Mappers.transformComponents.get(entity);
        creature=Mappers.creatureComponents.get(entity);
        currentPoint= MapManager.getInstance().pointGraph.nearestPoint(Mappers.transformComponents.get(entity).pos);
    }

    public void addAbility(AbilityController<?> abilityController){
        for (AbilityController.Type type :abilityController.types)
            abilities.get(type).add(abilityController);
        if (abilityController instanceof TimeLimit)
            timedEffects.get(abilityController.abilityEffect.getClass()).add((TimeLimit) abilityController);
        if (abilityController instanceof Stack)
            stacks.get(((Stack)abilityController).abilityCreator).add((Stack) abilityController);

    }
    public void removeAbility(AbilityController<?> abilityController){
        for (AbilityController.Type type :abilityController.types)
            abilities.get(type).removeValue(abilityController,false);
        if (abilityController instanceof TimeLimit)
            timedEffects.get(abilityController.abilityEffect.getClass()).removeValue((TimeLimit) abilityController,false);
        if (abilityController instanceof Stack)
            stacks.get(((Stack)abilityController).abilityCreator).removeValue((Stack) abilityController,false);
    }

    public void updateAbilities(AbilityController.Type type){
        /*if (type== AbilityController.Type.UPDATE)
            for (AbilityController<?> ability:abilities.get(type)) {
                //Gdx.app.log(TAG,"AbilityUpdate: "+ability.getClass().getSimpleName());
                ability.update(this, type);
            }
        else if (type == AbilityController.Type.STATE){
            for (AbilityController<?> ability:abilities.get(type)){
                ability.update(this,type);
            }
        }
        else if (type == AbilityController.Type.ATTACK){
            for (AbilityController<?> ability:abilities.get(type)){
                ability.update(this,type);
            }
        }
        else if (type == AbilityController.Type.GET_ATTACKED){
            for (AbilityController<?> ability:abilities.get(type)){
                ability.update(this,type);
            }
        }
        else if (type == AbilityController.Type.DIED){
            for (AbilityController<?> ability:abilities.get(type)){
                ability.update(this,type);
            }
        }*/
    }
}
