package com.katafrakt.zombieoff.ashley.systems.graphics.entity;

import com.badlogic.ashley.core.ComponentMapper;
import com.badlogic.ashley.core.Entity;
import com.badlogic.ashley.core.Family;
import com.badlogic.ashley.systems.IteratingSystem;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.agentsV2.CivilianAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.agentsV2.MercenaryAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.agentsV2.PoliceAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.agentsV2.RangedZombieAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.agentsV2.VeteranAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.agentsV2.ZombieAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.graphics.GraphicsComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.HandGraphicComponent;
import com.katafrakt.zombieoff.ashley.systems.agents.AgentV2System;
import com.katafrakt.zombieoff.game.AnimationName;
import com.katafrakt.zombieoff.game.StateType;
import com.katafrakt.zombieoff.ui.CameraComposite;

import java.util.Comparator;

public class AgentRendererSystem extends IteratingSystem {
    private static final String TAG = AgentRendererSystem.class.getSimpleName();

    private Array<Entity> renderQueue;
    private Comparator<Entity> comparator;
    private SpriteBatch spriteBatch;
    private CameraComposite cameraComposite;
    private Vector2 vector2=new Vector2();


    public AgentRendererSystem(SpriteBatch spriteBatch, CameraComposite cameraComposite) {
        super(Family.all(GraphicsComponent.class)
                .one(CivilianAgentComponentV2.class, PoliceAgentComponentV2.class, VeteranAgentComponentV2.class, MercenaryAgentComponentV2.class, ZombieAgentComponentV2.class, RangedZombieAgentComponentV2.class).get());
        this.spriteBatch=spriteBatch;
        this.cameraComposite=cameraComposite;

        renderQueue =new Array<>();
        comparator=new Comparator<Entity>() {
            @Override
            public int compare(Entity t1, Entity t2) {
                if (Mappers.transformComponents.get(t1).pos.y> Mappers.transformComponents.get(t2).pos.y){
                    return -1;
                }
                else if (Mappers.transformComponents.get(t1).pos.y< Mappers.transformComponents.get(t2).pos.y){
                    return 1;
                }
                else
                    return 0;
            }
        };
    }

    float dx;
    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        //renderQuene.sort();
        dx+=Gdx.graphics.getDeltaTime();

        cameraComposite.getCamera().update();
        spriteBatch.begin();
        spriteBatch.setProjectionMatrix(cameraComposite.getCamera().combined);

        renderQueue.sort(comparator);

        for (Entity entity: renderQueue){
            GraphicsComponent gc = Mappers.graphicsComponents.get(entity);
            TransformComponent tc = Mappers.transformComponents.get(entity);
            AgentComponentV2 ac=Mappers.agentComponentV2(entity);
            vector2.setZero();
            if (gc.textureRegion==null){
                Gdx.app.log(TAG,ac.creature.entityType.name+"hasn't graphic");
                continue;
            }
            //Yukarıya dönük olduğunda Silah arkada kalır.
            if (!ac.animationName.isGunFront){
                if (gc.width==0||gc.height==0){
                    gc.width=gc.textureRegion.getRegionWidth();
                    gc.height=gc.textureRegion.getRegionHeight();
                }

                float originX=gc.width/2,originY=gc.height/2;

                //Silah animasyonu
                if (ac!=null&&ac.primaryWeapon.weaponGraphics!=null){


                    float angle;
                    int dir;


                    if (ac.currentState == StateType.ATTACK){
                        angle=(float) Math.atan((ac.targetTransform.pos.y+ac.primaryWeapon.weaponGraphics.position.x-8-tc.pos.y)/(ac.targetTransform.pos.x+ac.primaryWeapon.weaponGraphics.position.x-8-tc.pos.x));
                        if (0<ac.targetTransform.pos.x-tc.pos.x)
                            dir=1;
                        else
                            dir=-1;
                    }
                    else {
                        if (ac.direction== AnimationName.Direction.LEFT||ac.direction== AnimationName.Direction.DOWN){
                            angle=45;
                            dir=-1;
                        }
                        else{
                            angle=-45;
                            dir=1;
                        }
                    }
                    //ac.primaryWeapon.weaponGraphics.attackAnimation.weaponPosition(ac,vector2);

                    float second= AgentV2System.totalTime - ac.lastAttackTime;
                    float anim_x,anim_y;
                    if (0<second&&second<0.05f){
                        anim_x=-second*20*MathUtils.cos(angle)*dir;
                        anim_y=-second*20*MathUtils.sin(angle)*dir;
                    }
                    else if (0.05f<second&&second<0.15f){
                        anim_x=-(1.5f-second*10)*MathUtils.cos(angle)*dir;
                        anim_y=-(1.5f-second*10)*MathUtils.sin(angle)*dir;
                    }
                    else {
                        anim_x=0;
                        anim_y=0;
                    }

                    spriteBatch.draw(ac.primaryWeapon.weaponGraphics.weaponTexture,tc.pos.x-ac.primaryWeapon.weaponGraphics.position.x+anim_x,tc.pos.y-ac.primaryWeapon.weaponGraphics.position.y+anim_y,
                            ac.primaryWeapon.weaponGraphics.origin.x,ac.primaryWeapon.weaponGraphics.origin.y,
                            16,16,
                            dir,1,
                            MathUtils.radiansToDegrees*angle
                    );
                    HandGraphicComponent hc= ComponentMapper.getFor(HandGraphicComponent.class).get(entity);
                    if (hc!=null){
                        spriteBatch.draw(hc.handTexture,tc.pos.x-ac.primaryWeapon.weaponGraphics.position.x+ac.primaryWeapon.weaponGraphics.firstHand.x+anim_x,tc.pos.y-ac.primaryWeapon.weaponGraphics.position.y+ac.primaryWeapon.weaponGraphics.firstHand.y+anim_y,
                                -ac.primaryWeapon.weaponGraphics.firstHand.x + ac.primaryWeapon.weaponGraphics.origin.x,-ac.primaryWeapon.weaponGraphics.firstHand.y + ac.primaryWeapon.weaponGraphics.origin.y,
                                2,2,
                                dir,1,
                                MathUtils.radiansToDegrees*angle
                        );

                        spriteBatch.draw(hc.handTexture,tc.pos.x-ac.primaryWeapon.weaponGraphics.position.x+ac.primaryWeapon.weaponGraphics.secondHand.x+anim_x,tc.pos.y-ac.primaryWeapon.weaponGraphics.position.y+ac.primaryWeapon.weaponGraphics.secondHand.y+anim_y,
                                -ac.primaryWeapon.weaponGraphics.secondHand.x + ac.primaryWeapon.weaponGraphics.origin.x,-ac.primaryWeapon.weaponGraphics.secondHand.y + ac.primaryWeapon.weaponGraphics.origin.y,
                                2,2,
                                dir,1,
                                MathUtils.radiansToDegrees*angle
                        );
                    }
                }

                spriteBatch.draw(gc.textureRegion,tc.pos.x-originX+gc.x_offset,tc.pos.y-originY+gc.y_offset,
                        originX,originY,
                        gc.width,gc.height,
                        tc.scale,tc.scale,
                        tc.rotation);

            }
            //Diğer durumlarda silah önde kalır
            else {
                if (gc.width==0||gc.height==0){
                    gc.width=gc.textureRegion.getRegionWidth();
                    gc.height=gc.textureRegion.getRegionHeight();
                }

                float originX=gc.width/2,originY=gc.height/2;

                spriteBatch.draw(gc.textureRegion,tc.pos.x-originX+gc.x_offset,tc.pos.y-originY+gc.y_offset,
                        originX,originY,
                        gc.width,gc.height,
                        tc.scale,tc.scale,
                        tc.rotation);

                //Silah animasyonu
                if (ac!=null&&ac.primaryWeapon.weaponGraphics!=null){


                    float angle;
                    int dir;


                    if (ac.currentState == StateType.ATTACK){
                        angle=(float) Math.atan((ac.targetTransform.pos.y+ac.primaryWeapon.weaponGraphics.position.x-8-tc.pos.y)/(ac.targetTransform.pos.x+ac.primaryWeapon.weaponGraphics.position.x-8-tc.pos.x));
                        if (0<ac.targetTransform.pos.x-tc.pos.x)
                            dir=1;
                        else
                            dir=-1;
                    }
                    else {
                        if (ac.direction== AnimationName.Direction.LEFT||ac.direction== AnimationName.Direction.DOWN){
                            angle=45;
                            dir=-1;
                        }
                        else{
                            angle=-45;
                            dir=1;
                        }
                    }
                    //ac.primaryWeapon.weaponGraphics.attackAnimation.weaponPosition(ac,vector2);

                    float second= AgentV2System.totalTime - ac.lastAttackTime;
                    float anim_x,anim_y;
                    if (0<second&&second<0.05f){
                        anim_x=-second*20*MathUtils.cos(angle)*dir;
                        anim_y=-second*20*MathUtils.sin(angle)*dir;
                    }
                    else if (0.05f<second&&second<0.15f){
                        anim_x=-(1.5f-second*10)*MathUtils.cos(angle)*dir;
                        anim_y=-(1.5f-second*10)*MathUtils.sin(angle)*dir;
                    }
                    else {
                        anim_x=0;
                        anim_y=0;
                    }

                    spriteBatch.draw(ac.primaryWeapon.weaponGraphics.weaponTexture,tc.pos.x-ac.primaryWeapon.weaponGraphics.position.x+anim_x,tc.pos.y-ac.primaryWeapon.weaponGraphics.position.y+anim_y,
                            ac.primaryWeapon.weaponGraphics.origin.x,ac.primaryWeapon.weaponGraphics.origin.y,
                            16,16,
                            dir,1,
                            MathUtils.radiansToDegrees*angle
                    );
                    HandGraphicComponent hc= ComponentMapper.getFor(HandGraphicComponent.class).get(entity);
                    if (hc!=null){
                        spriteBatch.draw(hc.handTexture,tc.pos.x-ac.primaryWeapon.weaponGraphics.position.x+ac.primaryWeapon.weaponGraphics.firstHand.x+anim_x,tc.pos.y-ac.primaryWeapon.weaponGraphics.position.y+ac.primaryWeapon.weaponGraphics.firstHand.y+anim_y,
                                -ac.primaryWeapon.weaponGraphics.firstHand.x + ac.primaryWeapon.weaponGraphics.origin.x,-ac.primaryWeapon.weaponGraphics.firstHand.y + ac.primaryWeapon.weaponGraphics.origin.y,
                                2,2,
                                dir,1,
                                MathUtils.radiansToDegrees*angle
                        );

                        spriteBatch.draw(hc.handTexture,tc.pos.x-ac.primaryWeapon.weaponGraphics.position.x+ac.primaryWeapon.weaponGraphics.secondHand.x+anim_x,tc.pos.y-ac.primaryWeapon.weaponGraphics.position.y+ac.primaryWeapon.weaponGraphics.secondHand.y+anim_y,
                                -ac.primaryWeapon.weaponGraphics.secondHand.x + ac.primaryWeapon.weaponGraphics.origin.x,-ac.primaryWeapon.weaponGraphics.secondHand.y + ac.primaryWeapon.weaponGraphics.origin.y,
                                2,2,
                                dir,1,
                                MathUtils.radiansToDegrees*angle
                        );
                    }
                }


            }
        }
        spriteBatch.end();
        renderQueue.clear();

    }

    @Override
    protected void processEntity(Entity entity, float deltaTime) {
        renderQueue.add(entity);
    }
}
