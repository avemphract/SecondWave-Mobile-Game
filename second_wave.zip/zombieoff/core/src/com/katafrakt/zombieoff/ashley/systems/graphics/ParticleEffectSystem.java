package com.katafrakt.zombieoff.ashley.systems.graphics;

import com.badlogic.ashley.core.Entity;
import com.badlogic.ashley.core.Family;
import com.badlogic.ashley.systems.IteratingSystem;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.ParticleEffectPool;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.OrderedMap;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.ParticleEffectComponent;
import com.katafrakt.zombieoff.game.abilitiybehaviours.StatusTypes;

public class ParticleEffectSystem extends IteratingSystem {
    private static final String TAG=ParticleEffectSystem.class.getSimpleName();
    private static final boolean shouldRender=true;

    private Array<ParticleEffectPool.PooledEffect> renderQueue;
    private SpriteBatch spriteBatch;
    private OrthographicCamera camera;

    public ParticleEffectSystem(SpriteBatch spriteBatch, OrthographicCamera camera) {
        super(Family.all(ParticleEffectComponent.class).get());
        this.spriteBatch=spriteBatch;
        this.camera=camera;
        renderQueue=new Array<>();
    }

    @Override
    public void update(float deltaTime) {
        //spriteBatch.enableBlending();
        if (shouldRender){
            spriteBatch.begin();
            for (ParticleEffectPool.PooledEffect pooledEffect :renderQueue){
                pooledEffect.draw(spriteBatch,deltaTime);
            }
            //Gdx.app.log(TAG,"Total particle: "+renderQueue.size);
            renderQueue.clear();
            spriteBatch.end();
        }
        super.update(deltaTime);
    }

    @Override
    protected void processEntity(Entity entity, float deltaTime) {
        ParticleEffectComponent pec=Mappers.particleComponents.get(entity);
        TransformComponent transform=Mappers.transformComponents.get(entity);
        OrderedMap.Entries<ParticleEffectPool.PooledEffect, Float> iterator=pec.effects.iterator();
        while (iterator.hasNext){
            OrderedMap.Entry<ParticleEffectPool.PooledEffect, Float> pair=iterator.next();

            pec.effects.put(pair.key,pair.value-deltaTime);

            if (pair.value<0){
                iterator.remove();
                pair.key.free();
            }
            else {
                renderQueue.add(pair.key);
            }
        }

        OrderedMap.Entries<StatusTypes, OrderedMap.Entry<ParticleEffectPool.PooledEffect,Float>> iterator2=pec.statusEffects.iterator();
        while (iterator2.hasNext()){
            OrderedMap.Entry<StatusTypes,OrderedMap.Entry<ParticleEffectPool.PooledEffect,Float>> pair=iterator2.next();
            if (pair.value.value>0){
                pair.value.value=pair.value.value-deltaTime;
                pec.statusEffects.put(pair.key,pair.value);
                pair.value.key.setPosition(transform.pos.x,transform.pos.y);
                renderQueue.add(pair.value.key);
            }
            else {
                pair.value.key.free();
                iterator2.remove();
            }
        }

    }
}
