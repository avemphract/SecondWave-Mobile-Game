package com.katafrakt.zombieoff.ashley.systems.graphics;

import com.badlogic.ashley.core.Entity;
import com.badlogic.ashley.core.Family;
import com.badlogic.ashley.systems.IteratingSystem;
import com.badlogic.gdx.Gdx;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.graphics.AnimationComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.GraphicsComponent;

public class AnimationSystem extends IteratingSystem {
    private final static String TAG=AnimationSystem.class.getSimpleName();
    float time=0;


    public AnimationSystem() {
        super(Family.all(AnimationComponent.class,GraphicsComponent.class).get());
    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        time+=deltaTime;
    }

    @Override
    protected void processEntity(Entity entity, float deltaTime) {
        AnimationComponent ac= Mappers.animationComponents.get(entity);
        GraphicsComponent gc=Mappers.graphicsComponents.get(entity);
        AgentComponentV2 agentComponent=Mappers.agentComponentV2(entity);
        if (ac.animations.get(agentComponent.animationName)==null) Gdx.app.log(TAG,"An: "+agentComponent.animationName);
        if (agentComponent.animationName!=null){
            gc.textureRegion=ac.animations.get(agentComponent.animationName).getKeyFrame(time);
        }

    }
}
