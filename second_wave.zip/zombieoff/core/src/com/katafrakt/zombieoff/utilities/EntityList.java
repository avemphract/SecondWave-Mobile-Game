package com.katafrakt.zombieoff.utilities;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ArrayMap;
import com.katafrakt.zombieoff.ashley.components.BoundComponent;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.entities.EntityType;
import com.katafrakt.zombieoff.ui.EntityUI;

public class EntityList extends ArrayMap<EntityType, Array<Entity>> {
    private static final String TAG=EntityList.class.getSimpleName();

    public static EntityList entityList=new EntityList();


    public Array<Entity> zombieEntities=new Array<>();
    public Array<Entity> humanEntities=new Array<>();

    //public Array<CreatureComponent> zombieCreatures =new Array<>();
    //public Array<CreatureComponent> humanCreatures =new Array<>();



    public void add(Entity entity,CreatureComponent creatureComponent){
        EntityType entityType=entity.getComponent(CreatureComponent.class).entityType;
        if (get(entityType)==null){
            put(entityType,new Array<Entity>());
        }

        get(entityType).add(entity);

        if (entityType.member==0){
            humanEntities.add(entity);
           // humanCreatures.add(creatureComponent);
        }
        else if (entityType.member==1){
            zombieEntities.add(entity);
          //  zombieCreatures.add(creatureComponent);
        }
    }

    public void remove(Entity entity){
        EntityType entityType=entity.getComponent(CreatureComponent.class).entityType;
        get(entityType).removeValue(entity,true);

        if (entityType.member==0){
            humanEntities.removeValue(entity,true);
           // humanCreatures.removeValue(entity.getComponent(CreatureComponent.class),true);
        }
        else if (entityType.member==1){
            zombieEntities.removeValue(entity,true);
          //  zombieCreatures.removeValue(entity.getComponent(CreatureComponent.class),true);
        }
        //Gdx.app.log(TAG,"Zombie entities:"+zombieEntities.size+","+humanEntities.size);
    }

    public Entity getFromCoordinate(Vector2 vector2){
        for (Entity entity:humanEntities){
            TransformComponent transformComponent=entity.getComponent(TransformComponent.class);
            BoundComponent boundComponent=entity.getComponent(BoundComponent.class);
            if (entity== EntityUI.getEntity())
                continue;
            if (vector2.x>transformComponent.pos.x-boundComponent.width/2&&vector2.x<transformComponent.pos.x+boundComponent.width/2){
                if (vector2.y>transformComponent.pos.y-boundComponent.height/2&&vector2.y<transformComponent.pos.y+boundComponent.height/2){
                    return entity;
                }
            }
        }
        for (Entity entity:zombieEntities){
            TransformComponent transformComponent=entity.getComponent(TransformComponent.class);
            BoundComponent boundComponent=entity.getComponent(BoundComponent.class);
            if (vector2.x>transformComponent.pos.x-boundComponent.width/2&&vector2.x<transformComponent.pos.x+boundComponent.width/2){
                if (vector2.y>transformComponent.pos.y-boundComponent.height/2&&vector2.y<transformComponent.pos.y+boundComponent.height/2){
                    return entity;
                }
            }
        }
        return null;
    }
}
