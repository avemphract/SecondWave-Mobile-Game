package com.katafrakt.zombieoff.utilities;

import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Sort;

public class SortingArray<T extends Comparable<T>> extends Array<T> {
    Sort sort=new Sort();

    @Override
    public void add(T value) {
        super.add(value);
        sort.sort(this);
    }

    @Override
    public boolean removeValue(T value, boolean identity) {
        boolean result= super.removeValue(value, identity);
        sort.sort(this);
        return result;
    }
}
