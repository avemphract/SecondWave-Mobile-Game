package com.katafrakt.zombieoff.utilities;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.graphics.FloatingTextComponent;

public class FloatingText implements Pool.Poolable {
    public FloatingTextComponent.Type type;
    public float value;
    public float remainTime;
    public Vector2 pos;
    public String text;

    public FloatingText(){}

    public FloatingText init(FloatingTextComponent.Type type, float value, float remainTime, Vector2 pos) {
        this.type = type;
        this.value = value;
        this.remainTime = remainTime;
        this.pos = pos;
        text=value+" "+ type.string;
        return this;
    }

    public FloatingText init(String text,float remainTime, Vector2 pos) {
        this.remainTime = remainTime;
        this.pos = pos;
        this.text = text;
        return this;
    }

    public void setText(){
        text= value+" "+type.string;
    }

    @Override
    public void reset() {
        pos=null;
    }
}
