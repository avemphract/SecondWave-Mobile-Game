package com.katafrakt.zombieoff.utilities;

public class Pair<K,E> {
    public K key;
    public E value;
    public Pair(K key,E value){
        this.key=key;
        this.value=value;
    }
    public Pair<K,E> set(K key,E value){
        this.key=key;
        this.value=value;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof Pair){
            if (key.equals(((Pair)o).key) && value.equals(((Pair)o).value))
                return true;

        }
        return false;
    }
}
