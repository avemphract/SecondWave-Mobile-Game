package com.katafrakt.zombieoff.utilities;

import com.badlogic.gdx.utils.ArrayMap;

public class DoubleIntMap<T> extends ArrayMap<Pair<Integer,Integer>,T> {
    Pair<Integer,Integer> pair=new Pair<>(0,0);

    public int put(int x,int y, T value) {
        return super.put(new Pair<>(x,y), value);
    }

    public T get(int x, int y){
        return super.get(pair.set(x,y));
    }

}
