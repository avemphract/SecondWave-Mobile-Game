package com.katafrakt.zombieoff.utilities;


import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.async.AsyncExecutor;
import com.badlogic.gdx.utils.async.AsyncTask;

import java.util.Iterator;

public class RangeGenerator {
    private static final String TAG= RangeGenerator.class.getSimpleName();
    public Array<Array<Integer[]>> circleLine =new Array<>();
    public Array<Array<Integer[]>> circleArea = new Array<>();

    AsyncExecutor asyncExecutor;

    private static RangeGenerator initiate;
    public static RangeGenerator getInstance(){
        if (initiate==null)
            initiate=new RangeGenerator();
        return initiate;
    }

static int i;
    private RangeGenerator(){
        Gdx.app.log(TAG,"Range generator start");
        asyncExecutor=new AsyncExecutor(99);
        for (int i=0;i<30;i++){
            final int finalI = i;
            asyncExecutor.submit(new AsyncTask<Object>() {
                @Override
                public Object call() throws Exception {
                    circleArea.add(rangeArea(finalI));
                    return null;
                }
            });
        }
        asyncExecutor.dispose();
        asyncExecutor=new AsyncExecutor(99);
        for (int i=0;i<30;i++){
            final int finalI = i;
            asyncExecutor.submit(new AsyncTask<Object>() {
                @Override
                public Object call() throws Exception {
                    circleLine.add(rangeRing(finalI));
                    return null;
                }
            });
        }
        asyncExecutor.dispose();
        Gdx.app.log(TAG,"Range generator finished");
    }

    private Array<Integer[]> range(int r){
        Array<Integer[]> array=new Array<>();
        int currentY=r,currentX;
        for (currentX=0;currentX<currentY;currentX++){
            float minError=99;
            int min=0;
            for (int i=0;i>-2;i--){
                if (minError>getError(currentX,currentY+i,r)){
                    min=i;
                    minError=getError(currentX,currentY+i,r);
                }
            }
            currentY+=min;
            array.addAll(p(currentX,currentY),p(-currentX,currentY),p(-currentX,-currentY),p(currentX,-currentY));
            array.addAll(p(currentY,currentX),p(-currentY,currentX),p(-currentY,-currentX),p(currentY,-currentX));
        }

        array = removeDuplicates(array);

        return array;
    }
    private Array<Integer[]> rangeRing(int r){
        if (r==0)
            return rangeArea(0);
        else {
            return removeArray(circleArea.get(r),circleArea.get(r-1));
            //return removeArray(rangeArea(r),rangeRing(r-1));
        }

    }
    private Array<Integer[]> rangeArea(int r){
        Array<Integer[]> result=new Array<>();
        if (r==0){
            result.add(new Integer[]{0,0});
            return result;
        }
        Array<Integer[]> circum=range(r);
        for (Integer[] integers:circum){
            result.add(integers);
            if (integers[0]>0){
                for (int i=integers[0];i>=0;i--){
                    result.add(new Integer[]{i,integers[1]});
                    result.add(new Integer[]{-i,integers[1]});
                }
            }
        }
        result=removeDuplicates(result);



        return result;
    }
    private Array<Integer[]> removeArray(Array<Integer[]> total,Array<Integer[]> absent){
        Array<Integer[]> result=new Array<>(total);
        Iterator<Integer[]> ite=result.iterator();
        Integer[] current;
        first: while (ite.hasNext()){
            current= ite.next();
            for (Integer[] temp:absent){
                if (current[0].intValue()==temp[0].intValue() && current[1].intValue()==temp[1].intValue()){
                    ite.remove();
                    continue first;
                }
            }
        }
        return result;
    }

    private Array<Integer[]> removeDuplicates(Array<Integer[]> array){
        Array<Integer[]> temp=new Array<>();
        first:for (Integer[] integers:array){
            for (Integer[] temps:temp){
                if (integers[0].intValue() == temps[0].intValue() && integers[1].intValue() == temps[1].intValue()){
                    i++;
                    continue first;
                }
            }
            temp.add(integers);
        }
        return temp;
    }

    private float getError(int x, int y, int r){
        return Math.abs(x*x+y*y-r*r);
    }

    Integer[] p(int x,int y){return new Integer[]{x,y};}
}
