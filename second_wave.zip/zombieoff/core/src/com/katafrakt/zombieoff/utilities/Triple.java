package com.katafrakt.zombieoff.utilities;

public class Triple<A,B,C> {
    public A value1;
    public B value2;
    public C value3;
    public Triple(A value1, B value2, C value3){
        this.value1=value1;
        this.value2=value2;
        this.value3=value3;
    }
}
