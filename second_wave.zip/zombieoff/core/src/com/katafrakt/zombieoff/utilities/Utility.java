package com.katafrakt.zombieoff.utilities;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ai.pfa.Point;

import java.util.HashMap;

public class Utility {
    private static final String TAG=Utility.class.getSimpleName();
    public static HashMap<String, Array<TextureRegion>> getFromAtlas(TextureAtlas atlas){
        HashMap<String,Array<TextureRegion>> hash=new HashMap<>();
        Array<TextureAtlas.AtlasRegion> list= atlas.getRegions();
        String name;
        for (int i=0;i<list.size;i++){
            name=list.get(i).name.split("-")[0];
            if(!hash.containsKey(name)){
                hash.put(name,new Array<TextureRegion>());
                hash.get(name).add(list.get(i));
            }
            else if (hash.containsKey(name))
                hash.get(name).add(list.get(i));
        }
        return  hash;
    }

    public static Texture createTextureFromColor(Color color){
        Pixmap pixmap=new Pixmap(1,1, Pixmap.Format.RGB888);
        pixmap.setColor(color);
        pixmap.fill();
        Texture texture=new Texture(pixmap);
        pixmap.dispose();
        return texture;
    }
    public static TextureRegion[] createAnimation(TextureRegion textureRegion){
        return textureRegion.split(textureRegion.getRegionHeight(),textureRegion.getRegionHeight())[0];
    }
    public static TextureRegion[] createAnimation(TextureRegion textureRegion,int width, int height){
        return textureRegion.split(width,height)[0];
    }
    public static Pool<Array<Point>> pointArrayPool=new Pool<Array<Point>>() {
        @Override
        protected Array<Point> newObject() {
            return new Array<>(false,100);
        }

        @Override
        public synchronized Array<Point> obtain() {
            return super.obtain();
        }

        @Override
        public void free(Array<Point> object) {
            object.clear();
            super.free(object);
        }
    };
}
