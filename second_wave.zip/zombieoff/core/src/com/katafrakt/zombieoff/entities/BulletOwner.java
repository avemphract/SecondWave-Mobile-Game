package com.katafrakt.zombieoff.entities;

public enum BulletOwner {
    HUMAN_BULLET,ZOMBIE_BULLET;
}
