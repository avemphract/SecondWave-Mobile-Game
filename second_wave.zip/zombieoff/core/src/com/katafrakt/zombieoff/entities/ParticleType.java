package com.katafrakt.zombieoff.entities;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.ParticleEffect;
import com.badlogic.gdx.graphics.g2d.ParticleEffectPool;

public enum ParticleType {
    BLOOD(){
        public ParticleEffectPool.PooledEffect getParticle(){
            return bloodPool.obtain();
        }
    },EXPLOSION(){
        @Override
        public ParticleEffectPool.PooledEffect getParticle() {
            return explosionPool.obtain();
        }
    };

    ParticleType(){
        ParticleEffect particleEffect=new ParticleEffect();
        particleEffect.load(Gdx.files.internal("particles/blood.party"),Gdx.files.internal("particles"));
        bloodPool=new ParticleEffectPool(particleEffect,10,100);

        ParticleEffect particleEffect1=new ParticleEffect();
        particleEffect1.load(Gdx.files.internal("particles/explosion.party"),Gdx.files.internal("particles"));
        explosionPool=new ParticleEffectPool(particleEffect1,1,20);

    }

    protected ParticleEffectPool bloodPool;
    protected ParticleEffectPool explosionPool;
    public abstract ParticleEffectPool.PooledEffect getParticle();
}
