package com.katafrakt.zombieoff.entities.zombies;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.math.MathUtils;
import com.katafrakt.zombieoff.ashley.components.BoundComponent;
import com.katafrakt.zombieoff.ashley.components.Init;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.VelocityComponent;
import com.katafrakt.zombieoff.ashley.components.agentsV2.ZombieAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.AnimationComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.DebugGraphicsComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.FloatingTextComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.GraphicsComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.ParticleEffectComponent;
import com.katafrakt.zombieoff.entities.EntityType;
import com.katafrakt.zombieoff.game.AnimationName;
import com.katafrakt.zombieoff.managers.AssetOrganizer;
import com.katafrakt.zombieoff.player.ZombieBuilder;
import com.katafrakt.zombieoff.utilities.EntityList;
import com.katafrakt.zombieoff.utilities.Utility;

public class BasicZombie extends Entity implements Init {
    private static final String TAG=BasicZombie.class.getSimpleName();


    TransformComponent transformComponent;
    BoundComponent boundComponent;
    CreatureComponent creatureComponent;
    ZombieAgentComponentV2 zombieAgentComponent;
    VelocityComponent velocityComponent;

    DebugGraphicsComponent debugGraphicsComponent;

    ParticleEffectComponent particleEffectComponent;
    GraphicsComponent graphicsComponent;
    AnimationComponent animationComponent;
    FloatingTextComponent floatingTextComponent;


    public BasicZombie(float x, float y, ZombieBuilder.BasicZombie builder){
        transformComponent = new TransformComponent(x,y);
        boundComponent = new BoundComponent(16,16);
        creatureComponent = new CreatureComponent(this, EntityType.BASIC_ZOMBIE,builder.getHp(),builder.getAtt(),builder.getSpe(),builder.getReg(),builder.getRed());
        //Gdx.app.log(TAG,"Att: "+builder.getAtt());
        //zombieAgentComponent = new ZombieAgentComponent(this,builder.weapons,builder.abilities,builder.getAwa());
        zombieAgentComponent=new ZombieAgentComponentV2(this,builder.weaponCreators,builder.abilities,builder.getAwa());
        velocityComponent=new VelocityComponent();

        debugGraphicsComponent=new DebugGraphicsComponent();debugGraphicsComponent.colorOut=Color.GREEN;
        graphicsComponent = new GraphicsComponent(0,6);
        animationComponent=new AnimationComponent();
        particleEffectComponent=new ParticleEffectComponent(this);
        floatingTextComponent=new FloatingTextComponent();

        addAnimations();
        addComponents();
    }

    private void addComponents(){
        add(transformComponent);
        add(boundComponent);
        add(creatureComponent);
        add(zombieAgentComponent);
        add(velocityComponent);

        //add(debugGraphicsComponent);
        add(graphicsComponent);
        add(animationComponent);
        add(particleEffectComponent);
        add(floatingTextComponent);
    }


    public void addAnimations(){

        TextureAtlas textureAtlas=AssetOrganizer.getInstance().get("atlases/entities/zbsc.atlas",TextureAtlas.class);
        int i= MathUtils.random(1,4);
        animationComponent.addLoop(AnimationName.WALK_DOWN,0.15f,Utility.createAnimation(textureAtlas.findRegion("bsc_"+i+"_walk_down"),16,32));
        animationComponent.addLoop(AnimationName.WALK_UP,0.15f,Utility.createAnimation(textureAtlas.findRegion("bsc_"+i+"_walk_up"),16,32));
        animationComponent.addLoop(AnimationName.WALK_RIGHT,0.15f,Utility.createAnimation(textureAtlas.findRegion("bsc_"+i+"_walk_right"),16,32));
        animationComponent.addLoop(AnimationName.WALK_LEFT,0.15f,Utility.createAnimation(textureAtlas.findRegion("bsc_"+i+"_walk_left"),16,32));

        animationComponent.addLoop(AnimationName.WAIT_DOWN,1f,Utility.createAnimation(textureAtlas.findRegion("bsc_"+i+"_wait_down"),16,32));
        animationComponent.addLoop(AnimationName.WAIT_UP,1f,Utility.createAnimation(textureAtlas.findRegion("bsc_"+i+"_wait_up"),16,32));
        animationComponent.addLoop(AnimationName.WAIT_RIGHT,1f,Utility.createAnimation(textureAtlas.findRegion("bsc_"+i+"_wait_right"),16,32));
        animationComponent.addLoop(AnimationName.WAIT_LEFT,1f,Utility.createAnimation(textureAtlas.findRegion("bsc_"+i+"_wait_left"),16,32));

        animationComponent.addConstant(AnimationName.ATTACK_DOWN,Utility.createAnimation(textureAtlas.findRegion("bsc_"+i+"_wait_down"),16,32));
        animationComponent.addConstant(AnimationName.ATTACK_UP,Utility.createAnimation(textureAtlas.findRegion("bsc_"+i+"_wait_up"),16,32));
        animationComponent.addConstant(AnimationName.ATTACK_RIGHT,Utility.createAnimation(textureAtlas.findRegion("bsc_"+i+"_wait_right"),16,32));
        animationComponent.addConstant(AnimationName.ATTACK_LEFT,Utility.createAnimation(textureAtlas.findRegion("bsc_"+i+"_wait_left"),16,32));

    }

    @Override
    public void addedEngine() {
        zombieAgentComponent.addedEngine();
        particleEffectComponent.addedEngine();
        EntityList.entityList.add(this,getComponent(CreatureComponent.class));
    }
}
