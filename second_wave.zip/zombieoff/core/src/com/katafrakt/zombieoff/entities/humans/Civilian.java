package com.katafrakt.zombieoff.entities.humans;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.math.MathUtils;
import com.katafrakt.zombieoff.ashley.components.BoundComponent;
import com.katafrakt.zombieoff.ashley.components.Init;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.VelocityComponent;
import com.katafrakt.zombieoff.ashley.components.agentsV2.CivilianAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.AnimationComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.DebugGraphicsComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.FloatingTextComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.GraphicsComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.HandGraphicComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.ParticleEffectComponent;
import com.katafrakt.zombieoff.entities.EntityType;
import com.katafrakt.zombieoff.game.AnimationName;
import com.katafrakt.zombieoff.managers.AssetOrganizer;
import com.katafrakt.zombieoff.managers.EntityFactory;
import com.katafrakt.zombieoff.managers.GeneralOrganizer;
import com.katafrakt.zombieoff.utilities.EntityList;
import com.katafrakt.zombieoff.utilities.Utility;

public class Civilian extends Entity implements Init {
    private static final String TAG=Civilian.class.getSimpleName();

    TransformComponent transformComponent;
    BoundComponent boundComponent;
    CreatureComponent creatureComponent;
    //CivilianAgentComponent civilianAgentComponent;
    CivilianAgentComponentV2 civilianAgentComponent;
    VelocityComponent velocityComponent;

    DebugGraphicsComponent debugGraphicsComponent;

    GraphicsComponent graphicsComponent;
    HandGraphicComponent handGraphicComponent;
    AnimationComponent animationComponent;
    ParticleEffectComponent particleEffectComponent;
    FloatingTextComponent floatingTextComponent;

    public Civilian(float x, float y, EntityFactory.HumanBuilder builder){
        transformComponent = new TransformComponent(x,y);
        boundComponent = new BoundComponent(10,24);
        creatureComponent = new CreatureComponent(this, EntityType.CIVILIAN,builder.health,builder.damage,builder.speed,builder.regen,builder.reduction);
        velocityComponent=new VelocityComponent();
        civilianAgentComponent=new CivilianAgentComponentV2(this,builder.weaponCreators,builder.abilityUnlocks,builder.aware);


        debugGraphicsComponent = new DebugGraphicsComponent();
        debugGraphicsComponent.colorOut =new Color(1,0,0,1);
        graphicsComponent=new GraphicsComponent(0,6);
        handGraphicComponent=new HandGraphicComponent(AssetOrganizer.getInstance().get("atlases/hands.atlas",TextureAtlas.class).findRegion("hand_1"));
        animationComponent=new AnimationComponent();
        particleEffectComponent=new ParticleEffectComponent(this);
        floatingTextComponent=new FloatingTextComponent();

        addAnimations();
        addComponents();
    }
    public void addComponents(){
        add(transformComponent);
        add(boundComponent);
        add(creatureComponent);
        add(velocityComponent);
        add(civilianAgentComponent);


        //add(debugGraphicsComponent);
        add(graphicsComponent);
        add(handGraphicComponent);
        add(animationComponent);
        add(particleEffectComponent);
        add(floatingTextComponent);
    }

    public void addAnimations(){/*
        TextureAtlas walk= AssetOrganizer.getInstance().get("atlases/entities/civilian_walk.atlas",TextureAtlas.class);
        int i= GeneralOrganizer.getInstance().random.nextInt(3)+1;

        animationComponent.addLoop(AnimationName.WALK_DOWN,0.15f,Utility.createAnimation(walk.findRegion("civ"+i+"_walk_down"),16,32));
        animationComponent.addLoop(AnimationName.WALK_UP,0.15f,Utility.createAnimation(walk.findRegion("civ"+i+"_walk_up"),16,32));
        animationComponent.addLoop(AnimationName.WALK_RIGHT,0.15f,Utility.createAnimation(walk.findRegion("civ"+i+"_walk_right"),16,32));
        animationComponent.addLoop(AnimationName.WALK_LEFT,0.15f,Utility.createAnimation(walk.findRegion("civ"+i+"_walk_left"),16,32));

        TextureAtlas wait= AssetOrganizer.getInstance().get("atlases/entities/civilian_wait.atlas",TextureAtlas.class);

        animationComponent.addLoop(AnimationName.WAIT_DOWN,1,Utility.createAnimation(wait.findRegion("civ"+i+"_wait_down"),16,32));
        animationComponent.addLoop(AnimationName.WAIT_UP,1,Utility.createAnimation(wait.findRegion("civ"+i+"_wait_up"),16,32));
        animationComponent.addLoop(AnimationName.WAIT_RIGHT,1,Utility.createAnimation(wait.findRegion("civ"+i+"_wait_right"),16,32));
        animationComponent.addLoop(AnimationName.WAIT_LEFT,1,Utility.createAnimation(wait.findRegion("civ"+i+"_wait_left"),16,32));

        TextureAtlas attack= AssetOrganizer.getInstance().get("atlases/entities/civilian_attack.atlas", TextureAtlas.class);

        animationComponent.addOne(AnimationName.ATTACK_DOWN,0.4f,Utility.createAnimation(attack.findRegion("civ"+i+"_attack_down"),16,32));
        animationComponent.addOne(AnimationName.ATTACK_UP,0.4f,Utility.createAnimation(attack.findRegion("civ"+i+"_attack_up"),16,32));
        animationComponent.addOne(AnimationName.ATTACK_RIGHT,0.4f,Utility.createAnimation(attack.findRegion("civ"+i+"_attack_right"),16,32));
        animationComponent.addOne(AnimationName.ATTACK_LEFT,0.4f,Utility.createAnimation(attack.findRegion("civ"+i+"_attack_left"),16,32));
*/
        //TextureAtlas wait=AssetOrganizer.getInstance().get("atlases/entities/civ_wait.atlas",TextureAtlas.class);
        //TextureAtlas walk=AssetOrganizer.getInstance().get("atlases/entities/civ_walk.atlas",TextureAtlas.class);

        TextureAtlas textureAtlas=AssetOrganizer.getInstance().get("atlases/entities/hciv.atlas",TextureAtlas.class);
        int i= MathUtils.random(1,2);
        animationComponent.addLoop(AnimationName.WALK_DOWN,0.15f,Utility.createAnimation(textureAtlas.findRegion("civ_"+i+"_walk_down"),16,32));
        animationComponent.addLoop(AnimationName.WALK_UP,0.15f,Utility.createAnimation(textureAtlas.findRegion("civ_"+i+"_walk_up"),16,32));
        animationComponent.addLoop(AnimationName.WALK_RIGHT,0.15f,Utility.createAnimation(textureAtlas.findRegion("civ_"+i+"_walk_right"),16,32));
        animationComponent.addLoop(AnimationName.WALK_LEFT,0.15f,Utility.createAnimation(textureAtlas.findRegion("civ_"+i+"_walk_left"),16,32));

        animationComponent.addLoop(AnimationName.WAIT_DOWN,1f,Utility.createAnimation(textureAtlas.findRegion("civ_"+i+"_wait_down"),16,32));
        animationComponent.addLoop(AnimationName.WAIT_UP,1f,Utility.createAnimation(textureAtlas.findRegion("civ_"+i+"_wait_up"),16,32));
        animationComponent.addLoop(AnimationName.WAIT_RIGHT,1f,Utility.createAnimation(textureAtlas.findRegion("civ_"+i+"_wait_right"),16,32));
        animationComponent.addLoop(AnimationName.WAIT_LEFT,1f,Utility.createAnimation(textureAtlas.findRegion("civ_"+i+"_wait_left"),16,32));

        animationComponent.addConstant(AnimationName.ATTACK_DOWN,Utility.createAnimation(textureAtlas.findRegion("civ_"+i+"_wait_down"),16,32));
        animationComponent.addConstant(AnimationName.ATTACK_UP,Utility.createAnimation(textureAtlas.findRegion("civ_"+i+"_wait_up"),16,32));
        animationComponent.addConstant(AnimationName.ATTACK_RIGHT,Utility.createAnimation(textureAtlas.findRegion("civ_"+i+"_wait_right"),16,32));
        animationComponent.addConstant(AnimationName.ATTACK_LEFT,Utility.createAnimation(textureAtlas.findRegion("civ_"+i+"_wait_left"),16,32));

    }


    @Override
    public void addedEngine() {
        civilianAgentComponent.addedEngine();
        particleEffectComponent.addedEngine();
        EntityList.entityList.add(this,getComponent(CreatureComponent.class));
    }
}
