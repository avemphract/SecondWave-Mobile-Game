package com.katafrakt.zombieoff.entities;

import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponInformation;

public enum EntityType {
    CIVILIAN("civilian","Civilian",0,0),POLICE("police","Police",0,1),MERCENARY("mercenary","Mercenary",0,2),VETERAN("veteran","Veteran",0,3),SOLDIER("soldier","Soldier",0,4),
    COMMON_ZOMBIE("common_zombie","Common",1,10),BASIC_ZOMBIE("basic_zombie","Basic",1,11),GIANT_ZOMBIE("giant_zombie","Giant",1,12), RANGED_ZOMBIE("spit_zombie","Ranged",1,14),
    ;
    public final String atlas_name;
    public final String name;
    public Array<WeaponInformation.Type> weaponTypes=new Array<>();
    public int member;//Member: 0-Human 1-Zombie 10-HumanBullet 11-ZombieBullet
    int type;
    EntityType(String string,String name,int member,int type){
        atlas_name =string;
        this.name=name;
        this.member=member;
        this.type=type;
        switch (type){
            case 10:
                weaponTypes.add(WeaponInformation.Type.Melee);
                break;
            case 11:
                weaponTypes.add(WeaponInformation.Type.Melee);
                break;
            case 12:
                weaponTypes.add(WeaponInformation.Type.Melee, WeaponInformation.Type.Area);
                break;
            case 14:
                weaponTypes.add(WeaponInformation.Type.Ranged);
                break;
        }
    }
    public BulletOwner getBullet(){
        if (member==0){
            return BulletOwner.HUMAN_BULLET;
        }
        else {
            return BulletOwner.ZOMBIE_BULLET;
        }
    }
    public String getName(){
        return name;
    }
    public int toInteger(){
        return type;
    }
}
