package com.katafrakt.zombieoff.entities.bullets;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.BoundComponent;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.creatures.BulletComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.DebugGraphicsComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.GraphicsComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.ParticleEffectComponent;
import com.katafrakt.zombieoff.entities.BulletOwner;
import com.katafrakt.zombieoff.entities.BulletType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.CloneableAbilityController;
import com.katafrakt.zombieoff.game.weapons.hitbehaviour.HitBehaviour;
import com.katafrakt.zombieoff.managers.EngineEdited;


public class Bullet extends Entity implements Pool.Poolable {
    private static final String TAG=Bullet.class.getSimpleName();

    TransformComponent transformComponent=new TransformComponent();
    DebugGraphicsComponent debugGraphicsComponent=new DebugGraphicsComponent();
    BoundComponent boundComponent=new BoundComponent();
    BulletComponent bulletComponent=new BulletComponent();
    ParticleEffectComponent particleEffectComponent=new ParticleEffectComponent();
    GraphicsComponent graphicsComponent=new GraphicsComponent();

    static int total;
    int anInt;

    public Bullet(){
        total++;
        anInt=total;

        add(transformComponent);
        //add(debugGraphicsComponent);
        add(boundComponent);
        add(particleEffectComponent);
        add(bulletComponent);
        add(graphicsComponent);
    }
    public Bullet init(Builder builder, TextureRegion textureRegion,int size){
        transformComponent.init(builder.x,builder.y);
        boundComponent.init(builder.width,builder.height);
        if(builder.bulletOwner == BulletOwner.HUMAN_BULLET){
            debugGraphicsComponent.colorOut =new Color(0.4f,0.4f,1f,1);
            debugGraphicsComponent.colorIn=new Color(0,0,0,1);
        }
        else if (builder.bulletOwner == BulletOwner.ZOMBIE_BULLET){
            debugGraphicsComponent.colorOut=new Color(1,0.4f,0.4f,1);
            debugGraphicsComponent.colorIn=new Color(0,0,0,1);
        }
        debugGraphicsComponent.isActive=true;
        bulletComponent.set(this,builder.bulletOwner,builder.bulletType,builder.hitBehaviour.clone(),builder.speed,builder.damage,builder.totalTime);
        bulletComponent.abilityControllers.addAll(builder.abilityControllers);
        graphicsComponent.init(textureRegion,size,size);
        particleEffectComponent.init(this);
        return this;
    }

    @Override
    public void reset() {
        Gdx.app.log(TAG,"Bullet reseted");
        EngineEdited.initiate.removeEntity(this);
        bulletComponent.reset();
        graphicsComponent.textureRegion=null;
    }

    @Override
    public String toString() {
        return super.toString()+" "+bulletComponent.hitBehaviour.getClass().getSimpleName()+" "+bulletComponent.totalTime+" "+anInt;
    }

    public static class Builder {
        Array<CloneableAbilityController> abilityControllers=new Array<>();
        public BulletOwner bulletOwner;
        public BulletType bulletType;
        HitBehaviour hitBehaviour;
        float x,y;
        float width,height;
        Vector2 speed;
        public float damage;
        float totalTime;
        public Builder(){}

        public void set(BulletOwner bulletOwner,BulletType bulletType, HitBehaviour hitBehaviour, float x, float y, float width, float height, Vector2 speed, float damage, float totalTime, Array<CloneableAbilityController> abilityControllers) {
            this.bulletOwner = bulletOwner;
            this.bulletType=bulletType;
            this.hitBehaviour = hitBehaviour;
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.speed = speed;
            this.damage = damage;
            this.totalTime = totalTime;
            this.abilityControllers.clear();
            this.abilityControllers.addAll(abilityControllers);
        }
    }
}
