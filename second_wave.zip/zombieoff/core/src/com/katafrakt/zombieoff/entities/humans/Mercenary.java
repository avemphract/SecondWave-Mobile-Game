package com.katafrakt.zombieoff.entities.humans;


import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.graphics.Color;
import com.katafrakt.zombieoff.ashley.components.BoundComponent;
import com.katafrakt.zombieoff.ashley.components.Init;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.VelocityComponent;
import com.katafrakt.zombieoff.ashley.components.agentsV2.MercenaryAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.DebugGraphicsComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.FloatingTextComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.ParticleEffectComponent;
import com.katafrakt.zombieoff.entities.EntityType;
import com.katafrakt.zombieoff.managers.EntityFactory;
import com.katafrakt.zombieoff.utilities.EntityList;

public class Mercenary extends Entity implements Init {
    TransformComponent transformComponent;
    BoundComponent boundComponent;
    CreatureComponent creatureComponent;
    MercenaryAgentComponentV2 mercenaryAgentComponent;
    VelocityComponent velocityComponent;


    DebugGraphicsComponent debugGraphicsComponent;
    ParticleEffectComponent particleEffectComponent;
    FloatingTextComponent floatingTextComponent;

    public Mercenary(float x, float y, EntityFactory.HumanBuilder builder){

        transformComponent = new TransformComponent(x,y);
        boundComponent = new BoundComponent(16,16);
        creatureComponent = new CreatureComponent(this, EntityType.MERCENARY,builder.health,builder.damage,builder.speed,builder.regen,builder.reduction);
        mercenaryAgentComponent = new MercenaryAgentComponentV2(this,builder.weaponCreators,builder.abilityUnlocks,builder.aware);
        velocityComponent=new VelocityComponent();


        debugGraphicsComponent = new DebugGraphicsComponent();
        debugGraphicsComponent.colorOut=new Color(0,0.5f,0.5f,1);
        particleEffectComponent = new ParticleEffectComponent(this);
        floatingTextComponent = new FloatingTextComponent();
        addComponents();
    }

    private void addComponents(){
        add(transformComponent);
        add(boundComponent);
        add(creatureComponent);
        add(mercenaryAgentComponent);
        add(velocityComponent);
        //Gdx.app.log("Merc",mercenaryAgentComponent.toString());

        add(debugGraphicsComponent);
        add(particleEffectComponent);
        add(floatingTextComponent);
    }

    @Override
    public void addedEngine() {
        mercenaryAgentComponent.addedEngine();
        particleEffectComponent.addedEngine();
        EntityList.entityList.add(this,getComponent(CreatureComponent.class));
    }
}
