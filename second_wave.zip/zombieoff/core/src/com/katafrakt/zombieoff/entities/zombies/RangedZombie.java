package com.katafrakt.zombieoff.entities.zombies;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.katafrakt.zombieoff.ashley.components.BoundComponent;
import com.katafrakt.zombieoff.ashley.components.Init;
import com.katafrakt.zombieoff.ashley.components.TransformComponent;
import com.katafrakt.zombieoff.ashley.components.VelocityComponent;
import com.katafrakt.zombieoff.ashley.components.agentsV2.RangedZombieAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.AnimationComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.DebugGraphicsComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.FloatingTextComponent;
import com.katafrakt.zombieoff.ashley.components.graphics.ParticleEffectComponent;
import com.katafrakt.zombieoff.entities.EntityType;
import com.katafrakt.zombieoff.player.ZombieBuilder;
import com.katafrakt.zombieoff.utilities.EntityList;

public class RangedZombie extends Entity implements Init {
    private static final String TAG= RangedZombie.class.getSimpleName();

    TransformComponent transformComponent;
    BoundComponent boundComponent;
    CreatureComponent creatureComponent;
    //ZombieRangedAgentComponent zombieRangedAgentComponent;
    RangedZombieAgentComponentV2 rangedZombieAgentComponent;
    VelocityComponent velocityComponent;

    DebugGraphicsComponent debugGraphicsComponent;
    ParticleEffectComponent particleEffectComponent;
    //GraphicsComponent graphicsComponent;
    AnimationComponent animationComponent;
    FloatingTextComponent floatingTextComponent;

    public RangedZombie(float x, float y, ZombieBuilder.RangedZombie builder){
        transformComponent=new TransformComponent(x,y);
        boundComponent=new BoundComponent(16,16);
        creatureComponent=new CreatureComponent(this,EntityType.RANGED_ZOMBIE,builder.getHp(),builder.getAtt(),builder.getSpe(),builder.getReg(),builder.getRed());
        //zombieRangedAgentComponent=new ZombieRangedAgentComponent(this,builder.weapons,builder.abilities,builder.getAwa());
        rangedZombieAgentComponent=new RangedZombieAgentComponentV2(this,builder.weaponCreators,builder.abilities,builder.getAwa());
        velocityComponent=new VelocityComponent();

        debugGraphicsComponent= new DebugGraphicsComponent();
        debugGraphicsComponent.colorOut = new Color(0.7f,0.8f,0.2f,1);
        particleEffectComponent=new ParticleEffectComponent(this);
        floatingTextComponent=new FloatingTextComponent();

        Gdx.app.log(TAG,"Size: "+builder.abilities.size);

        addComponents();
    }

    private void addComponents(){

        add(transformComponent);
        add(boundComponent);
        add(creatureComponent);
        //add(zombieRangedAgentComponent);
        add(rangedZombieAgentComponent);
        add(velocityComponent);
        //add(graphicsComponent);
        //add(animationComponent);
        add(debugGraphicsComponent);
        add(particleEffectComponent);
        add(floatingTextComponent);
    }

    @Override
    public void addedEngine() {
        rangedZombieAgentComponent.addedEngine();
        particleEffectComponent.addedEngine();
        EntityList.entityList.add(this,creatureComponent);

    }
}
