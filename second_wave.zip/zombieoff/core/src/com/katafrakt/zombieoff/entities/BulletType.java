package com.katafrakt.zombieoff.entities;

public enum  BulletType {
    AIRBORNE("Airborne"),LINE("Line"),UNDERGROUND("Underground");

    public final String NAME;
    BulletType(String name){
        NAME=name;
    }
}