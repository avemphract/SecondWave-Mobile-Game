package com.katafrakt.zombieoff.player;

import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ArrayMap;
import com.badlogic.gdx.utils.Sort;
import com.katafrakt.zombieoff.entities.EntityType;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.UpgradeBehaviour;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponInformation;
import com.katafrakt.zombieoff.game.upgradebehaviours.weapon_creators.zombie.CommonZombieAttack;
import com.katafrakt.zombieoff.game.upgradebehaviours.weapon_creators.zombie.CommonZombieRangedAttack;

import java.util.Comparator;


public class ZombieBuilder {
    private static ZombieBuilder instance;
    private ZombieBuilder(){}

    public static ZombieBuilder getInstance(){if (instance==null) instance=new ZombieBuilder(); return instance;}

    public float zombieCooldown=1;



    public GeneralBuilder builder=new GeneralBuilder();

    WeaponInformation commonZombieAttack=new CommonZombieAttack();
    WeaponInformation commonZombieRangedAttack=new CommonZombieRangedAttack();

    CommonZombie commonZombieBuilder=new CommonZombie();
    BasicZombie basicZombieBuilder=new BasicZombie();
    GiantZombie giantZombieBuilder=new GiantZombie();
    RangedZombie rangedZombieBuilder =new RangedZombie();

    public ArrayMap<EntityType,Builder> builderMap =new ArrayMap<>();{
        builderMap.put(EntityType.COMMON_ZOMBIE,commonZombieBuilder);
        builderMap.put(EntityType.BASIC_ZOMBIE,basicZombieBuilder);
        builderMap.put(EntityType.GIANT_ZOMBIE,giantZombieBuilder);
        builderMap.put(EntityType.RANGED_ZOMBIE, rangedZombieBuilder);
    }

    Sort sort=new Sort();
    Comparator<UpgradeBehaviour> sortByIndex=new Comparator<UpgradeBehaviour>() {
        @Override
        public int compare(UpgradeBehaviour t1, UpgradeBehaviour t2) {
            if (t1.getIndex()>t2.getIndex())
                return 1;
            else if (t1.getIndex()<t2.getIndex())
                return -1;
            else
                return 0;
        }
    };


    public Array<WeaponInformation> weaponCreators =new Array<WeaponInformation>();
    {weaponCreators.add(commonZombieAttack);weaponCreators.add(commonZombieRangedAttack);}

    public Array<AbilityCreator> abilityCreators =new Array<AbilityCreator>();

    public Array<EntityType> unlockedTypes=new Array<>();{
        unlockedTypes.add(EntityType.COMMON_ZOMBIE);
        unlockedTypes.add(EntityType.BASIC_ZOMBIE);
        unlockedTypes.add(EntityType.GIANT_ZOMBIE);
        unlockedTypes.add(EntityType.RANGED_ZOMBIE);
    }

    public static class GeneralBuilder{
        public float hpAddition;
        public float hpMultiplier=0;
        public float hpMultiplierTrophy=0;//Human Death

        public float attAddition=0;
        public float attMultiplier=0;
        public float getAttMultiplierTrophy=0;//TotalDamage

        public int awaAddition;

        public float speAddition;
        public float speMultiplierTrophy;//TotalMovement

        public float eneAddition;

        public float bulletSpeedMultiplier;//BulletFired

        public float regenAddition;

        public float reductionAddition;
    }


    public abstract class Builder{
        public int weaponLimit;
        public Array<WeaponInformation> weapons=new Array<WeaponInformation>(){
            @Override
            public void add(WeaponInformation value) {
                super.add(value);
                weaponCreators.add(value);
                eneAddition+=value.energy;
            }

            @Override
            public void clear() {
                for (WeaponInformation weaponInformation :weapons){
                    weaponCreators.clear();
                    eneAddition-= weaponInformation.energy;
                }
                super.clear();
            }
        };
        public Array<WeaponCreator> weaponCreators=new Array<>();

        public int abilityLimit;
        public Array<AbilityCreator> abilities=new Array<AbilityCreator>(){
            @Override
            public void add(AbilityCreator value) {
                super.add(value);
                eneAddition+=value.energy;
            }

            @Override
            public void clear() {
                for (AbilityCreator abilityCreator:abilities)
                    eneAddition-=abilityCreator.energy;
                super.clear();
            }
        };
        //HealthPoint
        public float hpInit=100;
        public float hpAddition;
        public float hpMultiplier=0;

        public float getHp(){
            return (hpInit + hpAddition + builder.hpAddition) * (1 + hpMultiplier + builder.hpMultiplier) * (1 + builder.hpMultiplierTrophy);
        }

        //Attack
        public float attInit=5;
        public float attAddition=0;
        public float attMultiplier=0;

        public float getAtt(){
            return (attInit + attAddition + builder.attAddition) * (1 + attMultiplier + builder.attMultiplier) * (1 + builder.getAttMultiplierTrophy);
        }

        //Awareness
        public int awaInit=8;
        public int awaAddition=8;
        public int awaMultiplier=0;

        public int getAwa(){
            return (awaInit + awaAddition + builder.awaAddition) * (1 + awaMultiplier);
        }

        //Speed
        public float speInit=5;
        public float speAddition;

        public float getSpe(){
            return (speInit + speAddition + builder.speAddition)*(1+builder.speMultiplierTrophy);
        }

        //Energy
        public float eneInit;
        public float eneAddition;

        public float getEne(){
            return (eneInit + eneAddition + builder.eneAddition);
        }

        public float regenAddition;

        public float getReg(){ return regenAddition+builder.regenAddition; }

        public float redAddition;

        public float getRed(){ return redAddition*builder.reductionAddition; }
    }
    public class CommonZombie extends Builder{
        private CommonZombie(){
            weapons.add(commonZombieAttack);
        }

        public float freInit;
        public float freAddition;

        public float getFre(){
            return (freInit+freAddition);
        }
    }
    public class BasicZombie extends Builder{
        private BasicZombie(){
            eneInit=5;
            weaponLimit=1;
            abilityLimit=1;
            weapons.add(commonZombieAttack);
        }
        //Frequency

    }
    public class GiantZombie extends Builder {
        private GiantZombie(){
            hpInit=200;
            eneInit=10;
            weaponLimit=1;
            abilityLimit=1;

            weapons.add(commonZombieAttack);
        }
    }
    public class RangedZombie extends Builder {
        private RangedZombie(){
            hpInit=100;
            eneInit=10;
            attInit=10;

            weaponLimit=1;
            abilityLimit=1;
            weapons.add(commonZombieRangedAttack);
        }
    }
}
