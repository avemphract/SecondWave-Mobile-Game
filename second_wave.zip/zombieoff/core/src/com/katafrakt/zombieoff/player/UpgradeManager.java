package com.katafrakt.zombieoff.player;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Sort;
import com.katafrakt.zombieoff.game.tree.TreeNode;
import com.katafrakt.zombieoff.game.upgradebehaviours.ResourceUpgrade;
import com.katafrakt.zombieoff.game.upgradebehaviours.UpgradeBehaviour;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponUnlock;
import com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_I.AttackToTime_Fire_Upgrade;
import com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_I.Attack_Health_Upgrade;
import com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_I.GetAttacked_Health_Upgrade;
import com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_I.StateTimeFollow_Speed_Upgrade;
import com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_I.Time_Speed_Upgrade;
import com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_II.AttackToTime_Poison_Upgrade;
import com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_II.AttackToTime_Weak_Upgrade;
import com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_II.Died_Explosion_I_Upgrade;
import com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_II.GetAttackedTime_Speed_Upgrade;
import com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_II.StateIdle_Speed_Upgrade;
import com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_III.Attack_IncMaxHealth_Upgrade;
import com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_III.Died_ExplosionFire_Upgrade;
import com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_III.GetAttacked_Aware_Upgrade;
import com.katafrakt.zombieoff.game.upgradebehaviours.abilityunlock.level_III.StateIdle_Resistance_Upgrade;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.resource.BloodCapacity_I;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.resource.BloodGainZombie;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.resource.BloodTickle_I;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.resource.EnergyCapacity_I;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.resource.EnergyProduction_I;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.attack.ZombieAttackRatio;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.attack.ZombieAttack_I;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.attack.ZombieAttack_II;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.attack.ZombieAttack_III;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.attack.ZombieAttack_IV;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.attack.ZombieAttack_V;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.attack.ZombieAwareRange;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.attack.ZombieConversion;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.attack.ZombieSpeed_I;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.attack.ZombieSpeed_II;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.defence.ZombieHealth_I;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.defence.ZombieHealth_II;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.defence.ZombieHealth_III;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.defence.ZombieHealth_IV;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.defence.ZombieLifeSteal;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.defence.ZombieReduction;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.defence.ZombieRegeneration;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.defence.ZombieSpawnRate_I;
import com.katafrakt.zombieoff.game.upgradebehaviours.generalupgrades.zombies.defence.ZombieSpawnRate_II;
import com.katafrakt.zombieoff.game.upgradebehaviours.prestige_upgrades.BloodCapacityPrestige;
import com.katafrakt.zombieoff.game.upgradebehaviours.prestige_upgrades.BloodGainPrestige;
import com.katafrakt.zombieoff.game.upgradebehaviours.prestige_upgrades.EnergyCapacityPrestige;
import com.katafrakt.zombieoff.game.upgradebehaviours.prestige_upgrades.GeneCapacityPrestige;
import com.katafrakt.zombieoff.game.upgradebehaviours.prestige_upgrades.GeneGainPrestige;
import com.katafrakt.zombieoff.game.upgradebehaviours.prestige_upgrades.ReduceEnergyAdditionPrestige;
import com.katafrakt.zombieoff.game.upgradebehaviours.prestige_upgrades.ReduceSpawnCooldownPrestige;
import com.katafrakt.zombieoff.game.upgradebehaviours.prestige_upgrades.UnlockAutoZombieUpgradesPrestige;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.BulletFired_I;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.BulletFired_II;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.BulletFired_III;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.BulletFired_IV;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.HumanDeath_I;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.HumanDeath_II;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.HumanDeath_III;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.HumanDeath_IV;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.SpendEnergy_I;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.SpendEnergy_II;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.SpendEnergy_III;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.SpendEnergy_IV;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.TotalBlood_I;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.TotalBlood_II;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.TotalBlood_III;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.TotalBlood_IV;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.TotalDamage_I;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.TotalDamage_II;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.TotalDamage_III;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.TotalDamage_IV;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.TotalImprovement_I;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.TotalImprovement_II;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.TotalImprovement_III;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.TotalImprovement_IV;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.TotalMovement_I;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.TotalMovement_II;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.TotalMovement_III;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.TotalMovement_IV;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.TotalTrophies_I;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.TotalTrophies_II;
import com.katafrakt.zombieoff.game.upgradebehaviours.trophyupgrades.TotalTrophies_III;
import com.katafrakt.zombieoff.game.upgradebehaviours.weaponunlocker.melee.BasicAttackUnlock;
import com.katafrakt.zombieoff.game.upgradebehaviours.weaponunlocker.melee.BurstAttackUnlock;
import com.katafrakt.zombieoff.game.upgradebehaviours.weaponunlocker.melee.CriticAttackUnlock;
import com.katafrakt.zombieoff.game.upgradebehaviours.weaponunlocker.melee.PowerAttackUnlock;
import com.katafrakt.zombieoff.game.upgradebehaviours.weaponunlocker.melee.QuickAttackUnlock;

import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;


public class UpgradeManager {
    private static final String TAG=UpgradeManager.class.getSimpleName();
    private static UpgradeManager initiate;
    public static UpgradeManager getInstance(){if (initiate==null)initiate=new UpgradeManager();return initiate;}
    private static int index;
    public static int setIndex(){index++;return index;}
    public Comparator<UpgradeBehaviour> comparator=new Comparator<UpgradeBehaviour>() {
        @Override
        public int compare(UpgradeBehaviour t1, UpgradeBehaviour t2) {
            if (t1.currentCount()==t1.maximumCount()&&t2.currentCount()==t2.maximumCount()){
                if (t1.getIndex()>t2.getIndex())
                    return 1;
                else if (t1.getIndex()<t2.getIndex())
                    return -1;
                else
                    return 0;
            }
            else if (t1.currentCount()==t1.maximumCount())
                return 1;
            else if (t2.currentCount()==t2.maximumCount())
                return -1;

            if (t1.getIndex()>t2.getIndex())
                return 1;
            else if (t1.getIndex()<t2.getIndex())
                return -1;
            else
                return 0;
        }
    };

    private UpgradeManager(){
        createTrees();
        setChildren();
        createPrerequisite();

        setWeapons();

        setPrestigeArray();

        setUpgradeBehaviours();
    }

    HashMap<String, TreeNode<UpgradeBehaviour>> generalUp=new LinkedHashMap<String, TreeNode<UpgradeBehaviour>>();

    TreeNode<UpgradeBehaviour> resourceManAncestor =new TreeNode<UpgradeBehaviour>(true);
    public Array<UpgradeBehaviour> resourceManArray = new Array<>();

    TreeNode<UpgradeBehaviour> zombiesUpAncestor=new TreeNode<>(true);
    public Array<UpgradeBehaviour> zombieUpArray = new Array<>();

    TreeNode<UpgradeBehaviour> trophyAncestor=new TreeNode<>(true);
    public Array<UpgradeBehaviour> trophyArray=new Array<>();

    TreeNode<UpgradeBehaviour> weaponAncestor =new TreeNode<>(true);
    public Array<WeaponUnlock> weaponArray =new Array<>();

    public Array<UpgradeBehaviour> abilityArray=new Array<>();
    public AbilityLevel abilityLevel=new AbilityLevel();





    public Array<ResourceUpgrade> prestigeArray=new Array<>();


    private Sort sort=new Sort();
    public void createTrees(){
        //Resource Management
        {
            //tier 1
            generalUp.put(BloodCapacity_I.NAME,new TreeNode<UpgradeBehaviour>(new BloodCapacity_I()));
            generalUp.put(EnergyCapacity_I.NAME,new TreeNode<UpgradeBehaviour>(new EnergyCapacity_I()));

            //tier 2
            generalUp.put(BloodTickle_I.NAME,new TreeNode<UpgradeBehaviour>(new BloodTickle_I()));
            generalUp.put(EnergyProduction_I.NAME,new TreeNode<UpgradeBehaviour>(new EnergyProduction_I()));

            //tier 3
            generalUp.put(BloodGainZombie.NAME,new TreeNode<UpgradeBehaviour>(new BloodGainZombie()));
        }

        //Zombies Upgrade
        {
            //
            generalUp.put(ZombieAttack_I.NAME,new TreeNode<UpgradeBehaviour>(new ZombieAttack_I()));
            generalUp.put(ZombieAttack_II.NAME,new TreeNode<UpgradeBehaviour>(new ZombieAttack_II()));
            generalUp.put(ZombieAttack_III.NAME,new TreeNode<UpgradeBehaviour>(new ZombieAttack_III()));
            generalUp.put(ZombieAttack_IV.NAME,new TreeNode<UpgradeBehaviour>(new ZombieAttack_IV()));
            generalUp.put(ZombieAttack_V.NAME,new TreeNode<UpgradeBehaviour>(new ZombieAttack_V()));

            generalUp.put(ZombieHealth_I.NAME,new TreeNode<UpgradeBehaviour>(new ZombieHealth_I()));
            generalUp.put(ZombieHealth_II.NAME,new TreeNode<UpgradeBehaviour>(new ZombieHealth_II()));
            generalUp.put(ZombieHealth_III.NAME,new TreeNode<UpgradeBehaviour>(new ZombieHealth_III()));
            generalUp.put(ZombieHealth_IV.NAME,new TreeNode<UpgradeBehaviour>(new ZombieHealth_IV()));

            generalUp.put(ZombieSpeed_I.NAME,new TreeNode<UpgradeBehaviour>(new ZombieSpeed_I()));
            generalUp.put(ZombieSpawnRate_I.NAME,new TreeNode<UpgradeBehaviour>(new ZombieSpawnRate_I()));
            generalUp.put(ZombieConversion.NAME,new TreeNode<UpgradeBehaviour>(new ZombieConversion()));
            generalUp.put(ZombieAwareRange.NAME,new TreeNode<UpgradeBehaviour>(new ZombieAwareRange()));
            generalUp.put(ZombieRegeneration.NAME,new TreeNode<UpgradeBehaviour>(new ZombieRegeneration()));
            generalUp.put(ZombieReduction.NAME,new TreeNode<UpgradeBehaviour>(new ZombieReduction()));
            generalUp.put(ZombieSpeed_II.NAME,new TreeNode<UpgradeBehaviour>(new ZombieSpeed_II()));
            generalUp.put(ZombieSpawnRate_II.NAME,new TreeNode<UpgradeBehaviour>(new ZombieSpawnRate_II()));
            generalUp.put(ZombieAttackRatio.NAME,new TreeNode<UpgradeBehaviour>(new ZombieAttackRatio()));
            generalUp.put(ZombieLifeSteal.NAME,new TreeNode<UpgradeBehaviour>(new ZombieLifeSteal()));


        }

        //Trophy
        {
            //BulletFired
            generalUp.put(BulletFired_I.NAME,new TreeNode<UpgradeBehaviour>(new BulletFired_I()));
            generalUp.put(BulletFired_II.NAME,new TreeNode<UpgradeBehaviour>(new BulletFired_II()));
            generalUp.put(BulletFired_III.NAME,new TreeNode<UpgradeBehaviour>(new BulletFired_III()));
            generalUp.put(BulletFired_IV.NAME,new TreeNode<UpgradeBehaviour>(new BulletFired_IV()));

            //HumanDeath
            generalUp.put(HumanDeath_I.NAME,new TreeNode<UpgradeBehaviour>(new HumanDeath_I()));
            generalUp.put(HumanDeath_II.NAME,new TreeNode<UpgradeBehaviour>(new HumanDeath_II()));
            generalUp.put(HumanDeath_III.NAME,new TreeNode<UpgradeBehaviour>(new HumanDeath_III()));
            generalUp.put(HumanDeath_IV.NAME,new TreeNode<UpgradeBehaviour>(new HumanDeath_IV()));

            //SpendEnergy
            generalUp.put(SpendEnergy_I.NAME,new TreeNode<UpgradeBehaviour>(new SpendEnergy_I()));
            generalUp.put(SpendEnergy_II.NAME,new TreeNode<UpgradeBehaviour>(new SpendEnergy_II()));
            generalUp.put(SpendEnergy_III.NAME,new TreeNode<UpgradeBehaviour>(new SpendEnergy_III()));
            generalUp.put(SpendEnergy_IV.NAME,new TreeNode<UpgradeBehaviour>(new SpendEnergy_IV()));

            //TotalBlood
            generalUp.put(TotalBlood_I.NAME,new TreeNode<UpgradeBehaviour>(new TotalBlood_I()));
            generalUp.put(TotalBlood_II.NAME,new TreeNode<UpgradeBehaviour>(new TotalBlood_II()));
            generalUp.put(TotalBlood_III.NAME,new TreeNode<UpgradeBehaviour>(new TotalBlood_III()));
            generalUp.put(TotalBlood_IV.NAME,new TreeNode<UpgradeBehaviour>(new TotalBlood_IV()));

            //TotalDamage
            generalUp.put(TotalDamage_I.NAME,new TreeNode<UpgradeBehaviour>(new TotalDamage_I()));
            generalUp.put(TotalDamage_II.NAME,new TreeNode<UpgradeBehaviour>(new TotalDamage_II()));
            generalUp.put(TotalDamage_III.NAME,new TreeNode<UpgradeBehaviour>(new TotalDamage_III()));
            generalUp.put(TotalDamage_IV.NAME,new TreeNode<UpgradeBehaviour>(new TotalDamage_IV()));

            //TotalImprovement
            generalUp.put(TotalImprovement_I.NAME,new TreeNode<UpgradeBehaviour>(new TotalImprovement_I()));
            generalUp.put(TotalImprovement_II.NAME,new TreeNode<UpgradeBehaviour>(new TotalImprovement_II()));
            generalUp.put(TotalImprovement_III.NAME,new TreeNode<UpgradeBehaviour>(new TotalImprovement_III()));
            generalUp.put(TotalImprovement_IV.NAME,new TreeNode<UpgradeBehaviour>(new TotalImprovement_IV()));

            //TotalMovement
            generalUp.put(TotalMovement_I.NAME,new TreeNode<UpgradeBehaviour>(new TotalMovement_I()));
            generalUp.put(TotalMovement_II.NAME,new TreeNode<UpgradeBehaviour>(new TotalMovement_II()));
            generalUp.put(TotalMovement_III.NAME,new TreeNode<UpgradeBehaviour>(new TotalMovement_III()));
            generalUp.put(TotalMovement_IV.NAME,new TreeNode<UpgradeBehaviour>(new TotalMovement_IV()));

            //TotalTrophies
            generalUp.put(TotalTrophies_I.NAME,new TreeNode<UpgradeBehaviour>(new TotalTrophies_I()));
            generalUp.put(TotalTrophies_II.NAME,new TreeNode<UpgradeBehaviour>(new TotalTrophies_II()));
            generalUp.put(TotalTrophies_III.NAME,new TreeNode<UpgradeBehaviour>(new TotalTrophies_III()));
        }

        //Weapons
        {

        }

    }

    public void setChildren(){

        //Resource Management
        {
            //tier 0
            resourceManAncestor.addChildren(generalUp.get(BloodCapacity_I.NAME),generalUp.get(EnergyCapacity_I.NAME));

            //tier1
            generalUp.get(BloodCapacity_I.NAME).addChildren(generalUp.get(BloodTickle_I.NAME));
            generalUp.get(EnergyCapacity_I.NAME).addChildren(generalUp.get(EnergyProduction_I.NAME));

            //tier2
            generalUp.get(BloodTickle_I.NAME).addChildren(generalUp.get(BloodGainZombie.NAME));

        }

        //Zombie Upgrade
        {
            //tier 0
            zombiesUpAncestor.addChildren(generalUp.get(ZombieAttack_I.NAME),generalUp.get(ZombieHealth_I.NAME));
            //tier 1
            generalUp.get(ZombieAttack_I.NAME).addChildren(generalUp.get(ZombieAttack_II.NAME),generalUp.get(ZombieSpeed_I.NAME),generalUp.get(ZombieConversion.NAME));
            generalUp.get(ZombieHealth_I.NAME).addChildren(generalUp.get(ZombieHealth_II.NAME),generalUp.get(ZombieSpawnRate_I.NAME));
            //tier 2
            generalUp.get(ZombieAttack_II.NAME).addChildren(generalUp.get(ZombieAttack_III.NAME),generalUp.get(ZombieAwareRange.NAME));
            generalUp.get(ZombieHealth_II.NAME).addChildren(generalUp.get(ZombieHealth_III.NAME),generalUp.get(ZombieRegeneration.NAME));
            //tier 3
            generalUp.get(ZombieAttack_III.NAME).addChildren(generalUp.get(ZombieAttack_IV.NAME),generalUp.get(ZombieSpeed_II.NAME));
            generalUp.get(ZombieHealth_III.NAME).addChildren(generalUp.get(ZombieHealth_IV.NAME),generalUp.get(ZombieReduction.NAME),generalUp.get(ZombieLifeSteal.NAME));

        }

        //Trophy
        {
            //BulletFired
            trophyAncestor.addChildren(generalUp.get(BulletFired_I.NAME));
            generalUp.get(BulletFired_I.NAME).addChildren(generalUp.get(BulletFired_II.NAME));
            generalUp.get(BulletFired_II.NAME).addChildren(generalUp.get(BulletFired_III.NAME));
            generalUp.get(BulletFired_III.NAME).addChildren(generalUp.get(BulletFired_IV.NAME));

            //HumanDeath
            trophyAncestor.addChildren(generalUp.get(HumanDeath_I.NAME));
            generalUp.get(HumanDeath_I.NAME).addChildren(generalUp.get(HumanDeath_II.NAME));
            generalUp.get(HumanDeath_II.NAME).addChildren(generalUp.get(HumanDeath_III.NAME));
            generalUp.get(HumanDeath_III.NAME).addChildren(generalUp.get(HumanDeath_IV.NAME));

            //SpendEnergy
            trophyAncestor.addChildren(generalUp.get(SpendEnergy_I.NAME));
            generalUp.get(SpendEnergy_I.NAME).addChildren(generalUp.get(SpendEnergy_II.NAME));
            generalUp.get(SpendEnergy_II.NAME).addChildren(generalUp.get(SpendEnergy_III.NAME));
            generalUp.get(SpendEnergy_III.NAME).addChildren(generalUp.get(SpendEnergy_IV.NAME));

            //TotalBlood
            trophyAncestor.addChildren(generalUp.get(TotalBlood_I.NAME));
            generalUp.get(TotalBlood_I.NAME).addChildren(generalUp.get(TotalBlood_II.NAME));
            generalUp.get(TotalBlood_II.NAME).addChildren(generalUp.get(TotalBlood_III.NAME));
            generalUp.get(TotalBlood_III.NAME).addChildren(generalUp.get(TotalBlood_IV.NAME));

            //TotalDamage
            trophyAncestor.addChildren(generalUp.get(TotalDamage_I.NAME));
            generalUp.get(TotalDamage_I.NAME).addChildren(generalUp.get(TotalDamage_II.NAME));
            generalUp.get(TotalDamage_II.NAME).addChildren(generalUp.get(TotalDamage_III.NAME));
            generalUp.get(TotalDamage_III.NAME).addChildren(generalUp.get(TotalDamage_IV.NAME));

            //TotalImprovement
            trophyAncestor.addChildren(generalUp.get(TotalImprovement_I.NAME));
            generalUp.get(TotalImprovement_I.NAME).addChildren(generalUp.get(TotalImprovement_II.NAME));
            generalUp.get(TotalImprovement_II.NAME).addChildren(generalUp.get(TotalImprovement_III.NAME));
            generalUp.get(TotalImprovement_III.NAME).addChildren(generalUp.get(TotalImprovement_IV.NAME));

            //TotalMovement
            trophyAncestor.addChildren(generalUp.get(TotalMovement_I.NAME));
            generalUp.get(TotalMovement_I.NAME).addChildren(generalUp.get(TotalMovement_II.NAME));
            generalUp.get(TotalMovement_II.NAME).addChildren(generalUp.get(TotalMovement_III.NAME));
            generalUp.get(TotalMovement_III.NAME).addChildren(generalUp.get(TotalMovement_IV.NAME));

            //TotalTrophies
            trophyAncestor.addChildren(generalUp.get(TotalTrophies_I.NAME));
            generalUp.get(TotalTrophies_I.NAME).addChildren(generalUp.get(TotalTrophies_II.NAME));
            generalUp.get(TotalTrophies_II.NAME).addChildren(generalUp.get(TotalTrophies_III.NAME));
        }

        //Weapons
        {

        }

    }

    public void createPrerequisite(){

        //Resource Management
        {
            //tier 2
            generalUp.get(BloodTickle_I.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(BloodCapacity_I.NAME),5));
            generalUp.get(EnergyProduction_I.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(EnergyCapacity_I.NAME),5));

            //tier 3
            generalUp.get(BloodGainZombie.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(BloodTickle_I.NAME),5));

        }

        //Zombie Upgrade
        {
            //Attack
            //tier 1
            generalUp.get(ZombieSpeed_I.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(ZombieAttack_I.NAME),10));
            generalUp.get(ZombieConversion.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(ZombieAttack_I.NAME),25));
            //tier 2
            generalUp.get(ZombieAttack_II.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(ZombieAttack_I.NAME),20));
            generalUp.get(ZombieAwareRange.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(ZombieAttack_II.NAME),10));
            //tier 3
            generalUp.get(ZombieAttack_III.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(ZombieAttack_II.NAME),20));
            generalUp.get(ZombieSpeed_II.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(ZombieAttack_III.NAME),10));


            //Defence
            //tier 1
            generalUp.get(ZombieSpawnRate_I.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(ZombieHealth_I.NAME),10));
            //tier2
            generalUp.get(ZombieHealth_II.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(ZombieHealth_I.NAME),20));
            generalUp.get(ZombieRegeneration.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(ZombieHealth_II.NAME),10));
            generalUp.get(ZombieReduction.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(ZombieHealth_II.NAME),25));
            //tier3
            generalUp.get(ZombieHealth_III.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(ZombieHealth_II.NAME),20));
            generalUp.get(ZombieLifeSteal.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(ZombieHealth_III.NAME),25));


        }

        //Trophy
        {
            //BulletFired
            generalUp.get(BulletFired_II.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(BulletFired_I.NAME),1));
            generalUp.get(BulletFired_III.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(BulletFired_II.NAME),1));
            generalUp.get(BulletFired_IV.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(BulletFired_III.NAME),1));

            //HumanDeath
            generalUp.get(HumanDeath_II.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(HumanDeath_I.NAME),1));
            generalUp.get(HumanDeath_III.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(HumanDeath_II.NAME),1));
            generalUp.get(HumanDeath_IV.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(HumanDeath_III.NAME),1));

            //SpendEnergy
            generalUp.get(SpendEnergy_II.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(SpendEnergy_I.NAME),1));
            generalUp.get(SpendEnergy_III.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(SpendEnergy_II.NAME),1));
            generalUp.get(SpendEnergy_IV.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(SpendEnergy_III.NAME),1));

            //TotalBlood
            generalUp.get(TotalBlood_II.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(TotalBlood_I.NAME),1));
            generalUp.get(TotalBlood_III.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(TotalBlood_II.NAME),1));
            generalUp.get(TotalBlood_IV.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(TotalBlood_III.NAME),1));

            //TotalDamage
            generalUp.get(TotalDamage_II.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(TotalDamage_I.NAME),1));
            generalUp.get(TotalDamage_III.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(TotalDamage_II.NAME),1));
            generalUp.get(TotalDamage_IV.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(TotalDamage_III.NAME),1));

            //TotalImprovement
            generalUp.get(TotalImprovement_II.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(TotalImprovement_I.NAME),1));
            generalUp.get(TotalImprovement_III.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(TotalImprovement_II.NAME),1));
            generalUp.get(TotalImprovement_IV.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(TotalImprovement_III.NAME),1));

            //TotalMovement
            generalUp.get(TotalMovement_II.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(TotalMovement_I.NAME),1));
            generalUp.get(TotalMovement_III.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(TotalMovement_II.NAME),1));
            generalUp.get(TotalMovement_IV.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(TotalMovement_III.NAME),1));

            //TotalTrophies
            generalUp.get(TotalTrophies_II.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(TotalTrophies_I.NAME),1));
            generalUp.get(TotalTrophies_III.NAME).addPrerequisite(TreeNode.createPair(generalUp.get(TotalTrophies_II.NAME),1));


        }

    }

    public void setWeapons(){
        weaponArray.add(new BasicAttackUnlock());
        weaponArray.add(new BurstAttackUnlock());
        weaponArray.add(new CriticAttackUnlock());
        weaponArray.add(new PowerAttackUnlock());
        weaponArray.add(new QuickAttackUnlock());
        Gdx.app.log(TAG,"WeaponSize: "+weaponArray.size);
    }

    public void setPrestigeArray(){
        prestigeArray.add(new BloodCapacityPrestige());
        prestigeArray.add(new BloodGainPrestige());
        prestigeArray.add(new EnergyCapacityPrestige());
        prestigeArray.add(new GeneCapacityPrestige());
        prestigeArray.add(new GeneGainPrestige());
        prestigeArray.add(new ReduceEnergyAdditionPrestige());
        prestigeArray.add(new ReduceSpawnCooldownPrestige());
        prestigeArray.add(new UnlockAutoZombieUpgradesPrestige());
    }

    public void setUpgradeBehaviours(){
        resourceManArray.clear();
        resourceManAncestor.getUpgradeBehaviours(resourceManArray);
        sort.sort(resourceManArray,comparator);

        zombieUpArray.clear();
        zombiesUpAncestor.getUpgradeBehaviours(zombieUpArray);
        sort.sort(zombieUpArray,comparator);

        int totalImp=0;//TotalImprovement
        for (UpgradeBehaviour upgradeBehaviour:trophyArray)
            totalImp+=upgradeBehaviour.currentCount();
        //PlayerStatics.getInstance().totalImprovement=totalImp;//TotalImprovement
        PlayerStatics.getInstance().totalMovement.set(totalImp);

        trophyArray.clear();
        trophyAncestor.getUpgradeBehaviours(trophyArray);
        sort.sort(trophyArray,comparator);

        int totalTrophy=0;//TotalTrophy
        for (UpgradeBehaviour trophyUpgrade:trophyArray)
            if (trophyUpgrade.currentCount()==1)
                totalTrophy++;
        //PlayerStatics.getInstance().totalTrophy=totalTrophy;//TotalTrophy
        PlayerStatics.getInstance().totalTrophy.set(totalTrophy);


        sort.sort(weaponArray,comparator);

    }

    public class AbilityLevel{
        public float[] abilityLevelPoints=new float[]{0,0,40,120,220,350,600};
        public int currentAbilityLevel=1;
        public float currentAbilityPoint;

        private AbilityLevel(){
            newLevel(1);
            newLevel(2);
        }

        public void addPoint(float point){
            currentAbilityPoint+=point;
            if (currentAbilityPoint>abilityLevelPoints[currentAbilityLevel+1]){
                currentAbilityLevel++;
                newLevel(currentAbilityLevel);
            }
        }



        public void newLevel(int i){
            switch (i){
                case 1:
                    abilityArray.add(new Attack_Health_Upgrade());
                    abilityArray.add(new AttackToTime_Fire_Upgrade());
                    abilityArray.add(new GetAttacked_Health_Upgrade());
                    abilityArray.add(new StateTimeFollow_Speed_Upgrade());
                    abilityArray.add(new Time_Speed_Upgrade());
                    break;
                case 2:
                    abilityArray.add(new AttackToTime_Poison_Upgrade());
                    abilityArray.add(new AttackToTime_Weak_Upgrade());
                    abilityArray.add(new Died_Explosion_I_Upgrade());
                    abilityArray.add(new GetAttackedTime_Speed_Upgrade());
                    abilityArray.add(new StateIdle_Speed_Upgrade());
                    break;
                case 3:
                    abilityArray.add(new Attack_IncMaxHealth_Upgrade());
                    abilityArray.add(new Died_ExplosionFire_Upgrade());
                    abilityArray.add(new GetAttacked_Aware_Upgrade());
                    abilityArray.add(new StateIdle_Resistance_Upgrade());
                    break;
                case 4:
                    break;
                case 5:
                    break;
            }
            Gdx.app.log(TAG,"New level: "+i);
        }

    }
}
