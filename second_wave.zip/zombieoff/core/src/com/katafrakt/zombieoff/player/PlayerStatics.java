package com.katafrakt.zombieoff.player;

import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ArrayMap;
import com.katafrakt.zombieoff.entities.EntityType;
import com.katafrakt.zombieoff.ui.desicions.ChangeInterface;

import java.util.HashMap;

public class PlayerStatics {
    private static PlayerStatics initiate;

    private PlayerStatics(){
        resourceSystem =new ResourceSystem();

        totalDeath.put(EntityType.CIVILIAN,0);
        totalDeath.put(EntityType.POLICE,0);
        totalDeath.put(EntityType.MERCENARY,0);
        totalDeath.put(EntityType.VETERAN,0);

        totalDeath.put(EntityType.BASIC_ZOMBIE,0);
        totalDeath.put(EntityType.GIANT_ZOMBIE,0);
        totalDeath.put(EntityType.RANGED_ZOMBIE,0);
    }
    public static PlayerStatics getInstance(){if (initiate==null) initiate=new PlayerStatics();return initiate;}

    public ResourceSystem resourceSystem;

    /*
    public float bulletFired;
    public float humanDeath;
    public float spendEnergy;
    public float totalBlood;
    public float totalDamage;
    public float totalImprovement;
    public float totalMovement;
    public float totalTrophy;
     */

    public EventFloat bulletFired=new EventFloat();
    public EventFloat humanDeath=new EventFloat();
    public EventFloat spendEnergy=new EventFloat();
    public EventFloat totalBlood=new EventFloat();
    public EventFloat totalDamage=new EventFloat();
    public EventFloat totalImprovement=new EventFloat();
    public EventFloat totalMovement=new EventFloat();
    public EventFloat totalTrophy=new EventFloat();

    public ArrayMap<EntityType,Integer> totalDeath=new ArrayMap<EntityType, Integer>(){
        @Override
        public Integer get(EntityType key) {
            if (super.get(key)==null)
                super.put(key,0);
            return super.get(key);
        }
    };

    public static class EventFloat{
        public Array<ChangeInterface> listeners=new Array<>();
        private float variable;
        public float get(){
            return variable;
        }
        public void set(float variable){
            this.variable=variable;
            for (ChangeInterface listener:listeners)
                listener.change();
        }
        public void add(float variable){
            this.variable+=variable;
            for (ChangeInterface listener:listeners)
                listener.change();
        }

        public static void addListener(EventFloat eventFloat,ChangeInterface changeInterface){
            eventFloat.listeners.add(changeInterface);
        }
    }
}
