package com.katafrakt.zombieoff.player;

import com.badlogic.ashley.core.EntitySystem;
import com.katafrakt.zombieoff.game.ResourceType;

public class ResourceSystem extends EntitySystem {
    private static final String TAG= ResourceSystem.class.getSimpleName();



    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        ResourceType.getInstance().ENERGY.production(deltaTime);
        ResourceType.getInstance().BLOOD.production(deltaTime);
        ResourceType.getInstance().GENE.production(deltaTime);
        ResourceType.getInstance().BRAIN.production(deltaTime);
    }
}
