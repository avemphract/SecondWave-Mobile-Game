package com.katafrakt.zombieoff.ai.states;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ai.fsm.State;
import com.badlogic.gdx.ai.msg.Telegram;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agents.AgentComponent;
import com.katafrakt.zombieoff.ashley.components.agents.VeteranAgentComponent;
import com.katafrakt.zombieoff.entities.BulletType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.weapons.RangedWeapon;
import com.katafrakt.zombieoff.managers.GeneralOrganizer;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.player.PlayerStatics;
import com.katafrakt.zombieoff.ui.EntityUI;
import com.katafrakt.zombieoff.utilities.Utility;

import java.util.Random;


public enum  VeteranState implements State<VeteranAgentComponent> {
    IDLE(){
        float idleMovProb;


        private void setTargetPosition(VeteranAgentComponent agent){
            agent.targetPosition.set(agent.transform.pos.x+4* Point.UNIT*(0.5f-random.nextFloat()),agent.transform.pos.y+4*Point.UNIT*(0.5f-random.nextFloat()));
            agent.path=mapManager.pointGraph.findPath(agent.currentPoint,mapManager.pointGraph.nearestPoint(agent.targetPosition));
            agent.iterator=agent.path.iterator();
            agent.targetPoint=agent.iterator.next();

            if (agent.targetPoint.x==agent.currentPoint.x){
                agent.targetPosition.set(agent.targetPoint.x+Point.UNIT*random.nextFloat()-Point.UNIT/2,agent.targetPoint.y);
            }
            else {
                agent.targetPosition.set(agent.targetPoint.x,agent.targetPoint.y+Point.UNIT*random.nextFloat()-Point.UNIT/2);
            }

            agent.startTime=agent.currentTime;
            agent.progressTime= (float) Math.pow(Math.pow(agent.targetPosition.x-agent.transform.pos.x,2)+Math.pow(agent.targetPosition.y-agent.transform.pos.y,2),0.5f)/agent.creature.getSpeed();
            agent.direction.set(agent.targetPosition.x-agent.transform.pos.x,agent.targetPosition.y-agent.transform.pos.y).scl(1/agent.direction.len());
        }
        @Override
        public void enter(VeteranAgentComponent agent) {
            generalStateEnter(agent);
            agent.targetPosActive=false;
        }

        @Override
        public void update(VeteranAgentComponent agent) {
            float deltaTime = generalUpdate(agent);
            if (agent.currentTime>agent.count){
                findTarget(agent);
            }
            if (agent.target!=null&&agent.targetCreature.isAlive==true){
                if (agent.awareness<1){
                    agent.awareness+=deltaTime;
                    if (agent.awareness>1)
                        agent.awareness=1;
                }
                if (agent.awareness==1){
                    agent.stateMachine.changeState(FOLLOW);
                }
            }
            else {
                agent.awareness-=deltaTime;
                if (agent.awareness<0)
                    agent.awareness=0;
            }

            if (agent.targetPosActive&&agent.awareness<1){
                if (agent.targetPoint!=null){
                    //PlayerStatics.getInstance().totalMovement.set(PlayerStatics.getInstance().totalMovement.get()+agent.creatureComponent.getSpeed()*deltaTime);//TotalMovement
                    PlayerStatics.getInstance().totalMovement.add(agent.creature.getSpeed()*deltaTime);
                    //agent.direction.set(agent.targetPosition.x-agent.transformComponent.pos.x,agent.targetPosition.y-agent.transformComponent.pos.y).scl(1/agent.direction.len());
                    if(agent.progressTime+agent.startTime>agent.currentTime){
                        agent.transform.pos.x+=agent.direction.x*agent.creature.getSpeed()*deltaTime;
                        agent.transform.pos.y+=agent.direction.y*agent.creature.getSpeed()*deltaTime;
                    }
                    else{
                        //if (tempVector.set(agent.targetPosition.x-agent.transform.pos.x,agent.targetPosition.y-agent.transform.pos.y).len2()<2f){
                        if (agent.iterator.hasNext()){
                            //agent.currentPoint=agent.targetPoint;
                            agent.targetPoint=agent.iterator.next();
                            if (agent.targetPoint.x==agent.currentPoint.x){
                                agent.targetPosition.set(agent.targetPoint.x+Point.UNIT*random.nextFloat()-Point.UNIT/2,agent.targetPoint.y);
                            }
                            else {
                                agent.targetPosition.set(agent.targetPoint.x,agent.targetPoint.y+Point.UNIT*random.nextFloat()-Point.UNIT/2);
                            }
                            agent.direction.set(agent.targetPosition.x-agent.transform.pos.x,agent.targetPosition.y-agent.transform.pos.y).scl(1/agent.direction.len());

                        }
                        else {
                            agent.targetPoint=null;
                            if (random.nextFloat()>idleMovProb)
                                setTargetPosition(agent);
                        }
                        agent.startTime=agent.currentTime;
                        agent.progressTime= (float) Math.pow(Math.pow(agent.targetPosition.x-agent.transform.pos.x,2)+Math.pow(agent.targetPosition.y-agent.transform.pos.y,2),0.5f)/agent.creature.getSpeed();
                    }
                }
                else if (agent.currentTime>agent.count){
                    if (random.nextFloat()>idleMovProb)
                        setTargetPosition(agent);
                }
            }
            else {
                float rng=random.nextFloat();
                if (rng>0f){
                    agent.targetPosActive=true;
                    agent.targetPoint=mapManager.pointGraph.nearestPoint(tempVector.set(agent.transform.pos.x+2*Point.UNIT*(0.5f-random.nextFloat()*1),agent.transform.pos.y+2*Point.UNIT*(0.5f-random.nextFloat()*1)));

                    agent.targetPosition.set(agent.targetPoint.x+Point.UNIT*(0.5f-random.nextFloat()*1),agent.targetPoint.y+Point.UNIT*(0.5f-random.nextFloat()*1));
                    agent.direction.set(agent.targetPosition.x-agent.transform.pos.x,agent.targetPosition.y-agent.transform.pos.y).scl(1f/agent.direction.len());
                    setTargetPosition(agent);
                }
            }
            generalUpdateEnd(agent);
        }

        @Override
        public void exit(VeteranAgentComponent entity) {

        }

        @Override
        public boolean onMessage(VeteranAgentComponent entity, Telegram telegram) {
            return false;
        }
    },
    ATTACK() {
        @Override
        public void enter(VeteranAgentComponent agent) {
            generalStateEnter(agent);
        }

        @Override
        public void update(VeteranAgentComponent agent) {
            float deltaTime=generalUpdate(agent);

            if (agent.target==null||agent.targetCreature.isAlive==false){
                agent.stateMachine.changeState(IDLE);
                return;
            }

            if (agent.nextAttackTime <agent.currentTime){
                float distance=agent.transform.distance(agent.targetTransform);
                switch (agent.primaryWeapon.bulletType){
                    case LINE:
                        if (!mapManager.pointGraph.anyObstacle(agent.currentPoint, agent.targetAgent.currentPoint) && distance<agent.primaryWeapon.range*Point.UNIT){
                            agent.nextAttackTime =agent.currentTime+agent.primaryWeapon.getAttackRate(agent.creature);
                            agent.primaryWeapon.abilityControllers.clear();
                            agent.updateAbilities(AbilityController.Type.ATTACK);
                            agent.primaryWeapon.attack(agent.creature,agent.targetCreature);
                        }
                        else{
                            Gdx.app.log(TAG,"AttToFoll");
                            agent.stateMachine.changeState(FOLLOW);
                        }
                        break;
                    case AIRBORNE:
                        if(agent.targetAgent.currentPoint.roofed==false && distance<agent.primaryWeapon.range*Point.UNIT){
                            agent.nextAttackTime =agent.currentTime+agent.primaryWeapon.getAttackRate(agent.creature);
                            agent.primaryWeapon.abilityControllers.clear();
                            agent.updateAbilities(AbilityController.Type.ATTACK);
                            agent.primaryWeapon.attack(agent.creature,agent.targetCreature);
                        }
                        else {
                            findInRange(agent);
                            if (agent.target==null){
                                agent.stateMachine.changeState(IDLE);
                            }
                            else{
                                agent.stateMachine.changeState(FOLLOW);
                            }
                        }
                        break;
                    case UNDERGROUND:
                        if (distance<agent.primaryWeapon.range*Point.UNIT){
                            agent.nextAttackTime =agent.currentTime+agent.primaryWeapon.getAttackRate(agent.creature);
                            agent.primaryWeapon.abilityControllers.clear();
                            agent.updateAbilities(AbilityController.Type.ATTACK);
                            agent.primaryWeapon.attack(agent.creature,agent.targetCreature);
                        }
                        else{
                            agent.stateMachine.changeState(FOLLOW);
                        }

                }
            }
            else if (agent.nextAttackTime <agent.currentTime+agent.primaryWeapon.getAttackRate(agent.creature)-1){
                if (agent.primaryWeapon.range< agent.transform.distance(agent.targetTransform)/Point.UNIT){
                    agent.stateMachine.changeState(FOLLOW);
                }
                else if(agent.transform.distance(agent.targetTransform)/Point.UNIT<(agent.primaryWeapon.recommended.min+agent.primaryWeapon.recommended.max)/2) {
                    agent.stateMachine.changeState(RETREAT);
                }

            }
            generalUpdateEnd(agent);
        }

        @Override
        public void exit(VeteranAgentComponent entity) {

        }

        @Override
        public boolean onMessage(VeteranAgentComponent entity, Telegram telegram) {
            return false;
        }
    },
    FOLLOW() {

        protected void createPath(VeteranAgentComponent agent){
            agent.path=mapManager.pointGraph.findPath(agent.currentPoint,mapManager.pointGraph.attackPosition(agent.currentPoint,agent.targetAgent.currentPoint,agent.primaryWeapon.range,((RangedWeapon)agent.primaryWeapon).bulletType));
            agent.iterator=agent.path.iterator();
            agent.nextPoint=agent.iterator.next();
            if (agent.nextPoint==agent.currentPoint&&agent.iterator.hasNext())
                agent.nextPoint=agent.iterator.next();
        }

        @Override
        public void enter(VeteranAgentComponent agent) {
            generalStateEnter(agent);
            createPath(agent);
        }

        @Override
        public void update(VeteranAgentComponent agent) {
            float deltaTime = generalUpdate(agent);
            if (agent.target==null||agent.targetCreature.isAlive==false){
                agent.stateMachine.changeState(IDLE);
                return;
            }

            if (agent.currentTime>agent.count){
                Entity entity=findInRange(agent);
                if (entity!=null){
                    agent.target=entity;
                    agent.targetTransform=Mappers.transformComponents.get(entity);
                    agent.targetCreature= Mappers.creatureComponents.get(entity);
                    agent.targetAgent= Mappers.agentComponents(entity);
                }
                createPath(agent);
                switch (agent.primaryWeapon.bulletType){
                    case LINE:
                        if (!mapManager.pointGraph.anyObstacle(agent.currentPoint,agent.targetAgent.currentPoint)&&agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT) {
                            agent.stateMachine.changeState(ATTACK);
                        }
                        break;
                    case AIRBORNE:
                        if (agent.targetAgent.currentPoint.roofed)
                            findTarget(agent);
                        else if (agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT)
                            agent.stateMachine.changeState(ATTACK);
                        break;
                    case UNDERGROUND:
                        if (agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT)
                            agent.stateMachine.changeState(ATTACK);
                        break;
                }
            }

            if (agent.nextPoint!=null){
                PlayerStatics.getInstance().totalMovement.add(agent.creature.getSpeed()*deltaTime);
                //agent.direction.set(agent.targetPosition.x-agent.transformComponent.pos.x,agent.targetPosition.y-agent.transformComponent.pos.y).scl(1/agent.direction.len());
                if(agent.currentTime<agent.startTime+agent.progressTime) {
                    agent.transform.pos.x += agent.direction.x * agent.creature.getSpeed() * deltaTime;
                    agent.transform.pos.y += agent.direction.y * agent.creature.getSpeed() * deltaTime;
                }
                else {
                    if (agent.iterator.hasNext()){
                        agent.nextPoint=agent.iterator.next();
                        if (agent.nextPoint.x==agent.currentPoint.x){
                            agent.targetPosition.set(agent.nextPoint.x+Point.UNIT*random.nextFloat()-Point.UNIT/2,agent.nextPoint.y);
                        }
                        else {
                            agent.targetPosition.set(agent.nextPoint.x,agent.nextPoint.y+Point.UNIT*random.nextFloat()-Point.UNIT/2);
                        }
                        agent.startTime=agent.currentTime;
                        agent.progressTime= (float) Math.pow(Math.pow(agent.targetPosition.x-agent.transform.pos.x,2)+Math.pow(agent.targetPosition.y-agent.transform.pos.y,2),0.5f)/agent.creature.getSpeed();
                        agent.direction.set(agent.targetPosition.x-agent.transform.pos.x,agent.targetPosition.y-agent.transform.pos.y).scl(1/agent.direction.len());
                    }
                    else {
                        agent.nextPoint=null;
                    }
                }
            }
            else {
                createPath(agent);
            }
        }

        @Override
        public void exit(VeteranAgentComponent entity) {

        }

        @Override
        public boolean onMessage(VeteranAgentComponent entity, Telegram telegram) {
            return false;
        }
    },
    RETREAT() {

        protected void createPath(VeteranAgentComponent agent){
            agent.path=mapManager.pointGraph.findPath(agent.currentPoint,mapManager.pointGraph.nearestPoint(agent.targetPosition));
            agent.iterator=agent.path.iterator();

            agent.nextPoint=agent.iterator.next();
            if (agent.nextPoint==agent.currentPoint&&agent.iterator.hasNext())
                agent.nextPoint=agent.iterator.next();
        }

        @Override
        public void enter(VeteranAgentComponent agent) {
            generalStateEnter(agent);
            setFleePosition(agent);
            createPath(agent);
        }

        @Override
        public void update(VeteranAgentComponent agent) {
            float deltaTime = generalUpdate(agent);
            if (agent.count>agent.currentTime)
                findTarget(agent);

            if (agent.target == null || agent.targetCreature.isAlive==false){
                agent.stateMachine.changeState(IDLE);
                return;
            }
            if (agent.nextAttackTime +agent.primaryWeapon.getAttackRate(agent.creature)<agent.currentTime){
                agent.stateMachine.changeState(ATTACK);
                return;
            }
            if (agent.count>agent.currentTime){
                setFleePosition(agent);
                createPath(agent);
            }
            if (agent.nextPoint!=null){
                PlayerStatics.getInstance().totalMovement.add(agent.creature.getSpeed()*deltaTime);
                //agent.direction.set(agent.targetPosition.x-agent.transformComponent.pos.x,agent.targetPosition.y-agent.transformComponent.pos.y).scl(1/agent.direction.len());
                if(agent.currentTime<agent.startTime+agent.progressTime) {
                    agent.transform.pos.x += agent.direction.x * agent.creature.getSpeed() * deltaTime;
                    agent.transform.pos.y += agent.direction.y * agent.creature.getSpeed() * deltaTime;
                }
                else {
                    if (agent.iterator.hasNext()){
                        agent.nextPoint=agent.iterator.next();
                        if (agent.nextPoint.x==agent.currentPoint.x){
                            agent.targetPosition.set(agent.nextPoint.x+Point.UNIT*random.nextFloat()-Point.UNIT/2,agent.nextPoint.y);
                        }
                        else {
                            agent.targetPosition.set(agent.nextPoint.x,agent.nextPoint.y+Point.UNIT*random.nextFloat()-Point.UNIT/2);
                        }
                        agent.startTime=agent.currentTime;
                        agent.progressTime= (float) Math.pow(Math.pow(agent.targetPosition.x-agent.transform.pos.x,2)+Math.pow(agent.targetPosition.y-agent.transform.pos.y,2),0.5f)/agent.creature.getSpeed();
                        agent.direction.set(agent.targetPosition.x-agent.transform.pos.x,agent.targetPosition.y-agent.transform.pos.y).scl(1/agent.direction.len());
                    }
                    else {
                        agent.nextPoint=null;
                    }
                }
            }
            else {
                setFleePosition(agent);
                createPath(agent);
            }
            generalUpdateEnd(agent);
        }

        @Override
        public void exit(VeteranAgentComponent entity) {

        }

        @Override
        public boolean onMessage(VeteranAgentComponent entity, Telegram telegram) {
            return false;
        }
    };
    private static final String TAG= VeteranState.class.getSimpleName();
    MapManager mapManager;
    Random random;
    Vector2 tempVector=new Vector2();

    VeteranState() {
        mapManager=MapManager.getInstance();
        random= GeneralOrganizer.getInstance().random;
    }

    protected void findTarget(VeteranAgentComponent agent){
        agent.target=null;
        agent.targetTransform=null;
        agent.targetCreature=null;
        agent.targetAgent=null;
        for (int i=0;i<=agent.awareRadius;i++){
            Array<Point> points= Utility.pointArrayPool.obtain();
            points=mapManager.pointGraph.getRangePoints(points,agent.currentPoint,i);
            for (int j=0;j<points.size;j++){
                if (points.get(j).zombies.size!=0){
                    agent.target=points.get(j).zombies.random();
                    agent.targetTransform= Mappers.transformComponents.get(agent.target);
                    agent.targetCreature= Mappers.creatureComponents.get(agent.target);
                    agent.targetAgent=Mappers.agentComponents(agent.target);
                    Utility.pointArrayPool.free(points);
                    return;
                }
            }
            Utility.pointArrayPool.free(points);

        }
    }

    protected Entity findInRange(VeteranAgentComponent agent){
        for (int i=0;i<=agent.primaryWeapon.range;i++){
            Array<Point> points=Utility.pointArrayPool.obtain();
            points=mapManager.pointGraph.getRangePoints(points,agent.currentPoint,i);
            for (int j=0; j<points.size; j++){
                if (points.get(j).roofed && ((RangedWeapon)agent.primaryWeapon).bulletType== BulletType.AIRBORNE)
                    continue;
                if (((RangedWeapon)agent.primaryWeapon).bulletType==BulletType.LINE&&mapManager.pointGraph.anyObstacle(agent.currentPoint,points.get(j)))
                    continue;

                if (points.get(j).zombies.size!=0){
                    Entity result=points.get(j).zombies.random();
                    Utility.pointArrayPool.free(points);
                    return result;
                }
            }
            Utility.pointArrayPool.free(points);
        }
        return null;
    }

    protected void setFleePosition(VeteranAgentComponent agent){
        float x=0,y=0;


        for (int i=0;i<=agent.primaryWeapon.recommended.max;i++){
            Array<Point> points =Utility.pointArrayPool.obtain();
            points=mapManager.pointGraph.getRangePoints(points,agent.currentPoint,i);
            for (int j=0;j<points.size;j++){
                if (points.get(j).zombies.size!=0){
                    x+=(points.get(j).x - agent.currentPoint.x)/i/i;
                    y+=(points.get(j).y - agent.currentPoint.y)/i/i;
                }
            }
            Utility.pointArrayPool.free(points);
        }
        float length= (float) Math.pow(Math.pow(x,2)+Math.pow(y,2),0.5f);
        x/=length;
        y/=length;
        //Gdx.app.log(TAG,"Result:"+x+","+y);
        agent.targetPosition.set(agent.transform.pos).add(-x*agent.primaryWeapon.recommended.max,-y*agent.primaryWeapon.recommended.max);
    }


    protected void generalStateEnter(AgentComponent agent){
        //Gdx.app.log(TAG,agent.stateMachine.getCurrentState().toString());
        if (EntityUI.getEntity()==agent.entity)
            EntityUI.entityUI.entityStateChange();
        agent.count=0;
        agent.updateAbilities(AbilityController.Type.STATE);
    }

    protected float generalUpdate(AgentComponent agent){
        float delta= MathUtils.clamp(Gdx.graphics.getDeltaTime(),0,0.1f);
        agent.currentTime+=delta;
        if (agent.currentPoint!=MapManager.getInstance().pointGraph.nearestPoint(agent.transform.pos)){
            agent.currentPoint.humans.removeValue(agent.entity,true);
            agent.currentPoint=MapManager.getInstance().pointGraph.nearestPoint(agent.transform.pos);
            agent.currentPoint.humans.add(agent.entity);
        }
        agent.updateAbilities(AbilityController.Type.UPDATE);
        return delta;
    }

    protected void generalUpdateEnd(AgentComponent agent){
        if (agent.currentTime>agent.count) {
            agent.count = agent.currentTime + 1;
        }
    }
}
