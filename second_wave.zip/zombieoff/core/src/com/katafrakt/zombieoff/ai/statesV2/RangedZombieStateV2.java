package com.katafrakt.zombieoff.ai.statesV2;

import com.badlogic.gdx.ai.fsm.State;
import com.badlogic.gdx.ai.msg.Telegram;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ai.pfa.PointGraph;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agentsV2.RangedZombieAgentComponentV2;
import com.katafrakt.zombieoff.ashley.systems.agents.AgentV2System;
import com.katafrakt.zombieoff.entities.BulletType;
import com.katafrakt.zombieoff.game.StateType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.ui.EntityUI;

public enum RangedZombieStateV2 implements State<RangedZombieAgentComponentV2> {
    WAIT(){
        @Override
        public void enter(RangedZombieAgentComponentV2 agent) {
            agent.currentState=StateType.IDLE;
            agent.updateAbilities(AbilityController.Type.STATE);


            if (EntityUI.getEntity()==agent.entity)
                EntityUI.entityUI.entityStateChange();
        }

        @Override
        public void update(RangedZombieAgentComponentV2 agent) {
            findTarget(agent);
            if (agent.target!=null){
                agent.stateMachine.changeState(FOLLOW);
                return;
            }
            if (MathUtils.randomBoolean(0.5f)){
                agent.stateMachine.changeState(WALK);
            }
            else
                agent.nextTick= AgentV2System.totalTime+1+MathUtils.random();
        }

        @Override
        public void exit(RangedZombieAgentComponentV2 agent) {

        }

        @Override
        public boolean onMessage(RangedZombieAgentComponentV2 agent, Telegram telegram) {
            return false;
        }
    },
    WALK(){
        @Override
        public void enter(RangedZombieAgentComponentV2 agent) {
            agent.targetPoint=pointGraph.nearestPoint(agent.currentPoint.x+(0.5f-MathUtils.random())*Point.UNIT*3,agent.currentPoint.y+(0.5f-MathUtils.random())*Point.UNIT*3);
            agent.iterator=pointGraph.findPath(agent.currentPoint,agent.targetPoint).iterator();
            agent.currentState=StateType.IDLE;

            agent.updateAbilities(AbilityController.Type.STATE);


            if (EntityUI.getEntity()==agent.entity)
                EntityUI.entityUI.entityStateChange();
        }

        @Override
        public void update(RangedZombieAgentComponentV2 agent) {
            if (agent.currentPoint!=pointGraph.nearestPoint(agent.transform.pos)){
                agent.currentPoint.zombies.removeValue(agent.entity,true);
                agent.currentPoint=pointGraph.nearestPoint(agent.transform.pos);
                agent.currentPoint.zombies.add(agent.entity);
            }

            //ToDo scanRate ekle
            if (agent.target!=null){
                agent.nextTick=AgentV2System.totalTime+1;
                agent.stateMachine.changeState(FOLLOW);
            }
            else if (agent.iterator.hasNext()){
                agent.nextPoint=agent.iterator.next();
                agent.nextPosition.set(agent.nextPoint.x+(0.5f-MathUtils.random())*Point.UNIT,agent.nextPoint.y+(0.5f-MathUtils.random())*Point.UNIT);
                float distance= (float) Math.pow(Math.pow(agent.nextPosition.x-agent.transform.pos.x,2)+Math.pow(agent.nextPosition.y-agent.transform.pos.y,2),0.5f);

                agent.velocityComponent.speed.set((agent.nextPosition.x-agent.transform.pos.x)/distance*agent.creature.getSpeed(), (agent.nextPosition.y-agent.transform.pos.y)/distance*agent.creature.getSpeed());
                agent.nextTick=AgentV2System.totalTime + distance/agent.creature.getSpeed();

                //ToDo AnimationName
            }
            else {
                agent.nextTick=AgentV2System.totalTime+1;
                agent.stateMachine.changeState(WAIT);
            }

        }

        @Override
        public void exit(RangedZombieAgentComponentV2 agent) {
            agent.velocityComponent.speed.setZero();
            agent.nextPoint=null;
            if (agent.currentPoint!=pointGraph.nearestPoint(agent.transform.pos)){
                agent.currentPoint.zombies.removeValue(agent.entity,true);
                agent.currentPoint=pointGraph.nearestPoint(agent.transform.pos);
                agent.currentPoint.zombies.add(agent.entity);
            }
        }

        @Override
        public boolean onMessage(RangedZombieAgentComponentV2 entity, Telegram telegram) {
            return false;
        }
    },
    FOLLOW(){
        @Override
        public void enter(RangedZombieAgentComponentV2 agent) {
            agent.targetPoint=pointGraph.attackPosition(agent.currentPoint,agent.targetAgent.currentPoint,agent.primaryWeapon.range,agent.primaryWeapon.bulletType);

            agent.iterator=pointGraph.findPath(agent.currentPoint,agent.targetPoint).iterator();
            agent.currentState=StateType.FOLLOW;

            agent.updateAbilities(AbilityController.Type.STATE);


            if (EntityUI.getEntity()==agent.entity)
                EntityUI.entityUI.entityStateChange();
        }

        @Override
        public void update(RangedZombieAgentComponentV2 agent) {
            if (agent.currentPoint!=pointGraph.nearestPoint(agent.transform.pos)){
                agent.currentPoint.zombies.removeValue(agent.entity,true);
                agent.currentPoint=pointGraph.nearestPoint(agent.transform.pos);
                agent.currentPoint.zombies.add(agent.entity);
            }
            if (!agent.targetCreature.isAlive){
                findTarget(agent);
                if(agent.target==null){
                    agent.stateMachine.changeState(WAIT);
                }
                else {
                    agent.stateMachine.changeState(FOLLOW);
                }
                return;
            }
            if (agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT){
                switch (agent.primaryWeapon.bulletType){
                    case LINE:
                        if (!pointGraph.anyObstacle(agent.currentPoint,agent.targetAgent.currentPoint)){
                            agent.stateMachine.changeState(ATTACK);
                            return;
                        }
                        break;
                    case AIRBORNE:
                        if (agent.targetAgent.currentPoint.roofed){
                            findTarget(agent);
                            if(agent.target==null){
                                agent.stateMachine.changeState(WAIT);
                            }
                            else {
                                agent.stateMachine.changeState(FOLLOW);
                            }
                        }
                        else {
                            agent.stateMachine.changeState(ATTACK);
                        }
                        return;
                    case UNDERGROUND:
                        agent.stateMachine.changeState(ATTACK);
                        break;
                }
            }

            if (agent.iterator.hasNext()){
                agent.nextPoint = agent.iterator.next();
                agent.nextPosition.set(agent.nextPoint.x+(0.5f-MathUtils.random())*Point.UNIT,agent.nextPoint.y+(0.5f-MathUtils.random())*Point.UNIT);

                float distance= (float) Math.pow(Math.pow(agent.nextPosition.x-agent.transform.pos.x,2)+Math.pow(agent.nextPosition.y-agent.transform.pos.y,2),0.5f);

                agent.velocityComponent.speed.set((agent.nextPosition.x-agent.transform.pos.x)/distance*agent.creature.getSpeed(), (agent.nextPosition.y-agent.transform.pos.y)/distance*agent.creature.getSpeed());
                agent.nextTick=AgentV2System.totalTime + distance/agent.creature.getSpeed();

            }
        }

        @Override
        public void exit(RangedZombieAgentComponentV2 agent) {
            agent.velocityComponent.speed.setZero();
            agent.nextPoint=null;
        }

        @Override
        public boolean onMessage(RangedZombieAgentComponentV2 entity, Telegram telegram) {
            return false;
        }
    },
    ATTACK(){
        @Override
        public void enter(RangedZombieAgentComponentV2 agent) {
            agent.currentState=StateType.ATTACK;

            agent.updateAbilities(AbilityController.Type.ATTACK);


            if (EntityUI.getEntity()==agent.entity)
                EntityUI.entityUI.entityStateChange();
        }

        @Override
        public void update(RangedZombieAgentComponentV2 agent) {
            //ToDo set false animation stop
            float distance=agent.transform.distance(agent.targetTransform);

            if (!agent.targetCreature.isAlive){
                agent.stateMachine.changeState(WAIT);
                return;
            }

            switch (agent.primaryWeapon.bulletType){
                case LINE:
                    if (!pointGraph.anyObstacle(agent.currentPoint,agent.targetAgent.currentPoint) && distance<agent.primaryWeapon.range*Point.UNIT){
                        //ToDo Mappers.animationComponents.get(agent.entity).stop=false;
                        agent.nextTick=AgentV2System.totalTime+agent.primaryWeapon.getAttackRate(agent.creature);//Set next tick
                        agent.primaryWeapon.abilityControllers.clear();//Set ability to weapon
                        agent.updateAbilities(AbilityController.Type.ATTACK);//Ability Update
                        agent.primaryWeapon.attack(agent.creature,agent.targetCreature);//Attack


                        //ToDo agent.animationName= AnimationName.getAttackName(AnimationName.getDirection(agent.targetTransform.pos.x-agent.transform.pos.x,agent.targetTransform.pos.y-agent.transform.pos.y));
                    }
                    else
                        agent.stateMachine.changeState(FOLLOW);
                    break;
                case AIRBORNE:
                    if (!agent.targetAgent.currentPoint.roofed && distance<agent.primaryWeapon.range*Point.UNIT){
                        agent.nextTick=AgentV2System.totalTime+agent.primaryWeapon.getAttackRate(agent.creature);//Set next tick
                        agent.primaryWeapon.abilityControllers.clear();//Set ability to weapon
                        agent.updateAbilities(AbilityController.Type.ATTACK);//Ability Update
                        agent.primaryWeapon.attack(agent.creature,agent.targetCreature);//Attack
                    }
                    else if (agent.targetAgent.currentPoint.roofed){
                        findTarget(agent);
                    }
                    else {
                        agent.stateMachine.changeState(FOLLOW);
                    }
                    break;
                case UNDERGROUND:
                    if (distance<agent.primaryWeapon.range*Point.UNIT){
                        agent.nextTick=AgentV2System.totalTime+agent.primaryWeapon.getAttackRate(agent.creature);//Set next tick
                        agent.primaryWeapon.abilityControllers.clear();//Set ability to weapon
                        agent.updateAbilities(AbilityController.Type.ATTACK);//Ability Update
                        agent.primaryWeapon.attack(agent.creature,agent.targetCreature);//Attack
                    }
                    else {
                        agent.stateMachine.changeState(FOLLOW);
                    }
                    break;
            }

        }

        @Override
        public void exit(RangedZombieAgentComponentV2 agent) {

        }

        @Override
        public boolean onMessage(RangedZombieAgentComponentV2 entity, Telegram telegram) {
            return false;
        }
    };
    PointGraph pointGraph= MapManager.getInstance().pointGraph;


    protected void findTarget(RangedZombieAgentComponentV2 agent){
        agent.target=null;
        agent.targetTransform=null;
        agent.targetCreature=null;
        agent.targetAgent=null;


        Array<Point> points=agent.currentPoint.rangeArrayMap.get(agent.awareRadius);
        for (int j=0;j<points.size;j++){
            if (agent.primaryWeapon.bulletType== BulletType.AIRBORNE&&points.get(j).roofed)
                continue;

            if (points.get(j).humans.size!=0){
                agent.target=points.get(j).humans.random();
                agent.targetTransform= Mappers.transformComponents.get(agent.target);
                agent.targetCreature=Mappers.creatureComponents.get(agent.target);
                agent.targetAgent=Mappers.agentComponentV2(agent.target);
                return;
            }
        }
    }
}
