package com.katafrakt.zombieoff.ai.pfa;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ArrayMap;
import com.katafrakt.zombieoff.managers.MapManager;

public class Point {
    private static final String TAG=Point.class.getSimpleName();
    public static final int UNIT=8;
    public float x,y;
    public int tableX,tableY;
    public static int count;
    public int index;


    public boolean walkable;
    public boolean roofed;
    public boolean obstacle;
    public float speedPer;

    public int loadedRange;

    public ArrayMap<Integer,Array<Point>> rangeArrayMap=new ArrayMap<Integer, Array<Point>>(){
        @Override
        synchronized public Array<Point> get(Integer key) {
            if (super.get(key)==null){
                if (key==0){
                    Array<Point> array=new Array<>();
                    array.add(Point.this);
                    super.put(key,array);
                }
                else {
                    super.put(key, MapManager.getInstance().pointGraph.getRangePoints(new Array<>(get(key-1)),Point.this,key));
                }
                loadedRange=key;
            }
            return super.get(key);
        }

        @Override
        public synchronized int put(Integer key, Array<Point> value) {
            return super.put(key, value);
        }
    };

    public Array<Entity> zombies=new Array<Entity>();
    public Array<Entity> humans=new Array<Entity>();


    public Point(float x, float y,boolean walkable,boolean obstacle,boolean roofed){
        this.x=x;
        this.y=y;
        index=count;
        count++;
        this.walkable=walkable;
        this.obstacle=obstacle;
        this.roofed=roofed;
    }


    public static Array<Entity> getHumans(Array<Entity> humans,Array<Point> points){
        humans.clear();
        for (Point point:points){
            humans.addAll(point.humans);
        }
        return humans;
    }
    public static Array<Entity> getZombies(Array<Entity> humans,Array<Point> points){
        humans.clear();
        for (Point point:points){
            humans.addAll(point.humans);
        }
        return humans;
    }
}
