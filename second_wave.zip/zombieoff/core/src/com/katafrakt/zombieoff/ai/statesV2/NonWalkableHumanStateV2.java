package com.katafrakt.zombieoff.ai.statesV2;

import com.badlogic.gdx.ai.fsm.State;
import com.badlogic.gdx.ai.msg.Telegram;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ai.pfa.PointGraph;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agentsV2.NonWalkableHumanAgentComponentV2;
import com.katafrakt.zombieoff.ashley.systems.agents.AgentV2System;
import com.katafrakt.zombieoff.game.StateType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.ui.EntityUI;

public enum NonWalkableHumanStateV2 implements State<NonWalkableHumanAgentComponentV2> {
    WAIT(){
        @Override
        public void enter(NonWalkableHumanAgentComponentV2 agent) {

            agent.currentState= StateType.IDLE;
            agent.updateAbilities(AbilityController.Type.STATE);

            if (EntityUI.getEntity()==agent.entity)
                EntityUI.entityUI.entityStateChange();
        }

        @Override
        public void update(NonWalkableHumanAgentComponentV2 agent) {
            findTarget(agent);

            if (agent.target!=null){
                agent.nextTick= AgentV2System.totalTime+1;
                agent.stateMachine.changeState(ATTACK);
                return;
            }
            else {
                agent.nextTick=AgentV2System.totalTime+1+ MathUtils.random();
            }


        }

        @Override
        public void exit(NonWalkableHumanAgentComponentV2 entity) {

        }

        @Override
        public boolean onMessage(NonWalkableHumanAgentComponentV2 entity, Telegram telegram) {
            return false;
        }
    },
    ATTACK(){
        @Override
        public void enter(NonWalkableHumanAgentComponentV2 agent) {
            agent.currentState=StateType.ATTACK;
            agent.updateAbilities(AbilityController.Type.STATE);

            if (EntityUI.getEntity()==agent.entity)
                EntityUI.entityUI.entityStateChange();
        }

        @Override
        public void update(NonWalkableHumanAgentComponentV2 agent) {
            if (!agent.targetCreature.isAlive){
                findTarget(agent);
                if (agent.target==null){
                    agent.stateMachine.changeState(WAIT);
                    return;
                }
            }
            float distance=agent.transform.distance(agent.targetTransform);
            switch (agent.primaryWeapon.bulletType){
                case LINE:
                    if (!pointGraph.anyObstacle(agent.currentPoint,agent.targetAgent.currentPoint) && distance<agent.primaryWeapon.range*Point.UNIT){
                        agent.nextTick=AgentV2System.totalTime+agent.primaryWeapon.getAttackRate(agent.creature);
                        agent.primaryWeapon.abilityControllers.clear();
                        agent.updateAbilities(AbilityController.Type.ATTACK);
                        agent.primaryWeapon.attack(agent.creature,agent.targetCreature);
                    }
                    else {
                        findTarget(agent);
                        if (agent.target==null)
                            agent.stateMachine.changeState(WAIT);
                    }
                    break;
                case AIRBORNE:
                    if (!agent.targetAgent.currentPoint.roofed && distance<agent.primaryWeapon.range*Point.UNIT){
                        agent.nextTick=AgentV2System.totalTime+agent.primaryWeapon.getAttackRate(agent.creature);
                        agent.primaryWeapon.abilityControllers.clear();
                        agent.updateAbilities(AbilityController.Type.ATTACK);
                    }
                    else {
                        findTarget(agent);
                        if (agent.target==null)
                            agent.stateMachine.changeState(WAIT);
                    }
                    break;
                case UNDERGROUND:
                    if (distance<agent.primaryWeapon.range*Point.UNIT){
                        agent.nextTick=AgentV2System.totalTime+agent.primaryWeapon.getAttackRate(agent.creature);
                        agent.primaryWeapon.abilityControllers.clear();
                        agent.updateAbilities(AbilityController.Type.ATTACK);
                    }
                    else {
                        findTarget(agent);
                        if (agent.target==null)
                            agent.stateMachine.changeState(WAIT);
                    }
                    break;
            }
        }

        @Override
        public void exit(NonWalkableHumanAgentComponentV2 entity) {

        }

        @Override
        public boolean onMessage(NonWalkableHumanAgentComponentV2 entity, Telegram telegram) {
            return false;
        }
    };
    PointGraph pointGraph;

    protected void findTarget(NonWalkableHumanAgentComponentV2 agent){
        agent.target=null;
        agent.targetTransform=null;
        agent.targetCreature=null;
        agent.targetAgent=null;

        Array<Point> points=agent.currentPoint.rangeArrayMap.get(agent.awareRadius);
        for (Point point:points){
            switch (agent.primaryWeapon.bulletType){
                case LINE:
                    if (pointGraph.anyObstacle(agent.currentPoint,point))
                        continue;
                    break;
                case AIRBORNE:
                    if (point.roofed)
                        continue;
                    break;
            }
            if (point.zombies.size!=0){
                agent.target=point.zombies.random();
                agent.targetTransform= Mappers.transformComponents.get(agent.target);
                agent.targetCreature= Mappers.creatureComponents.get(agent.target);
                agent.targetAgent= Mappers.agentComponentV2(agent.target);
                return;
            }
        }
    }
}
