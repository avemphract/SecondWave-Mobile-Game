package com.katafrakt.zombieoff.ai.states;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ai.fsm.State;
import com.badlogic.gdx.ai.msg.Telegram;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agents.AgentComponent;
import com.katafrakt.zombieoff.ashley.components.agents.MercenaryAgentComponent;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.managers.GeneralOrganizer;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.ui.EntityUI;
import com.katafrakt.zombieoff.utilities.Utility;

import java.util.Random;

public enum MercenaryState implements State<MercenaryAgentComponent> {
    IDLE(){

        @Override
        public void enter(MercenaryAgentComponent agent) {
            generalStateEnter(agent);

        }

        @Override
        public void update(MercenaryAgentComponent agent) {
            float deltaTime=generalUpdate(agent);
            if (agent.currentTime>agent.count){
                findTarget(agent);
                if (agent.idleMoveIsActive)
                    agent.direction.set(agent.targetPosition.x-agent.transform.pos.x,agent.targetPosition.y-agent.transform.pos.y).scl(1f/agent.direction.len());
            }
            if (!agent.primaryMap.isEmpty()){
                if (agent.awareness<1){
                    agent.awareness +=deltaTime;
                    if (agent.awareness>1)
                        agent.awareness=1;
                }
                if (agent.awareness==1){
                    agent.stateMachine.changeState(ATTACK);
                    /*
                    if (agent.transform.distance(agent.targetTransform)/Point.UNIT>Math.max(agent.primaryWeapon.range,agent.secondaryWeapon.range))
                        agent.stateMachine.changeState(FOLLOW);
                    else
                        agent.stateMachine.changeState(ATTACK);*/
                }
            }
            else {
                agent.awareness-=deltaTime;
                if (agent.awareness<0)
                    agent.awareness=0;
            }

            if (agent.idleMoveIsActive){
                float diff = (float) Math.pow(Math.pow(agent.transform.pos.x-agent.targetPosition.x,2)+Math.pow(agent.transform.pos.y-agent.targetPosition.y,2),0.5f);
                if (diff<1)
                    agent.idleMoveIsActive=false;
                else {
                    agent.transform.pos.x+= agent.direction.x*deltaTime*agent.creature.getSpeed();
                    agent.transform.pos.y+= agent.direction.y*deltaTime*agent.creature.getSpeed();
                }
            }
            else if (agent.currentTime>agent.count){
                if (random.nextFloat()>0f){
                    agent.idleMoveIsActive=true;
                    agent.targetPoint=mapManager.pointGraph.nearestPoint(tempVector.set(agent.initialPoint.x+2* Point.UNIT*(0.5f-random.nextFloat()*1),agent.initialPoint.y+2*Point.UNIT*(0.5f-random.nextFloat()*1)));
                    agent.targetPosition.set(agent.targetPoint.x+Point.UNIT*(0.5f-random.nextFloat()*1),agent.targetPoint.y+Point.UNIT*(0.5f-random.nextFloat()*1));
                    agent.direction.set(agent.targetPosition.x-agent.transform.pos.x,agent.targetPosition.y-agent.transform.pos.y).scl(1f/agent.direction.len());
                }
            }

            generalUpdateEnd(agent);
        }

        @Override
        public void exit(MercenaryAgentComponent agent) {

        }

        @Override
        public boolean onMessage(MercenaryAgentComponent agent, Telegram telegram) {
            return false;
        }
    },
    ATTACK(){

        @Override
        public void enter(MercenaryAgentComponent agent) {
            generalStateEnter(agent);
        }

        @Override
        public void update(MercenaryAgentComponent agent) {
            float deltaTime = generalUpdate(agent);

            if (agent.currentTime>agent.count){
                findTarget(agent);
                if (agent.target==null)
                    agent.stateMachine.changeState(IDLE);
            }

            if (agent.nextAttackTime<agent.currentTime){
                if (agent.primaryMap.getFirstly()!=null){
                    Gdx.app.log(TAG,"PrimaryWeapon-First");
                    agent.nextAttackTime=agent.currentTime+agent.primaryWeapon.getAttackRate(agent.creature);

                    Entity entity=agent.primaryMap.getFirstly();
                    CreatureComponent entityCreature=Mappers.creatureComponents.get(entity);
                    agent.primaryWeapon.attack(agent.creature,entityCreature);
                }
                else if (agent.secondaryMap.getFirstly()!=null){
                    Gdx.app.log(TAG,"SecondWeapon-First");
                    agent.nextAttackTime=agent.currentTime+agent.secondaryWeapon.getAttackRate(agent.creature);

                    Entity entity=agent.secondaryMap.getFirstly();
                    CreatureComponent entityCreature=Mappers.creatureComponents.get(entity);
                    agent.secondaryWeapon.attack(agent.creature,entityCreature);
                }
                else if (agent.primaryMap.getSecondly()!=null){
                    Gdx.app.log(TAG,"PrimaryWeapon-Second");
                    agent.nextAttackTime=agent.currentTime+agent.primaryWeapon.getAttackRate(agent.creature);

                    Entity entity=agent.primaryMap.getSecondly();
                    CreatureComponent entityCreature=Mappers.creatureComponents.get(entity);
                    agent.primaryWeapon.attack(agent.creature,entityCreature);
                }
                else if (agent.secondaryMap.getSecondly()!=null){
                    Gdx.app.log(TAG,"SecondaryWeapon-Second");
                    agent.nextAttackTime=agent.currentTime+agent.secondaryWeapon.getAttackRate(agent.creature);

                    Entity entity=agent.secondaryMap.getSecondly();
                    CreatureComponent entityCreature=Mappers.creatureComponents.get(entity);
                    agent.secondaryWeapon.attack(agent.creature,entityCreature);
                }
                else {
                    //.app.log(TAG,"Waiting for Range");
                }


            }



            /*if (agent.nextAttackTime +agent.lastWeaponAttackRate<agent.currentTime){
                setAttackTarget(agent);
                if (agent.target!=null){
                    agent.nextAttackTime =agent.currentTime;
                    int distance= (int) (agent.targetTransform.distance(agent.transform)/Point.UNIT);
                    agent.updateAbilities(AbilityController.Type.ATTACK);
                    if (distance<agent.weaponChange){
                        agent.lastWeaponAttackRate=agent.secondaryWeapon.getAttackRate(agent.creature);
                        agent.secondaryWeapon.abilityControllers.clear();
                        agent.updateAbilities(AbilityController.Type.ATTACK);
                        agent.secondaryWeapon.attack(agent.creature,agent.targetCreature);
                    }
                    else if (agent.primaryWeapon.recommended.min<distance&&distance<agent.primaryWeapon.recommended.max){
                        agent.lastWeaponAttackRate=agent.primaryWeapon.getAttackRate(agent.creature);
                        agent.primaryWeapon.abilityControllers.clear();
                        agent.updateAbilities(AbilityController.Type.ATTACK);
                        agent.primaryWeapon.attack(agent.creature,agent.targetCreature);
                    }
                    else if (agent.secondaryWeapon.recommended.min<distance&&distance<agent.secondaryWeapon.recommended.max){
                        agent.lastWeaponAttackRate=agent.secondaryWeapon.getAttackRate(agent.creature);
                        agent.secondaryWeapon.abilityControllers.clear();
                        agent.updateAbilities(AbilityController.Type.ATTACK);
                        agent.secondaryWeapon.attack(agent.creature,agent.targetCreature);
                    }
                    else {
                        agent.lastWeaponAttackRate=agent.primaryWeapon.getAttackRate(agent.creature);
                        agent.primaryWeapon.abilityControllers.clear();
                        agent.updateAbilities(AbilityController.Type.ATTACK);
                        agent.primaryWeapon.attack(agent.creature,agent.targetCreature);
                    }
                }
                else if (agent.target==null&&agent.hashMap.isEmpty()){
                    agent.stateMachine.changeState(FOLLOW);
                }
                else
                    agent.stateMachine.changeState(IDLE);

            }*/

            generalUpdateEnd(agent);
        }

        @Override
        public void exit(MercenaryAgentComponent agent) {

        }

        @Override
        public boolean onMessage(MercenaryAgentComponent agent, Telegram telegram) {
            return false;
        }
    },
    /*
    FOLLOW(){

        private void createPath(MercenaryAgentComponent agent){
            agent.path=mapManager.pointGraph.findPath(mapManager.pointGraph.nearestPoint(agent.transform.pos),mapManager.pointGraph.nearestPoint(Mappers.transformComponents.get(agent.primaryMap.getClosest()).pos));
            agent.iterator=agent.path.iterator();
            agent.targetPoint=agent.iterator.next();
        }
        @Override
        public void enter(MercenaryAgentComponent agent) {
            generalStateEnter(agent);
            createPath(agent);
        }

        @Override
        public void update(MercenaryAgentComponent agent) {
            float deltaTime=generalUpdate(agent);

            if (agent.currentTime>agent.count){
                detectTarget(agent);
                if (agent.primaryMap.isEmpty()){
                    agent.stateMachine.changeState(RETURN);
                    return;
                }
                createPath(agent);
            }
            if (agent.primaryMap.size==0){
                agent.stateMachine.changeState(RETURN);
                return;
            }
            else if (agent.transform.distance(Mappers.transformComponents.get(agent.primaryMap.getClosest()))<agent.primaryWeapon.range*Point.UNIT){
                agent.stateMachine.changeState(ATTACK);
                return;
            }

            if (agent.targetPoint!=null){
                //Yön belirle
                if (agent.transform.pos.x>agent.targetPoint.x+Point.UNIT/2) {
                    agent.transform.pos.x-=agent.creature.getSpeed()*deltaTime;
                }
                else if(agent.transform.pos.x<agent.targetPoint.x-Point.UNIT/2) {
                    agent.transform.pos.x+=agent.creature.getSpeed()*deltaTime;
                }
                else if (agent.transform.pos.y>agent.targetPoint.y+Point.UNIT/2){
                    agent.transform.pos.y-=agent.creature.getSpeed()*deltaTime;
                }
                else if (agent.transform.pos.y<agent.targetPoint.y-Point.UNIT/2){
                    agent.transform.pos.y+=agent.creature.getSpeed()*deltaTime;
                }
                else{
                    if (agent.iterator.hasNext())
                        agent.targetPoint=agent.iterator.next();
                    else{
                        detectTarget(agent);
                        createPath(agent);
                    }
                }
            }
            generalUpdateEnd(agent);
        }

        @Override
        public void exit(MercenaryAgentComponent entity) {

        }

        @Override
        public boolean onMessage(MercenaryAgentComponent entity, Telegram telegram) {
            return false;
        }
    },
    RETURN(){


        private void createPath(MercenaryAgentComponent agent){
            agent.path=mapManager.pointGraph.findPath(mapManager.pointGraph.nearestPoint(agent.transform.pos),agent.initialPoint);
            agent.iterator=agent.path.iterator();
            agent.targetPoint=agent.iterator.next();
        }

        @Override
        public void enter(MercenaryAgentComponent agent) {
            generalStateEnter(agent);
            createPath(agent);
        }

        @Override
        public void update(MercenaryAgentComponent agent) {
            float deltaTime = generalUpdate(agent);

            if (agent.currentTime>agent.count){
                detectTarget(agent);
            }

            if (!agent.primaryMap.isEmpty()){
                if (agent.awareness<1){
                    agent.awareness +=deltaTime;
                    if (agent.awareness>1)
                        agent.awareness=1;
                }
                if (agent.awareness==1){
                    if (Mappers.transformComponents.get(agent.primaryMap.getClosest()).distance(agent.transform)>agent.primaryWeapon.range)
                        agent.stateMachine.changeState(FOLLOW);
                    else
                        agent.stateMachine.changeState(ATTACK);
                }
            }
            else {
                agent.awareness-=deltaTime;
                if (agent.awareness<0)
                    agent.awareness=0;
            }
            if (agent.targetPoint!=null){
                //Yön belirle
                if (agent.transform.pos.x>agent.targetPoint.x+Point.UNIT/2) {
                    agent.transform.pos.x-=agent.creature.speed*deltaTime;
                }
                else if(agent.transform.pos.x<agent.targetPoint.x-Point.UNIT/2) {
                    agent.transform.pos.x+=agent.creature.speed*deltaTime;
                }
                else if (agent.transform.pos.y>agent.targetPoint.y+Point.UNIT/2){
                    agent.transform.pos.y-=agent.creature.speed*deltaTime;
                }
                else if (agent.transform.pos.y<agent.targetPoint.y-Point.UNIT/2){
                    agent.transform.pos.y+=agent.creature.speed*deltaTime;
                }
                else{
                    if (agent.iterator.hasNext())
                        agent.targetPoint=agent.iterator.next();
                    else
                        agent.targetPoint=null;
                }
            }
            else
                agent.stateMachine.changeState(IDLE);

            generalUpdateEnd(agent);
        }

        @Override
        public void exit(MercenaryAgentComponent agent) {

        }

        @Override
        public boolean onMessage(MercenaryAgentComponent agent, Telegram telegram) {
            return false;
        }
    }*/
    ;
    private static final String TAG=MercenaryState.class.getSimpleName();
    MapManager mapManager;
    Random random;

    MercenaryState(){
        mapManager=MapManager.getInstance();
        random= GeneralOrganizer.getInstance().random;
    }

    /*protected void detectTarget(MercenaryAgentComponent agent){
        for (int i=0;i<=agent.awareRadius;i++){
            agent.primaryMap.get(i).clear();
            Array<Point> points=mapManager.pointGraph.getRangePoints(agent.currentPoint,i);
            for (int j=0;j<points.size;j++){
                agent.primaryMap.get(i).addAll(points.get(j).zombies);
            }
        }
    }*/

    /*protected Weapon setAttackTarget(MercenaryAgentComponent agent){
        for (int i=agent.primaryWeapon.recommended.min;i<Math.max(agent.primaryWeapon.recommended.max,agent.primaryWeapon.range);i++){

            if (agent.primaryMap.get(i).size!=0){
                agent.target=agent.primaryMap.get(i).random();
                agent.targetTransform=Mappers.transformComponents.get(agent.target);
                agent.targetCreature=Mappers.creatureComponents.get(agent.target);
                agent.targetAgent=Mappers.agentComponents(agent.target);
                Gdx.app.log(TAG,"First For");
                return agent.primaryWeapon;
            }
        }
        for (int i=agent.secondaryWeapon.recommended.min;i<Math.max(agent.secondaryWeapon.recommended.max,agent.secondaryWeapon.range);i++){
            if (agent.primaryMap.get(i).size!=0){
                agent.target=agent.primaryMap.get(i).random();
                agent.targetTransform=Mappers.transformComponents.get(agent.target);
                agent.targetCreature=Mappers.creatureComponents.get(agent.target);
                agent.targetAgent=Mappers.agentComponents(agent.target);
                Gdx.app.log(TAG,"Second For");
                return agent.secondaryWeapon;
            }
        }
        for (int i=0;i<agent.awareRadius;i++){
            if (agent.primaryMap.get(i).size!=0){
                agent.target=agent.primaryMap.get(i).random();
                agent.targetTransform=Mappers.transformComponents.get(agent.target);
                agent.targetCreature=Mappers.creatureComponents.get(agent.target);
                agent.targetAgent=Mappers.agentComponents(agent.target);
                Gdx.app.log(TAG,"Third For");
                return agent.primaryWeapon;
            }
        }
        return null;
    }*/

    protected void findTarget(MercenaryAgentComponent agent){
        agent.target=null;
        agent.targetTransform=null;
        for (int i=0;i<=agent.awareRadius;i++){
            Array<Point> points= Utility.pointArrayPool.obtain();
            points=mapManager.pointGraph.getRangePoints(points,agent.currentPoint,i);
            for (int j=0;j<points.size;j++){
                if (points.get(j).zombies.size!=0){
                    agent.target=points.get(j).zombies.random();
                    agent.targetTransform=Mappers.transformComponents.get(agent.target);
                }
            }
            Utility.pointArrayPool.free(points);
        }


    }

    void generalStateEnter(AgentComponent agent){
        if (EntityUI.getEntity()==agent.entity)
            EntityUI.entityUI.entityStateChange();
        agent.count=0;
        agent.updateAbilities(AbilityController.Type.STATE);
    }

    float generalUpdate(MercenaryAgentComponent agent){
        float delta= MathUtils.clamp(Gdx.graphics.getDeltaTime(),0,0.1f);
        agent.currentTime+=delta;
        if (agent.currentPoint!=MapManager.getInstance().pointGraph.nearestPoint(agent.transform.pos)){
            agent.currentPoint.humans.removeValue(agent.entity,true);
            agent.currentPoint=MapManager.getInstance().pointGraph.nearestPoint(agent.transform.pos);
            agent.currentPoint.humans.add(agent.entity);

            agent.primaryMap.setPoints(agent.currentPoint);
            agent.secondaryMap.setPoints(agent.currentPoint);
        }
        agent.updateAbilities(AbilityController.Type.UPDATE);
        return delta;
    }
    void generalUpdateEnd(AgentComponent agent){
        if (agent.currentTime>agent.count)
            agent.count= (int) (agent.currentTime+1);
    }

    Vector2 tempVector=new Vector2();
}
