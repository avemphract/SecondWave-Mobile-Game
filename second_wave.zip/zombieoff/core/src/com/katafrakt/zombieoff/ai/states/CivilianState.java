package com.katafrakt.zombieoff.ai.states;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ai.fsm.State;
import com.badlogic.gdx.ai.msg.Telegram;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agents.AgentComponent;
import com.katafrakt.zombieoff.ashley.components.agents.CivilianAgentComponent;
import com.katafrakt.zombieoff.entities.BulletType;
import com.katafrakt.zombieoff.game.AnimationName;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.weapons.MeleeWeapon;
import com.katafrakt.zombieoff.game.weapons.RangedWeapon;
import com.katafrakt.zombieoff.managers.GeneralOrganizer;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.ui.EntityUI;
import com.katafrakt.zombieoff.utilities.Utility;

import java.util.Random;

public enum CivilianState implements State<CivilianAgentComponent> {
    IDLE(){
        @Override
        public void enter(CivilianAgentComponent agent) {
            generalStateEnter(agent);
            agent.targetPosActive=false;
        }

        @Override
        public void update(CivilianAgentComponent agent) {
            float deltaTime = generalUpdate(agent);

            if (agent.currentTime>agent.count&&agent.count% AgentComponent.findTargetTime ==0){
                agent.currentTime+=GeneralOrganizer.getInstance().random.nextFloat()*0.2f;
                findTarget(agent);
            }

            //Aware||Guard
            if (agent.target!=null && agent.targetCreature.isAlive){
                if (agent.awareness<1){
                    agent.awareness +=deltaTime;
                    if (agent.awareness>1)
                        agent.awareness=1;
                }
                if (agent.awareness==1){
                    if (agent.primaryWeapon==null){
                        agent.stateMachine.changeState(FLEE);
                    }
                    else if (agent.primaryWeapon instanceof MeleeWeapon){
                        agent.stateMachine.changeState(FOLLOW);
                    }
                    else if (agent.primaryWeapon instanceof RangedWeapon){
                        agent.stateMachine.changeState(FOLLOW);
                    }
                }
            }
            else {
                if (agent.awareness==0);
                else if (agent.awareness<0)
                    agent.awareness=0;
                else
                agent.awareness -= deltaTime;
            }

            if (agent.targetPosActive&&agent.awareness<1){
                if(agent.progressTime+agent.startTime>agent.currentTime){
                    agent.transform.pos.x+=agent.direction.x*agent.creature.getSpeed()*deltaTime;
                    agent.transform.pos.y+=agent.direction.y*agent.creature.getSpeed()*deltaTime;
                }
                else{
                    agent.targetPosActive=false;
                    agent.animationName=AnimationName.getWaitName(agent.animationName.direction);
                }
            }

            //Should it idle movement?
            else if ((agent.currentTime>agent.count&&agent.awareness<1)){
                float rng=random.nextFloat();

                if (rng>0.5f||agent.currentPoint.humans.size>1){
                    agent.targetPosActive=true;

                    agent.targetPoint=mapManager.pointGraph.nearestPoint(tempVector.set(agent.transform.pos.x+2*Point.UNIT*(0.5f-random.nextFloat()*1),agent.transform.pos.y+2*Point.UNIT*(0.5f-random.nextFloat()*1)));
                    if (agent.targetPoint.humans.size>=agent.currentPoint.humans.size){
                        agent.targetPosActive=false;
                    }
                    else {
                        agent.targetPosition.set(agent.targetPoint.x+Point.UNIT*(0.5f-random.nextFloat()*1),agent.targetPoint.y+Point.UNIT*(0.5f-random.nextFloat()*1));
                        agent.direction.set(agent.targetPosition.x-agent.transform.pos.x,agent.targetPosition.y-agent.transform.pos.y).scl(1f/agent.direction.len());
                        agent.startTime=agent.currentTime;
                        agent.progressTime= (float) Math.pow(Math.pow(agent.targetPosition.x-agent.transform.pos.x,2)+Math.pow(agent.targetPosition.y-agent.transform.pos.y,2),0.5f)/agent.creature.getSpeed();
                        //********************Animation
                        if (Math.abs(agent.direction.x)>Math.abs(agent.direction.y)) {
                            if (agent.direction.x > 0) {
                                agent.animationName = AnimationName.WALK_RIGHT;
                            }
                            else {
                                agent.animationName = AnimationName.WALK_LEFT;
                            }
                        }
                        else {
                            if (agent.direction.y>0){
                                agent.animationName = AnimationName.WALK_UP;
                            }
                            else {
                                agent.animationName = AnimationName.WALK_DOWN;
                            }
                        }
                        //********************Animation

                    }
                }
            }
            generalUpdateEnd(agent);
        }

        @Override
        public void exit(CivilianAgentComponent entity) {

        }

        @Override
        public boolean onMessage(CivilianAgentComponent entity, Telegram telegram) {
            return false;
        }
    },
    FLEE(){
        private void fleeSelection(CivilianAgentComponent agent){
            float x=0,y=0;

            for (int i=0;i<=agent.awareRadius;i++){
                Array<Point> points =Utility.pointArrayPool.obtain();
                points=mapManager.pointGraph.getRangePoints(points,agent.currentPoint,i);
                for (int j=0;j<points.size;j++){
                    if (points.get(j).zombies.size!=0){
                        x+=(points.get(j).x - agent.currentPoint.x)/i/i;
                        y+=(points.get(j).y - agent.currentPoint.y)/i/i;
                    }
                }
            }

            float length= (float) Math.pow(Math.pow(x,2)+Math.pow(y,2),0.5f);
            x/=length;
            y/=length;
            //Gdx.app.log(TAG,"Result:"+result.x+","+result.y);
            agent.targetPosition.set(agent.transform.pos).add(-x*agent.awareRadius,-y*agent.awareRadius);
        }
        private void createPath(CivilianAgentComponent agent){
            agent.path=mapManager.pointGraph.findPath(mapManager.pointGraph.nearestPoint(agent.transform.pos),mapManager.pointGraph.nearestPoint(agent.targetPosition));
            agent.iterator=agent.path.iterator();
            if (agent.iterator.hasNext())
            agent.targetPoint=agent.iterator.next();
        }

        @Override
        public void enter(CivilianAgentComponent agent) {
            generalStateEnter(agent);
            fleeSelection(agent);
            createPath(agent);
        }

        @Override
        public void update(CivilianAgentComponent agent) {
            float deltaTime = generalUpdate(agent);

            if (agent.currentTime>agent.count||agent.targetPoint==null){
                findTarget(agent);
                fleeSelection(agent);
                createPath(agent);
            }
            if (agent.target==null||agent.targetCreature.isAlive==false){
                agent.stateMachine.changeState(IDLE);
                return;
            }

            if (agent.targetPoint!=null){
                if (agent.transform.pos.x>agent.targetPoint.x+Point.UNIT/2) {
                    agent.transform.pos.x-=agent.creature.getSpeed()*deltaTime;
                    agent.animationName =AnimationName.WALK_LEFT;
                }
                else if(agent.transform.pos.x<agent.targetPoint.x-Point.UNIT/2) {
                    agent.transform.pos.x+=agent.creature.getSpeed()*deltaTime;
                    agent.animationName = AnimationName.WALK_RIGHT;
                }
                else if (agent.transform.pos.y>agent.targetPoint.y+Point.UNIT/2){
                    agent.transform.pos.y-=agent.creature.getSpeed()*deltaTime;
                    agent.animationName = AnimationName.WALK_DOWN;
                }
                else if (agent.transform.pos.y<agent.targetPoint.y-Point.UNIT/2){
                    agent.transform.pos.y+=agent.creature.getSpeed()*deltaTime;
                    agent.animationName = AnimationName.WALK_UP;
                }
                else{
                    if (agent.iterator.hasNext())
                        agent.targetPoint=agent.iterator.next();
                    else
                        agent.targetPoint=null;
                }

            }
            generalUpdateEnd(agent);
        }

        @Override
        public void exit(CivilianAgentComponent entity) {

        }

        @Override
        public boolean onMessage(CivilianAgentComponent entity, Telegram telegram) {
            return false;
        }
    },
    FOLLOW(){

        private void createPath(CivilianAgentComponent agent){
            if (agent.primaryWeapon instanceof MeleeWeapon)
                agent.path=mapManager.pointGraph.findPath(mapManager.pointGraph.nearestPoint(tempVector.set(agent.transform.pos)),mapManager.pointGraph.nearestPoint(tempVector.set(agent.targetTransform.pos)));
            else if (agent.primaryWeapon instanceof RangedWeapon)
                agent.path=mapManager.pointGraph.findPath(agent.currentPoint,mapManager.pointGraph.attackPosition(agent.currentPoint,agent.targetAgent.currentPoint,agent.primaryWeapon.range,((RangedWeapon)agent.primaryWeapon).bulletType));
            else
                Gdx.app.log(TAG,"Null Weapon");
            agent.iterator=agent.path.iterator();
            agent.targetPoint=agent.iterator.next();
        }

        @Override
        public void enter(CivilianAgentComponent agent) {
            generalStateEnter(agent);
            createPath(agent);
        }

        @Override
        public void update(CivilianAgentComponent agent) {
            float deltaTime = generalUpdate(agent);

            if (agent.target==null || !agent.targetCreature.isAlive){
                agent.stateMachine.changeState(IDLE);
                return;
            }

            if (agent.currentTime>agent.count){
                Entity entity=findInRange(agent);
                if (entity!=null){
                    agent.target=entity;
                    agent.targetTransform=Mappers.transformComponents.get(entity);
                    agent.targetCreature= Mappers.creatureComponents.get(entity);
                    agent.targetAgent= Mappers.agentComponents(entity);
                }

                createPath(agent);

                if (agent.primaryWeapon instanceof MeleeWeapon){
                    if (agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT){
                        agent.stateMachine.changeState(ATTACK);
                        return;
                    }
                }
                else if (agent.primaryWeapon instanceof RangedWeapon){
                    RangedWeapon rangedWeapon= (RangedWeapon) agent.primaryWeapon;
                    switch (rangedWeapon.bulletType){
                        case LINE:
                            if (!mapManager.pointGraph.anyObstacle(agent.currentPoint,agent.targetAgent.currentPoint)&&agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT) {
                                agent.stateMachine.changeState(ATTACK);
                            }
                            break;
                        case AIRBORNE:
                            if (agent.targetAgent.currentPoint.roofed)
                                findTarget(agent);
                            else if (agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT)
                                agent.stateMachine.changeState(ATTACK);
                            break;
                        case UNDERGROUND:
                            if (agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT)
                                agent.stateMachine.changeState(ATTACK);
                            break;
                    }
                }
                else {
                    Gdx.app.log(TAG,"Absent Weapon");
                }

            }

            if (agent.targetPoint!=null){
                //Yön belirle
                if (agent.transform.pos.x>agent.targetPoint.x+Point.UNIT/2) {
                    agent.transform.pos.x-=agent.creature.speed*deltaTime;
                    agent.animationName=AnimationName.WALK_LEFT;
                }
                else if(agent.transform.pos.x<agent.targetPoint.x-Point.UNIT/2) {
                    agent.transform.pos.x+=agent.creature.speed*deltaTime;
                    agent.animationName=AnimationName.WALK_RIGHT;
                }
                else if (agent.transform.pos.y>agent.targetPoint.y+Point.UNIT/2){
                    agent.transform.pos.y-=agent.creature.speed*deltaTime;
                    agent.animationName=AnimationName.WALK_DOWN;
                }
                else if (agent.transform.pos.y<agent.targetPoint.y-Point.UNIT/2){
                    agent.transform.pos.y+=agent.creature.speed*deltaTime;
                    agent.animationName=AnimationName.WALK_UP;
                }
                else{
                    if (agent.iterator.hasNext())
                        agent.targetPoint=agent.iterator.next();
                    else
                        createPath(agent);
                }
            }
            generalUpdateEnd(agent);
        }

        @Override
        public void exit(CivilianAgentComponent entity) {

        }

        @Override
        public boolean onMessage(CivilianAgentComponent entity, Telegram telegram) {
            return false;
        }
    },
    ATTACK(){
        @Override
        public void enter(CivilianAgentComponent agent) {
            generalStateEnter(agent);
            agent.animationName=AnimationName.getAttackName(AnimationName.getDirection(agent.targetTransform.pos.x-agent.transform.pos.x,agent.targetTransform.pos.y-agent.transform.pos.y));
        }

        @Override
        public void update(CivilianAgentComponent agent) {
            float deltaTime=generalUpdate(agent);

            if (agent.target==null || !agent.targetCreature.isAlive){
                agent.stateMachine.changeState(IDLE);
                return;
            }
            if (agent.currentTime>agent.count){
                agent.animationName=AnimationName.getAttackName(AnimationName.getDirection(agent.targetTransform.pos.x-agent.transform.pos.x,agent.targetTransform.pos.y-agent.transform.pos.y));
            }

            if (agent.nextAttackTime <agent.currentTime){
                Mappers.animationComponents.get(agent.entity).stop=false;
                float distance = agent.transform.distance(agent.targetTransform);
                if (agent.primaryWeapon instanceof MeleeWeapon){
                    if (distance<agent.primaryWeapon.range*Point.UNIT){
                        agent.nextAttackTime =agent.currentTime+agent.primaryWeapon.getAttackRate(agent.creature);
                        agent.primaryWeapon.abilityControllers.clear();
                        agent.updateAbilities(AbilityController.Type.ATTACK);
                        agent.primaryWeapon.attack(agent.creature,agent.targetCreature);
                    }
                    else {
                        agent.stateMachine.changeState(FOLLOW);
                    }
                }
                else if (agent.primaryWeapon instanceof RangedWeapon){
                    RangedWeapon rangedWeapon= (RangedWeapon) agent.primaryWeapon;
                    switch (rangedWeapon.bulletType){
                        case LINE:
                            if (!mapManager.pointGraph.anyObstacle(agent.currentPoint, agent.targetAgent.currentPoint) && distance<agent.primaryWeapon.range*Point.UNIT){
                                agent.nextAttackTime =agent.currentTime+agent.primaryWeapon.getAttackRate(agent.creature);
                                agent.primaryWeapon.abilityControllers.clear();
                                agent.updateAbilities(AbilityController.Type.ATTACK);
                                agent.primaryWeapon.attack(agent.creature,agent.targetCreature);
                            }
                            else{
                                Gdx.app.log(TAG,"AttToFoll");
                                agent.stateMachine.changeState(FOLLOW);
                            }
                            break;
                        case AIRBORNE:
                            if(agent.targetAgent.currentPoint.roofed==false && distance<agent.primaryWeapon.range*Point.UNIT){
                                agent.nextAttackTime =agent.currentTime+agent.primaryWeapon.getAttackRate(agent.creature);
                                agent.primaryWeapon.abilityControllers.clear();
                                agent.updateAbilities(AbilityController.Type.ATTACK);
                                agent.primaryWeapon.attack(agent.creature,agent.targetCreature);
                            }
                            else {
                                findInRange(agent);
                                if (agent.target==null){
                                    agent.stateMachine.changeState(IDLE);
                                }
                                else{
                                    agent.stateMachine.changeState(FOLLOW);
                                }
                            }
                            break;
                        case UNDERGROUND:
                            if (distance<agent.primaryWeapon.range*Point.UNIT){
                                agent.nextAttackTime =agent.currentTime+agent.primaryWeapon.getAttackRate(agent.creature);
                                agent.primaryWeapon.abilityControllers.clear();
                                agent.updateAbilities(AbilityController.Type.ATTACK);
                                agent.primaryWeapon.attack(agent.creature,agent.targetCreature);
                            }
                            else{
                                agent.stateMachine.changeState(FOLLOW);
                            }
                    }
                }
            }
            else if (agent.nextAttackTime>agent.currentTime){

            }
            generalUpdateEnd(agent);
        }

        @Override
        public void exit(CivilianAgentComponent agent) {

        }

        @Override
        public boolean onMessage(CivilianAgentComponent agent, Telegram telegram) {
            return false;
        }
    };
    private static final String TAG= CivilianState.class.getSimpleName();
    MapManager mapManager;
    Random random;


    CivilianState(){
        mapManager=MapManager.getInstance();
        random= GeneralOrganizer.getInstance().random;
    }

    protected void findTarget(CivilianAgentComponent agent){
        agent.target=null;
        agent.targetTransform=null;
        agent.targetCreature=null;
        agent.targetAgent=null;
        /*
        for (int i=0;i<=agent.awareRadius;i++){
            Array<Point> points=mapManager.getInstance().pointGraph.getRangePoints(agent.currentPoint,i);
            for (int j=0;j<points.size;j++){
                if (points.get(j).zombies.size!=0){
                    agent.target=points.get(j).zombies.random();
                    agent.targetTransform=Mappers.transformComponents.get(agent.target);
                    agent.targetCreature=Mappers.creatureComponents.get(agent.target);
                    agent.targetAgent=Mappers.agentComponents(agent.target);
                    return;
                }
            }
        }*/

        Array<Point> points2= Utility.pointArrayPool.obtain();
        points2=mapManager.pointGraph.getAreaPoints(points2,agent.currentPoint,agent.awareRadius);
        for (int j=0;j<points2.size;j++){
            if (points2.get(j).zombies.size!=0){
                agent.target=points2.get(j).zombies.random();
                agent.targetTransform=Mappers.transformComponents.get(agent.target);
                agent.targetCreature=Mappers.creatureComponents.get(agent.target);
                agent.targetAgent=Mappers.agentComponents(agent.target);
                Utility.pointArrayPool.free(points2);
                return;
            }
        }
        Utility.pointArrayPool.free(points2);
    }

    protected Entity findInRange(CivilianAgentComponent agent){
        for (int i=0;i<=agent.primaryWeapon.range;i++){

            Array<Point> points=Utility.pointArrayPool.obtain();
            points=mapManager.pointGraph.getRangePoints(points,agent.currentPoint,i);
            for (int j=0; j<points.size; j++){
                if (agent.primaryWeapon instanceof RangedWeapon){
                    if (points.get(j).roofed && ((RangedWeapon)agent.primaryWeapon).bulletType== BulletType.AIRBORNE)
                        continue;
                    if (((RangedWeapon)agent.primaryWeapon).bulletType==BulletType.LINE&&mapManager.pointGraph.anyObstacle(agent.currentPoint,points.get(j)))
                        continue;
                }
                if (points.get(j).zombies.size!=0){
                    Utility.pointArrayPool.free(points);
                    return points.get(j).zombies.random();
                }

            }
            Utility.pointArrayPool.free(points);
        }
        return null;
    }

    protected void generalStateEnter(CivilianAgentComponent agent){
        if (EntityUI.getEntity()==agent.entity)
            EntityUI.entityUI.entityStateChange();
        agent.updateAbilities(AbilityController.Type.STATE);
    }

    protected float generalUpdate(CivilianAgentComponent agent){
        float delta= MathUtils.clamp(Gdx.graphics.getDeltaTime(),0,0.1f);
        agent.currentTime+=delta;

        if (agent.currentPoint!=MapManager.getInstance().pointGraph.getPoint(agent.transform.pos.x,agent.transform.pos.y)){
            agent.currentPoint.humans.removeValue(agent.entity,true);
            agent.currentPoint=MapManager.getInstance().pointGraph.nearestPoint(agent.transform.pos);
            agent.currentPoint.humans.add(agent.entity);
            agent.newPoint=true;
        }
        agent.updateAbilities(AbilityController.Type.UPDATE);
        return delta;
    }
    void generalUpdateEnd(CivilianAgentComponent agent){
        if (agent.currentTime>agent.count)
            agent.count= (int) (agent.currentTime+1);
    }

    Vector2 tempVector=new Vector2();
}
