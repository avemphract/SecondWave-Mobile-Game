package com.katafrakt.zombieoff.ai.states;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ai.fsm.State;
import com.badlogic.gdx.ai.msg.Telegram;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agents.ZombieRangedAgentComponent;
import com.katafrakt.zombieoff.entities.BulletType;
import com.katafrakt.zombieoff.game.AnimationName;
import com.katafrakt.zombieoff.game.StateType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.managers.GeneralOrganizer;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.player.PlayerStatics;
import com.katafrakt.zombieoff.ui.EntityUI;
import com.katafrakt.zombieoff.utilities.Utility;

import java.util.Random;

public enum ZombieRangedState implements State<ZombieRangedAgentComponent> {
    IDLE(){
        private void setTargetPosition(ZombieRangedAgentComponent agent){
            float xOri=0;
            float yOri=0;
            if (0<agent.transform.pos.x && agent.transform.pos.x< mapManager.mapPixelWidth/4)
                xOri=(mapManager.mapPixelWidth/4-agent.transform.pos.x)/(mapManager.mapPixelWidth/4);
            else if (agent.transform.pos.x>mapManager.mapPixelWidth*3/4 && mapManager.mapPixelWidth>agent.transform.pos.x)
                xOri=(mapManager.mapPixelWidth*3/4-agent.transform.pos.x)/(mapManager.mapPixelWidth/4);
            if (0<agent.transform.pos.y&&agent.transform.pos.y<mapManager.mapPixelHeight/4)
                yOri=(mapManager.mapPixelHeight/4-agent.transform.pos.y)/(mapManager.mapPixelHeight/4);
            else if (agent.transform.pos.y>mapManager.mapPixelHeight*3/4&&mapManager.mapPixelHeight>agent.transform.pos.y)
                yOri=(mapManager.mapPixelHeight/4*3-agent.transform.pos.y)/(mapManager.mapPixelHeight/4);

            agent.targetPosition.set(agent.transform.pos.x+4* Point.UNIT*(0.5f- random.nextFloat()+xOri/2f) ,agent.transform.pos.y+4*Point.UNIT*(0.5f-random.nextFloat()+yOri/2f));
            agent.path= MapManager.getInstance().pointGraph.findPath(mapManager.pointGraph.nearestPoint(agent.transform.pos),mapManager.pointGraph.nearestPoint(agent.targetPosition));
            agent.iterator=agent.path.iterator();
            //agent.currentPoint=mapManager.pointGraph.nearestPoint(agent.transformComponent.pos);
            agent.targetPoint=agent.iterator.next();

            if (agent.targetPoint.x==agent.currentPoint.x){
                agent.targetPosition.set(agent.targetPoint.x+Point.UNIT*random.nextFloat()-Point.UNIT/2,agent.targetPoint.y);
            }
            else {
                agent.targetPosition.set(agent.targetPoint.x,agent.targetPoint.y+Point.UNIT*random.nextFloat()-Point.UNIT/2);
            }

            agent.startTime=agent.currentTime;
            agent.progressTime= (float) Math.pow(Math.pow(agent.targetPosition.x-agent.transform.pos.x,2)+Math.pow(agent.targetPosition.y-agent.transform.pos.y,2),0.5f)/agent.creature.getSpeed();
            agent.direction.set(agent.targetPosition.x-agent.transform.pos.x,agent.targetPosition.y-agent.transform.pos.y).scl(1/agent.direction.len());
        }

        @Override
        public void enter(ZombieRangedAgentComponent agent) {
            agent.currentState= StateType.IDLE;
            generalStateEnter(agent);
        }

        @Override
        public void update(ZombieRangedAgentComponent agent) {
            float deltaTime = generalUpdate(agent);

            if (agent.currentTime>agent.count){
                findTarget(agent);
                if (agent.target!=null&&agent.targetCreature.isAlive==true){
                    agent.stateMachine.changeState(FOLLOW);
                }
            }

            if (agent.targetPoint!=null){
                //PlayerStatics.getInstance().totalMovement.set(PlayerStatics.getInstance().totalMovement.get()+agent.creatureComponent.getSpeed()*deltaTime);//TotalMovement
                PlayerStatics.getInstance().totalMovement.add(agent.creature.getSpeed()*deltaTime);
                //agent.direction.set(agent.targetPosition.x-agent.transformComponent.pos.x,agent.targetPosition.y-agent.transformComponent.pos.y).scl(1/agent.direction.len());
                if(agent.progressTime+agent.startTime>agent.currentTime){
                    agent.transform.pos.x+=agent.direction.x*agent.creature.getSpeed()*deltaTime;
                    agent.transform.pos.y+=agent.direction.y*agent.creature.getSpeed()*deltaTime;
                }
                else{
                    //if (tempVector.set(agent.targetPosition.x-agent.transform.pos.x,agent.targetPosition.y-agent.transform.pos.y).len2()<2f){
                    if (agent.iterator.hasNext()){
                        //agent.currentPoint=agent.targetPoint;
                        agent.targetPoint=agent.iterator.next();
                        if (agent.targetPoint.x==agent.currentPoint.x){
                            agent.targetPosition.set(agent.targetPoint.x+Point.UNIT*random.nextFloat()-Point.UNIT/2,agent.targetPoint.y);
                        }
                        else {
                            agent.targetPosition.set(agent.targetPoint.x,agent.targetPoint.y+Point.UNIT*random.nextFloat()-Point.UNIT/2);

                        }
                        agent.direction.set(agent.targetPosition.x-agent.transform.pos.x,agent.targetPosition.y-agent.transform.pos.y).scl(1/agent.direction.len());

                        //****************Animation
                        if (Math.abs(agent.direction.x)>Math.abs(agent.direction.y)) {
                            if (agent.direction.x > 0) {
                                agent.animationName = AnimationName.WALK_RIGHT;
                            }
                            else {
                                agent.animationName = AnimationName.WALK_LEFT;
                            }
                        }
                        else {
                            if (agent.direction.y>0){
                                agent.animationName = AnimationName.WALK_UP;
                            }
                            else {
                                agent.animationName = AnimationName.WALK_DOWN;
                            }
                        }
                        //****************Animation

                    }
                    else {
                        agent.targetPoint=null;
                        setTargetPosition(agent);
                    }
                    agent.startTime=agent.currentTime;
                    agent.progressTime= (float) Math.pow(Math.pow(agent.targetPosition.x-agent.transform.pos.x,2)+Math.pow(agent.targetPosition.y-agent.transform.pos.y,2),0.5f)/agent.creature.getSpeed();
                }
            }
            else if (agent.currentTime>agent.count){
                setTargetPosition(agent);
            }

            generalUpdateEnd(agent);
        }

        @Override
        public void exit(ZombieRangedAgentComponent agent) {

        }

        @Override
        public boolean onMessage(ZombieRangedAgentComponent agent, Telegram telegram) {
            return false;
        }
    },
    FOLLOW() {
        private void createPath(ZombieRangedAgentComponent agent){
            agent.path=mapManager.pointGraph.findPath(agent.currentPoint,mapManager.pointGraph.attackPosition(agent.currentPoint,agent.targetAgent.currentPoint,agent.primaryWeapon.range,agent.primaryWeapon.bulletType));
            agent.iterator=agent.path.iterator();
            agent.nextPoint=agent.iterator.next();
            if (agent.nextPoint==agent.currentPoint&&agent.iterator.hasNext())
                agent.nextPoint=agent.iterator.next();
        }
        @Override
        public void enter(ZombieRangedAgentComponent agent) {
            agent.currentState=StateType.FOLLOW;
            generalStateEnter(agent);
            createPath(agent);
        }

        @Override
        public void update(ZombieRangedAgentComponent agent) {
            float deltaTime = generalUpdate(agent);

            if (agent.target==null || !agent.targetCreature.isAlive){
                findInRange(agent);
                if (agent.target==null)
                    agent.stateMachine.changeState(IDLE);
            }

            if (agent.currentTime>agent.count){
                Entity entity=findInRange(agent);
                if (entity!=null){
                    agent.target=entity;
                    agent.targetTransform=Mappers.transformComponents.get(agent.target);
                    agent.targetCreature=Mappers.creatureComponents.get(agent.target);
                    agent.targetAgent=Mappers.agentComponents(agent.target);
                }

                createPath(agent);

                switch (agent.primaryWeapon.bulletType){
                    case LINE:
                        if (!mapManager.pointGraph.anyObstacle(agent.currentPoint,agent.targetAgent.currentPoint)&&agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT)
                            {agent.stateMachine.changeState(ATTACK);
                                Gdx.app.log(TAG,"Swi:" +"LINE");}
                        break;
                    case AIRBORNE:
                        if (agent.targetAgent.currentPoint.roofed){
                            findTarget(agent);
                        }
                        else if (agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT)
                            agent.stateMachine.changeState(ATTACK);
                        Gdx.app.log(TAG,"Swi:"+"AIRBORNE");
                        break;
                    case UNDERGROUND:
                        if (agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT)
                            agent.stateMachine.changeState(ATTACK);
                        break;
                }
            }


            if (agent.nextPoint!=null){
                PlayerStatics.getInstance().totalMovement.add(agent.creature.getSpeed()*deltaTime);

                if (agent.currentTime<agent.startTime+agent.progressTime){
                    agent.transform.pos.x += agent.direction.x * agent.creature.getSpeed()*deltaTime;
                    agent.transform.pos.y += agent.direction.y * agent.creature.getSpeed()*deltaTime;
                }
                else {
                    if (agent.iterator.hasNext()){
                        agent.nextPoint=agent.iterator.next();
                        if (agent.nextPoint.x==agent.currentPoint.x)
                            agent.targetPosition.set(agent.nextPoint.x+(Point.UNIT*random.nextFloat()-Point.UNIT/2),agent.nextPoint.y);
                        else
                            agent.targetPosition.set(agent.nextPoint.x,agent.nextPoint.y+(Point.UNIT*random.nextFloat()-Point.UNIT/2));

                        agent.startTime=agent.currentTime;
                        agent.progressTime= (float) (Math.pow(Math.pow(agent.targetPosition.x-agent.transform.pos.x,2)+Math.pow(agent.targetPosition.y-agent.transform.pos.y,2),0.5f)/agent.creature.getSpeed());
                        agent.direction.set(agent.targetPosition.x-agent.transform.pos.x,agent.targetPosition.y-agent.transform.pos.y).scl(1/agent.direction.len());
                    }
                    else{
                        agent.nextPoint=null;
                    }
                }
            }
            else {
                createPath(agent);
            }
            generalUpdateEnd(agent);
        }

        @Override
        public void exit(ZombieRangedAgentComponent entity) {

        }

        @Override
        public boolean onMessage(ZombieRangedAgentComponent entity, Telegram telegram) {
            return false;
        }
    },
    ATTACK() {

        @Override
        public void enter(ZombieRangedAgentComponent agent) {
            agent.currentState=StateType.ATTACK;
            generalStateEnter(agent);

        }

        @Override
        public void update(ZombieRangedAgentComponent agent) {
            float deltaTime=generalUpdate(agent);

            if (agent.target==null || agent.targetCreature.isAlive==false){
                agent.stateMachine.changeState(IDLE);
                return;
            }
            if (agent.nextAttackTime <agent.currentTime){
                float distance = agent.transform.distance(agent.targetTransform);
                //BulletType==Line
                switch (agent.primaryWeapon.bulletType){
                    case LINE:
                        if (!mapManager.pointGraph.anyObstacle(agent.currentPoint, agent.targetAgent.currentPoint) && distance<agent.primaryWeapon.range*Point.UNIT){
                            agent.nextAttackTime =agent.currentTime+agent.primaryWeapon.getAttackRate(agent.creature);
                            agent.primaryWeapon.abilityControllers.clear();
                            agent.updateAbilities(AbilityController.Type.ATTACK);
                            agent.primaryWeapon.attack(agent.creature,agent.targetCreature);
                        }
                        else{
                            Gdx.app.log(TAG,"AttToFoll");
                            agent.stateMachine.changeState(FOLLOW);
                        }
                        break;
                    case AIRBORNE:
                        if(agent.targetAgent.currentPoint.roofed==false && distance<agent.primaryWeapon.range*Point.UNIT){
                            agent.nextAttackTime =agent.currentTime+agent.primaryWeapon.getAttackRate(agent.creature);
                            agent.primaryWeapon.abilityControllers.clear();
                            agent.updateAbilities(AbilityController.Type.ATTACK);
                            agent.primaryWeapon.attack(agent.creature,agent.targetCreature);
                        }
                        else {
                            findInRange(agent);
                            if (agent.target==null){
                                agent.stateMachine.changeState(IDLE);
                            }
                            else{
                                agent.stateMachine.changeState(FOLLOW);
                            }
                        }
                        break;
                    case UNDERGROUND:
                        if (distance<agent.primaryWeapon.range*Point.UNIT){
                            agent.nextAttackTime =agent.currentTime+agent.primaryWeapon.getAttackRate(agent.creature);
                            agent.primaryWeapon.abilityControllers.clear();
                            agent.updateAbilities(AbilityController.Type.ATTACK);
                            agent.primaryWeapon.attack(agent.creature,agent.targetCreature);
                        }
                        else{
                            agent.stateMachine.changeState(FOLLOW);
                        }
                }
            }

            generalUpdateEnd(agent);
        }

        @Override
        public void exit(ZombieRangedAgentComponent agent) {

        }

        @Override
        public boolean onMessage(ZombieRangedAgentComponent entity, Telegram telegram) {
            return false;
        }
    };

    private static final String TAG=ZombieRangedState.class.getSimpleName();
    MapManager mapManager;
    Random random;

    ZombieRangedState() {
        mapManager=MapManager.getInstance();
        random= GeneralOrganizer.getInstance().random;
    }

    protected void findTarget(ZombieRangedAgentComponent agent){
        agent.target=null;
        agent.targetTransform=null;
        agent.targetCreature=null;
        agent.targetTransform=null;

        for (int i=0;i<=agent.awareRadius;i++){
            Array<Point> points= Utility.pointArrayPool.obtain();
            points=mapManager.pointGraph.getAreaPoints(points,agent.currentPoint,i);
            for (int j=0;j<points.size;j++){
                if (agent.primaryWeapon.bulletType==BulletType.AIRBORNE){
                    if (points.get(j).roofed)
                        continue;
                }
                if (points.get(j).humans.size!=0){
                    agent.target=points.get(j).humans.random();
                    agent.targetTransform= Mappers.transformComponents.get(agent.target);
                    agent.targetCreature= Mappers.creatureComponents.get(agent.target);
                    agent.targetAgent= Mappers.agentComponents(agent.target);
                    Utility.pointArrayPool.free(points);
                    return;
                }
            }
            Utility.pointArrayPool.free(points);
        }
    }

    protected Entity findInRange(ZombieRangedAgentComponent agent){
        for (int i=0;i<=agent.primaryWeapon.range;i++){
            Array<Point> points=Utility.pointArrayPool.obtain();
            points=mapManager.pointGraph.getRangePoints(points,agent.currentPoint,i);
            for (int j=0; j<points.size; j++){
                if (points.get(j).roofed && agent.primaryWeapon.bulletType==BulletType.AIRBORNE)
                    continue;
                if (agent.primaryWeapon.bulletType==BulletType.LINE&&mapManager.pointGraph.anyObstacle(agent.currentPoint,points.get(j)))
                    continue;
                if (points.get(j).humans.size!=0){
                    return points.get(j).humans.random();
                }

            }
        }
        return null;
    }

    protected void generalStateEnter(ZombieRangedAgentComponent agent){
        if (EntityUI.getEntity()==agent.entity)
            EntityUI.entityUI.entityStateChange();
        agent.count=0;
        agent.updateAbilities(AbilityController.Type.STATE);
    }

    protected float generalUpdate(ZombieRangedAgentComponent agent){
        float delta= MathUtils.clamp(Gdx.graphics.getDeltaTime(),0,0.1f);
        agent.currentTime+=delta;
        if (agent.currentPoint!=mapManager.pointGraph.getPoint(agent.transform.pos.x,agent.transform.pos.y)){
            agent.currentPoint.zombies.removeValue(agent.entity,false);
            agent.currentPoint=mapManager.pointGraph.nearestPoint(agent.transform.pos);
            agent.currentPoint.zombies.add(agent.entity);
        }
        agent.updateAbilities(AbilityController.Type.UPDATE);
        return delta;
    }

    protected void generalUpdateEnd(ZombieRangedAgentComponent agent){
        if (agent.currentTime>agent.count)
            agent.count=(int)(agent.currentTime+1);
    }
}
