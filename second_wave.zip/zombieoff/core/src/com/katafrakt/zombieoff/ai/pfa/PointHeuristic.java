package com.katafrakt.zombieoff.ai.pfa;

import com.badlogic.gdx.ai.pfa.Heuristic;

public class PointHeuristic implements Heuristic<Point> {
    @Override
    public float estimate(Point beginNode, Point endNode) {
        return (Math.abs(endNode.x-beginNode.x)+Math.abs(endNode.y-endNode.y));
        //return Vector2.dst(beginNode.x,beginNode.y,endNode.x,endNode.y);
    }
}
