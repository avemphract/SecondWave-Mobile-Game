package com.katafrakt.zombieoff.ai.pfa;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ai.pfa.Connection;
import com.badlogic.gdx.ai.pfa.DefaultGraphPath;
import com.badlogic.gdx.ai.pfa.GraphPath;
import com.badlogic.gdx.ai.pfa.indexed.IndexedAStarPathFinder;
import com.badlogic.gdx.ai.pfa.indexed.IndexedGraph;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ObjectMap;
import com.badlogic.gdx.utils.Pool;
import com.badlogic.gdx.utils.async.AsyncExecutor;
import com.badlogic.gdx.utils.async.AsyncTask;
import com.katafrakt.zombieoff.entities.BulletType;
import com.katafrakt.zombieoff.utilities.DoubleIntMap;
import com.katafrakt.zombieoff.utilities.RangeGenerator;
import com.katafrakt.zombieoff.utilities.Utility;


public class PointGraph implements IndexedGraph<Point> {
    private static final String TAG=PointGraph.class.getSimpleName();
    private static Pool<GraphPath<Point>> graphPathPool=new Pool<GraphPath<Point>>() {
        @Override
        protected GraphPath<Point> newObject() {
            return new DefaultGraphPath<Point>();
        }
    };

    IndexedAStarPathFinder<Point> indexedAStarPathFinder;
    public void postCreation(){

        indexedAStarPathFinder=new IndexedAStarPathFinder<>(this);
    }

    PointHeuristic pointHeuristic = new PointHeuristic();

    public Array<Point> points = new Array<>();
    Array<PointConnection> connections=new Array<>();

    public Array<Vector2> nonConnection;

    //public Table<Integer,Integer,Point> pointTable= HashBasedTable.create();
    public DoubleIntMap<Point> pointTable=new DoubleIntMap<>();

    int width,height,tileSize;

    ObjectMap<Point,Array<Connection<Point>>> pointsMap=new ObjectMap<>();

    Array<Point> debugPoint;
    BitmapFont bitmapFont;

    public PointGraph(int width,int height, int tileSize){
        this.width=width*tileSize/Point.UNIT;
        this.height=height*tileSize/Point.UNIT;
        this.tileSize=tileSize;
        bitmapFont=new BitmapFont();
        bitmapFont.getData().setScale(0.2f);
        //bitmapFont= AssetOrganizer.getInstance().get("skin/htt.fnt",BitmapFont.class);
    }

    public Array<Point> getRangePoints(Array<Point> own,Point pos, int range){
        Array<Integer[]> integers=RangeGenerator.getInstance().circleLine.get(range);
        for (int i=0;i<integers.size;i++){
            Point point=pointTable.get(pos.tableX+integers.get(i)[0],pos.tableY+integers.get(i)[1]);
            if (point!=null&&point.walkable){
                own.add(point);
            }
        }
        return own;
    }
    public Array<Point> getAreaPoints(Array<Point> own,Point pos, int range){
        Array<Integer[]> integers=RangeGenerator.getInstance().circleArea.get(range);
        for (int i=0;i<integers.size;i++){
            Point point=pointTable.get(pos.tableX+integers.get(i)[0],pos.tableY+integers.get(i)[1]);
            if (point!=null){
                if (own==null){
                    Gdx.app.log(TAG,"Bir problem var");
                }
                own.add(point);
            }
        }
        return own;
    }

    public Array<Point> getRangeBetween(Array<Point> own,Point pos, int in, int out){
        for (int i=in;i<=out;i++){
            Array<Integer[]> integers=RangeGenerator.getInstance().circleLine.get(i);
            for (int j=0;j<integers.size;j++){
                Point point=pointTable.get(pos.tableX+integers.get(i)[0],pos.tableY+integers.get(i)[1]);

                if (point!=null){
                    own.add(point);
                }
            }
        }
        return own;
    }

    public void addPoint(Point point){
        row1: for (Point temp:points){
            if (point.walkable==true&&temp.walkable==true)
                if (Vector2.dst(temp.x,temp.y,point.x,point.y)==Point.UNIT){
                    for (int i=0;i<nonConnection.size;i++){
                        if ((point.x+temp.x)/2==nonConnection.get(i).x && (point.y+temp.y)/2==nonConnection.get(i).y){
                            continue row1;
                        }
                    }
                    addConnection(temp,point);
                    addConnection(point,temp);
                }
        }
        points.add(point);
        //Gdx.app.log(TAG,point.x+" , "+point.y);
        pointTable.put((int)(point.x-Point.UNIT/2)/Point.UNIT,(int)(point.y-Point.UNIT/2)/Point.UNIT,point);
        point.tableX=(int)(point.x-Point.UNIT/2)/Point.UNIT;
        point.tableY=(int)(point.y-Point.UNIT/2)/Point.UNIT;
    }

    private void addConnection(Point fromCity,Point toCity){
        PointConnection connection=new PointConnection(fromCity,toCity);
        if (!pointsMap.containsKey(fromCity)){
            pointsMap.put(fromCity,new Array<Connection<Point>>());
        }
        pointsMap.get(fromCity).add(connection);
        connections.add(connection);
    }

    public Point nearestPoint(Vector2 target){
        int pointX=(int)(target.x)/Point.UNIT;
        int pointY=(int)(target.y)/Point.UNIT;
        if (0>pointX)
            pointX=0;
        else if (pointX>=width)
            pointX=width-1;
        if (0>pointY)
            pointY=0;
        else if (pointY>=height)
            pointY=height-1;

        Point point=pointTable.get(pointX,pointY);
        if (point!=null&&point.walkable)
            return point;

        if (point!=null){
            //Gdx.app.log(TAG,"type_1");
            Array<Point> points=point.rangeArrayMap.get(5);
            for (int i=0;i<points.size;i++){
                if (points.get(i).walkable)
                    return points.get(i);
            }
        }

        {
            float minDist = 999;
            for (int i=0;i<points.size;i++){
                if (!points.get(i).walkable)
                    continue;
                float tempDist=(float) Math.pow(Math.pow(points.get(i).x-target.x,2)+Math.pow(points.get(i).y-target.y,2),0.5f);
                if (tempDist<minDist){
                    minDist=tempDist;
                    point=points.get(i);
                }
            }
        }
        return point;
    }

    public Point nearestPoint(float targetX, float targetY){
        int pointX=(int)(targetX)/Point.UNIT;
        int pointY=(int)(targetY)/Point.UNIT;
        if (0>pointX)
            pointX=0;
        else if (pointX>=width)
            pointX=width-1;
        if (0>pointY)
            pointY=0;
        else if (pointY>=height)
            pointY=height-1;

        Point point=pointTable.get(pointX,pointY);
        if (point!=null&&point.walkable)
            return point;

        //Type1
        if (point!=null){
            //Gdx.app.log(TAG,"type_1");
            for (int i=1;i<30 || point==null;i++){
                Array<Point> points= Utility.pointArrayPool.obtain();
                getRangePoints(points,point,i);
                for (Point temp:points){
                    if (temp.walkable){
                        Utility.pointArrayPool.free(points);
                        return temp;
                    }
                }
                Utility.pointArrayPool.free(points);
            }
        }

        //Type2
        {
            float minDist = 999;
            for (Point temp:points){
                if (!temp.walkable)
                    continue;
                float tempDist=(float) Math.pow(Math.pow(temp.x-targetX,2)+Math.pow(temp.y-targetY,2),0.5f);
                if (tempDist<minDist){
                    minDist=tempDist;
                    point=temp;
                }
            }
        }
        return point;
    }


    public Point nearestPointWithRange(Vector2 position, Vector2 target, int range){
        float minNDistance=999;
        Point targetPoint = null;
        //range-=Point.UNIT/2;
        for (Point point:points){

            //nokta yürünemezse atla
            if (!point.walkable)
                continue;
            //nokta maksimum menzilden daha uzaksa atla
            float currentRange = (float) Math.pow(Math.pow(point.x-target.x,2)+Math.pow(point.y-target.y,2),0.5f);
            if (range<currentRange)
                continue;

            float tempNDistance = (float) Math.pow(Math.pow(point.x-position.x,2)+Math.pow(point.y-position.y,2),0.5f);
            if (minNDistance>tempNDistance){
                minNDistance=tempNDistance;
                targetPoint=point;
            }
        }
        return targetPoint;
    }

    public Point nearestPointWithRange(Array<Point> points,Point position,Point target,int range){
        float minNDistance=999;
        Point targetPoint = null;
        //range-=Point.UNIT/2;
        for (Point point:points){
            float currentRange = (float) Math.pow(Math.pow(point.x-target.x,2)+Math.pow(point.y-target.y,2),0.5f);
            if (range*Point.UNIT<currentRange)
                continue;

            float tempNDistance = (float) Math.pow(Math.pow(point.x-position.x,2)+Math.pow(point.y-position.y,2),0.5f);
            if (minNDistance>tempNDistance){
                minNDistance=tempNDistance;
                targetPoint=point;
            }

        }
        return targetPoint;
    }

    //Array<Point> areaPoints=new Array<>();
    public Point attackPosition(Point position, Point target, int range, BulletType bulletType){

        Array<Point> areaPoints=target.rangeArrayMap.get(range-2);
        float minDistance=999;
        Point result=null;

        for (int i=0;i<areaPoints.size;i++) {
            if (!areaPoints.get(i).walkable) {
                continue;
            }

            switch (bulletType) {
                case LINE:
                    if (anyObstacle(target, areaPoints.get(i)))
                        continue;
                    break;
                case UNDERGROUND:
                    if (areaPoints.get(i).roofed)
                        continue;
                    break;
            }

            //Gdx.app.log(TAG,"P: "+point.x+","+point.y+" - "+position);
            //int tempDis = findPath(position, point).getCount();
            float tempDis=pointHeuristic.estimate(position,areaPoints.get(i));

            if (tempDis < minDistance) {
                minDistance = tempDis;
                result = areaPoints.get(i);
            }

        }
        //Debug
        if (result==null){
            Gdx.app.log(TAG,"Result: "+minDistance+" - "+target.x+","+target.y+" - "+range+" - "+areaPoints.size);
            for (int i=0;i<areaPoints.size;i++) {
                if (!areaPoints.get(i).walkable) {
                    Gdx.app.log(TAG,"NonWalkable: "+areaPoints.get(i).x+","+areaPoints.get(i).y);
                    continue;
                }
                switch (bulletType) {
                    case LINE:
                        if (anyObstacle(target, areaPoints.get(i))){
                            Gdx.app.log(TAG,"Obs: "+areaPoints.get(i).x+","+areaPoints.get(i).y);
                            continue;
                        }
                        break;
                    case UNDERGROUND:
                        if (areaPoints.get(i).roofed)
                            continue;
                        break;
                }

                //Gdx.app.log(TAG,"P: "+point.x+","+point.y+" - "+position);
                int tempDis = findPath(position, areaPoints.get(i)).getCount();
                Gdx.app.log(TAG,"TempDis:"+tempDis+" - "+areaPoints.get(i).x+","+areaPoints.get(i).y);
                if (tempDis < minDistance) {
                    minDistance = tempDis;
                    result = areaPoints.get(i);
                }

            }

        }

        return result;
    }

    public synchronized GraphPath<Point> findPath(Point startPoint, Point endPoint){ ;
        GraphPath<Point> pointPath=new DefaultGraphPath<>();
        if (startPoint.walkable==false)
            Gdx.app.log(TAG,"StartPoint isnt walkale");
        if (endPoint==null){
            Gdx.app.log(TAG,"EndPoint is null");
            indexedAStarPathFinder.searchNodePath(startPoint,startPoint,pointHeuristic,pointPath);
            return pointPath;
        }
        if (endPoint.walkable==false)
            Gdx.app.log(TAG,"EndPoint isnt walkable");
        //Gdx.app.log(TAG,"Total created path: "+i);
        indexedAStarPathFinder.searchNodePath(startPoint,endPoint,pointHeuristic,pointPath);
        return pointPath;
    }

    public boolean anyObstacle(Point startPoint, Point endPoint){
        int totalStep= Math.max((int) Math.abs((startPoint.x-endPoint.x)/Point.UNIT),(int) Math.abs((startPoint.y-endPoint.y)/Point.UNIT));
        float[] direction=new float[]{ (endPoint.x-startPoint.x)/(totalStep) , (endPoint.y-startPoint.y)/(totalStep)};
        float[] currentPoint=new float[2];
        for (int n=1;n<totalStep-1;n++){
            currentPoint[0]=startPoint.x+direction[0]*n;
            currentPoint[1]=startPoint.y+direction[1]*n;
            Point tempPoint=getPoint(currentPoint[0],currentPoint[1]);
            //if (tempPoint==null)
              //  Gdx.app.log(TAG,"Temp is null:"+currentPoint[0]+","+currentPoint[1]);
            if (tempPoint!=null&&tempPoint.obstacle){
                return true;
            }
        }
        return false;
    }

    public Point getPoint(float x,float y){
        return pointTable.get((int)(x/Point.UNIT),(int)(y/Point.UNIT));
    }
    /*
    public Point getExtensivePoint(Point point){
        if (pointTable.get(point.tableX+1,point.tableY)!=null&&pointTable.get(point.tableX+1,point.tableY).walkable){
            if (MathUtils.randomBoolean()){
                if ()
            }else {

            }
        }
        else if (pointTable.get(point.tableX-1,point.tableY)!=null&&pointTable.get(point.tableX-1,point.tableY).walkable){

        }
        else if (pointTable.get(point.tableX,point.tableY+1)!=null&&pointTable.get(point.tableX,point.tableY+1).walkable){

        }
        else if (pointTable.get(point.tableX,point.tableY-1)!=null&&pointTable.get(point.tableX,point.tableY-1).walkable){

        }
    }
*/
    Color roofColor=new Color(0,0,0,0.2f);

    int i=0;
    public void render(ShapeRenderer shapeRenderer){
        shapeRenderer.set(ShapeRenderer.ShapeType.Line);


        shapeRenderer.setColor(Color.BROWN);
        for (PointConnection connection:connections){
            connection.render(shapeRenderer);
        }

        shapeRenderer.setColor(Color.GRAY);
        shapeRenderer.set(ShapeRenderer.ShapeType.Filled);
        for (Point point:points){
            if (point.obstacle){
                shapeRenderer.setColor(Color.BROWN);
                //shapeRenderer.circle(point.x,point.y,Point.UNIT/2);
            }

            if (point.humans.size==1){
                shapeRenderer.setColor(Color.GRAY);
                shapeRenderer.circle(point.x,point.y,1);
            }
            if (point.humans.size>1){
                shapeRenderer.setColor(Color.WHITE);
                shapeRenderer.circle(point.x,point.y,1);
            }
            if (point.zombies.size>0){
                shapeRenderer.setColor(Color.BLACK);
                shapeRenderer.circle(point.x,point.y,1);
            }
            if (point.zombies.size>1){
                shapeRenderer.setColor(Color.GOLD);
                shapeRenderer.circle(point.x,point.y,1);
            }
        }
        shapeRenderer.setColor(roofColor);
        for (Point point:points){
            if (point.roofed){
                shapeRenderer.rect(point.x-Point.UNIT/2,point.y-Point.UNIT/2,Point.UNIT,Point.UNIT);
            }
        }
        shapeRenderer.end();
    }

    public void drawString(SpriteBatch spriteBatch){
        for (Point point:points){
            bitmapFont.draw(spriteBatch,""+point.loadedRange,(int)point.x-1,(int)point.y+1);
        }
    }

    @Override
    public int getIndex(Point node) {
        return node.index;
    }

    @Override
    public int getNodeCount() {
        return points.size;
    }

    @Override
    public Array<Connection<Point>> getConnections(Point fromNode) {
        if (pointsMap.containsKey(fromNode)){
            return pointsMap.get(fromNode);
        }
        return null;
    }
}
