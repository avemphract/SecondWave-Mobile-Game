package com.katafrakt.zombieoff.ai.statesV2;

import com.badlogic.gdx.ai.fsm.State;
import com.badlogic.gdx.ai.msg.Telegram;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ai.pfa.PointGraph;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agentsV2.ZombieAgentComponentV2;
import com.katafrakt.zombieoff.ashley.systems.agents.AgentV2System;
import com.katafrakt.zombieoff.game.AnimationName;
import com.katafrakt.zombieoff.game.StateType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.managers.GeneralOrganizer;
import com.katafrakt.zombieoff.managers.MapManager;

import java.util.Random;

public enum ZombieStateV2 implements State<ZombieAgentComponentV2> {
    WAIT(){
        @Override
        public void enter(ZombieAgentComponentV2 agent) {
            agent.currentState= StateType.IDLE;
            agent.animationName= AnimationName.getWaitName(agent.animationName.direction);
            agent.currentState= StateType.IDLE;

            agent.updateAbilities(AbilityController.Type.STATE);
        }

        @Override
        public void update(ZombieAgentComponentV2 agent) {
            findTarget(agent);
            if (agent.target!=null){
                agent.stateMachine.changeState(FOLLOW);
                return;
            }
            if (random.nextFloat()>0.2f)
                agent.stateMachine.changeState(WALK);
            else
                agent.nextTick=AgentV2System.totalTime+1+random.nextFloat();
        }

        @Override
        public void exit(ZombieAgentComponentV2 entity) {

        }

        @Override
        public boolean onMessage(ZombieAgentComponentV2 entity, Telegram telegram) {
            return false;
        }
    },WALK(){
        @Override
        public void enter(ZombieAgentComponentV2 agent) {
            agent.targetPoint=pointGraph.nearestPoint(agent.currentPoint.x+(0.5f-random.nextFloat())*Point.UNIT*3,agent.currentPoint.y+(0.5f-random.nextFloat())*Point.UNIT*3);
            agent.iterator=pointGraph.findPath(agent.currentPoint,agent.targetPoint).iterator();
            agent.currentState= StateType.IDLE;

            agent.updateAbilities(AbilityController.Type.STATE);
        }

        @Override
        public void update(ZombieAgentComponentV2 agent) {

            if (agent.currentPoint!=pointGraph.nearestPoint(agent.transform.pos)){
                agent.currentPoint.zombies.removeValue(agent.entity,true);
                agent.currentPoint=pointGraph.nearestPoint(agent.transform.pos);
                agent.currentPoint.zombies.add(agent.entity);
            }
            agent.count++;
            if (agent.count%agent.scanRate==0)
                findTarget(agent);
            if (agent.target!=null){
                agent.nextTick=AgentV2System.totalTime+1;
                agent.stateMachine.changeState(FOLLOW);
            }
            else if (agent.iterator.hasNext()){
                agent.nextPoint=agent.iterator.next();
                agent.nextPosition.set(agent.nextPoint.x+(0.5f-random.nextFloat())*Point.UNIT*EXTRA_WALK,agent.nextPoint.y+(0.5f-random.nextFloat())*Point.UNIT*EXTRA_WALK);
                float distance= (float) Math.pow(Math.pow(agent.nextPosition.x-agent.transform.pos.x,2)+Math.pow(agent.nextPosition.y-agent.transform.pos.y,2),0.5f);

                agent.velocityComponent.speed.set((agent.nextPosition.x-agent.transform.pos.x)/distance*agent.creature.getSpeed(), (agent.nextPosition.y-agent.transform.pos.y)/distance*agent.creature.getSpeed());
                agent.nextTick=AgentV2System.totalTime + distance/agent.creature.getSpeed();

                agent.direction=AnimationName.getDirection(agent.velocityComponent.speed.x,agent.velocityComponent.speed.y);
                agent.animationName=AnimationName.getWalkName(agent.direction);//Animation set
            }
            else {
                agent.nextTick=AgentV2System.totalTime+1;
                agent.stateMachine.changeState(WAIT);

            }
        }

        @Override
        public void exit(ZombieAgentComponentV2 agent) {
            agent.velocityComponent.speed.setZero();
            agent.nextPoint=null;
            if (agent.currentPoint!=pointGraph.nearestPoint(agent.transform.pos)){
                agent.currentPoint.zombies.removeValue(agent.entity,true);
                agent.currentPoint=pointGraph.nearestPoint(agent.transform.pos);
                agent.currentPoint.zombies.add(agent.entity);
            }
        }

        @Override
        public boolean onMessage(ZombieAgentComponentV2 entity, Telegram telegram) {
            return false;
        }
    },FOLLOW(){
        @Override
        public void enter(ZombieAgentComponentV2 agent) {
            agent.targetPoint=pointGraph.nearestPoint(agent.targetTransform.pos);
            agent.iterator=pointGraph.findPath(agent.currentPoint,agent.targetPoint).iterator();

            agent.currentState= StateType.FOLLOW;

            agent.updateAbilities(AbilityController.Type.STATE);
        }

        @Override
        public void update(ZombieAgentComponentV2 agent) {

            if (agent.currentPoint!=pointGraph.nearestPoint(agent.transform.pos)){
                agent.currentPoint.zombies.removeValue(agent.entity,true);
                agent.currentPoint=pointGraph.nearestPoint(agent.transform.pos);
                agent.currentPoint.zombies.add(agent.entity);
            }

            if (!agent.targetCreature.isAlive){
                findTarget(agent);
                if (agent.target==null){
                    agent.stateMachine.changeState(WAIT);
                    return;
                }
            }
            if (agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT){
                agent.stateMachine.changeState(ATTACK);
            }
            else if (agent.iterator.hasNext()){
                agent.nextPoint=agent.iterator.next();
                agent.nextPosition.set(agent.nextPoint.x+(0.5f-random.nextFloat())*Point.UNIT*EXTRA_WALK,agent.nextPoint.y+(0.5f-random.nextFloat())*Point.UNIT*EXTRA_WALK);
                float distance= (float) Math.pow(Math.pow(agent.nextPosition.x-agent.transform.pos.x,2)+Math.pow(agent.nextPosition.y-agent.transform.pos.y,2),0.5f);

                agent.velocityComponent.speed.set((agent.nextPosition.x-agent.transform.pos.x)/distance*agent.creature.getSpeed(), (agent.nextPosition.y-agent.transform.pos.y)/distance*agent.creature.getSpeed());
                agent.nextTick= AgentV2System.totalTime + distance/agent.creature.getSpeed();

                agent.direction=AnimationName.getDirection(agent.velocityComponent.speed.x,agent.velocityComponent.speed.y);
                agent.animationName=AnimationName.getWalkName(agent.direction);//Animation set
            }
            else {
                agent.nextTick=AgentV2System.totalTime+1;
                agent.stateMachine.changeState(WAIT);
            }
        }

        @Override
        public void exit(ZombieAgentComponentV2 agent) {
            agent.velocityComponent.speed.setZero();
            agent.nextPoint=null;
            if (agent.currentPoint!=pointGraph.nearestPoint(agent.transform.pos)){
                agent.currentPoint.zombies.removeValue(agent.entity,true);
                agent.currentPoint=pointGraph.nearestPoint(agent.transform.pos);
                agent.currentPoint.zombies.add(agent.entity);
            }
        }

        @Override
        public boolean onMessage(ZombieAgentComponentV2 entity, Telegram telegram) {
            return false;
        }
    },ATTACK(){
        @Override
        public void enter(ZombieAgentComponentV2 agent) {
            agent.currentState= StateType.ATTACK;

            agent.updateAbilities(AbilityController.Type.STATE);
        }

        @Override
        public void update(ZombieAgentComponentV2 agent) {
            if (agent.target==null || !agent.targetCreature.isAlive){
                agent.stateMachine.changeState(WAIT);
                return;
            }
            float distance=agent.transform.distance(agent.targetTransform);
            if (distance<agent.primaryWeapon.range*Point.UNIT){
                agent.nextTick=AgentV2System.totalTime+agent.primaryWeapon.getAttackRate(agent.creature);
                agent.primaryWeapon.abilityControllers.clear();//Set ability to weapon
                agent.updateAbilities(AbilityController.Type.ATTACK);//Ability Update
                agent.primaryWeapon.attack(agent.creature,agent.targetCreature);
            }
            else
                agent.stateMachine.changeState(FOLLOW);
            agent.direction=AnimationName.getDirection(agent.targetTransform.pos.x-agent.transform.pos.x,agent.targetTransform.pos.y-agent.transform.pos.y);
            agent.animationName=AnimationName.getAttackName(agent.direction);
        }

        @Override
        public void exit(ZombieAgentComponentV2 entity) {

        }

        @Override
        public boolean onMessage(ZombieAgentComponentV2 entity, Telegram telegram) {
            return false;
        }
    };

    protected Random random= GeneralOrganizer.getInstance().random;
    protected PointGraph pointGraph= MapManager.getInstance().pointGraph;
    final protected float EXTRA_WALK=0.7f;

    protected void findTarget(ZombieAgentComponentV2 agent){
        agent.target=null;
        agent.targetTransform=null;
        agent.targetCreature=null;
        agent.targetAgent=null;


        Array<Point> points=agent.currentPoint.rangeArrayMap.get(agent.awareRadius);
        for (int j=0;j<points.size;j++){
            if (points.get(j).humans.size!=0){
                agent.target=points.get(j).humans.random();
                agent.targetTransform= Mappers.transformComponents.get(agent.target);
                agent.targetCreature=Mappers.creatureComponents.get(agent.target);
                agent.targetAgent=Mappers.agentComponentV2(agent.target);
                return;
            }
        }
    }
}
