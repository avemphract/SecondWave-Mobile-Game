package com.katafrakt.zombieoff.ai.statesV2;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ai.fsm.State;
import com.badlogic.gdx.ai.msg.MessageManager;
import com.badlogic.gdx.ai.msg.Telegram;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ai.pfa.PointGraph;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agentsV2.PoliceAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.ashley.systems.agents.AgentV2System;
import com.katafrakt.zombieoff.entities.BulletType;
import com.katafrakt.zombieoff.entities.EntityType;
import com.katafrakt.zombieoff.game.AnimationName;
import com.katafrakt.zombieoff.game.StateType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.weapons.MeleeWeapon;
import com.katafrakt.zombieoff.game.weapons.RangedWeapon;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.ui.EntityUI;


public enum PoliceStateV2 implements State<PoliceAgentComponentV2> {
    WAIT(){
        @Override
        public void enter(PoliceAgentComponentV2 agent) {
            agent.animationName=AnimationName.getWaitName(agent.animationName.direction);
            agent.currentState= StateType.IDLE;
            agent.updateAbilities(AbilityController.Type.STATE);

            if (EntityUI.getEntity()==agent.entity)
                EntityUI.entityUI.entityStateChange();
        }

        @Override
        public void update(PoliceAgentComponentV2 agent) {
            findTarget(agent);

            if (agent.target!=null){
                agent.nextTick= AgentV2System.totalTime+1;
                agent.stateMachine.changeState(GIVER);
                return;
            }

            if (MathUtils.random()>0.7f)
                agent.stateMachine.changeState(WALK);
            else
                agent.nextTick=AgentV2System.totalTime+1+MathUtils.random();
        }

        @Override
        public void exit(PoliceAgentComponentV2 entity) {

        }

        @Override
        public boolean onMessage(PoliceAgentComponentV2 agent, Telegram telegram) {
            agent.target= (Entity) telegram.extraInfo;
            agent.targetTransform=Mappers.transformComponents.get(agent.target);
            agent.targetCreature=Mappers.creatureComponents.get(agent.target);
            agent.targetAgent=Mappers.agentComponentV2(agent.target);
            agent.stateMachine.changeState(FOLLOW);

            return false;
        }
    },
    WALK(){
        @Override
        public void enter(PoliceAgentComponentV2 agent) {
            agent.targetPoint=pointGraph.nearestPoint(agent.currentPoint.x+(0.5f-MathUtils.random())*Point.UNIT*4,agent.currentPoint.y+(0.5f-MathUtils.random())*Point.UNIT*4);
            agent.path=pointGraph.findPath(agent.currentPoint,agent.targetPoint);
            agent.iterator=agent.path.iterator();

            agent.currentState=StateType.IDLE;

            agent.updateAbilities(AbilityController.Type.STATE);

            if (EntityUI.getEntity()==agent.entity)
                EntityUI.entityUI.entityStateChange();
        }

        @Override
        public void update(PoliceAgentComponentV2 agent) {
            if (agent.currentPoint!=pointGraph.nearestPoint(agent.transform.pos)){
                agent.currentPoint.humans.removeValue(agent.entity,true);
                agent.currentPoint=pointGraph.nearestPoint(agent.transform.pos);
                agent.currentPoint.humans.add(agent.entity);
            }
            agent.count++;
            if (agent.count%agent.scanRate==0){
                findTarget(agent);
            }

            if (agent.target!=null){
                agent.stateMachine.changeState(GIVER);
            }

            if (agent.iterator.hasNext()){

                agent.nextPoint = agent.iterator.next();
                agent.nextPosition.set(agent.nextPoint.x+(0.5f-MathUtils.random())*Point.UNIT,agent.nextPoint.y+(0.5f-MathUtils.random())*Point.UNIT);

                float distance= (float) Math.pow(Math.pow(agent.nextPosition.x-agent.transform.pos.x,2)+Math.pow(agent.nextPosition.y-agent.transform.pos.y,2),0.5f);

                //Gdx.app.log(TAG,"Dis"+distance);
                agent.velocityComponent.speed.set((agent.nextPosition.x-agent.transform.pos.x)/distance*agent.creature.getSpeed(), (agent.nextPosition.y-agent.transform.pos.y)/distance*agent.creature.getSpeed());
                agent.nextTick=AgentV2System.totalTime + distance/agent.creature.getSpeed();

                agent.direction=AnimationName.getDirection(agent.velocityComponent.speed.x,agent.velocityComponent.speed.y);
                agent.animationName=AnimationName.getWalkName(agent.direction);//Animation set

            }
            else {
                agent.nextTick=AgentV2System.totalTime+1;
                agent.stateMachine.changeState(WAIT);
            }


        }

        @Override
        public void exit(PoliceAgentComponentV2 agent) {
            agent.velocityComponent.speed.setZero();
            agent.nextPoint=null;

        }

        @Override
        public boolean onMessage(PoliceAgentComponentV2 agent, Telegram telegram) {
            agent.target= (Entity) telegram.extraInfo;
            agent.targetTransform=Mappers.transformComponents.get(agent.target);
            agent.targetCreature=Mappers.creatureComponents.get(agent.target);
            agent.targetAgent=Mappers.agentComponentV2(agent.target);
            agent.stateMachine.changeState(FOLLOW);
            return false;
        }
    },
    GIVER(){
        @Override
        public void enter(PoliceAgentComponentV2 agent) {
            agent.currentState=StateType.GIVER;
            findNearbyPolice(agent);
            agent.arrayQueue=0;
        }

        @Override
        public void update(PoliceAgentComponentV2 agent) {

            if (!agent.targetCreature.isAlive){

                agent.stateMachine.changeState(WAIT);
            }

            Gdx.app.log(TAG,"Police count:"+agent.arrayQueue+"/"+agent.nearbyPolices.size);
            //Polise haber ver
            while (agent.arrayQueue<agent.nearbyPolices.size){
                Entity entity=agent.nearbyPolices.get(agent.arrayQueue);

                PoliceAgentComponentV2 policeAgentComponentV2=Mappers.policeAgentComponentV2.get(entity);
                CreatureComponent policeCreature=Mappers.creatureComponents.get(entity);
                if (policeCreature.isAlive&&policeAgentComponentV2.currentState==StateType.IDLE){
                    messageManager.dispatchMessage(agent, policeAgentComponentV2,2,agent.target);
                    agent.nextTick=AgentV2System.totalTime+0.4f;
                    agent.arrayQueue++;
                    break;
                }
                agent.arrayQueue++;
            }
            //Haber verilecek polis kalmadıysa Saldır
            if (agent.arrayQueue==agent.nearbyPolices.size){
                agent.stateMachine.changeState(FOLLOW);
            }

        }

        @Override
        public void exit(PoliceAgentComponentV2 entity) {

        }

        @Override
        public boolean onMessage(PoliceAgentComponentV2 entity, Telegram telegram) {
            return false;
        }
    },
    FOLLOW(){
        @Override
        public void enter(PoliceAgentComponentV2 agent) {
            agent.targetPoint=pointGraph.nearestPoint(agent.targetTransform.pos);
            if (agent.primaryWeapon instanceof MeleeWeapon)
                agent.path=pointGraph.findPath(agent.currentPoint,agent.targetAgent.currentPoint);
            if (agent.primaryWeapon instanceof RangedWeapon)
                agent.path=pointGraph.findPath(agent.currentPoint,pointGraph.attackPosition(agent.currentPoint,agent.targetAgent.currentPoint,agent.primaryWeapon.range,((RangedWeapon) agent.primaryWeapon).bulletType));

            agent.iterator=agent.path.iterator();
            if (agent.iterator.hasNext())
                agent.iterator.next();

            agent.currentState=StateType.FOLLOW;

            agent.updateAbilities(AbilityController.Type.STATE);

            if (EntityUI.getEntity()==agent.entity)
                EntityUI.entityUI.entityStateChange();
        }

        @Override
        public void update(PoliceAgentComponentV2 agent) {
            if (agent.currentPoint!=pointGraph.nearestPoint(agent.transform.pos)) {
                agent.currentPoint.humans.removeValue(agent.entity,true);
                agent.currentPoint=pointGraph.nearestPoint(agent.transform.pos);
                agent.currentPoint.humans.add(agent.entity);
            }

            agent.count++;
            if (agent.count%agent.scanRate==0){
                Entity tempEntity=findInRange(agent);
                if (tempEntity!=null){
                    agent.target=tempEntity;
                    agent.targetTransform= Mappers.transformComponents.get(tempEntity);
                    agent.targetCreature=Mappers.creatureComponents.get(tempEntity);
                    agent.targetAgent=Mappers.agentComponentV2(tempEntity);
                    agent.stateMachine.changeState(ATTACK);
                    return;
                }
            }
            if (!agent.targetCreature.isAlive){
                findTarget(agent);
                if (agent.target==null){
                    agent.nextTick=AgentV2System.totalTime+1;
                    agent.stateMachine.changeState(WAIT);
                }
                else {
                    agent.stateMachine.changeState(FOLLOW);
                }
                return;
            }
            if (agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT){
                if (agent.primaryWeapon instanceof MeleeWeapon) {
                    if (agent.transform.distance(agent.targetTransform) < agent.primaryWeapon.range * Point.UNIT) {
                        agent.stateMachine.changeState(ATTACK);
                        return;
                    }
                } else if (agent.primaryWeapon instanceof RangedWeapon) {

                    RangedWeapon rangedWeapon = (RangedWeapon) agent.primaryWeapon;
                    switch (rangedWeapon.bulletType) {
                        case LINE:
                            if (!pointGraph.anyObstacle(agent.currentPoint, agent.targetAgent.currentPoint)) {
                                agent.stateMachine.changeState(ATTACK);
                                return;
                            }
                            break;
                        case AIRBORNE:
                            if (agent.targetAgent.currentPoint.roofed)
                                findTarget(agent);
                            else {
                                agent.stateMachine.changeState(ATTACK);
                                break;
                            }
                            break;
                        case UNDERGROUND:
                            agent.stateMachine.changeState(ATTACK);
                            return;

                    }
                }
            }

            if (agent.iterator.hasNext()){
                agent.nextPoint = agent.iterator.next();
                agent.nextPosition.set(agent.nextPoint.x+(0.5f-MathUtils.random())*Point.UNIT,agent.nextPoint.y+(0.5f-MathUtils.random())*Point.UNIT);

                float distance= (float) Math.pow(Math.pow(agent.nextPosition.x-agent.transform.pos.x,2)+Math.pow(agent.nextPosition.y-agent.transform.pos.y,2),0.5f);

                agent.velocityComponent.speed.set((agent.nextPosition.x-agent.transform.pos.x)/distance*agent.creature.getSpeed(), (agent.nextPosition.y-agent.transform.pos.y)/distance*agent.creature.getSpeed());
                agent.nextTick=AgentV2System.totalTime + distance/agent.creature.getSpeed();

                agent.direction=AnimationName.getDirection(agent.velocityComponent.speed.x,agent.velocityComponent.speed.y);
                agent.animationName=AnimationName.getWalkName(agent.direction);//Animation set

            }
            else {
                agent.stateMachine.changeState(FOLLOW);
            }
        }

        @Override
        public void exit(PoliceAgentComponentV2 agent) {
            agent.velocityComponent.speed.setZero();
            agent.nextPoint=null;
        }

        @Override
        public boolean onMessage(PoliceAgentComponentV2 entity, Telegram telegram) {
            return false;
        }
    },
    ATTACK(){
        @Override
        public void enter(PoliceAgentComponentV2 agent) {
            agent.currentState=StateType.ATTACK;

            agent.updateAbilities(AbilityController.Type.STATE);

            if (EntityUI.getEntity()==agent.entity)
                EntityUI.entityUI.entityStateChange();
        }

        @Override
        public void update(PoliceAgentComponentV2 agent) {
            //ToDo Mappers.animationComponents.get(agent.entity).stop=false;

            float distance=agent.transform.distance(agent.targetTransform);
            if (!agent.targetCreature.isAlive){
                findTarget(agent);
                if (agent.target==null)
                    agent.stateMachine.changeState(WAIT);
                else
                    agent.stateMachine.changeState(FOLLOW);
                return;
            }

            if (agent.primaryWeapon instanceof MeleeWeapon){
                if (distance<agent.primaryWeapon.range*Point.UNIT){
                    agent.nextTick=AgentV2System.totalTime+agent.primaryWeapon.getAttackRate(agent.creature);
                    agent.primaryWeapon.attack(agent.creature,agent.targetCreature);
                }
                else
                    agent.stateMachine.changeState(FOLLOW);
            }
            else if (agent.primaryWeapon instanceof RangedWeapon){
                switch (((RangedWeapon) agent.primaryWeapon).bulletType){
                    case LINE:
                        if (!pointGraph.anyObstacle(agent.currentPoint,agent.targetAgent.currentPoint) && distance<agent.primaryWeapon.range*Point.UNIT){
                            //ToDo Mappers.animationComponents.get(agent.entity).stop=false;
                            agent.nextTick=AgentV2System.totalTime+agent.primaryWeapon.getAttackRate(agent.creature);//Set next tick
                            agent.primaryWeapon.abilityControllers.clear();//Set ability to weapon
                            agent.updateAbilities(AbilityController.Type.ATTACK);//Ability Update
                            agent.primaryWeapon.attack(agent.creature,agent.targetCreature);//Attack


                            agent.animationName=AnimationName.getAttackName(AnimationName.getDirection(agent.targetTransform.pos.x-agent.transform.pos.x,agent.targetTransform.pos.y-agent.transform.pos.y));

                        }
                        else
                            agent.stateMachine.changeState(FOLLOW);
                        break;
                    case AIRBORNE:
                        if (!agent.targetAgent.currentPoint.roofed && distance<agent.primaryWeapon.range*Point.UNIT){
                            agent.nextTick=AgentV2System.totalTime+agent.primaryWeapon.getAttackRate(agent.creature);//Set next tick
                            agent.primaryWeapon.abilityControllers.clear();//Set ability to weapon
                            agent.updateAbilities(AbilityController.Type.ATTACK);//Ability Update
                            agent.primaryWeapon.attack(agent.creature,agent.targetCreature);//Attack
                        }
                        else {
                            agent.stateMachine.changeState(FOLLOW);
                        }
                        break;
                    case UNDERGROUND:
                        if (distance<agent.primaryWeapon.range*Point.UNIT){
                            agent.nextTick=AgentV2System.totalTime+agent.primaryWeapon.getAttackRate(agent.creature);//Set next tick
                            agent.primaryWeapon.abilityControllers.clear();//Set ability to weapon
                            agent.updateAbilities(AbilityController.Type.ATTACK);//Ability Update
                            agent.primaryWeapon.attack(agent.creature,agent.targetCreature);//Attack
                        }
                        else {
                            agent.stateMachine.changeState(FOLLOW);
                        }
                        break;
                }
            }
            agent.direction=AnimationName.getDirection(agent.targetTransform.pos.x-agent.transform.pos.x,agent.targetTransform.pos.y-agent.transform.pos.y);
            agent.animationName=AnimationName.getAttackName(agent.direction);

        }

        @Override
        public void exit(PoliceAgentComponentV2 agent) {

        }

        @Override
        public boolean onMessage(PoliceAgentComponentV2 entity, Telegram telegram) {
            return false;
        }
    }


    ;
    private static final String TAG = PoliceStateV2.class.getSimpleName();
    MessageManager messageManager=MessageManager.getInstance();
    PointGraph pointGraph= MapManager.getInstance().pointGraph;
    protected void findTarget(PoliceAgentComponentV2 agent){
        agent.target=null;
        agent.targetTransform=null;
        agent.targetCreature=null;
        agent.targetAgent=null;

        Array<Point> points=agent.currentPoint.rangeArrayMap.get(agent.awareRadius);
        for (Point point:points){
            if (agent.primaryWeapon instanceof RangedWeapon){
                if (((RangedWeapon) agent.primaryWeapon).bulletType== BulletType.AIRBORNE&&point.roofed)
                    continue;
            }
            if (point.zombies.size!=0){
                agent.target=point.zombies.random();
                agent.targetTransform= Mappers.transformComponents.get(agent.target);
                agent.targetCreature=Mappers.creatureComponents.get(agent.target);
                agent.targetAgent=Mappers.agentComponentV2(agent.target);
                return;
            }
        }
    }

    protected Entity findInRange(PoliceAgentComponentV2 agent){
        Array<Point> points=agent.currentPoint.rangeArrayMap.get(agent.primaryWeapon.range-1);

        for (int i=0;i<points.size;i++){
            if (agent.primaryWeapon instanceof RangedWeapon){
                switch (((RangedWeapon) agent.primaryWeapon).bulletType){
                    case LINE:
                        if (pointGraph.anyObstacle(agent.currentPoint,points.get(i)))
                            continue;
                        break;
                    case AIRBORNE:
                        if (points.get(i).roofed)
                            continue;
                        break;
                }
            }
            if (points.get(i).zombies.size!=0){
                return points.get(i).zombies.random();
            }
        }

        return null;
    }

    protected void findNearbyPolice(PoliceAgentComponentV2 agent){
        agent.nearbyPolices.clear();
        Array<Point> points=agent.currentPoint.rangeArrayMap.get(agent.awareRadius);
        for (Point point:points){
            for (Entity human:point.humans){
                if (human==agent.entity)
                    continue;
                if (Mappers.creatureComponents.get(human).entityType== EntityType.POLICE){
                    agent.nearbyPolices.add(human);
                }
            }
        }

    }

}
