package com.katafrakt.zombieoff.ai.states;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ai.fsm.State;
import com.badlogic.gdx.ai.msg.Telegram;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agents.AgentComponent;
import com.katafrakt.zombieoff.ashley.components.agents.ZombieAgentComponent;
import com.katafrakt.zombieoff.game.AnimationName;
import com.katafrakt.zombieoff.game.StateType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.managers.GeneralOrganizer;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.player.PlayerStatics;
import com.katafrakt.zombieoff.ui.EntityUI;
import com.katafrakt.zombieoff.utilities.Utility;

import java.util.Random;


public enum ZombieState implements State<ZombieAgentComponent> {
    IDLE(){
        private void setTargetPosition(ZombieAgentComponent agent){
            float xOri=0;
            float yOri=0;
            if (0<agent.transform.pos.x && agent.transform.pos.x< mapManager.mapPixelWidth/4)
                xOri=(mapManager.mapPixelWidth/4-agent.transform.pos.x)/(mapManager.mapPixelWidth/4);
            else if (agent.transform.pos.x>mapManager.mapPixelWidth*3/4 && mapManager.mapPixelWidth>agent.transform.pos.x)
                xOri=(mapManager.mapPixelWidth*3/4-agent.transform.pos.x)/(mapManager.mapPixelWidth/4);
            if (0<agent.transform.pos.y&&agent.transform.pos.y<mapManager.mapPixelHeight/4)
                yOri=(mapManager.mapPixelHeight/4-agent.transform.pos.y)/(mapManager.mapPixelHeight/4);
            else if (agent.transform.pos.y>mapManager.mapPixelHeight*3/4&&mapManager.mapPixelHeight>agent.transform.pos.y)
                yOri=(mapManager.mapPixelHeight/4*3-agent.transform.pos.y)/(mapManager.mapPixelHeight/4);

            agent.targetPosition.set(agent.transform.pos.x+4* Point.UNIT*(0.5f- random.nextFloat()+xOri/2f) ,agent.transform.pos.y+4*Point.UNIT*(0.5f-random.nextFloat()+yOri/2f));
            agent.path=MapManager.getInstance().pointGraph.findPath(mapManager.pointGraph.nearestPoint(tempVector.set(agent.transform.pos)),mapManager.pointGraph.nearestPoint(agent.targetPosition));
            agent.iterator=agent.path.iterator();
            //agent.currentPoint=mapManager.pointGraph.nearestPoint(agent.transformComponent.pos);
            agent.targetPoint=agent.iterator.next();

            if (agent.targetPoint.x==agent.currentPoint.x){
                agent.targetPosition.set(agent.targetPoint.x+Point.UNIT*random.nextFloat()-Point.UNIT/2,agent.targetPoint.y);
            }
            else {
                agent.targetPosition.set(agent.targetPoint.x,agent.targetPoint.y+Point.UNIT*random.nextFloat()-Point.UNIT/2);
            }

            agent.startTime=agent.currentTime;
            agent.progressTime= (float) Math.pow(Math.pow(agent.targetPosition.x-agent.transform.pos.x,2)+Math.pow(agent.targetPosition.y-agent.transform.pos.y,2),0.5f)/agent.creature.getSpeed();
            agent.direction.set(agent.targetPosition.x-agent.transform.pos.x,agent.targetPosition.y-agent.transform.pos.y).scl(1/agent.direction.len());
        }

        @Override
        public void enter(ZombieAgentComponent agent) {
            agent.currentState=StateType.IDLE;
            generalStateEnter(agent);
        }

        @Override
        public void update(ZombieAgentComponent agent) {
            float deltaTime = generalUpdate(agent);

            if (agent.currentTime>agent.count&&agent.count % AgentComponent.findTargetTime==0){
                agent.currentTime+=GeneralOrganizer.getInstance().random.nextFloat()*0.2f;
                findTarget(agent);
                if (agent.target!=null&&agent.targetCreature.isAlive==true){
                    agent.stateMachine.changeState(FOLLOW);
                }
            }

            if (agent.targetPoint!=null){
                //PlayerStatics.getInstance().totalMovement.set(PlayerStatics.getInstance().totalMovement.get()+agent.creatureComponent.getSpeed()*deltaTime);//TotalMovement
                PlayerStatics.getInstance().totalMovement.add(agent.creature.getSpeed()*deltaTime);
                //agent.direction.set(agent.targetPosition.x-agent.transformComponent.pos.x,agent.targetPosition.y-agent.transformComponent.pos.y).scl(1/agent.direction.len());
                if(agent.progressTime+agent.startTime>agent.currentTime){
                    agent.transform.pos.x+=agent.direction.x*agent.creature.getSpeed()*deltaTime;
                    agent.transform.pos.y+=agent.direction.y*agent.creature.getSpeed()*deltaTime;
                }
                else{
                //if (tempVector.set(agent.targetPosition.x-agent.transform.pos.x,agent.targetPosition.y-agent.transform.pos.y).len2()<2f){
                    if (agent.iterator.hasNext()){
                        //agent.currentPoint=agent.targetPoint;
                        agent.targetPoint=agent.iterator.next();
                        if (agent.targetPoint.x==agent.currentPoint.x){
                            agent.targetPosition.set(agent.targetPoint.x+Point.UNIT*random.nextFloat()-Point.UNIT/2,agent.targetPoint.y);
                        }
                        else {
                            agent.targetPosition.set(agent.targetPoint.x,agent.targetPoint.y+Point.UNIT*random.nextFloat()-Point.UNIT/2);

                        }
                        agent.direction.set(agent.targetPosition.x-agent.transform.pos.x,agent.targetPosition.y-agent.transform.pos.y).scl(1/agent.direction.len());
                        //****************Animation
                        if (Math.abs(agent.direction.x)>Math.abs(agent.direction.y)) {
                            if (agent.direction.x > 0) {
                                agent.animationName = AnimationName.WALK_RIGHT;
                            }
                            else {
                                agent.animationName = AnimationName.WALK_LEFT;
                            }
                        }
                        else {
                            if (agent.direction.y>0){
                                agent.animationName = AnimationName.WALK_UP;
                            }
                            else {
                                agent.animationName = AnimationName.WALK_DOWN;
                            }
                        }
                        //****************Animation

                    }
                    else {
                        agent.targetPoint=null;
                        setTargetPosition(agent);
                    }
                    agent.startTime=agent.currentTime;
                    agent.progressTime= (float) Math.pow(Math.pow(agent.targetPosition.x-agent.transform.pos.x,2)+Math.pow(agent.targetPosition.y-agent.transform.pos.y,2),0.5f)/agent.creature.getSpeed();
                }
            }
            else if (agent.currentTime>agent.count){
                setTargetPosition(agent);
            }

            generalUpdateEnd(agent);
        }

        @Override
        public void exit(ZombieAgentComponent agent) {

        }

        @Override
        public boolean onMessage(ZombieAgentComponent agent, Telegram telegram) {
            return false;
        }
    },
    FOLLOW(){
        private void createPath(ZombieAgentComponent agent){
            agent.path=mapManager.pointGraph.findPath(agent.currentPoint,mapManager.pointGraph.nearestPoint(agent.targetTransform.pos));
            agent.iterator=agent.path.iterator();
            agent.nextPoint=agent.iterator.next();
            if (agent.nextPoint==agent.currentPoint&&agent.iterator.hasNext())
                agent.nextPoint=agent.iterator.next();
        }

        @Override
        public void enter(ZombieAgentComponent agent) {
            agent.currentState=StateType.FOLLOW;
            generalStateEnter(agent);
            createPath(agent);
        }

        @Override
        public void update(ZombieAgentComponent agent) {
            float deltaTime = generalUpdate(agent);
            if (agent.currentTime>agent.count&&agent.count%4==0){
                Entity entity = findInRange(agent);
                if (entity!=null){
                    agent.target=entity;
                    agent.targetTransform=Mappers.transformComponents.get(agent.target);
                    agent.targetCreature=Mappers.creatureComponents.get(agent.target);
                    createPath(agent);
                }
            }
            if (agent.target==null||agent.targetCreature.isAlive==false){
                agent.stateMachine.changeState(IDLE);
                return;
            }
            //Eğer hedef yeteri kadar yakınsa saldırma durumuna geç
            if (agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT){
                agent.stateMachine.changeState(ATTACK);
                return;
            }
            if (agent.nextPoint!=null){
                PlayerStatics.getInstance().totalMovement.add(agent.creature.getSpeed()*deltaTime);
                //agent.direction.set(agent.targetPosition.x-agent.transformComponent.pos.x,agent.targetPosition.y-agent.transformComponent.pos.y).scl(1/agent.direction.len());
                if(agent.currentTime<agent.startTime+agent.progressTime) {
                    agent.transform.pos.x += agent.direction.x * agent.creature.getSpeed() * deltaTime;
                    agent.transform.pos.y += agent.direction.y * agent.creature.getSpeed() * deltaTime;
                }
                else {
                    if (agent.iterator.hasNext()){
                        agent.nextPoint=agent.iterator.next();
                        if (agent.nextPoint.x==agent.currentPoint.x){
                            agent.targetPosition.set(agent.nextPoint.x+Point.UNIT*random.nextFloat()-Point.UNIT/2,agent.nextPoint.y);
                        }
                        else {
                            agent.targetPosition.set(agent.nextPoint.x,agent.nextPoint.y+Point.UNIT*random.nextFloat()-Point.UNIT/2);

                        }
                        agent.startTime=agent.currentTime;
                        agent.progressTime= (float) Math.pow(Math.pow(agent.targetPosition.x-agent.transform.pos.x,2)+Math.pow(agent.targetPosition.y-agent.transform.pos.y,2),0.5f)/agent.creature.getSpeed();
                        agent.direction.set(agent.targetPosition.x-agent.transform.pos.x,agent.targetPosition.y-agent.transform.pos.y).scl(1/agent.direction.len());

                        //****************Animation
                        if (Math.abs(agent.direction.x)>Math.abs(agent.direction.y)) {
                            if (agent.direction.x > 0) {
                                agent.animationName = AnimationName.WALK_RIGHT;
                            }
                            else {
                                agent.animationName = AnimationName.WALK_LEFT;
                            }
                        }
                        else {
                            if (agent.direction.y>0){
                                agent.animationName = AnimationName.WALK_UP;
                            }
                            else {
                                agent.animationName = AnimationName.WALK_DOWN;
                            }
                        }
                        //****************Animation
                    }
                    else {
                        agent.nextPoint=null;
                    }
                }
            }
            else {
                createPath(agent);
            }
            generalUpdateEnd(agent);
        }

        @Override
        public void exit(ZombieAgentComponent agent) {

        }

        @Override
        public boolean onMessage(ZombieAgentComponent agent, Telegram telegram) {
            return false;
        }
    },
    ATTACK(){
        @Override
        public void enter(ZombieAgentComponent agent) {
            agent.currentState=StateType.ATTACK;
            generalStateEnter(agent);
        }

        @Override
        public void update(ZombieAgentComponent agent) {
            float delta=generalUpdate(agent);

            if (agent.target == null || agent.targetCreature.isAlive==false){
                agent.stateMachine.changeState(IDLE);
                return;
            }
            float distance = agent.transform.distance(agent.targetTransform);
            if (agent.nextAttackTime <agent.currentTime){
                if (distance<agent.primaryWeapon.range*Point.UNIT){
                    agent.nextAttackTime =agent.currentTime+agent.primaryWeapon.getAttackRate(agent.creature);
                    agent.primaryWeapon.abilityControllers.clear();
                    agent.updateAbilities(AbilityController.Type.ATTACK);
                    agent.primaryWeapon.attack(agent.creature,agent.targetCreature);
                }else {
                    agent.stateMachine.changeState(FOLLOW);
                    return;
                }
            }
            generalUpdateEnd(agent);
        }

        @Override
        public void exit(ZombieAgentComponent entity) {

        }

        @Override
        public boolean onMessage(ZombieAgentComponent entity, Telegram telegram) {
            return false;
        }
    };

    private static final String TAG =ZombieState.class.getSimpleName();
    MapManager mapManager;
    Random random;
    ZombieState(){
        mapManager=MapManager.getInstance();

        random=GeneralOrganizer.getInstance().random;
    }
    protected void findTarget(ZombieAgentComponent agent){
        agent.target=null;
        agent.targetTransform=null;
        agent.targetCreature=null;
        /*
        for (int i=0;i<=agent.awareRadius;i++){
            Array<Point> points=mapManager.pointGraph.getRangePoints(agent.currentPoint,i);
            for (int j=0;j<points.size;j++){
                if (points.get(j).humans.size!=0){
                    agent.target=points.get(j).humans.random();
                    agent.targetTransform=Mappers.transformComponents.get(agent.target);
                    agent.targetCreature=Mappers.creatureComponents.get(agent.target);
                    return;
                }
            }
        }*/
        Array<Point> points= Utility.pointArrayPool.obtain();
        points=mapManager.pointGraph.getAreaPoints(points,agent.currentPoint,agent.awareRadius);

        for (int j=0;j<points.size;j++){
            if (points.get(j).humans.size!=0){
                agent.target=points.get(j).humans.random();
                agent.targetTransform=Mappers.transformComponents.get(agent.target);
                agent.targetCreature=Mappers.creatureComponents.get(agent.target);
                Utility.pointArrayPool.free(points);
                return;
            }
        }
        Utility.pointArrayPool.free(points);
    }
    protected Entity findInRange(ZombieAgentComponent agent){
        for (int i=0;i<=agent.primaryWeapon.range;i++){
            Array<Point> points=Utility.pointArrayPool.obtain();
            points=mapManager.pointGraph.getRangePoints(points,agent.currentPoint,i);
            for (int j=0;j<points.size;j++){
                if (points.get(j).humans.size!=0){
                    Entity result=points.get(j).humans.random();
                    Utility.pointArrayPool.free(points);
                    return result;
                }
            }
            Utility.pointArrayPool.free(points);
        }
        return null;
}

    protected void generalStateEnter(ZombieAgentComponent agent){
        if (EntityUI.getEntity()==agent.entity)
            EntityUI.entityUI.entityStateChange();
        agent.updateAbilities(AbilityController.Type.STATE);

    }
    protected float generalUpdate(ZombieAgentComponent agent){
        float delta= MathUtils.clamp(Gdx.graphics.getDeltaTime(),0,0.1f);
        agent.currentTime+=delta;

        if (agent.currentPoint!=MapManager.getInstance().pointGraph.getPoint(agent.transform.pos.x,agent.transform.pos.y)){
            agent.currentPoint.zombies.removeValue(agent.entity,false);
            agent.currentPoint=MapManager.getInstance().pointGraph.nearestPoint(agent.transform.pos);
            agent.currentPoint.zombies.add(agent.entity);
            agent.newPoint=true;
        }
        agent.updateAbilities(AbilityController.Type.UPDATE);
        return delta;
    }
    protected void generalUpdateEnd(ZombieAgentComponent agent){
        if (agent.currentTime>agent.count)
            agent.count= (int) (agent.currentTime+1);
    }

    Vector2 tempVector=new Vector2();
}
