package com.katafrakt.zombieoff.ai.statesV2;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ai.fsm.State;
import com.badlogic.gdx.ai.msg.Telegram;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ai.pfa.PointGraph;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agentsV2.AgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.agentsV2.MercenaryAgentComponentV2;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.ashley.systems.agents.AgentV2System;
import com.katafrakt.zombieoff.entities.BulletType;
import com.katafrakt.zombieoff.game.AnimationName;
import com.katafrakt.zombieoff.game.StateType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.ui.EntityUI;

public enum MercenaryStateV2 implements State<MercenaryAgentComponentV2> {
    WAIT(){
        @Override
        public void enter(MercenaryAgentComponentV2 agent) {
            agent.currentState= StateType.IDLE;
            agent.updateAbilities(AbilityController.Type.STATE);

            if (EntityUI.getEntity()==agent.entity)
                EntityUI.entityUI.entityStateChange();
        }

        @Override
        public void update(MercenaryAgentComponentV2 agent) {
            findTarget(agent);

            if (agent.target!=null){
                agent.nextTick= AgentV2System.totalTime+1;
                if (agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT)
                    agent.stateMachine.changeState(ATTACK);
                else
                    agent.stateMachine.changeState(FOLLOW);

                return;
            }
            if (MathUtils.random()>0.7)
                agent.stateMachine.changeState(WALK);
            else
                agent.nextTick=AgentV2System.totalTime+1;

        }

        @Override
        public void exit(MercenaryAgentComponentV2 agent) {

        }

        @Override
        public boolean onMessage(MercenaryAgentComponentV2 agent, Telegram telegram) {
            return false;
        }
    },
    WALK(){
        @Override
        public void enter(MercenaryAgentComponentV2 agent) {
            agent.targetPoint=pointGraph.nearestPoint(agent.transform.pos);
            agent.path=pointGraph.findPath(agent.currentPoint,agent.targetPoint);
            agent.iterator=agent.path.iterator();

            agent.currentState=StateType.IDLE;

            agent.updateAbilities(AbilityController.Type.STATE);

            if (EntityUI.getEntity()==agent.entity)
                EntityUI.entityUI.entityStateChange();
        }

        @Override
        public void update(MercenaryAgentComponentV2 agent) {
            if (agent.currentPoint!=pointGraph.nearestPoint(agent.transform.pos)){
                agent.currentPoint.humans.removeValue(agent.entity,true);
                agent.currentPoint=pointGraph.nearestPoint(agent.transform.pos);
                agent.currentPoint.humans.add(agent.entity);
            }
            agent.count++;
            if (agent.count%agent.scanRate==0){
                findTarget(agent);
            }

            if (agent.target!=null){
                agent.stateMachine.changeState(FOLLOW);
            }
            if (agent.iterator.hasNext()){
                agent.nextPoint=agent.iterator.next();
                agent.nextPosition.set(agent.nextPoint.x+(0.5f-MathUtils.random())*Point.UNIT,agent.nextPoint.y+(0.5f-MathUtils.random())*Point.UNIT);

                float distance = (float) Math.pow(Math.pow(agent.nextPosition.x-agent.transform.pos.x,2)+Math.pow(agent.nextPosition.y-agent.transform.pos.y,2),0.5f);

                agent.velocityComponent.speed.set((agent.nextPosition.x-agent.transform.pos.x)/distance*agent.creature.getSpeed(), (agent.nextPosition.y-agent.transform.pos.y)/distance*agent.creature.getSpeed());
                agent.nextTick=AgentV2System.totalTime + distance/agent.creature.getSpeed();
            }
            else {
                agent.nextTick=AgentV2System.totalTime+1;
                agent.stateMachine.changeState(WAIT);
            }
        }

        @Override
        public void exit(MercenaryAgentComponentV2 agent) {
            agent.velocityComponent.speed.setZero();
            agent.nextPoint=null;
        }

        @Override
        public boolean onMessage(MercenaryAgentComponentV2 agent, Telegram telegram) {
            return false;
        }
    },
    FOLLOW(){
        @Override
        public void enter(MercenaryAgentComponentV2 agent) {
            agent.targetPoint=agent.targetAgent.currentPoint;
            agent.path=pointGraph.findPath(agent.currentPoint,pointGraph.attackPosition(agent.currentPoint,agent.targetPoint,agent.primaryWeapon.range-1,agent.primaryWeapon.bulletType));
            agent.iterator=agent.path.iterator();
            if (agent.iterator.hasNext())
                agent.iterator.next();

            agent.currentState=StateType.FOLLOW;

            agent.updateAbilities(AbilityController.Type.STATE);
            if (EntityUI.getEntity()==agent.entity)
                EntityUI.entityUI.entityStateChange();
        }

        @Override
        public void update(MercenaryAgentComponentV2 agent) {
            if (agent.currentPoint!=pointGraph.nearestPoint(agent.transform.pos)){
                agent.currentPoint.humans.removeValue(agent.entity,true);
                agent.currentPoint=pointGraph.nearestPoint(agent.transform.pos);
                agent.currentPoint.humans.add(agent.entity);
            }

            agent.count++;
            if (agent.count%agent.scanRate==0){
                Entity tempEntity=findInRange(agent);
                findNearestTarget(agent);
                if (tempEntity!=null){
                    agent.target=tempEntity;
                    agent.targetTransform=Mappers.transformComponents.get(tempEntity);
                    agent.targetCreature=Mappers.creatureComponents.get(tempEntity);
                    agent.targetAgent=Mappers.agentComponentV2(tempEntity);

                    agent.nextTick=AgentV2System.totalTime+0.1f;
                    agent.stateMachine.changeState(ATTACK);
                }
            }
            if (!agent.targetCreature.isAlive){
                findTarget(agent);
                if (agent.target==null){
                    agent.nextTick=AgentV2System.totalTime+1;
                    agent.stateMachine.changeState(WAIT);
                }
                else{
                    agent.nextTick=AgentV2System.totalTime+0.1f;
                    agent.stateMachine.changeState(FOLLOW);
                }
                return;
            }

            if (agent.nearestZombie!=null && agent.transform.distance(agent.nearestTransform)<6*Point.UNIT){
                agent.stateMachine.changeState(FLEE);
                Gdx.app.log(TAG,"toFlee");
                return;
            }
            else if (agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT){
                switch (agent.primaryWeapon.bulletType) {
                    case LINE:
                        if (!pointGraph.anyObstacle(agent.currentPoint, agent.targetAgent.currentPoint)) {

                            agent.nextTick=AgentV2System.totalTime+0.1f;
                            agent.stateMachine.changeState(ATTACK);
                            return;
                        }
                        break;
                    case AIRBORNE:
                        if (agent.targetAgent.currentPoint.roofed)
                            findTarget(agent);
                        else {
                            agent.nextTick=AgentV2System.totalTime+0.1f;
                            agent.stateMachine.changeState(ATTACK);
                            return;
                        }
                        break;
                    case UNDERGROUND:
                        agent.nextTick=AgentV2System.totalTime+0.1f;
                        agent.stateMachine.changeState(ATTACK);
                        return;

                }
            }
            if (agent.iterator.hasNext()){
                agent.nextPoint = agent.iterator.next();
                agent.nextPosition.set(agent.nextPoint.x+(0.5f-MathUtils.random())*Point.UNIT,agent.nextPoint.y+(0.5f-MathUtils.random())*Point.UNIT);

                float distance= (float) Math.pow(Math.pow(agent.nextPosition.x-agent.transform.pos.x,2)+Math.pow(agent.nextPosition.y-agent.transform.pos.y,2),0.5f);

                agent.velocityComponent.speed.set((agent.nextPosition.x-agent.transform.pos.x)/distance*agent.creature.getSpeed(), (agent.nextPosition.y-agent.transform.pos.y)/distance*agent.creature.getSpeed());
                agent.nextTick=AgentV2System.totalTime + distance/agent.creature.getSpeed();

            }else {
                agent.nextTick=AgentV2System.totalTime+0.1f;
                agent.stateMachine.changeState(FOLLOW);
            }


        }

        @Override
        public void exit(MercenaryAgentComponentV2 agent) {
            agent.velocityComponent.speed.setZero();
            Gdx.app.log(TAG,"velZero");
            agent.nextPoint=null;
        }

        @Override
        public boolean onMessage(MercenaryAgentComponentV2 entity, Telegram telegram) {
            return false;
        }
    },
    FLEE(){
        @Override
        public void enter(MercenaryAgentComponentV2 agent) {
            agent.path=pointGraph.findPath(agent.currentPoint,getFleePoint(agent));
            agent.iterator=agent.path.iterator();
            agent.currentState=StateType.FLEE;
            Gdx.app.log(TAG,"FLEE");
        }

        @Override
        public void update(MercenaryAgentComponentV2 agent) {
            if (agent.currentPoint!=pointGraph.nearestPoint(agent.transform.pos)){
                agent.currentPoint.humans.removeValue(agent.entity,true);
                agent.currentPoint=pointGraph.nearestPoint(agent.transform.pos);
                agent.currentPoint.humans.add(agent.entity);
            }

            if (agent.iterator.hasNext()){
                agent.nextPoint=agent.iterator.next();
                agent.nextPosition.set(agent.nextPoint.x+(0.5f-MathUtils.random())*Point.UNIT,agent.nextPoint.y+(0.5f-MathUtils.random())*Point.UNIT);

                float distancePosition= (float) Math.pow(Math.pow(agent.nextPosition.x-agent.transform.pos.x,2)+Math.pow(agent.nextPosition.y-agent.transform.pos.y,2),0.5f);

                agent.velocityComponent.speed.set((agent.nextPosition.x-agent.transform.pos.x)/distancePosition*agent.creature.getSpeed(), (agent.nextPosition.y-agent.transform.pos.y)/distancePosition*agent.creature.getSpeed());
                agent.nextTick=AgentV2System.totalTime + distancePosition/agent.creature.getSpeed();

                //ToDo animation
            }
            else {
                findNearestTarget(agent);
                if (agent.nearestZombie!=null && agent.transform.distance(agent.nearestTransform)<Point.UNIT*3){
                    agent.stateMachine.changeState(FLEE);
                }
                else {
                    agent.stateMachine.changeState(FOLLOW);
                }
            }

        }

        @Override
        public void exit(MercenaryAgentComponentV2 agent) {
            agent.velocityComponent.speed.setZero();
            agent.nextPoint=null;
        }

        @Override
        public boolean onMessage(MercenaryAgentComponentV2 entity, Telegram telegram) {
            return false;
        }
    },
    ATTACK(){
        @Override
        public void enter(MercenaryAgentComponentV2 agent) {
            agent.currentState=StateType.ATTACK;

            agent.updateAbilities(AbilityController.Type.STATE);
            if (EntityUI.getEntity()==agent.entity)
                EntityUI.entityUI.entityStateChange();
        }

        @Override
        public void update(MercenaryAgentComponentV2 agent) {
            float distance=agent.transform.distance(agent.targetTransform);

            agent.count++;
            if (agent.count%agent.scanRate==0){
                findNearestTarget(agent);
            }

            if (!agent.targetCreature.isAlive){
                findTarget(agent);
                if (agent.target==null)
                    agent.stateMachine.changeState(WAIT);
                else
                    agent.stateMachine.changeState(FOLLOW);
                return;
            }
            if (agent.nearestZombie!=null && agent.transform.distance(agent.nearestTransform)<Point.UNIT*3){
                agent.stateMachine.changeState(FLEE);
                Gdx.app.log(TAG,"attToFlee");
            }
            else if (distance<agent.primaryWeapon.range*Point.UNIT){
                switch (agent.primaryWeapon.bulletType){
                    case LINE:
                        if (!pointGraph.anyObstacle(agent.currentPoint,agent.targetAgent.currentPoint) && distance<agent.primaryWeapon.range*Point.UNIT){
                            //ToDo Mappers.animationComponents.get(agent.entity).stop=false;
                            agent.nextTick=AgentV2System.totalTime+agent.primaryWeapon.getAttackRate(agent.creature);//Set next tick
                            agent.primaryWeapon.abilityControllers.clear();//Set ability to weapon
                            agent.updateAbilities(AbilityController.Type.ATTACK);//Ability Update
                            agent.primaryWeapon.attack(agent.creature,agent.targetCreature);//Attack


                            agent.animationName= AnimationName.getAttackName(AnimationName.getDirection(agent.targetTransform.pos.x-agent.transform.pos.x,agent.targetTransform.pos.y-agent.transform.pos.y));

                        }
                        else
                            agent.stateMachine.changeState(FOLLOW);
                        break;
                    case AIRBORNE:
                        if (!agent.targetAgent.currentPoint.roofed && distance<agent.primaryWeapon.range*Point.UNIT){
                            agent.nextTick=AgentV2System.totalTime+agent.primaryWeapon.getAttackRate(agent.creature);//Set next tick
                            agent.primaryWeapon.abilityControllers.clear();//Set ability to weapon
                            agent.updateAbilities(AbilityController.Type.ATTACK);//Ability Update
                            agent.primaryWeapon.attack(agent.creature,agent.targetCreature);//Attack
                        }
                        else {
                            agent.stateMachine.changeState(FOLLOW);
                        }
                        break;
                    case UNDERGROUND:
                        if (distance<agent.primaryWeapon.range*Point.UNIT){
                            agent.nextTick=AgentV2System.totalTime+agent.primaryWeapon.getAttackRate(agent.creature);//Set next tick
                            agent.primaryWeapon.abilityControllers.clear();//Set ability to weapon
                            agent.updateAbilities(AbilityController.Type.ATTACK);//Ability Update
                            agent.primaryWeapon.attack(agent.creature,agent.targetCreature);//Attack
                        }
                        else {
                            agent.stateMachine.changeState(FOLLOW);
                        }
                        break;
                }
            }

        }

        @Override
        public void exit(MercenaryAgentComponentV2 agent) {

        }

        @Override
        public boolean onMessage(MercenaryAgentComponentV2 entity, Telegram telegram) {
            return false;
        }
    };
    private static final String TAG=MercenaryStateV2.class.getSimpleName();
    PointGraph pointGraph= MapManager.getInstance().pointGraph;

    protected void findTarget(MercenaryAgentComponentV2 agent){
        agent.target=null;
        agent.targetTransform=null;
        agent.targetCreature=null;
        agent.targetAgent=null;
        float maxTargetDPS=0;

        Array<Point> points=agent.currentPoint.rangeArrayMap.get(agent.awareRadius);
        for (Point point:points){
            if (agent.primaryWeapon.bulletType==BulletType.AIRBORNE && point.roofed)
                continue;

            for (Entity zombie:point.zombies){
                CreatureComponent targetCreature=Mappers.creatureComponents.get(zombie);
                AgentComponentV2 targetAgent=Mappers.agentComponentV2(zombie);
                float dps=(targetCreature.getDamage()*targetAgent.primaryWeapon.damageRatio)/targetAgent.primaryWeapon.getAttackRate(targetCreature)* MathUtils.log2(targetAgent.primaryWeapon.range+2);
                Gdx.app.log(TAG,"Dps: "+dps);
                //saldırı*saldırıhızı*Log2(range)
                if (maxTargetDPS<dps){
                    agent.target=zombie;
                    agent.targetTransform=Mappers.transformComponents.get(zombie);
                    agent.targetCreature=targetCreature;
                    agent.targetAgent=targetAgent;

                }
            }
        }
    }

    protected void findNearestTarget(MercenaryAgentComponentV2 agent){
        Array<Point> points=agent.currentPoint.rangeArrayMap.get(agent.primaryWeapon.range);
        for (int i=0;i<points.size;i++){
            if (!points.get(i).zombies.isEmpty()){
                agent.nearestZombie=points.get(i).zombies.random();
                agent.nearestTransform=Mappers.transformComponents.get(agent.nearestZombie);
                return;
            }
        }
    }

    protected Entity findInRange(MercenaryAgentComponentV2 agent){
        Array<Point> points=agent.currentPoint.rangeArrayMap.get(agent.primaryWeapon.range-1);
        Entity tempEntity=null;
        float maxTargetDPS=0;
        for (int i=0;i<points.size;i++){
            switch (agent.primaryWeapon.bulletType){
                case LINE:
                    if (pointGraph.anyObstacle(agent.currentPoint,points.get(i)))
                        continue;
                    break;
                case AIRBORNE:
                    if (points.get(i).roofed)
                        continue;
                    break;
            }
            for (Entity zombie:points.get(i).zombies){

                AgentComponentV2 targetAgent=Mappers.agentComponentV2(zombie);
                CreatureComponent targetCreature=Mappers.creatureComponents.get(zombie);
                float dps=(targetCreature.getDamage()*targetAgent.primaryWeapon.damageRatio)/targetAgent.primaryWeapon.getAttackRate(targetCreature)* MathUtils.log2(targetAgent.primaryWeapon.range);
                if (dps>maxTargetDPS){
                    tempEntity=zombie;
                    maxTargetDPS=dps;
                }
            }
        }

        return tempEntity;
    }

    protected Point getFleePoint(MercenaryAgentComponentV2 agent){
        float x=0,y=0;

        Array<Point> points= agent.currentPoint.rangeArrayMap.get(agent.primaryWeapon.range/2);
        for (int i=0;i<points.size;i++){
            if (points.get(i).zombies.size!=0){
                float t=Math.abs(agent.currentPoint.x-points.get(i).x)+Math.abs(agent.currentPoint.y-points.get(i).y);
                x+=(agent.currentPoint.x-points.get(i).x)/(t*t);
                y+=(agent.currentPoint.y-points.get(i).y)/(t*t);
            }
        }
        float length= (float) Math.pow(x*x+y*y,0.5f);
        return pointGraph.nearestPoint(agent.currentPoint.x + (x/length*Point.UNIT*4),agent.currentPoint.y + (y/length*Point.UNIT*4));
    }

}
