package com.katafrakt.zombieoff.ai.states;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ai.fsm.State;
import com.badlogic.gdx.ai.msg.MessageManager;
import com.badlogic.gdx.ai.msg.Telegram;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agents.AgentComponent;
import com.katafrakt.zombieoff.ashley.components.agents.PoliceAgentComponent;
import com.katafrakt.zombieoff.entities.BulletType;
import com.katafrakt.zombieoff.entities.EntityType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.weapons.MeleeWeapon;
import com.katafrakt.zombieoff.game.weapons.RangedWeapon;
import com.katafrakt.zombieoff.managers.GeneralOrganizer;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.ui.EntityUI;
import com.katafrakt.zombieoff.utilities.Utility;

import java.util.Random;

public enum  PoliceState implements State<PoliceAgentComponent> {//0 awareness arttır
    IDLE(){

        @Override
        public void enter(PoliceAgentComponent agent) {
            generalStateEnter(agent);
            agent.initialPoint=mapManager.pointGraph.nearestPoint(Mappers.transformComponents.get(agent.entity).pos);
            agent.idleMoveIsActive=false;
        }

        @Override
        public void update(PoliceAgentComponent agent) {
            float deltaTime=generalUpdate(agent);

            if (agent.currentTime>agent.count){
                findTarget(agent);
            }

            //Aware
            if (agent.target!=null&&agent.targetCreature.isAlive==true){
                if (agent.awareness<1){
                    agent.awareness +=deltaTime;
                    if (agent.awareness>1)
                        agent.awareness=1;
                }
                if (agent.awareness==1){
                    if (agent.transform.distance(agent.targetTransform)>agent.primaryWeapon.range*Point.UNIT)
                        agent.stateMachine.changeState(GIVER);
                    else
                        agent.stateMachine.changeState(FOLLOW);
                }
            }
            else {
                agent.awareness -= deltaTime;
                if (agent.awareness<0)
                    agent.awareness=0;
            }

            if (agent.idleMoveIsActive){
                float diff = (float) (Math.pow(agent.transform.pos.x-agent.targetPosition.x,2)+Math.pow(agent.transform.pos.y-agent.targetPosition.y,2));
                if (diff<2)
                    agent.idleMoveIsActive=false;
                else {
                    agent.transform.pos.x+= agent.direction.x*deltaTime*agent.creature.getSpeed();
                    agent.transform.pos.y+= agent.direction.y*deltaTime*agent.creature.getSpeed();
                }
            }
            else if (agent.currentTime>agent.count){
                if (random.nextFloat()>0f){
                    agent.idleMoveIsActive=true;
                    agent.targetPoint=mapManager.pointGraph.nearestPoint(tempVector.set(agent.initialPoint.x+2* Point.UNIT*(0.5f-random.nextFloat()*1),agent.initialPoint.y+2*Point.UNIT*(0.5f-random.nextFloat()*1)));
                    agent.targetPosition.set(agent.targetPoint.x+Point.UNIT*(0.5f-random.nextFloat()*1),agent.targetPoint.y+Point.UNIT*(0.5f-random.nextFloat()*1));
                    agent.direction.set(agent.targetPosition.x-agent.transform.pos.x,agent.targetPosition.y-agent.transform.pos.y).scl(1f/agent.direction.len());
                }
            }

            generalUpdateEnd(agent);
        }

        @Override
        public void exit(PoliceAgentComponent agent) {

        }

        @Override
        public boolean onMessage(PoliceAgentComponent agent, Telegram telegram) {
            agent.target= (Entity) telegram.extraInfo;
            agent.stateMachine.changeState(RECEIVER);
            Gdx.app.log(TAG,"message recieved");
            return false;
        }
    },
    FOLLOW() {
        private void createPath(PoliceAgentComponent agent){
            Gdx.app.log(TAG,"Weapon"+agent.currentPoint);
            if (agent.primaryWeapon instanceof MeleeWeapon)
                agent.path=mapManager.pointGraph.findPath(mapManager.pointGraph.nearestPoint(tempVector.set(agent.transform.pos)),mapManager.pointGraph.nearestPoint(tempVector.set(agent.targetTransform.pos)));
            else if (agent.primaryWeapon instanceof RangedWeapon)
                agent.path=mapManager.pointGraph.findPath(agent.currentPoint,mapManager.pointGraph.attackPosition(agent.currentPoint,agent.targetAgent.currentPoint,agent.primaryWeapon.range,((RangedWeapon)agent.primaryWeapon).bulletType));
            agent.iterator=agent.path.iterator();
            agent.targetPoint=agent.iterator.next();
        }

        @Override
        public void enter(PoliceAgentComponent agent) {
            generalStateEnter(agent);
            createPath(agent);
        }

        @Override
        public void update(PoliceAgentComponent agent) {
            float deltaTime = generalUpdate(agent);
            if (agent.target==null || !agent.targetCreature.isAlive){
                agent.stateMachine.changeState(IDLE);
                return;
            }
            //Eğer hedef yeteri kadar yakınsa saldırma durumuna geç
            if (agent.currentTime>agent.count){
                Entity entity=findInRange(agent);
                if (entity!=null){
                    agent.target=entity;
                    agent.targetTransform=Mappers.transformComponents.get(entity);
                    agent.targetCreature= Mappers.creatureComponents.get(entity);
                    agent.targetAgent= Mappers.agentComponents(entity);
                }
                createPath(agent);

                if (agent.primaryWeapon instanceof MeleeWeapon){
                    if (agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT){
                        agent.stateMachine.changeState(ATTACK);
                        return;
                    }
                }
                else if (agent.primaryWeapon instanceof RangedWeapon){
                    RangedWeapon rangedWeapon= (RangedWeapon) agent.primaryWeapon;
                    switch (rangedWeapon.bulletType){
                        case LINE:
                            if (!mapManager.pointGraph.anyObstacle(agent.currentPoint,agent.targetAgent.currentPoint)&&agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT) {
                                agent.stateMachine.changeState(ATTACK);
                            }
                            break;
                        case AIRBORNE:
                            if (agent.targetAgent.currentPoint.roofed)
                                findTarget(agent);
                            else if (agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT)
                                agent.stateMachine.changeState(ATTACK);
                            break;
                        case UNDERGROUND:
                            if (agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT)
                                agent.stateMachine.changeState(ATTACK);
                            break;
                    }
                }
            }


            if (agent.targetPoint!=null){
                //Yön belirle
                if (agent.transform.pos.x>agent.targetPoint.x+Point.UNIT/2) {
                    agent.transform.pos.x-=agent.creature.speed*deltaTime;
                }
                else if(agent.transform.pos.x<agent.targetPoint.x-Point.UNIT/2) {
                    agent.transform.pos.x+=agent.creature.speed*deltaTime;
                }
                else if (agent.transform.pos.y>agent.targetPoint.y+Point.UNIT/2){
                    agent.transform.pos.y-=agent.creature.speed*deltaTime;
                }
                else if (agent.transform.pos.y<agent.targetPoint.y-Point.UNIT/2){
                    agent.transform.pos.y+=agent.creature.speed*deltaTime;
                }
                else{
                    if (agent.iterator.hasNext())
                        agent.targetPoint=agent.iterator.next();
                    else
                        agent.targetPoint=null;
                }
            }
            generalUpdateEnd(agent);
        }

        @Override
        public void exit(PoliceAgentComponent agent) {

        }

        @Override
        public boolean onMessage(PoliceAgentComponent agent, Telegram telegram) {
            return false;
        }
    },
    ATTACK() {
        @Override
        public void enter(PoliceAgentComponent agent) {
            generalStateEnter(agent);
        }

        @Override
        public void update(PoliceAgentComponent agent) {
            float deltaTime = generalUpdate(agent);

            if (agent.target == null || agent.targetCreature.isAlive==false){
                agent.stateMachine.changeState(IDLE);
                return;
            }
            if (agent.nextAttackTime +agent.primaryWeapon.getAttackRate(agent.creature)<agent.currentTime){
                float distance = agent.transform.distance(agent.targetTransform);
                if (agent.primaryWeapon instanceof MeleeWeapon){
                    if (distance<agent.primaryWeapon.range*Point.UNIT){
                        agent.nextAttackTime=agent.currentTime+agent.primaryWeapon.getAttackRate(agent.creature);
                        agent.primaryWeapon.abilityControllers.clear();
                        agent.updateAbilities(AbilityController.Type.ATTACK);
                        agent.primaryWeapon.attack(agent.creature,agent.targetCreature);
                    }
                    else
                        agent.stateMachine.changeState(FOLLOW);
                }
                else if (agent.primaryWeapon instanceof RangedWeapon){
                        RangedWeapon rangedWeapon= (RangedWeapon) agent.primaryWeapon;
                        switch (rangedWeapon.bulletType){
                            case LINE:
                                if (!mapManager.pointGraph.anyObstacle(agent.currentPoint, agent.targetAgent.currentPoint) && distance<agent.primaryWeapon.range*Point.UNIT){
                                    agent.nextAttackTime =agent.currentTime+agent.primaryWeapon.getAttackRate(agent.creature);
                                    agent.primaryWeapon.abilityControllers.clear();
                                    agent.updateAbilities(AbilityController.Type.ATTACK);
                                    agent.primaryWeapon.attack(agent.creature,agent.targetCreature);
                                }
                                else{
                                    agent.stateMachine.changeState(FOLLOW);
                                }
                                break;
                            case AIRBORNE:
                                if(agent.targetAgent.currentPoint.roofed==false && distance<agent.primaryWeapon.range*Point.UNIT){
                                    agent.nextAttackTime =agent.currentTime+agent.primaryWeapon.getAttackRate(agent.creature);
                                    agent.primaryWeapon.abilityControllers.clear();
                                    agent.updateAbilities(AbilityController.Type.ATTACK);
                                    agent.primaryWeapon.attack(agent.creature,agent.targetCreature);
                                }
                                else {
                                    findInRange(agent);
                                    if (agent.target==null){
                                        agent.stateMachine.changeState(IDLE);
                                    }
                                    else{
                                        agent.stateMachine.changeState(FOLLOW);
                                    }
                                }
                                break;
                            case UNDERGROUND:
                                if (distance<agent.primaryWeapon.range*Point.UNIT){
                                    agent.nextAttackTime =agent.currentTime+agent.primaryWeapon.getAttackRate(agent.creature);
                                    agent.primaryWeapon.abilityControllers.clear();
                                    agent.updateAbilities(AbilityController.Type.ATTACK);
                                    agent.primaryWeapon.attack(agent.creature,agent.targetCreature);
                                }
                                else{
                                    agent.stateMachine.changeState(FOLLOW);
                                }
                    }
                }
            }

            generalUpdateEnd(agent);
        }

        @Override
        public void exit(PoliceAgentComponent agent) {

        }

        @Override
        public boolean onMessage(PoliceAgentComponent agent, Telegram telegram) {
            return false;
        }
    },
    GIVER(){
        MessageManager messageManager=MessageManager.getInstance();


        @Override
        public void enter(PoliceAgentComponent agent) {
            generalStateEnter(agent);
            agent.counter=0;
            findInRange(agent);
        }

        @Override
        public void update(PoliceAgentComponent agent) {
            float deltaTime=generalUpdate(agent);
            agent.counter+=deltaTime;

            if (agent.target==null||agent.targetCreature.isAlive==false||agent.transform.distance(agent.targetTransform)>agent.awareRadius*Point.UNIT){
                findTarget(agent);
                if (agent.target==null){
                    agent.stateMachine.changeState(IDLE);
                    return;
                }
            }
            else if (agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT){
                agent.stateMachine.changeState(ATTACK);
            }

            for (Entity entity:agent.inRange){
                messageManager.dispatchMessage(agent,Mappers.agentComponents(entity),EntityType.POLICE.toInteger(),agent.target);
            }

            if (agent.counter>4f){
                if (agent.transform.distance(agent.targetTransform)<agent.primaryWeapon.range*Point.UNIT)
                    agent.stateMachine.changeState(ATTACK);
                else
                    agent.stateMachine.changeState(FOLLOW);
                return;
            }
            generalUpdateEnd(agent);
        }

        @Override
        public void exit(PoliceAgentComponent entity) {

        }

        @Override
        public boolean onMessage(PoliceAgentComponent entity, Telegram telegram) {
            return false;
        }
    },
    RECEIVER(){
        @Override
        public void enter(PoliceAgentComponent agent) {
            generalStateEnter(agent);
            agent.remainTimeToIdle=0.2f;
            Gdx.app.log(TAG,"Giriş yapılıyor");
        }

        @Override
        public void update(PoliceAgentComponent agent) {
            float deltaTime = generalUpdate(agent);
            if (agent.awareness>1){
                agent.targetTransform=Mappers.transformComponents.get(agent.target);
                agent.targetCreature=Mappers.creatureComponents.get(agent.target);
                if (agent.transform.distance(agent.targetTransform)>agent.primaryWeapon.range*Point.UNIT){
                    agent.stateMachine.changeState(FOLLOW);
                }
                else {
                    agent.stateMachine.changeState(ATTACK);
                }
            }
            if (agent.remainTimeToIdle<0){
                agent.target=null;
                agent.stateMachine.changeState(IDLE);
            }
            agent.remainTimeToIdle-=deltaTime;
            agent.messaged=false;
            generalUpdateEnd(agent);
        }

        @Override
        public void exit(PoliceAgentComponent agent) {
            Gdx.app.log(TAG,"Çıkış yapılıyor");
        }

        @Override
        public boolean onMessage(PoliceAgentComponent agent, Telegram telegram) {
            if (agent.messaged==false){
                agent.target= (Entity) telegram.extraInfo;
                agent.awareness += Gdx.graphics.getDeltaTime()/3;
                agent.remainTimeToIdle=0.3f;
                agent.messaged=true;
            }
            return false;
        }
    };


    private static final String TAG= PoliceState.class.getSimpleName();

    MapManager mapManager;
    Random random;


    PoliceState(){
        mapManager=MapManager.getInstance();
        random= GeneralOrganizer.getInstance().random;
    }

    protected void findTarget(PoliceAgentComponent agent){
        for (int i=0;i<=agent.awareRadius;i++){

            Array<Point> points= Utility.pointArrayPool.obtain();
            points=mapManager.getInstance().pointGraph.getRangePoints(points,agent.currentPoint,i);
            for (int j=0;j<points.size;j++){
                if (points.get(j).zombies.size!=0){
                    agent.target=points.get(j).zombies.random();
                    agent.targetCreature=Mappers.creatureComponents.get(agent.target);
                    agent.targetTransform=Mappers.transformComponents.get(agent.target);
                    agent.targetAgent=Mappers.agentComponents(agent.target);
                    Utility.pointArrayPool.free(points);
                    return;
                }
            }
            Utility.pointArrayPool.free(points);
        }
    }
    protected Entity findInRange(PoliceAgentComponent agent){
        for (int i=0;i<=agent.primaryWeapon.range;i++){
            Array<Point> points=Utility.pointArrayPool.obtain();
            points=mapManager.pointGraph.getRangePoints(points,agent.currentPoint,i);
            for (int j=0; j<points.size; j++){
                if (agent.primaryWeapon instanceof RangedWeapon){
                    if (points.get(j).roofed && ((RangedWeapon)agent.primaryWeapon).bulletType== BulletType.AIRBORNE)
                        continue;
                    if (((RangedWeapon)agent.primaryWeapon).bulletType==BulletType.LINE&&mapManager.pointGraph.anyObstacle(agent.currentPoint,points.get(j)))
                        continue;
                }
                if (points.get(j).zombies.size!=0){
                    Entity result=points.get(j).zombies.random();
                    Utility.pointArrayPool.free(points);
                    return result;
                }

            }
        }
        return null;
    }

    protected void generalStateEnter(AgentComponent agent){
        if (EntityUI.getEntity()==agent.entity)
            EntityUI.entityUI.entityStateChange();
        agent.count=0;
        agent.updateAbilities(AbilityController.Type.STATE);
    }

    protected float generalUpdate(AgentComponent agent){
        float delta= MathUtils.clamp(Gdx.graphics.getDeltaTime(),0,0.1f);
        agent.currentTime+=delta;

        if (agent.currentPoint!=MapManager.getInstance().pointGraph.nearestPoint(agent.transform.pos)){
            agent.currentPoint.humans.removeValue(agent.entity,true);
            agent.currentPoint=MapManager.getInstance().pointGraph.nearestPoint(agent.transform.pos);
            agent.currentPoint.humans.add(agent.entity);
        }
        agent.updateAbilities(AbilityController.Type.UPDATE);
        return delta;
    }
    protected void generalUpdateEnd(AgentComponent agent){
        if (agent.currentTime>agent.count)
            agent.count= (int) (agent.currentTime+1);
    }

    Vector2 tempVector=new Vector2();
}
