package com.katafrakt.zombieoff.ai.pfa;

import com.badlogic.gdx.ai.pfa.Connection;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;

public class PointConnection implements Connection<Point> {
    Point fromPoint, toPoint;
    float cost;

    public PointConnection(Point fromPoint, Point toPoint){
        this.fromPoint = fromPoint;
        this.toPoint = toPoint;
        cost= Vector2.dst(fromPoint.x, fromPoint.y, toPoint.x, toPoint.y);
    }

    public void render(ShapeRenderer shapeRenderer){
        shapeRenderer.line(fromPoint.x,fromPoint.y,toPoint.x,toPoint.y);
    }

    @Override
    public float getCost() {
        return cost+ MathUtils.random();
    }

    @Override
    public Point getFromNode() {
        return fromPoint;
    }

    @Override
    public Point getToNode() {
        return toPoint;
    }
}
