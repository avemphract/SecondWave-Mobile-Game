package com.katafrakt.zombieoff.ai.statesV2;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ai.fsm.State;
import com.badlogic.gdx.ai.msg.Telegram;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ai.pfa.PointGraph;
import com.katafrakt.zombieoff.ashley.components.Mappers;
import com.katafrakt.zombieoff.ashley.components.agentsV2.VeteranAgentComponentV2;
import com.katafrakt.zombieoff.ashley.systems.agents.AgentV2System;
import com.katafrakt.zombieoff.entities.BulletType;
import com.katafrakt.zombieoff.game.AnimationName;
import com.katafrakt.zombieoff.game.StateType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.AbilityController;
import com.katafrakt.zombieoff.game.weapons.RangedWeapon;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.ui.EntityUI;

public enum VeteranStateV2 implements State<VeteranAgentComponentV2> {
    WAIT(){
        @Override
        public void enter(VeteranAgentComponentV2 agent) {
            agent.animationName=AnimationName.getWaitName(agent.animationName.direction);
            agent.currentState= StateType.IDLE;
            agent.updateAbilities(AbilityController.Type.STATE);

            if (EntityUI.getEntity()==agent.entity)
                EntityUI.entityUI.entityStateChange();
        }

        @Override
        public void update(VeteranAgentComponentV2 agent) {
            findTarget(agent);

            if (agent.target!=null){
                agent.nextTick= AgentV2System.totalTime+1;
                agent.stateMachine.changeState(FOLLOW);
            }

            if (MathUtils.random()>0.9f)
                agent.stateMachine.changeState(WALK);
            else
                agent.nextTick=AgentV2System.totalTime+1+MathUtils.random();
        }

        @Override
        public void exit(VeteranAgentComponentV2 entity) {

        }

        @Override
        public boolean onMessage(VeteranAgentComponentV2 entity, Telegram telegram) {
            return false;
        }
    },
    WALK() {
        @Override
        public void enter(VeteranAgentComponentV2 agent) {
            agent.targetPoint=pointGraph.nearestPoint(agent.currentPoint.x+(0.5f-MathUtils.random())*Point.UNIT*4,agent.currentPoint.y+(0.5f-MathUtils.random())*Point.UNIT*4);
            agent.path=pointGraph.findPath(agent.currentPoint,agent.targetPoint);
            agent.iterator=agent.path.iterator();

            agent.currentState=StateType.IDLE;

            agent.updateAbilities(AbilityController.Type.STATE);

            if (EntityUI.getEntity()==agent.entity)
                EntityUI.entityUI.entityStateChange();

        }

        @Override
        public void update(VeteranAgentComponentV2 agent) {
            if (agent.currentPoint!=pointGraph.nearestPoint(agent.transform.pos)){
                agent.currentPoint.humans.removeValue(agent.entity,true);
                agent.currentPoint= pointGraph.nearestPoint(agent.transform.pos);
                agent.currentPoint.humans.add(agent.entity);
            }
            agent.count++;
            if (agent.count%agent.scanRate==0)
                findTarget(agent);

            if (agent.target!=null){
                agent.stateMachine.changeState(FOLLOW);
                return;
            }

            if (agent.iterator.hasNext()){
                agent.nextPoint = agent.iterator.next();
                agent.nextPosition.set(agent.nextPoint.x+(0.5f-MathUtils.random())*Point.UNIT,agent.nextPoint.y+(0.5f-MathUtils.random())*Point.UNIT);

                float distance= (float) Math.pow(Math.pow(agent.nextPosition.x-agent.transform.pos.x,2)+Math.pow(agent.nextPosition.y-agent.transform.pos.y,2),0.5f);

                //Gdx.app.log(TAG,"Dis"+distance);
                agent.velocityComponent.speed.set((agent.nextPosition.x-agent.transform.pos.x)/distance*agent.creature.getSpeed(), (agent.nextPosition.y-agent.transform.pos.y)/distance*agent.creature.getSpeed());
                agent.nextTick=AgentV2System.totalTime + distance/agent.creature.getSpeed();

                agent.direction=AnimationName.getDirection(agent.velocityComponent.speed.x,agent.velocityComponent.speed.y);
                agent.animationName=AnimationName.getWalkName(agent.direction);//Animation set

            }
            else {
                agent.nextTick=AgentV2System.totalTime+1;
                agent.stateMachine.changeState(WAIT);
            }
        }

        @Override
        public void exit(VeteranAgentComponentV2 agent) {
            agent.velocityComponent.speed.setZero();
            agent.nextPoint=null;
        }

        @Override
        public boolean onMessage(VeteranAgentComponentV2 entity, Telegram telegram) {
            return false;
        }
    },
    FOLLOW() {
        @Override
        public void enter(VeteranAgentComponentV2 agent) {

            agent.targetPoint=pointGraph.nearestPoint(agent.targetTransform.pos);
            agent.path=pointGraph.findPath(agent.currentPoint,pointGraph.attackPosition(agent.currentPoint,agent.targetAgent.currentPoint,agent.primaryWeapon.range,agent.primaryWeapon.bulletType));
            agent.iterator=agent.path.iterator();
            if (agent.iterator.hasNext())
                agent.iterator.next();
        }

        @Override
        public void update(VeteranAgentComponentV2 agent) {
            if (agent.currentPoint!=pointGraph.nearestPoint(agent.transform.pos)){
                agent.currentPoint.humans.removeValue(agent.entity,false);
                agent.currentPoint=pointGraph.nearestPoint(agent.transform.pos);
                agent.currentPoint.humans.add(agent.entity);
            }

            agent.count++;
            if (agent.count%agent.scanRate==0){
                Entity tempEntity=findInRange(agent);
                if (tempEntity!=null){
                    agent.target=tempEntity;
                    agent.targetTransform=Mappers.transformComponents.get(tempEntity);
                    agent.targetCreature=Mappers.creatureComponents.get(tempEntity);
                    agent.targetAgent=Mappers.agentComponentV2(tempEntity);
                }
            }

            if (!agent.targetCreature.isAlive){
                findTarget(agent);
                if (agent.target==null){
                    agent.nextTick=AgentV2System.totalTime+1;
                    agent.stateMachine.changeState(WAIT);
                    return;
                }
            }
            float distace=agent.transform.distance(agent.targetTransform)/Point.UNIT;
            if (distace<agent.primaryWeapon.range-4){
                agent.stateMachine.changeState(ATTACK_FLEE);
                return;
            }
            else if (distace<agent.primaryWeapon.range){
                switch (agent.primaryWeapon.bulletType) {
                    case LINE:
                        if (!pointGraph.anyObstacle(agent.currentPoint, agent.targetAgent.currentPoint)) {
                            agent.stateMachine.changeState(ATTACK);
                            return;
                        }
                        break;
                    case AIRBORNE:
                        if (agent.targetAgent.currentPoint.roofed)
                            findTarget(agent);
                        else {
                            agent.stateMachine.changeState(ATTACK);
                            return;
                        }
                        break;
                    case UNDERGROUND:
                        agent.stateMachine.changeState(ATTACK);
                        return;
                }
            }
            if (agent.iterator.hasNext()){
                agent.nextPoint = agent.iterator.next();
                agent.nextPosition.set(agent.nextPoint.x+(0.5f-MathUtils.random())*Point.UNIT,agent.nextPoint.y+(0.5f-MathUtils.random())*Point.UNIT);

                float distance= (float) Math.pow(Math.pow(agent.nextPosition.x-agent.transform.pos.x,2)+Math.pow(agent.nextPosition.y-agent.transform.pos.y,2),0.5f);

                agent.velocityComponent.speed.set((agent.nextPosition.x-agent.transform.pos.x)/distance*agent.creature.getSpeed(), (agent.nextPosition.y-agent.transform.pos.y)/distance*agent.creature.getSpeed());
                agent.nextTick=AgentV2System.totalTime + distance/agent.creature.getSpeed();

                agent.direction=AnimationName.getDirection(agent.velocityComponent.speed.x,agent.velocityComponent.speed.y);
                agent.animationName=AnimationName.getWalkName(agent.direction);//Animation set

            }
            else {
                agent.stateMachine.changeState(FOLLOW);
                return;
            }

        }

        @Override
        public void exit(VeteranAgentComponentV2 agent) {
            agent.velocityComponent.speed.setZero();
            agent.nextPoint=null;
        }

        @Override
        public boolean onMessage(VeteranAgentComponentV2 entity, Telegram telegram) {
            return false;
        }
    },
    ATTACK(){
        @Override
        public void enter(VeteranAgentComponentV2 agent) {
            agent.direction=AnimationName.getDirection(agent.targetTransform.pos.x-agent.transform.pos.x,agent.targetTransform.pos.y-agent.transform.pos.y);
            agent.animationName=AnimationName.getAttackName(agent.direction);

            agent.velocityComponent.speed.setZero();
            agent.currentState=StateType.ATTACK;

            agent.updateAbilities(AbilityController.Type.STATE);
            if (EntityUI.getEntity()==agent.entity)
                EntityUI.entityUI.entityStateChange();
        }

        @Override
        public void update(VeteranAgentComponentV2 agent) {
            //ToDo Animation
            float distance=agent.transform.distance(agent.targetTransform)/Point.UNIT;
            if (!agent.targetCreature.isAlive){
                findTarget(agent);
                if (agent.target==null){
                    agent.stateMachine.changeState(WAIT);
                }
                else{
                    agent.stateMachine.changeState(FOLLOW);
                }
                return;
            }

            if (distance<agent.primaryWeapon.range-4){
                agent.stateMachine.changeState(ATTACK_FLEE);
            }
            else if (distance<agent.primaryWeapon.range){
                switch (agent.primaryWeapon.bulletType){
                    case LINE:
                        if (!pointGraph.anyObstacle(agent.currentPoint,agent.targetAgent.currentPoint) && distance<agent.primaryWeapon.range*Point.UNIT){
                            agent.nextTick=AgentV2System.totalTime+agent.primaryWeapon.getAttackRate(agent.creature);//Set next tick
                            agent.lastAttackTime=AgentV2System.totalTime;
                            agent.primaryWeapon.abilityControllers.clear();//Set ability to weapon
                            agent.updateAbilities(AbilityController.Type.ATTACK);//Ability Update
                            agent.primaryWeapon.attack(agent.creature,agent.targetCreature);//Attack
                            agent.animationName= AnimationName.getAttackName(AnimationName.getDirection(agent.targetTransform.pos.x-agent.transform.pos.x,agent.targetTransform.pos.y-agent.transform.pos.y));
                        }
                        else{
                            agent.stateMachine.changeState(FOLLOW);
                            return;
                        }
                        break;
                    case AIRBORNE:
                        if (!agent.targetAgent.currentPoint.roofed && distance<agent.primaryWeapon.range*Point.UNIT){
                            agent.nextTick=AgentV2System.totalTime+agent.primaryWeapon.getAttackRate(agent.creature);//Set next tick
                            agent.lastAttackTime=AgentV2System.totalTime;
                            agent.primaryWeapon.abilityControllers.clear();//Set ability to weapon
                            agent.updateAbilities(AbilityController.Type.ATTACK);//Ability Update
                            agent.primaryWeapon.attack(agent.creature,agent.targetCreature);//Attack
                        }
                        else {
                            agent.stateMachine.changeState(FOLLOW);
                            return;
                        }
                        break;
                    case UNDERGROUND:
                        if (distance<agent.primaryWeapon.range*Point.UNIT){
                            agent.nextTick=AgentV2System.totalTime+agent.primaryWeapon.getAttackRate(agent.creature);//Set next tick
                            agent.lastAttackTime=AgentV2System.totalTime;
                            agent.primaryWeapon.abilityControllers.clear();//Set ability to weapon
                            agent.updateAbilities(AbilityController.Type.ATTACK);//Ability Update
                            agent.primaryWeapon.attack(agent.creature,agent.targetCreature);//Attack
                        }
                        else {
                            agent.stateMachine.changeState(FOLLOW);
                            return;
                        }
                        break;
                }
            }
            agent.direction=AnimationName.getDirection(agent.targetTransform.pos.x-agent.transform.pos.x,agent.targetTransform.pos.y-agent.transform.pos.y);
            agent.animationName=AnimationName.getAttackName(agent.direction);


        }

        @Override
        public void exit(VeteranAgentComponentV2 entity) {

        }

        @Override
        public boolean onMessage(VeteranAgentComponentV2 entity, Telegram telegram) {
            return false;
        }
    },
    ATTACK_FLEE() {
        @Override
        public void enter(VeteranAgentComponentV2 agent) {
            agent.path=pointGraph.findPath(agent.currentPoint,getFleePoint(agent));
            agent.iterator=agent.path.iterator();
            if (agent.iterator.hasNext())
                agent.iterator.next();
            agent.currentState=StateType.ATTACK;
        }

        @Override
        public void update(VeteranAgentComponentV2 agent) {
            if (agent.currentPoint!=pointGraph.nearestPoint(agent.transform.pos)) {
                agent.currentPoint.humans.removeValue(agent.entity,true);
                agent.currentPoint=pointGraph.nearestPoint(agent.transform.pos);
                agent.currentPoint.humans.add(agent.entity);
            }

            if (!agent.targetCreature.isAlive){
                findTarget(agent);
                if (agent.target==null){
                    agent.stateMachine.changeState(WAIT);
                    return;
                }
                else {
                    agent.stateMachine.changeState(FOLLOW);
                }


            }

            float distance=agent.transform.distance(agent.targetTransform)/Point.UNIT;


            if (agent.nextAttack<AgentV2System.totalTime){
                switch (agent.primaryWeapon.bulletType){
                    case LINE:
                        if (!pointGraph.anyObstacle(agent.currentPoint,agent.targetAgent.currentPoint) && distance<agent.primaryWeapon.range){
                            //ToDo Mappers.animationComponents.get(agent.entity).stop=false;
                            agent.nextAttack=AgentV2System.totalTime+agent.primaryWeapon.getAttackRate(agent.creature);//Set next tick
                            agent.lastAttackTime=AgentV2System.totalTime;
                            agent.primaryWeapon.abilityControllers.clear();//Set ability to weapon
                            agent.updateAbilities(AbilityController.Type.ATTACK);//Ability Update
                            agent.primaryWeapon.attack(agent.creature,agent.targetCreature);//Attack
                            //agent.animationName=AnimationName.getAttackName(AnimationName.getDirection(agent.targetTransform.pos.x-agent.transform.pos.x,agent.targetTransform.pos.y-agent.transform.pos.y));

                        }
                        else if (distance< agent.primaryWeapon.range){
                            Entity entity= findInRange(agent);
                            if (entity!=null){
                                agent.target=entity;
                                agent.targetTransform=Mappers.transformComponents.get(entity);
                                agent.targetCreature=Mappers.creatureComponents.get(entity);
                                agent.targetAgent=Mappers.agentComponentV2(entity);
                            }
                            else {
                                //ToDo: ne yapacağımı bilmiyorum
                            }
                        }
                        else{
                            agent.stateMachine.changeState(FOLLOW);
                            return;
                        }
                        break;
                    case AIRBORNE:
                        if (!agent.targetAgent.currentPoint.roofed && distance<agent.primaryWeapon.range){
                            agent.nextAttack=AgentV2System.totalTime+agent.primaryWeapon.getAttackRate(agent.creature);//Set next tick
                            agent.lastAttackTime=AgentV2System.totalTime;
                            agent.primaryWeapon.abilityControllers.clear();//Set ability to weapon
                            agent.updateAbilities(AbilityController.Type.ATTACK);//Ability Update
                            agent.primaryWeapon.attack(agent.creature,agent.targetCreature);//Attack
                        }
                        else if (distance<agent.primaryWeapon.range){
                            findTarget(agent);
                            if (agent.target!=null){
                                agent.stateMachine.changeState(FOLLOW);
                            }
                            else {
                                agent.stateMachine.changeState(WAIT);
                            }
                            return;
                        }
                        else {
                            agent.stateMachine.changeState(WAIT);
                            return;
                        }
                        break;
                    case UNDERGROUND:
                        if (distance<agent.primaryWeapon.range){
                            agent.nextTick=AgentV2System.totalTime+agent.primaryWeapon.getAttackRate(agent.creature);//Set next tick
                            agent.lastAttackTime=AgentV2System.totalTime;
                            agent.primaryWeapon.abilityControllers.clear();//Set ability to weapon
                            agent.updateAbilities(AbilityController.Type.ATTACK);//Ability Update
                            agent.primaryWeapon.attack(agent.creature,agent.targetCreature);//Attack
                        }
                        else {
                            agent.stateMachine.changeState(FOLLOW);
                        }
                        break;
                }
            }

            if (agent.nextWalk<AgentV2System.totalTime){
                if (agent.iterator.hasNext()){
                    agent.nextPoint = agent.iterator.next();
                    agent.nextPosition.set(agent.nextPoint.x+(0.5f-MathUtils.random())*Point.UNIT,agent.nextPoint.y+(0.5f-MathUtils.random())*Point.UNIT);

                    float distancePosition= (float) Math.pow(Math.pow(agent.nextPosition.x-agent.transform.pos.x,2)+Math.pow(agent.nextPosition.y-agent.transform.pos.y,2),0.5f);

                    agent.velocityComponent.speed.set((agent.nextPosition.x-agent.transform.pos.x)/distancePosition*agent.creature.getSpeed(), (agent.nextPosition.y-agent.transform.pos.y)/distancePosition*agent.creature.getSpeed());
                    agent.nextWalk=AgentV2System.totalTime + distancePosition/agent.creature.getSpeed();

                    agent.direction=AnimationName.getDirection(agent.velocityComponent.speed.x,agent.velocityComponent.speed.y);
                    float rad= (float) Math.atan((agent.targetTransform.pos.y-agent.transform.pos.y)/(agent.targetTransform.pos.x-agent.transform.pos.x));

                    if (agent.targetTransform.pos.x<agent.transform.pos.x){
                        if (rad<0){
                            rad=MathUtils.PI+rad;
                        }
                        else{
                            rad=MathUtils.PI+rad;
                        }

                    }
                    else {
                        if (rad<0){
                            rad=MathUtils.PI2+rad;
                        }

                    }
                    switch (agent.direction){
                        case DOWN:
                            if ((5f/4f)*MathUtils.PI<rad&&rad<(7f/4f)*MathUtils.PI){
                                //Dümdüz yürümeye devam eder
                                agent.animationName=AnimationName.WALK_DOWN;
                            }
                            else if ((1f/2f)*MathUtils.PI<rad&&rad<(5f/4f)*MathUtils.PI){
                                //Sola bakar
                                agent.animationName=AnimationName.WALK_DOWN_LOOK_LEFT;
                                //agent.animationName=AnimationName.WALK_DOWN_LOOK_RIGHT;
                            }
                            /*else if (((7f/4f)*MathUtils.PI<rad&&rad<2*MathUtils.PI) || (0<rad&&rad<(1f/2f)*MathUtils.PI)){
                                //Sağa bakar
                            }*/
                            else {
                                //Sağa bakar
                                agent.animationName=AnimationName.WALK_DOWN_LOOK_RIGHT;
                                //agent.animationName=AnimationName.WALK_DOWN_LOOK_LEFT;
                            }
                            break;
                        case UP:
                            if ((1f/4f)*MathUtils.PI<rad&&rad<(3f/4f)*MathUtils.PI){
                                //Dümdüz devam
                                agent.animationName=AnimationName.WALK_UP;
                            }
                            else if ((3f/4f)*MathUtils.PI<rad&&rad<(3f/2f)*MathUtils.PI){
                                //sola bakar
                                agent.animationName=AnimationName.WALK_UP_LOOK_LEFT;
                            }
                            else {
                                //Sağa bakar
                                agent.animationName=AnimationName.WALK_UP_LOOK_RIGHT;
                            }
                            break;
                        case LEFT:
                            if ((3f/4f)*MathUtils.PI<rad&&rad<(5f/4f)*MathUtils.PI){
                                //Dümdüz devam
                                agent.animationName=AnimationName.WALK_LEFT;
                            }
                            else if ((5f/4f)*MathUtils.PI<rad&&rad<2*MathUtils.PI){
                                //aşağıya bakar
                                agent.animationName=AnimationName.WALK_LEFT_LOOK_DOWN;
                            }
                            else {
                                //yukarıya bakar
                                agent.animationName=AnimationName.WALK_LEFT_LOOK_UP;
                            }
                            break;
                        case RIGHT:
                            if ((0<rad&&rad<(1f/4f)*MathUtils.PI)||((7f/4f)*MathUtils.PI<rad&&rad<2*MathUtils.PI)){
                                agent.animationName=AnimationName.WALK_RIGHT;
                            }
                            else if ((1f/4f)*MathUtils.PI<rad&&rad<MathUtils.PI){
                                //yukarıya bakar
                                agent.animationName=AnimationName.WALK_RIGHT_LOOK_UP;
                            }
                            else {
                                agent.animationName=AnimationName.WALK_RIGHT_LOOK_DOWN;
                            }
                            break;
                    }
                    Gdx.app.log(TAG,agent.animationName.name());
                    //agent.animationName=AnimationName.getWalkName(agent.direction);//Animation set

                }
                else {
                    if (distance>agent.primaryWeapon.range-3){
                        agent.stateMachine.changeState(ATTACK);
                    }
                    else{
                        agent.stateMachine.changeState(ATTACK_FLEE);
                        agent.animationName= AnimationName.getAttackName(AnimationName.getDirection(agent.targetTransform.pos.x-agent.transform.pos.x,agent.targetTransform.pos.y-agent.transform.pos.y));

                    }
                    agent.nextTick=agent.nextAttack;
                    return;
                }
            }

            agent.nextTick=Math.min(agent.nextWalk,agent.nextAttack);
        }

        @Override
        public void exit(VeteranAgentComponentV2 agent) {
            agent.velocityComponent.speed.setZero();
            agent.nextPoint=null;
        }

        @Override
        public boolean onMessage(VeteranAgentComponentV2 agent, Telegram telegram) {
            return false;
        }
    };
    private static final String TAG =VeteranStateV2.class.getSimpleName();
    PointGraph pointGraph= MapManager.getInstance().pointGraph;

    protected void findTarget(VeteranAgentComponentV2 agent){
        agent.target=null;
        agent.targetTransform=null;
        agent.targetCreature=null;
        agent.targetAgent=null;

        Array<Point> points=agent.currentPoint.rangeArrayMap.get(agent.awareRadius);
        for (Point point:points){
            if (agent.primaryWeapon.bulletType== BulletType.AIRBORNE&&point.roofed)
                continue;
            if (point.zombies.size!=0){
                agent.target=point.zombies.random();
                agent.targetTransform= Mappers.transformComponents.get(agent.target);
                agent.targetCreature=Mappers.creatureComponents.get(agent.target);
                agent.targetAgent=Mappers.agentComponentV2(agent.target);
                return;
            }
        }
    }

    protected Entity findInRange(VeteranAgentComponentV2 agent){
        Array<Point> points=agent.currentPoint.rangeArrayMap.get(agent.primaryWeapon.range-1);

        for (int i=0;i<points.size;i++){
            if (agent.primaryWeapon instanceof RangedWeapon){
                switch (((RangedWeapon) agent.primaryWeapon).bulletType){
                    case LINE:
                        if (pointGraph.anyObstacle(agent.currentPoint,points.get(i)))
                            continue;
                        break;
                    case AIRBORNE:
                        if (points.get(i).roofed)
                            continue;
                        break;
                }
            }
            if (points.get(i).zombies.size!=0){
                return points.get(i).zombies.random();
            }
        }

        return null;
    }

    protected Point getFleePoint(VeteranAgentComponentV2 agent){
        float x=0,y=0;

        Array<Point> points= agent.currentPoint.rangeArrayMap.get(agent.primaryWeapon.range);
        for (int i=0;i<points.size;i++){
            if (points.get(i).zombies.size!=0){
                float t=Math.abs(agent.currentPoint.x-points.get(i).x)+Math.abs(agent.currentPoint.y-points.get(i).y);
                x+=(agent.currentPoint.x-points.get(i).x)/(t*t);
                y+=(agent.currentPoint.y-points.get(i).y)/(t*t);
            }
        }
        float length= (float) Math.pow(x*x+y*y,0.5f);
        if (x==0){
            if (MathUtils.randomBoolean())
                x=length/2;
            else
                x=-length/2;
        }
        if (y==0){
            if (MathUtils.randomBoolean())
                y=length/2;
            else
                y=-length/2;
        }
        return pointGraph.nearestPoint(agent.currentPoint.x + (x/length*Point.UNIT*4),agent.currentPoint.y + (y/length*Point.UNIT*4));
    }

}
