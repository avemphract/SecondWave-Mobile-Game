package com.katafrakt.zombieoff.managers;

import com.badlogic.ashley.core.PooledEngine;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.maps.MapLayer;
import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.MapProperties;
import com.badlogic.gdx.maps.objects.PolylineMapObject;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.ai.pfa.Point;
import com.katafrakt.zombieoff.ai.pfa.PointGraph;
import com.katafrakt.zombieoff.entities.EntityType;

import java.util.Hashtable;

@SuppressWarnings("IntegerDivisionInFloatingPointContext")
public class MapManager {
    private final String TAG=MapManager.class.getSimpleName();
    private static MapManager mapManager;
    public static MapManager getInstance(){
        if (mapManager==null)
            mapManager=new MapManager();
        return mapManager;
    }

    public PointGraph pointGraph;

    private MapManager(){

    }

    public static Hashtable<Integer,String> mapTable=new Hashtable<>();
    static {
        mapTable.put(1,"maps/map_1.tmx");
        mapTable.put(2,"maps/map_2.tmx");
        mapTable.put(3,"maps/map_3.tmx");
        mapTable.put(4,"maps/map_4.tmx");
        mapTable.put(5,"maps/map_5.tmx");
    }

    private int currentLevel;
    public TiledMap currentMap;

    private MapLayer nonwalkable_area;
    private MapLayer nonwalkable_line;
    private MapLayer obstacle_area;
    private MapLayer roofed_area;

    private MapLayer civiliansLayer;
    private MapLayer policesLayer;
    private MapLayer mercenariesLayer;
    private MapLayer veteransLayer;

    public int mapTileWidth;
    public int mapTileHeight;
    public int mapPixelWidth;
    public int mapPixelHeight;
    public int tileSize;

    public void loadMap(int level){
        currentLevel=level;
        if (mapTable.get(level)==null || mapTable.get(level).isEmpty()){
            Gdx.app.log(TAG,"Map is empty or null:"+level+","+mapTable.get(level));
            return;
        }
        if (AssetOrganizer.getInstance().assetManager.isLoaded(mapTable.get(level))){
            currentMap=AssetOrganizer.getInstance().get(mapTable.get(level),TiledMap.class);
        }
        else {
            Gdx.app.log(TAG,"Map not loaded"); return;
        }

        nonwalkable_area = currentMap.getLayers().get("nonwalkable_area");
        nonwalkable_line = currentMap.getLayers().get("nonwalkable_line");

        obstacle_area = currentMap.getLayers().get("obstacle_area");
        roofed_area = currentMap.getLayers().get("roofed_area");

        civiliansLayer = currentMap.getLayers().get("civilians");
        policesLayer = currentMap.getLayers().get("polices");
        mercenariesLayer=currentMap.getLayers().get("mercenaries");
        veteransLayer=currentMap.getLayers().get("veterans");

        createPointGraph();
    }
    private void createPointGraph(){
        Gdx.app.log(TAG,"createdPointGraph");
        MapProperties prop=currentMap.getProperties();
        mapTileWidth = prop.get("width",Integer.class);
        mapTileHeight = prop.get("height",Integer.class);
        tileSize = prop.get("tilewidth",Integer.class);

        mapPixelWidth=mapTileWidth*tileSize;
        mapPixelHeight=mapTileHeight*tileSize;

        pointGraph=new PointGraph(mapTileWidth, mapTileHeight,tileSize);

        Array<Vector2> nonWalkablePos=new Array<>();
        for (MapObject object: nonwalkable_area.getObjects()){
            if (object instanceof RectangleMapObject){
                RectangleMapObject rectangle=(RectangleMapObject) object;
                for (float x=rectangle.getRectangle().x+Point.UNIT/2 ;x<=rectangle.getRectangle().x+rectangle.getRectangle().width ;x+=Point.UNIT){
                    for (float y=rectangle.getRectangle().y+Point.UNIT/2 ;y<=rectangle.getRectangle().y+rectangle.getRectangle().height ;y+=Point.UNIT){
                        nonWalkablePos.add(new Vector2(x,y));
                    }
                }
            }
        }

        Array<Vector2> nonConnectionPos=new Array<>();
        for (MapObject object: nonwalkable_line.getObjects()){
            if (object instanceof PolylineMapObject){
                PolylineMapObject polyline=(PolylineMapObject) object;
                float[] point=new float[polyline.getPolyline().getTransformedVertices().length];
                for (int i=0;i<point.length;i++){
                    point[i]=polyline.getPolyline().getTransformedVertices()[i];
                }
                float[] currentPoint=new float[2];
                float[] nextPoint=new float[2];
                float[] direction=new float[2];

                for (int i=0;i<(point.length/2-1);i++){
                    currentPoint[0]=point[2*i];
                    currentPoint[1]=point[2*i+1];

                    nextPoint[0]=point[2*i+2];
                    nextPoint[1]=point[2*i+3];

                    direction[0]=nextPoint[0]-currentPoint[0];
                    direction[1]=nextPoint[1]-currentPoint[1];
                    float length=Math.abs(direction[0]+direction[1]);

                    direction[0]=direction[0]/length*Point.UNIT;
                    direction[1]=direction[1]/length*Point.UNIT;

                    currentPoint[0]=currentPoint[0]+direction[0]/2;
                    currentPoint[1]=currentPoint[1]+direction[1]/2;

                    for (int j=0;j<(length/Point.UNIT);j++){
                        nonConnectionPos.add(new Vector2(currentPoint[0]+direction[0]*j,currentPoint[1]+direction[1]*j));
                    }

                }



            }
        }
        pointGraph.nonConnection=nonConnectionPos;


        Array<Vector2> obstaclePos=new Array<>();
        for (MapObject object: obstacle_area.getObjects()){
            if (object instanceof RectangleMapObject){
                RectangleMapObject rectangle=(RectangleMapObject) object;
                for (float x=rectangle.getRectangle().x+Point.UNIT/2 ;x<=rectangle.getRectangle().x+rectangle.getRectangle().width; x+=Point.UNIT){
                    for (float y=rectangle.getRectangle().y+Point.UNIT/2;y<=rectangle.getRectangle().y+rectangle.getRectangle().height; y+=Point.UNIT){
                        obstaclePos.add(new Vector2(x,y));
                    }
                }
            }
        }

        for (MapObject object: obstacle_area.getObjects()){
            if (object instanceof PolylineMapObject){
                PolylineMapObject polygon= (PolylineMapObject) object;
                float[] point=new float[polygon.getPolyline().getTransformedVertices().length];
                for (int i=0;i<point.length;i++){
                    point[i]=polygon.getPolyline().getTransformedVertices()[i];
                }
                Vector2 current=new Vector2();
                for (int i=0;i<point.length/2;i++){

                    current.set(point[i*2]+Point.UNIT/2,point[i*2+1]+Point.UNIT/2);
                    obstaclePos.add(new Vector2(current));
                    current.set(point[i*2]-Point.UNIT/2,point[i*2+1]+Point.UNIT/2);
                    obstaclePos.add(new Vector2(current));
                    current.set(point[i*2]-Point.UNIT/2,point[i*2+1]-Point.UNIT/2);
                    obstaclePos.add(new Vector2(current));
                    current.set(point[i*2]+Point.UNIT/2,point[i*2+1]-Point.UNIT/2);
                    obstaclePos.add(new Vector2(current));
                }
            }
        }



        Array<Vector2> roofedPos=new Array<>();
        for (MapObject object: roofed_area.getObjects()){
            if (object instanceof RectangleMapObject){
                RectangleMapObject rectangle=(RectangleMapObject) object;
                for (float x=rectangle.getRectangle().x+Point.UNIT/2 ;x<=rectangle.getRectangle().x+rectangle.getRectangle().width; x+=Point.UNIT){
                    for (float y=rectangle.getRectangle().y+Point.UNIT/2;y<=rectangle.getRectangle().y+rectangle.getRectangle().height; y+=Point.UNIT){
                        roofedPos.add(new Vector2(x,y));
                    }
                }
            }
        }
        Gdx.app.log(TAG,"Loading map elements");

        for (int x = 0; x< mapTileWidth *tileSize; x+=Point.UNIT){
            for (int y = 0; y< mapTileWidth *tileSize; y+=Point.UNIT){
                boolean isWalkable=true;
                for (Vector2 vector2:nonWalkablePos){
                    if (vector2.x==x+Point.UNIT/2&&vector2.y==y+Point.UNIT/2)
                        isWalkable=false;
                }
                if ((x<3*Point.UNIT||x>mapPixelWidth-3*Point.UNIT)||(y<3*Point.UNIT||y>mapPixelHeight-3*Point.UNIT))
                    isWalkable=false;

                boolean isObstacle=false;
                for (Vector2 vector2:obstaclePos){
                    if (vector2.x==x+Point.UNIT/2&&vector2.y==y+Point.UNIT/2)
                        isObstacle=true;
                }
                boolean isRoofed=false;
                for (Vector2 vector2:roofedPos){
                    if (vector2.x==x+Point.UNIT/2&&vector2.y==y+Point.UNIT/2)
                        isRoofed=true;
                }

                pointGraph.addPoint(new Point(x+Point.UNIT/2,y+Point.UNIT/2,isWalkable,isObstacle,isRoofed));
            }
        }
        Gdx.app.log(TAG,"Finished");
        pointGraph.postCreation();
    }
    public void setEntities(PooledEngine engineEdited){



        for (MapObject object: civiliansLayer.getObjects()){
            if (object instanceof RectangleMapObject){
                RectangleMapObject pointObject= (RectangleMapObject) object;
                engineEdited.addEntity(EntityFactory.getInstance().createHuman(EntityType.CIVILIAN,pointObject.getRectangle().x,pointObject.getRectangle().y));
            }
        }


        for (MapObject object: policesLayer.getObjects()){
            if (object instanceof RectangleMapObject){
                RectangleMapObject pointObject= (RectangleMapObject) object;
                engineEdited.addEntity(EntityFactory.getInstance().createHuman(EntityType.POLICE,pointObject.getRectangle().x,pointObject.getRectangle().y));
            }
        }

/*
        for (MapObject object: mercenariesLayer.getObjects()){
            if (object instanceof RectangleMapObject){
                RectangleMapObject pointObject= (RectangleMapObject) object;
                engineEdited.addEntity(EntityFactory.getInstance().createHuman(EntityType.MERCENARY,pointObject.getRectangle().x,pointObject.getRectangle().y));
            }
        }
*/

        for (MapObject object: veteransLayer.getObjects()){
            if (object instanceof RectangleMapObject){
                RectangleMapObject pointObject= (RectangleMapObject) object;
                engineEdited.addEntity(EntityFactory.getInstance().createHuman(EntityType.VETERAN,pointObject.getRectangle().x,pointObject.getRectangle().y));
            }
        }


    }
}
