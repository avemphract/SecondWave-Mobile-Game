package com.katafrakt.zombieoff.managers;

import com.badlogic.ashley.core.Entity;
import com.badlogic.ashley.core.PooledEngine;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.katafrakt.zombieoff.Main;
import com.katafrakt.zombieoff.ashley.components.Init;
import com.katafrakt.zombieoff.ashley.components.creatures.CreatureComponent;
import com.katafrakt.zombieoff.ashley.systems.BulletSystem;
import com.katafrakt.zombieoff.ashley.systems.CreatureSystem;
import com.katafrakt.zombieoff.ashley.systems.VelocitySystem;
import com.katafrakt.zombieoff.ashley.systems.agents.AgentV2System;
import com.katafrakt.zombieoff.ashley.systems.graphics.AnimationSystem;
import com.katafrakt.zombieoff.ashley.systems.graphics.FloatingTextSystem;
import com.katafrakt.zombieoff.ashley.systems.graphics.ParticleEffectSystem;
import com.katafrakt.zombieoff.ashley.systems.graphics.entity.AwareBar;
import com.katafrakt.zombieoff.ashley.systems.graphics.entity.BulletRendererSystem;
import com.katafrakt.zombieoff.ashley.systems.graphics.entity.DebugRendererSystem;
import com.katafrakt.zombieoff.ashley.systems.graphics.entity.AgentRendererSystem;
import com.katafrakt.zombieoff.ashley.systems.graphics.map.BackRenderer;
import com.katafrakt.zombieoff.entities.EntityType;
import com.katafrakt.zombieoff.player.PlayerStatics;
import com.katafrakt.zombieoff.player.ResourceSystem;
import com.katafrakt.zombieoff.ui.CameraComposite;
import com.katafrakt.zombieoff.utilities.EntityList;


public class EngineEdited extends PooledEngine {
    private static final String TAG=EngineEdited.class.getSimpleName();
    public static EngineEdited initiate;
    public ResourceSystem resourceSystem;
    CameraComposite cameraComposite;
    Main main;
    SpriteBatch spriteBatch;
    ShapeRenderer shapeRenderer;
    BitmapFont font;

    private boolean isPaused;

    BulletSystem bulletSystem;
    CreatureSystem creatureSystem;
    //AgentSystem agentSystem;
    AnimationSystem animationSystem;
    BackRenderer backRenderer;
    AgentRendererSystem agentRendererSystem;
    BulletRendererSystem bulletRendererSystem;
    DebugRendererSystem debugRendererSystem;
    ParticleEffectSystem particleEffectSystem;
    FloatingTextSystem floatingTextSystem;
    AwareBar awareBar;

    AgentV2System agentV2System;
    VelocitySystem velocitySystem;
    int index;

    public boolean isEnabledFloatingText;
    public boolean isEnabledParticleEffect;

    public EngineEdited(CameraComposite cameraComposite, Main main, ShapeRenderer shapeRenderer, SpriteBatch spriteBatch,BitmapFont font){
        super();
        this.main=main;
        this.spriteBatch=spriteBatch;
        this.shapeRenderer=shapeRenderer;
        this.font=font;
        this.cameraComposite=cameraComposite;

        createSystem();
        addSystem();
        initiate=this;

    }
    private void createSystem(){

        bulletSystem=new BulletSystem();
        creatureSystem=new CreatureSystem();
        resourceSystem= PlayerStatics.getInstance().resourceSystem;
        //agentSystem=new AgentSystem();
        animationSystem=new AnimationSystem();
        backRenderer=new BackRenderer(cameraComposite.getCamera(),new OrthogonalTiledMapRenderer(MapManager.getInstance().currentMap));
        agentRendererSystem =new AgentRendererSystem(spriteBatch,cameraComposite);
        bulletRendererSystem= new BulletRendererSystem(spriteBatch,cameraComposite);
        debugRendererSystem=new DebugRendererSystem(shapeRenderer,spriteBatch,cameraComposite.getCamera());

        particleEffectSystem=new ParticleEffectSystem(spriteBatch,cameraComposite.getCamera());
        floatingTextSystem=new FloatingTextSystem(spriteBatch,font);
        awareBar=new AwareBar(shapeRenderer);

        agentV2System=new AgentV2System();
        velocitySystem=new VelocitySystem();
    }

    private void addSystem(){
        addSystem(bulletSystem);
        addSystem(creatureSystem);
        addSystem(resourceSystem);
        addSystem(velocitySystem);
        addSystem(agentV2System);

        addSystem(animationSystem);
        addSystem(backRenderer);
        addSystem(agentRendererSystem);
        addSystem(bulletRendererSystem);
        addSystem(debugRendererSystem);
        addSystem(particleEffectSystem);
        addSystem(floatingTextSystem);
        //addSystem(awareBar);

        //removeSystem(debugRendererSystem);
        //removeSystem(awareBar);
        //removeSystem(agentSystem);



        creatureSystem.priority=2;
        resourceSystem.priority=3;
        bulletSystem.priority=4;
        agentV2System.priority=5;


        animationSystem.priority=6;
        backRenderer.priority=7;
        agentRendererSystem.priority=8;
        bulletRendererSystem.priority=9;
        debugRendererSystem.priority=10;
        particleEffectSystem.priority=11;
        floatingTextSystem.priority=12;
        awareBar.priority=13;

    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
    }

    @Override
    public synchronized void addEntity(Entity entity) {
        if (entity==null){
            Gdx.app.log(TAG,"Bir şeyler ters gitti");
        }
        super.addEntity(entity);
        if (entity instanceof Init)
            ((Init) entity).addedEngine();
    }

    public void setPause(boolean isPaused){
        if (isPaused!=this.isPaused){
            if (isPaused){
                /*
                removeSystem(bulletSystem);
                removeSystem(creatureSystem);
                removeSystem(resourceSystem);*/
                //removeSystem(debugRendererSystem);
                //removeSystem(awareBar);
            }
            else {/*
                addSystem(bulletSystem);
                addSystem(creatureSystem);
                addSystem(resourceSystem);*/
                //addSystem(debugRendererSystem);
                //addSystem(awareBar);

            }
            this.isPaused=isPaused;
        }
    }
    public boolean getPause(){return isPaused;}


    public void removeEntityType(EntityType entityType){
        for (Entity entity: EntityList.entityList.get(entityType)){
            entity.getComponent(CreatureComponent.class).currentHp=0;
        }
    }

    public void removeEntityMember(int member){
        if (member==0){
            for (Entity entity:EntityList.entityList.humanEntities)
                entity.getComponent(CreatureComponent.class).currentHp=0;
        }
        else if (member==1){
            for (Entity entity:EntityList.entityList.zombieEntities)
                entity.getComponent(CreatureComponent.class).currentHp=0;
        }
    }

}
