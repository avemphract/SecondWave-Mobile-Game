package com.katafrakt.zombieoff.managers;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.entities.EntityType;
import com.katafrakt.zombieoff.entities.humans.Civilian;
import com.katafrakt.zombieoff.entities.humans.Mercenary;
import com.katafrakt.zombieoff.entities.humans.Police;
import com.katafrakt.zombieoff.entities.humans.Veteran;
import com.katafrakt.zombieoff.entities.zombies.BasicZombie;
import com.katafrakt.zombieoff.entities.zombies.CommonZombie;
import com.katafrakt.zombieoff.entities.zombies.GiantZombie;
import com.katafrakt.zombieoff.entities.zombies.RangedZombie;
import com.katafrakt.zombieoff.game.upgradebehaviours.AbilityCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.WeaponCreator;
import com.katafrakt.zombieoff.game.upgradebehaviours.weapon_creators.WeaponTag;
import com.katafrakt.zombieoff.player.ZombieBuilder;

import java.util.Random;

public class EntityFactory {

    private static EntityFactory instance;
    public static EntityFactory getInstance(){
        if (instance==null)
            instance=new EntityFactory();
        return instance;
    }
    Random random=GeneralOrganizer.getInstance().random;
    static int level=2;

    public Entity createHuman(EntityType entityType, float x, float y){
        Entity entity=null;
        switch (entityType){
            case CIVILIAN:
                setHumanBuilder(entityType);
                entity=new Civilian(x,y,humanBuilder);
                break;
            case POLICE:
                setHumanBuilder(entityType);
                entity=new Police(x,y,humanBuilder);
                break;
            case MERCENARY:
                setHumanBuilder(entityType);
                entity=new Mercenary(x,y,humanBuilder);
                break;
            case VETERAN:
                setHumanBuilder(entityType);
                entity=new Veteran(x,y,humanBuilder);
                break;
        }
        return entity;
    }

    public float getHealth(){ return level*50;}
    public float getAttack(){ return level*5;}

    Array<WeaponCreator> weapons=new Array<>();
    HumanBuilder humanBuilder=new HumanBuilder();
    public void setHumanBuilder(EntityType entityType){
        weapons.clear();
        float rng=random.nextFloat();
        if (entityType==EntityType.CIVILIAN){

            if (rng>0.75f)
                weapons.add(WeaponTag.ROCKET_LAUNCHER);
            else if (rng>0.5f)
                weapons.add(WeaponTag.LONG_RANGE_II);
            else if (rng>0.25f)
                weapons.add(WeaponTag.MACHINE_GUN);
            else
                weapons.add(WeaponTag.RAPID_FIRE_IV);


/*
            if (rng>0.75f)
                weapons.add(WeaponTag.SHOTGUN_I);
            else if (rng>0.5f)
                weapons.add(WeaponTag.SHOTGUN_II);
            else if (rng>0.25f)
                weapons.add(WeaponTag.SHOTGUN_III);
            else
                weapons.add(WeaponTag.SHOTGUN_IV);
*/
/*
            if (rng>0.75f)
                weapons.add(WeaponTag.LONG_RANGE_I);
            else if (rng>0.5f)
                weapons.add(WeaponTag.LONG_RANGE_II);
            else if (rng>0.25f)
                weapons.add(WeaponTag.LONG_RANGE_III);
            else
                weapons.add(WeaponTag.LONG_RANGE_IV);
*/
/*
            if (rng>0f)
                weapons.add(WeaponTag.SHRAPNEL_RAPID);
            else if (rng>0.5f)
                weapons.add(WeaponTag.MACHINE_GUN);
            else if (rng>0.25f)
                weapons.add(WeaponTag.GRENADE_THROWER);
            else
                weapons.add(WeaponTag.ROCKET_LAUNCHER);
*/
            humanBuilder.set(getHealth(),getAttack(),10,10,weapons);
        }
        else if (entityType==EntityType.POLICE){
            weapons.clear();
            if (rng>0.75f)
                weapons.add(WeaponTag.LONG_RANGE_I);
            else if (rng>0.5f)
                weapons.add(WeaponTag.LONG_RANGE_II);
            else if (rng>0.25f)
                weapons.add(WeaponTag.LONG_RANGE_III);
            else
                weapons.add(WeaponTag.LONG_RANGE_IV);
            humanBuilder.set(getHealth(),getAttack(),10,20,weapons);
        }
        /*
        else if (entityType==EntityType.MERCENARY){
            weapons.clear();
            if (rng>0.75f)
                weapons.add(WeaponTag.LONG_RANGE_I);
            else if (rng>0.5f)
                weapons.add(WeaponTag.LONG_RANGE_II);
            else if (rng>0.25f)
                weapons.add(WeaponTag.LONG_RANGE_III);
            else
                weapons.add(WeaponTag.LONG_RANGE_IV);
            humanBuilder.set(getHealth(),getAttack(),10,20,weapons);
        }*/
        else if (entityType==EntityType.VETERAN){
            weapons.clear();
            if (rng>0.75f)
                weapons.add(WeaponTag.LONG_RANGE_I);
            else if (rng>0.5f)
                weapons.add(WeaponTag.LONG_RANGE_II);
            else if (rng>0.25f)
                weapons.add(WeaponTag.LONG_RANGE_III);
            else
                weapons.add(WeaponTag.LONG_RANGE_IV);
            humanBuilder.set(getHealth(),getAttack(),10,16,weapons);
        }
    }

    public Entity createEntity(EntityType entityType, float x, float y){
        Entity entity=null;
        switch (entityType){
            case COMMON_ZOMBIE:
                entity=new CommonZombie(x,y, ((ZombieBuilder.CommonZombie)ZombieBuilder.getInstance().builderMap.get(entityType)));
                break;
            case BASIC_ZOMBIE:
                entity=new BasicZombie(x,y,((ZombieBuilder.BasicZombie)ZombieBuilder.getInstance().builderMap.get(entityType)));
                break;
            case GIANT_ZOMBIE:
                entity=new GiantZombie(x,y,((ZombieBuilder.GiantZombie)ZombieBuilder.getInstance().builderMap.get(entityType)));
                break;
            case RANGED_ZOMBIE:
                entity=new RangedZombie(x,y,((ZombieBuilder.RangedZombie)ZombieBuilder.getInstance().builderMap.get(entityType)));
                break;
        }
        return entity;
    }

    public class HumanBuilder{
        public float health;
        public float damage;
        public float speed;
        public float regen=0;
        public float reduction=0;
        public int aware;
        public Array<WeaponCreator> weaponCreators;
        public Array<AbilityCreator> abilityUnlocks=new Array<>();
//        public CreatureComponent(Entity entity, EntityType entityType, float maxHp, float attRate, float damage, float speed, float regen, float reduction){

        public void set(float health, float damage, float speed, int aware, Array<WeaponCreator> weaponCreators){
            this.health=health;
            this.damage=damage;
            this.speed=speed;
            this.aware=aware;
            this.weaponCreators=weaponCreators;
        }
    }
}
