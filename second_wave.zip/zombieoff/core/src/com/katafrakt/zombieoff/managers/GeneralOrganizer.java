package com.katafrakt.zombieoff.managers;

import java.util.Random;

public class GeneralOrganizer {
    private static GeneralOrganizer initiance;
    public static GeneralOrganizer getInstance(){
        if (initiance==null)
            initiance=new GeneralOrganizer();
        return initiance;
    }
    public Random random;
    private GeneralOrganizer(){random=new Random();};

}
