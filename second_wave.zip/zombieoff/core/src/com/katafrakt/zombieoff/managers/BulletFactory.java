package com.katafrakt.zombieoff.managers;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.utils.Pool;
import com.katafrakt.zombieoff.ashley.components.creatures.BulletComponent;
import com.katafrakt.zombieoff.entities.BulletOwner;
import com.katafrakt.zombieoff.entities.bullets.Bullet;

public class BulletFactory {
    private static final String TAG=BulletFactory.class.getSimpleName();
    private static BulletFactory initiate;
    public static BulletFactory getInstance(){if (initiate==null)initiate=new BulletFactory();return initiate;}
    private BulletFactory(){ }
    TextureAtlas bulletAtlas=AssetOrganizer.getInstance().get("atlases/bullets.atlas",TextureAtlas.class);
    public static Pool<Bullet> pool= new Pool<Bullet>() {
        @Override
        protected Bullet newObject() {
            return new Bullet();
        }
    };

    int defaultBulletSize=4;
    public void createBullet(Bullet.Builder builder){
        Bullet bullet=pool.obtain();

        if (EngineEdited.initiate.getEntities().contains(bullet,false)){
            BulletComponent bc=bullet.getComponent(BulletComponent.class);
            Gdx.app.log(TAG,"progress: "+bc.progress);
            Gdx.app.log(TAG,"isDeath: "+bc.isDeath);
            Gdx.app.log(TAG,"deathTime: "+bc.deathTime);
        }
        if (builder.bulletOwner== BulletOwner.HUMAN_BULLET){
            switch (builder.bulletType){
                case LINE:
                    if (builder.damage<0.2f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_h_line_1"),defaultBulletSize);
                    else if (builder.damage<0.5f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_h_line_2"),defaultBulletSize);
                    else if (builder.damage<1.2f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_h_line_3"),defaultBulletSize);
                    else if (builder.damage<2.6f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_h_line_4"),defaultBulletSize);
                    else if (builder.damage<5f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_h_line_5"),defaultBulletSize);
                    else
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_h_line_6"),defaultBulletSize);

                    break;
                case AIRBORNE:
                    if (builder.damage<0.2f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_h_air_1"),defaultBulletSize);
                    else if (builder.damage<0.5f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_h_air_2"),defaultBulletSize);
                    else if (builder.damage<1.2f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_h_air_3"),defaultBulletSize);
                    else if (builder.damage<2.6f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_h_air_4"),defaultBulletSize);
                    else if (builder.damage<5f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_h_air_5"),defaultBulletSize);
                    else
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_h_air_6"),defaultBulletSize);

                    break;
                case UNDERGROUND:
                    if (builder.damage<0.2f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_h_under_1"),defaultBulletSize);
                    else if (builder.damage<0.5f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_h_under_2"),defaultBulletSize);
                    else if (builder.damage<1.2f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_h_under_3"),defaultBulletSize);
                    else if (builder.damage<2.6f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_h_under_4"),defaultBulletSize);
                    else if (builder.damage<5f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_h_under_5"),defaultBulletSize);
                    else
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_h_under_6"),defaultBulletSize);

                    break;
            }
        }
        else {
            switch (builder.bulletType){
                case LINE:
                    if (builder.damage<0.2f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_z_line_1"),defaultBulletSize);
                    else if (builder.damage<0.5f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_z_line_2"),defaultBulletSize);
                    else if (builder.damage<1.2f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_z_line_3"),defaultBulletSize);
                    else if (builder.damage<2.6f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_z_line_4"),defaultBulletSize);
                    else if (builder.damage<5f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_z_line_5"),defaultBulletSize);
                    else
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_z_line_6"),defaultBulletSize);

                    break;
                case AIRBORNE:
                    if (builder.damage<0.2f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_z_air_1"),defaultBulletSize);
                    else if (builder.damage<0.5f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_z_air_2"),defaultBulletSize);
                    else if (builder.damage<1.2f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_z_air_3"),defaultBulletSize);
                    else if (builder.damage<2.6f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_z_air_4"),defaultBulletSize);
                    else if (builder.damage<5f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_z_air_5"),defaultBulletSize);
                    else
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_z_air_6"),defaultBulletSize);

                    break;
                case UNDERGROUND:
                    if (builder.damage<0.2f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_z_under_1"),defaultBulletSize);
                    else if (builder.damage<0.5f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_z_under_2"),defaultBulletSize);
                    else if (builder.damage<1.2f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_z_under_3"),defaultBulletSize);
                    else if (builder.damage<2.6f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_z_under_4"),defaultBulletSize);
                    else if (builder.damage<5f)
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_z_under_5"),defaultBulletSize);
                    else
                        bullet.init(builder,bulletAtlas.findRegion("Bullet_z_under_6"),defaultBulletSize);
                    break;
            }
        }
        EngineEdited.initiate.addEntity(bullet);


    }
}
