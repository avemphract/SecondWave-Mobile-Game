package com.katafrakt.zombieoff.managers;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.katafrakt.zombieoff.Main;

import java.util.Stack;

public class ScreenManager {
    private static ScreenManager instance;

    private Stack<Screen> screens;
    Main main;
    ShapeRenderer shapeRenderer;

    private ScreenManager(){screens=new Stack<>();
    shapeRenderer=new ShapeRenderer();
    }

    public static ScreenManager getInstance(){
        if (instance==null)
            instance=new ScreenManager();
        return instance;
    }
    public void init(Main main){
        this.main=main;
    }

    public Screen peekScreen(){return screens.peek();}
    public void addScreen(Screen screen){
        screens.push(screen);
        //main.setScreen(screens.peek());
    }
    public void removeScreen(){
        screens.pop().dispose();
    }
    public void setScreens(){
        main.setScreen(screens.peek());
    }


}
