package com.katafrakt.zombieoff.managers;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.assets.loaders.resolvers.InternalFileHandleResolver;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGeneratorLoader;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.utils.Array;

public class AssetOrganizer {
    private final static String TAG=AssetOrganizer.class.getSimpleName();
    private static AssetOrganizer initiate;

    private static InternalFileHandleResolver fileHandleResolver=new InternalFileHandleResolver();
    public AssetManager assetManager=new AssetManager();
    Array<String> loadedAsset;

    public static AssetOrganizer getInstance(){
        if (initiate==null)
            initiate=new AssetOrganizer();
        return initiate;
    }
    private AssetOrganizer(){
        assetManager.setLoader(TiledMap.class, new TmxMapLoader(fileHandleResolver));
        assetManager.setLoader(FreeTypeFontGenerator.class,new FreeTypeFontGeneratorLoader(fileHandleResolver));
    }

    public void unloadAsset(String assetFileNamePath){
        if (assetManager.isLoaded(assetFileNamePath))
            assetManager.unload(assetFileNamePath);
        else
            Gdx.app.log(TAG,"Asset is not loaded");
    }

    public <T extends Object> void load(String assetFileNamePath, Class<T> type){
        if (fileHandleResolver.resolve(assetFileNamePath).exists()){
            assetManager.load(assetFileNamePath,type);
        }
        else {
            Gdx.app.log(TAG,type.getSimpleName()+" + "+assetFileNamePath+" does not exist");
        }

    }

    public <T extends Object> T get(String assetFileNamePath,Class<T> type){
        if (assetManager.isLoaded(assetFileNamePath,type)){
            return assetManager.get(assetFileNamePath,type);
        }
        else {
            Gdx.app.log(TAG,type.getSimpleName()+" + "+assetFileNamePath+" does not loaded");
            return null;
        }
    }
}
