package com.katafrakt.zombieoff.managers;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.utils.Array;
import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.game.abilitiybehaviours.abilitylimit.OneTime;
import com.katafrakt.zombieoff.ui.desicions.ChangeInterface;
import com.katafrakt.zombieoff.utilities.Pair;


public class PreferenceManager {
    private static PreferenceManager instance;
    public static PreferenceManager getInstance(){if (instance==null) instance=new PreferenceManager();return instance;}
    public Preferences prefs= Gdx.app.getPreferences("pref_1");

    //Options
    public static final String LANGUAGE_SELECTED_KEY="LanguageSelectedKey";

    public static final String FLOATING_TEXT_CHECK_KEY="FloatingTextCheckKey";
    public static final String PARTICLE_EFFECT_CHECK_KEY="ParticleEffectCheckKey";

    public static final String AUDIO_IS_ACTIVE="AudioIsActive";
    public static final String MUSIC_VOLUME_KEY="MusicVolumeKey";
    public static final String SOUND_VOLUME_KEY="SoundVolumeKey";

    public void exitSave(){

    }



    private PreferenceManager(){};

    public Language currentLanguage;
    public int currentLevel=4;


    public Event<Language> language= new Event<Language>(Language.getLanguage(prefs.getString(LANGUAGE_SELECTED_KEY))) {
        @Override
        public void change() {
            currentLanguage=variable;
            prefs.putString(LANGUAGE_SELECTED_KEY,variable.getStringValue());
            prefs.flush();
        }
    };

    public Event<Boolean> floatingText= new Event<Boolean>(prefs.getBoolean(FLOATING_TEXT_CHECK_KEY)) {
        @Override
        public void change() {
            if (EngineEdited.initiate!=null)
                EngineEdited.initiate.isEnabledFloatingText=variable;
            prefs.putBoolean(FLOATING_TEXT_CHECK_KEY,variable);
            prefs.flush();
        }
    };
    public Event<Boolean> particleText= new Event<Boolean>(prefs.getBoolean(PARTICLE_EFFECT_CHECK_KEY)){
        public void change(){
            if (EngineEdited.initiate!=null)
                EngineEdited.initiate.isEnabledParticleEffect=variable;
            prefs.putBoolean(PARTICLE_EFFECT_CHECK_KEY,variable);
            prefs.flush();
        }
    };

    public Event<Boolean> audioIsActive= new Event<Boolean>(prefs.getBoolean(AUDIO_IS_ACTIVE)) {
        @Override
        public void change() {
            prefs.putBoolean(AUDIO_IS_ACTIVE,variable);
            prefs.flush();
        }
    };
    public Event<Float> musicVolumeKey= new Event<Float>(prefs.getFloat(MUSIC_VOLUME_KEY)) {
        @Override
        public void change() {
            prefs.putFloat(MUSIC_VOLUME_KEY,variable);
            prefs.flush();
        }
    };
    public Event<Float> soundVolumeKey= new Event<Float>(prefs.getFloat(SOUND_VOLUME_KEY)) {
        @Override
        public void change() {
            prefs.putFloat(SOUND_VOLUME_KEY,variable);
            prefs.flush();
        }
    };



    public static abstract class Event<T>{
        public Array<ChangeInterface> listeners=new Array<>();
        public T variable;

        public Event(T variable) {
            this.variable = variable;
        }

        public void set(T variable){
            this.variable=variable;
            change();
            for (ChangeInterface listener:listeners)
                listener.change();
        }

        public void addListener( ChangeInterface changeInterface){
            listeners.add(changeInterface);
        }

       public abstract void change();

    }

    public enum Language implements Translator {
        TURKCE,
        ENGLISH;
        public String getStringValue(){
            return this.name();
        }



        public static Language getLanguage(String text){
            for (Language language :values()){
                if (language.toString().equals(text))
                    return language;
            }
            return null;
        }
    }
    public interface Translator{
        public String getStringValue();
    }
}
