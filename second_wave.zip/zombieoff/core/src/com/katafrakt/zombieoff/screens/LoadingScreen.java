package com.katafrakt.zombieoff.screens;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.assets.loaders.SkinLoader;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.utils.NinePatchDrawable;
import com.badlogic.gdx.utils.viewport.FillViewport;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.katafrakt.zombieoff.Main;
import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.managers.AssetOrganizer;
import com.katafrakt.zombieoff.managers.PreferenceManager;
import com.katafrakt.zombieoff.managers.ScreenManager;
import com.sun.org.apache.xpath.internal.operations.Or;

import static com.katafrakt.zombieoff.managers.PreferenceManager.*;

public class LoadingScreen implements Screen {
    private static final String TAG=LoadingScreen.class.getSimpleName();

    Main main;
    SpriteBatch spriteBatch;


    ShapeRenderer shapeRenderer;
    float progress;

    public LoadingScreen(Main main, SpriteBatch spriteBatch){
        this.main=main;
        this.spriteBatch=spriteBatch;
        shapeRenderer=new ShapeRenderer();

    }

    @Override
    public void show() {
        loadAssets();
    }

    private void scale(Button.ButtonStyle buttonStyle){
        ((NinePatchDrawable)buttonStyle.up).getPatch().scale(2,2);
        ((NinePatchDrawable)buttonStyle.down).getPatch().scale(2,2);
        ((NinePatchDrawable)buttonStyle.over).getPatch().scale(2,2);
        ((NinePatchDrawable)buttonStyle.checked).getPatch().scale(2,2);
    }
    @Override
    public void render(float delta) {
        if (!AssetOrganizer.getInstance().assetManager.update()){
            progress= MathUtils.lerp(progress,AssetOrganizer.getInstance().assetManager.getProgress(),0.8f);
        }else {
            /*
            ScreenManager.getInstance().removeScreen();
            ScreenManager.getInstance().addScreen(new MainMenuScreen(main,spriteBatch));
            ScreenManager.getInstance().setScreens();

             */

            AssetOrganizer.getInstance().get("skin/custom_skin.json",Skin.class).setScale(2);
            scale(AssetOrganizer.getInstance().get("skin/custom_skin.json",Skin.class).get("toggle_left",Button.ButtonStyle.class));
            scale(AssetOrganizer.getInstance().get("skin/custom_skin.json",Skin.class).get("toggle_right",Button.ButtonStyle.class));
            scale(AssetOrganizer.getInstance().get("skin/custom_skin.json",Skin.class).get("toggle_mid",Button.ButtonStyle.class));
            scale(AssetOrganizer.getInstance().get("skin/custom_skin.json",Skin.class).get(Button.ButtonStyle.class));

            ScreenManager.getInstance().removeScreen();
            ScreenManager.getInstance().addScreen(new MainMenuScreen(main,spriteBatch));
            ScreenManager.getInstance().setScreens();
            return;
        }


        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(Color.BLACK);
        shapeRenderer.rect(Main.WIDTH/4-5,Main.HEIGHT/3-5,Main.WIDTH/2+10,Main.HEIGHT/20+10);

        shapeRenderer.setColor(Color.BLUE);
        shapeRenderer.rect(Main.WIDTH/4,Main.HEIGHT/3,Main.WIDTH/2*progress,Main.HEIGHT/20);
        shapeRenderer.end();


        spriteBatch.begin();
        main.bitmapFont.draw(spriteBatch,TAG,20,40);
        spriteBatch.end();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
    private void loadAssets(){

        AssetOrganizer.getInstance().load("atlases/colors.atlas", TextureAtlas.class);
        AssetOrganizer.getInstance().load("atlases/hpbar.atlas",TextureAtlas.class);
        AssetOrganizer.getInstance().load("atlases/category.atlas",TextureAtlas.class);
        AssetOrganizer.getInstance().load("atlases/resource_types.atlas",TextureAtlas.class);
        AssetOrganizer.getInstance().load("atlases/zombies.atlas",TextureAtlas.class);
        AssetOrganizer.getInstance().load("atlases/symbols.atlas",TextureAtlas.class);
        AssetOrganizer.getInstance().load("atlases/buttonpatch.atlas",TextureAtlas.class);
        AssetOrganizer.getInstance().load("atlases/externaldrawable.atlas",TextureAtlas.class);

        AssetOrganizer.getInstance().load("atlases/entities/basic_zombie.atlas",TextureAtlas.class);
        AssetOrganizer.getInstance().load("atlases/entities/giant_zombie.atlas",TextureAtlas.class);
        /*AssetOrganizer.getInstance().load("atlases/entities/civilian_walk.atlas",TextureAtlas.class);
        AssetOrganizer.getInstance().load("atlases/entities/civilian_wait.atlas",TextureAtlas.class);
        AssetOrganizer.getInstance().load("atlases/entities/civilian_attack.atlas",TextureAtlas.class);*/
        AssetOrganizer.getInstance().load("atlases/bullets.atlas",TextureAtlas.class);

        /*AssetOrganizer.getInstance().load("atlases/entities/civ_wait.atlas",TextureAtlas.class);
        AssetOrganizer.getInstance().load("atlases/entities/civ_walk.atlas",TextureAtlas.class);*/
        AssetOrganizer.getInstance().load("atlases/entities/hciv.atlas",TextureAtlas.class);
        AssetOrganizer.getInstance().load("atlases/entities/hpol.atlas",TextureAtlas.class);
        AssetOrganizer.getInstance().load("atlases/entities/hvet.atlas",TextureAtlas.class);
        AssetOrganizer.getInstance().load("atlases/entities/zcom.atlas",TextureAtlas.class);
        AssetOrganizer.getInstance().load("atlases/entities/zbsc.atlas",TextureAtlas.class);
        AssetOrganizer.getInstance().load("atlases/entities/zgnt.atlas",TextureAtlas.class);
        AssetOrganizer.getInstance().load("atlases/human_ranged_weapons.atlas",TextureAtlas.class);
        AssetOrganizer.getInstance().load("atlases/hands.atlas",TextureAtlas.class);

        AssetOrganizer.getInstance().load("entityframe.png", Texture.class);
        AssetOrganizer.getInstance().load("ninepatch.png",Texture.class);

        AssetOrganizer.getInstance().load("skin/uiskin.atlas",TextureAtlas.class);
        AssetOrganizer.getInstance().assetManager.load("skin/uiskin.json", Skin.class,new SkinLoader.SkinParameter("skin/uiskin.atlas"));

        AssetOrganizer.getInstance().load("skin/custom_skin.atlas",TextureAtlas.class);
        AssetOrganizer.getInstance().assetManager.load("skin/custom_skin.json",Skin.class,new SkinLoader.SkinParameter("skin/custom_skin.atlas"));

        AssetOrganizer.getInstance().load("skin/vcr_font_generator.ttf", FreeTypeFontGenerator.class);
        AssetOrganizer.getInstance().load("skin/title.fnt", BitmapFont.class);

    }
}
