package com.katafrakt.zombieoff.screens;

import com.badlogic.ashley.core.PooledEngine;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.utils.viewport.ExtendViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.katafrakt.zombieoff.Main;
import com.katafrakt.zombieoff.entities.EntityType;
import com.katafrakt.zombieoff.game.ResourceType;
import com.katafrakt.zombieoff.managers.AssetOrganizer;
import com.katafrakt.zombieoff.managers.EngineEdited;
import com.katafrakt.zombieoff.managers.EntityFactory;
import com.katafrakt.zombieoff.managers.MapManager;
import com.katafrakt.zombieoff.managers.PreferenceManager;
import com.katafrakt.zombieoff.ui.CameraComposite;
import com.katafrakt.zombieoff.ui.PlayerHud;

public class GameScreen implements Screen {
    private final static String TAG=GameScreen.class.getSimpleName();
    Main main;

    int level;

    float viewportX,viewportY;

    CameraComposite cameraComposite;
    PlayerHud playerHud;

    PooledEngine engine;
    Viewport viewport;
    SpriteBatch spriteBatch;
    ShapeRenderer shapeRenderer;

    InputMultiplexer inputMultiplexer;


    public GameScreen(Main main, SpriteBatch spriteBatch,int level){
        this.main=main;
        this.spriteBatch=spriteBatch;
        this.level=level;

        viewportX=16;viewportY=9;

        shapeRenderer=new ShapeRenderer();
    }
    @Override
    public void show() {
        AssetOrganizer.getInstance().load(MapManager.mapTable.get(level), TiledMap.class);
        AssetOrganizer.getInstance().assetManager.finishLoading();

        Gdx.app.log(TAG,"Level: "+level+" loading");

        cameraComposite=new CameraComposite(new OrthographicCamera());
        viewport=new ExtendViewport(viewportX,viewportY,cameraComposite.getCamera());
        viewport.apply(false);
        cameraComposite.setInitialPosition(viewportX,viewportY);

        Gdx.app.log(TAG,"Map start");
        MapManager.getInstance().loadMap(level);
        engine=new EngineEdited(cameraComposite,main,shapeRenderer,spriteBatch,main.bitmapFont);
        MapManager.getInstance().setEntities(engine);

        playerHud=new PlayerHud(cameraComposite.getCamera());
        playerHud.stage.setDebugAll(false);

        inputMultiplexer=new InputMultiplexer(playerHud.stage,playerHud,cameraComposite);
        Gdx.input.setInputProcessor(inputMultiplexer);


        for (int i=0;i<1000;i++){
            //engine.addEntity(EntityFactory.getInstance().createHuman(EntityType.CIVILIAN,200,200));
            engine.addEntity(EntityFactory.getInstance().createEntity(EntityType.BASIC_ZOMBIE,MapManager.getInstance().mapPixelWidth-50,MapManager.getInstance().mapPixelHeight-100));
        }


    }

    float time;
    int count;
    @Override
    public void render(float delta) {
        time+=delta;
        //if (count<time)
        //Gdx.app.log(TAG,"Fps: "+Gdx.graphics.getFramesPerSecond());
        viewport.apply();
        spriteBatch.setProjectionMatrix(cameraComposite.getCamera().projection);
        //shapeRenderer.setProjectionMatrix(cameraComposite.getCamera().combined);
        engine.update(delta);
        playerHud.render(delta);

        if (count<time)
            count++;
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width,height);
        playerHud.resize(width,height);
        cameraComposite.resize(width,height);
        cameraComposite.getCamera().viewportWidth=width;
        cameraComposite.getCamera().viewportHeight=height;
        cameraComposite.getCamera().update();
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        AssetOrganizer.getInstance().unloadAsset(MapManager.mapTable.get(level));
        ResourceType.getInstance().dispose();
        PreferenceManager.getInstance().prefs.clear();
        PreferenceManager.getInstance().prefs.flush();
    }
}
