package com.katafrakt.zombieoff.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Event;
import com.badlogic.gdx.scenes.scene2d.EventListener;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.Touchable;
import com.badlogic.gdx.scenes.scene2d.ui.CheckBox;
import com.badlogic.gdx.scenes.scene2d.ui.Container;
import com.badlogic.gdx.scenes.scene2d.ui.Dialog;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.ui.SelectBox;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Slider;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.viewport.FillViewport;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.katafrakt.zombieoff.Main;
import com.katafrakt.zombieoff.managers.AssetOrganizer;
import com.katafrakt.zombieoff.managers.PreferenceManager;
import com.katafrakt.zombieoff.managers.ScreenManager;

public class MainMenuScreen implements Screen {
    private static final String TAG = MainMenuScreen.class.getSimpleName();
    Main main;
    SpriteBatch spriteBatch;
    Stage stage;
    Skin skin;

    FillViewport fillViewport;
    Container<Table> mainContainer;

    Table mainMenu;
        Label textMain;
        TextButton continueButton;
        TextButton levelButton;
        TextButton optionButton;
        TextButton exitButton;


    Table levelMenu;
        Label levelText;
        Table scrollTable;
        TextButton levelToMenu;
        ScrollPane scrollPane;
        Array<TextButton> levelButtons=new Array<>();

    Table optionsMenu;
        Label optionLabel;

        Table optionsContain;
            Label language;
            SelectBox<PreferenceManager.Language> xxx;

            Label soundLabel;
            Slider sound;

            Label musicLabel;
            Slider music;

            Label audioLabel;
            CheckBox audio;

            Label floatingLabel;
            CheckBox floating;

            Label particleLabel;
            CheckBox particle;

            Label hardReset;
            TextButton hardResetButton;

        TextButton optionToMain;


    public MainMenuScreen(Main main, SpriteBatch spriteBatch){
        this.main=main;
        this.spriteBatch=spriteBatch;
        fillViewport=new FillViewport(Main.WIDTH,Main.HEIGHT);
        mainContainer=new Container<>();
        mainContainer.setWidth(Main.WIDTH);
        mainContainer.setHeight(Main.HEIGHT);
        //Gdx.app.log(TAG,"Screen: "+screenViewport.getScreenWidth()+","+screenViewport.getScreenHeight());
    }

    @Override
    public void show() {
        stage = new Stage(fillViewport);

        while (!AssetOrganizer.getInstance().assetManager.update()){
            float progress=AssetOrganizer.getInstance().assetManager.getProgress();
            Gdx.app.log(TAG,"Loading...."+progress);
        }

        skin=AssetOrganizer.getInstance().assetManager.get("skin/uiskin.json",Skin.class);
        //mainTable.setFillParent(true);
        //mainTable.setPosition(0,0);

        //mainMenu
        {
            mainMenu=new Table();
                textMain=new Label("Second Wave",skin);
                textMain.setFontScale(4);
            mainMenu.add(textMain).padBottom(100);
            mainMenu.row();

                continueButton=new TextButton("Continue",skin);
                continueButton.getLabel().setFontScale(2);
                continueButton.getLabelCell().pad(10,20,10,20);
            mainMenu.add(continueButton).expandX().padBottom(10);
            mainMenu.row();

                levelButton=new TextButton("Level Select",skin);
                levelButton.getLabel().setFontScale(2);
                levelButton.getLabelCell().pad(10,20,10,20);
            mainMenu.add(levelButton).padBottom(10);
            mainMenu.row();

                optionButton=new TextButton("Options",skin);
                optionButton.getLabel().setFontScale(2);
                optionButton.getLabelCell().pad(10,20,10,20);
            mainMenu.add(optionButton).padBottom(10);
            mainMenu.row();

                exitButton=new TextButton("Exit",skin);
                exitButton.getLabel().setFontScale(2);
                exitButton.getLabelCell().pad(10,20,10,20);
            mainMenu.add(exitButton).padBottom(100);


            continueButton.addListener(new ClickListener(){
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    super.clicked(event, x, y);
                    ScreenManager.getInstance().removeScreen();
                    ScreenManager.getInstance().addScreen(new GameScreen(main,spriteBatch, PreferenceManager.getInstance().currentLevel));
                    ScreenManager.getInstance().setScreens();
                }
            });

            levelButton.addListener(new ClickListener(){
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    super.clicked(event, x, y);
                    mainContainer.setActor(levelMenu);
                }
            });

            optionButton.addListener(new ClickListener(){
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    super.clicked(event, x, y);
                    mainContainer.setActor(optionsMenu);
                }
            });

            exitButton.addListener(new ClickListener(){
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    super.clicked(event, x, y);


                    Dialog dialog = new Dialog("Exit", skin, "dialog") {
                        public void result(Object obj) {
                            if ((Boolean) obj==true){
                                Gdx.app.exit();
                            }
                        }

                    };
                    dialog.getTitleLabel().setFontScale(1.5f);

                        Label diaText=new Label("Are you sure you want to quit?",skin);
                        diaText.setFontScale(2f);
                    dialog.text(diaText);
                    dialog.button("Yes", true); //sends "true" as the result
                    dialog.button("No", false);  //sends "false" as the result



                    dialog.getTitleTable().pad(5,5,5,5).align(Align.center);
                    dialog.getTitleTable().getCell(dialog.getTitleLabel()).fill();
                    for (Actor button:dialog.getButtonTable().getChildren()){
                        ((TextButton)button).getLabel().setFontScale(2);
                        button.setSize(48,30);
                    }

                    dialog.show(stage);
                    dialog.setResizable(false);
                    dialog.setMovable(false);
                }
            });
        }

        //Level Select
        {
            levelMenu=new Table();

            levelMenu.add().size(196,0);

                levelText=new Label("Levels",skin);
                levelText.setFontScale(4);
            levelMenu.add(levelText).expandX();
            levelMenu.add().size(196,0);
            levelMenu.row();


                levelToMenu =new TextButton("Back",skin);
                levelToMenu.getLabel().setFontScale(3);
                levelToMenu.getLabelCell().pad(10,20,10,20);
            //levelMenu.add();
            levelMenu.add(levelToMenu).align(Align.bottomLeft).pad(0,20,20,0);

                scrollTable=new Table();
                scrollPane=new ScrollPane(scrollTable);
            int rows=0;
            for (int i=1;i<51;i++){
                TextButton button=new TextButton(i+"",skin);
                button.getLabel().setFontScale(2);
                scrollTable.add(button).size(48,48).pad(16,8,16,8);
                if (rows<i/5){
                    rows++;
                    scrollTable.row();
                }
                levelButtons.add(button);
                if (PreferenceManager.getInstance().currentLevel<i)
                    button.setTouchable(Touchable.disabled);
                else
                    button.setChecked(true);

                final int finalI = i;
                button.addListener(new ClickListener(){
                    @Override
                    public void clicked(InputEvent event, float x, float y) {
                        super.clicked(event, x, y);
                        ScreenManager.getInstance().removeScreen();
                        ScreenManager.getInstance().addScreen(new GameScreen(main,spriteBatch, finalI));
                        ScreenManager.getInstance().setScreens();

                    }
                });

            }
            levelMenu.add(scrollPane);

            levelToMenu.addListener(new ClickListener(){
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    super.clicked(event, x, y);
                    mainContainer.setActor(mainMenu);
                }
            });
        }

        //Options
        {
            optionsMenu=new Table();

            optionsMenu.add().size(196,0);

                optionLabel=new Label("Options",skin);
                optionLabel.setFontScale(4);
            optionsMenu.add(optionLabel).expandX();
            optionsMenu.add().size(196,0);
            optionsMenu.row();

                optionToMain=new TextButton("Back",skin);
                optionToMain.getLabel().setFontScale(3);
                optionToMain.getLabelCell().pad(5,10,5,10);
            optionsMenu.add(optionToMain).align(Align.bottomLeft).pad(0,20,20,0).expandY();


            //Language begins

                optionsContain=new Table(skin);
                    language=new Label("Language:",skin);
                    language.setFontScale(2);
                optionsContain.add(language).align(Align.left).expandX();
                    xxx=new SelectBox<PreferenceManager.Language>(skin);
                    xxx.getStyle().listStyle.font.getData().setScale(2);
                    xxx.setItems(PreferenceManager.Language.values());
                    xxx.addListener(new ChangeListener() {
                        @Override
                        public void changed(ChangeEvent event, Actor actor) {
                            PreferenceManager.getInstance().language.set(xxx.getSelected());
                        }
                    });
                    xxx.setSelected(PreferenceManager.getInstance().language.variable);
                optionsContain.add(xxx).expandX();
            //Language end

            //Sound begin
                optionsContain.row().padTop(20);
                    soundLabel=new Label("Sound:",skin);
                    soundLabel.setFontScale(2);
                optionsContain.add(soundLabel).align(Align.left);
                    sound=new Slider(0,1,0.1f,false,skin);
                    sound.setVisualPercent(PreferenceManager.getInstance().soundVolumeKey.variable);
                    sound.addListener(new ChangeListener() {
                        @Override
                        public void changed(ChangeEvent event, Actor actor) {
                            PreferenceManager.getInstance().soundVolumeKey.set(sound.getValue());
                        }
                    });
                optionsContain.add(sound);
            //Sound end


            //Music begin
                optionsContain.row().padTop(20);
                    musicLabel=new Label("Music:",skin);
                    musicLabel.setFontScale(2);
                optionsContain.add(musicLabel).align(Align.left);
                    music=new Slider(0,1,0.1f,false,skin);
                    music.setVisualPercent(PreferenceManager.getInstance().musicVolumeKey.variable);
                    music.addListener(new ChangeListener(){
                        @Override
                        public void changed(ChangeEvent event, Actor actor) {
                            PreferenceManager.getInstance().musicVolumeKey.set(music.getValue());
                        }
                    });
                optionsContain.add(music);
            //Music end

            //Audio begin
                optionsContain.row().padTop(20);
                    audioLabel=new Label("Mute audio:",skin);
                    audioLabel.setFontScale(2);
                optionsContain.add(audioLabel).align(Align.left);
                    audio=new CheckBox("",skin);
                    audio.setChecked(PreferenceManager.getInstance().audioIsActive.variable);
                    audio.addListener(new ChangeListener() {
                        @Override
                        public void changed(ChangeEvent event, Actor actor) {
                            PreferenceManager.getInstance().audioIsActive.set(audio.isChecked());
                        }
                    });
                optionsContain.add(audio);
            //Audio end

            //FloatingText begin
            optionsContain.row().padTop(20);
                floatingLabel=new Label("Floating texts",skin);
                floatingLabel.setFontScale(2);
            optionsContain.add(floatingLabel).align(Align.left);
                floating=new CheckBox("",skin);
                floating.setChecked(PreferenceManager.getInstance().floatingText.variable);
                floating.addListener(new ChangeListener() {
                    @Override
                    public void changed(ChangeEvent event, Actor actor) {
                        PreferenceManager.getInstance().floatingText.set(floating.isChecked());
                    }
                });
            optionsContain.add(floating);
            //FloatingText end

            //ParticleEffect begin
            optionsContain.row().padTop(20);
                particleLabel=new Label("Particle effects",skin);
                particleLabel.setFontScale(2);
            optionsContain.add(particleLabel).align(Align.left);
                particle=new CheckBox("",skin);
                particle.setChecked(PreferenceManager.getInstance().particleText.variable);
                particle.addListener(new ChangeListener() {
                    @Override
                    public void changed(ChangeEvent event, Actor actor) {
                        PreferenceManager.getInstance().particleText.set(particle.isChecked());
                    }
                });
            optionsContain.add(particle);
            //ParticleEffect end

            //HardReset begin
                optionsContain.row().padTop(20);
                    hardReset=new Label("Hard Reset:",skin);
                    hardReset.setFontScale(2);
                optionsContain.add(hardReset).align(Align.left);
                    hardResetButton=new TextButton("X",skin);
                    hardResetButton.getLabel().setFontScale(2);
                    hardResetButton.addListener(new ClickListener(){
                        @Override
                        public void clicked(InputEvent event, float x, float y) {
                            super.clicked(event, x, y);

                            Dialog dialog = new Dialog("Warning", skin, "dialog") {
                                public void result(Object obj) {
                                    System.out.println("result "+obj);
                                }
                            };
                            dialog.text("This action cannot be undone");
                            dialog.button("HardReset", true); //sends "true" as the result
                            dialog.button("Cancel", false);  //sends "false" as the result
                            dialog.show(stage);
                        }
            });
                optionsContain.add(hardResetButton);
            optionsMenu.add(optionsContain).fill();
            optionToMain.addListener(new ClickListener(){
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    super.clicked(event, x, y);
                    mainContainer.setActor(mainMenu);
                }
            });


        }

        mainContainer.setActor(mainMenu);
        mainContainer.fill();

        stage.addActor(mainContainer);
        stage.setDebugAll(false);
        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void render(float delta) {
        stage.act(delta);
        stage.draw();

        spriteBatch.begin();
        main.bitmapFont.draw(spriteBatch,TAG,20,40);
        spriteBatch.end();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width,height);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        stage.dispose();
    }
}
