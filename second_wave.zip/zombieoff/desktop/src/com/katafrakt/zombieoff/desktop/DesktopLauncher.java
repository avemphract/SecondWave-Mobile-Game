package com.katafrakt.zombieoff.desktop;

import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.katafrakt.zombieoff.Main;

public class DesktopLauncher {
	public static void main (String[] arg) {
		LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
		//config.vSyncEnabled=false;
		//config.backgroundFPS=999;
		//config.foregroundFPS=999;

		config.width=16*85;
		config.height=9*85;
		new LwjglApplication(new Main(), config);
	}
}
